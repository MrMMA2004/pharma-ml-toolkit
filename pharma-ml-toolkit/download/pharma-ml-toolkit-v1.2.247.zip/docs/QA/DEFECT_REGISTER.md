# DEFECT REGISTER — part14 §13.2

The part14-era defect register, seeded from the Phase-1 audit
(`PART14_PHASE1_AUDIT.md` — the D-1…D-5 opening rows) and maintained
per round. Every row names its evidence; a fix without evidence is not
a fix. Severity per part14 §3.1's impact classes.

| ID | Severity | Title | Status | Fixed (round) | Evidence |
| --- | --- | --- | --- | --- | --- |
| D-1 | Critical | `LOOPBACK_HOSTS` lacked `tauri.localhost` — every packaged-app REST request 403-rejected even with a valid token (dev worked via the loopback Vite origin; production WebView2 origin differs) | **FIXED** | 327 | `src/pharmaml/api/security.py` `TRUSTED_APP_ORIGINS` (scheme-strict, host-exact: `http(s)://tauri.localhost`, no port); regression `tests/api/test_trusted_origins.py` (P1/P2 legs 403→200; lookalikes/subdomains/ports stay 403); probe re-run `scratch/p14_r327_origin_probe_postfix.txt` |
| D-2 | Critical | No CORS lane — OPTIONS preflight answered 405 from ANY origin, so the browser blocked the actual request and `fetch` rejected (dev survived only via the Vite same-origin proxy) | **FIXED** | 327 | `src/pharmaml/api/__init__.py` `create_app()` — scoped `CORSMiddleware` (anchored regex: the two Tauri origins + loopback-any-port; exact-origin echo; `allow_credentials=False`; token headers allowlisted); preflight 405→200 for trusted origins (P3/P4), NO ACAO for arbitrary/lookalike origins, the 401/403 auth lanes unchanged (the lane never authenticates) |
| D-3 | High | `startup.ts` wrapped every health-probe failure as "the backend health probe failed" → the gate rendered "The backend did not start / stage: health / Failed to fetch" — mislabeling CORS/403 chains as startup crashes (§3.1 item 12) | **FIXED** | 327 | `frontend/src/services/api/startup.ts` `StartupFailureCause` (auth/network/http/protocol/handshake) + `classifyHealthFailure`; `StartupGate.tsx` cause-aware headline; 9-test suite `frontend/src/services/api/__tests__/startup.test.ts` (vitest 119/119 incl. the 6 gate tests; tsc clean) |
| D-4 | Medium | Rust handshake parse-failure path formatted the RAW `PHARMAML-READY` line (session token inside) into the error surface — a §3.3 redaction violation if reached by a log/UI message | **FIXED (source; compile-blocked)** | 327 | `src-tauri/src/backend_manager.rs` `redacted_parse_failure()` — the raw line NEVER appears (serde error + byte length only); `#[cfg(test)]` redaction test written; **no Rust toolchain in this sandbox — `cargo test` BLOCKED, rides the first cargo-enabled environment** (never marked passed) |
| D-5 | Medium | No handshake field validation in the Rust host (port bounds, pid sanity, token presence/format, version shape — §3.3's list unenforced) | **FIXED (source; compile-blocked)** | 327 | `src-tauri/src/backend_manager.rs` `validate_handshake()` (port ≠ 0; token 16..=128 bytes urlsafe-alphabet; pid ≠ 0; version short numeric-semver) with redacted rejection reasons; 10 `#[cfg(test)]` cases written; **compile/run BLOCKED as D-4** |
| D-6 | Low (candidate) → Medium (part15) | The WS handshake (`routes/events.py`) enforced the session token (close 4401) but not the Origin header — the trusted-origin policy guarded REST only; with a token leaked through a future XSS or a hostile browser extension, an evil page could have subscribed to the full event stream (job progress, dataset names, result payloads) cross-origin to `127.0.0.1` | **FIXED** | 339 | `src/pharmaml/api/routes/events.py` — the pre-accept handshake guard (a present Origin/Referer held to the exact REST-lane policy via `security.origin_is_trusted`, untrusted → close 4403 BEFORE accept, valid token included; absent Origin = the non-browser lane, unchanged); `security.py` exported `origin_is_trusted` (the REST predicate, zero policy change); regression `tests/api/test_ws_origin.py` (12 tests: 5 acceptance lanes — packaged http/https, loopback dev any-port, absent-Origin non-browser; 7 refusal lanes — evil origin WITH a valid token, no-token, lookalike subdomain/suffix, port-bearing trusted host, Referer dodge, `file://` scheme), FAIL-FIRST witnessed (6 red pre-fix, 12/12 post); unchanged lanes re-pinned (the full `tests/api` suite exit 0, ruff + mypy clean, vitest 119/119, tsc clean) |
| D-7 | Medium | The ledger-agreement guard's entry regex was ordinal-suffix-blind — `\*\*R(\d+) — the (\d+)th recorded run` matched only `-th` ordinals, so the R339 entry ("the 131**st** recorded run") was silently DROPPED and the guard compared the stale R338 against the counter (every 1st/2nd/3rd-ending run number — 131st, 132nd, 133rd, 141st… — would be skipped the same way, letting a stale ledger pair masquerade as agreement) | **FIXED** | 340 | `tests/test_documentation_consistency.py` `TestLedgerAgreement` — the failing guard WAS the reproduction (worklog newest R338 vs counter round 339); minimal fix: the ordinal suffix alternation `(\d+)(?:st\|nd\|rd\|th)`; post-fix the suite **13/13 green** with R339 correctly the newest entry (round 339 / run 131 agreeing with the counter); found during the r340 rollback recovery's gate re-pin |
| D-8 | Medium | The WS client treated every close as a transient drop — after r339's D-6 backend guard added the pre-accept policy closes, a 4403 (untrusted Origin) or 4401 (refused token) close ran the client's full reconnect ladder: maxReconnectAttempts futile dials (the browser's Origin and the same memory-only token cannot change between attempts, so every retry re-met the refusal — a guaranteed reconnect storm), then a silent terminal `closed` with no surfaced cause (the operator had no way to know the origin policy refused the stream) | **FIXED** | 341 | `frontend/src/services/websocket/client.ts` — `onclose` reads the close code; `POLICY_CLOSE_REASONS` maps 4401/4403 to terminal with the named cause surfaced on `status.terminalReason` (null everywhere else; an explicit `connect()` clears the stale reason — an operator retry, never an automatic storm); the wire-contract doc extended. The surfacing: `StartupGate.tsx` `ConnectionBanner` names the terminal cause beside the REST-fallback notice. Regression: 6 fail-first vitest legs in `client.test.ts` (the 4403/4401 handshake refusals terminal with zero retries after 200 ms of fake-timer sweep; the mid-stream 4403; the explicit-reconnect reason clearing; the user-close cause-free pin; the token+cursor retry-URL pin — 6 red witnessed against the un-edited client) + the banner test in `StartupGate.test.tsx` + the Python drift guard `test_ws_client_treats_policy_close_codes_as_terminal` (the 4401/4403 pair pinned on BOTH sides of the wire); vitest **126/126** post (was 119) |
| D-9 | Medium (P2) — a red CI lane on main | `tests/test_docking_prep.py::TestLigandStructureGeneration::test_mol2_graceful_without_openbabel` (line 1109) asserted `"OpenBabel" in error` while the backend's valid skip message uses the tool's official spelling "Open Babel" (`src/pharmaml/docking/ligands.py:932`) — the assertion was whitespace-strict, so the CI "Chemistry and docking preparation" lane failed at main HEAD bd53f7b3 (run 46016289515: 1 failed, 498 passed), exactly part20's Known-Finding A | **FIXED** | 370 | part20 §"Known Findings A" prescribed the minimal fix: the assertion now accepts either spelling (`"Open Babel" in error_text or "OpenBabel" in error_text`) — the semantic check (the skip reason names the missing optional dependency) is preserved, the backend message untouched. Regression: the full `tests/test_docking_prep.py` **84 passed** + the whole CI lane's test set re-run locally **499 passed, exit 0** (tests/test_descriptors + docking_prep + engine_discovery_part5 + campaign x5 + docking + docking_contacts + pose_rmsd); the remote lane turns green on the r370 push |
| D-10 | Low (P3) — version-carrier inconsistency | `src-tauri/Cargo.toml` still declared `version = "1.2.229"` while every other carrier (VERSION, pyproject.toml, tauri.conf.json — the one that actually drives the installer version) shipped 1.2.243; the crate version had drifted unnoticed across the r229→r243 releases (part20 §7.1 "version metadata consistent across all application components") | **FIXED** | 370 | metadata-only alignment in Cargo.toml (no committed Cargo.lock exists — generated on the runner); no code logic touched; all four carriers now read 1.2.243; the change compiles trivially on the next `cargo tauri build` (the release workflow regenerates the lock) |
| D-11 | Medium (P2) — orphaned sidecar on host crash | The Rust host terminates the backend child only on `RunEvent::Exit` (src-tauri/src/lib.rs:52-56); there is no Windows Job Object `KILL_ON_JOB_CLOSE` and no Unix PDEATHSIG — if the host itself crashes or is force-killed, the pharmaml-backend sidecar is orphaned (loopback port + process leak until manual kill) | **OPEN (compile-blocked)** | 370 (found) | part20 §6 full-read of backend_manager.rs/lib.rs; the fix (Job Object wrap on Windows) is drafted as the recommendation but **cannot be compile-verified in this sandbox (no cargo/rustc)** — per the D-4/D-5 precedent, a source-only unverifiable change is never marked FIXED; rides the first cargo-enabled environment or the Windows runner |
| D-12 | Medium (P2) — Retry cannot recover a dead backend | `StartupGate.tsx` Retry (lines 86-90/:144-150) re-acquires the stale endpoint over IPC; the Rust child is never respawned (no restart IPC command exists — commands.rs has exactly one, `backend_endpoint`), so after a post-startup backend crash every retry just re-probes the dead port and the only real recovery is an app relaunch | **OPEN (compile-blocked)** | 370 (found) | part20 §6 full-read; recommendation: a respawn-aware retry (restart IPC command or respawn-on-EPIPE inside `backend_endpoint`); same cargo-unavailable constraint as D-11 |
| D-13 | Low (P3) — dead frontend service methods | Four typed service methods are exported but never called by any page/component/test: `unsupervisedApi.methods` (services/ml/unsupervised.ts:335), `reinforceApi.methods` (:384), `reinforceApi.evaluate` (:417), `generativeApi.priorView` (services/generative/client.ts:271) — part20 §4's "unused frontend functionality" class | **DOCUMENTED (kept)** | 370 | BACKEND_FRONTEND_TRACEABILITY.md §2: decision per part20 §12 minimal-change — kept as typed-surface parity for the API-only lanes (thin wrappers, no runtime consumer, no test consumer); removal buys nothing; revisit if the corresponding GUI lanes are built |
| D-14 | Low (P3) — traceability-matrix census drift | The ROUND368 matrix reports 148 operations and prose "nine" GUI-unconsumed routes while its own table enumerates 10; the true census is **149 operations / 142 paths** (148 + the uncounted `HEAD /api/v1/artifacts/{artifact_id}/download`, routes/artifacts.py:328) | **FIXED (doc)** | 370 | BACKEND_FRONTEND_TRACEABILITY.md §1 carries the corrected census (re-derived from contracts/openapi.json this round: 54 GET / 89 POST / 4 DELETE / 1 PUT / 1 HEAD); the ROUND368 matrix stands as the historical 148-row artifact |
| D-15 | Medium (P2) — shipped installers lag main (finding B) | Release v1.2.243 was built from tag 902dd89b while main is now 16 commits / 172 files ahead (38 backend, 3 frontend — the r368 F-1/F-3 UI fixes — plus the r370 test/metadata fixes): the shipped EXE/MSI do not contain those fixes (part20 §7.1's "source changes made after the installer was built") | **CLOSED (r371)** | 370 (revalidated) → 372 (row conversion) | WINDOWS_EXE_MSI_AUDIT.md §2: internally consistent (manifest==tag==VERSION) but stale; the r371 release cycle closed the gap — **v1.2.244 published 2026-11-27T18:23:04Z from the r371 build ladder (attempt 4, run 46043111328, commit 5a48d6cf) with the install-smoke run 46049348450 green (15/15 incl. the 1.2.243→1.2.244 upgrade leg)** — the D-15 CLOSE was triple-recorded in the CHANGELOG/RELEASE_READINESS/TEST_EXECUTION_REPORT of r371 but this standing register row was never converted; the r372 revalidation (ROUND372_PREVIOUS_TASK_REVALIDATION.md, row 14) caught the stale row and this is that conversion |

## Register conventions

- **FIXED** requires: the source change + the focused regression
  tests executed green + the unchanged lanes re-pinned (no auth
  bypass, no Host-policy weakening, lookalikes still rejected).
- **FIXED (source; compile-blocked)** means the change is in the
  tree with its tests written but the toolchain to compile/run them
  does not exist in this sandbox — the row converts to plain FIXED
  only after the first real `cargo test` pass. Never marked passed
  before then (§16.14).
- **OPEN** rows carry their next action; nothing silently closes.
- New findings append as D-N+1 with the discovery round named.

— seeded round 327 (the 119th recorded run); supersedes the
D-1…D-5 table inside `PART14_PHASE1_AUDIT.md` (which stands as the
Phase-1 historical record per the §2.4 historical-records rule).
D-6 closed round 339 (the 131st recorded run — part15 §4.2's
headline recheck; the register's first part15-era row conversion).
D-7 closed round 340 (the 132nd recorded run — the rollback-recovery
gate re-pin caught the ordinal-blind ledger guard; the register's
first r340-era row).
D-8 closed round 341 (the 133rd recorded run — the IMPROVEMENT_ROADMAP's
own #2 sandbox lane: the D-6 frontend client half, found by the
fail-first lane the roadmap named; 6 red pre-fix, 126/126 post).
D-9..D-15 seeded round 370 (the 162nd recorded run — MASTER_PROMPT
part20's full repository audit): D-9 (the failing CI chemistry lane —
part20 Known-Finding A — fixed with the lane re-run 499 green) and
D-10 (the Cargo.toml version-carrier skew — fixed) closed in-round;
D-11/D-12 (the two Tauri lifecycle findings from the part20 §6 full-read:
orphan-on-host-crash + retry-without-respawn) stay OPEN compile-blocked
per the D-4/D-5 precedent (no cargo in this sandbox — never marked fixed);
D-13/D-14 are the documented P3 rows (dead service methods kept as
typed-surface parity; the corrected 149-operation census in
BACKEND_FRONTEND_TRACEABILITY.md); D-15 (part20 Known-Finding B: the
shipped installers lag main by the post-tag delta) stays OPEN
release-gated — no release published or asset overwritten without the
owner's authorization.

Round 372 (the 166th recorded run — MASTER_PROMPT part21): **no new
defects seeded** — the part21 implementation round closed green on
every gate (the shared ML/DL evaluation layer, its 19 new tests, the
full regressions). One register transition + one lane state recorded:

- **D-15 CLOSED (row conversion, evidence above)** — the r371 cycle
  had closed the defect; the standing row said OPEN (release-gated)
  until this round's revalidation caught it. The post-v1.2.244 main
  delta (r372 housekeeping + the part21 work) is the normal
  between-release drift, NOT a D-15 regression: D-15's finding was
  the STALE installers vs main at audit time; the next release cycle
  (the standing owner-gated ladder) carries the delta as before.
- **The ZAP penetration lane (run 46038496882) is STILL in-limbo**:
  `in_progress` / no conclusion, last API update 2026-11-27T17:01:51Z
  (~12h stale at the r372 revalidation's reading; the ephemeral target
  expired mid-scan). NOT counted green, NOT closed — the local 67-test
  penetration API suite stays the in-sandbox green lane; the remote
  ZAP re-run rides the standing Monday 2026-11-30 deep-scan slot.
- D-11/D-12 unchanged (compile-blocked, cargo absent); signing
  certificate-gated; clean-machine validation owner-side.
