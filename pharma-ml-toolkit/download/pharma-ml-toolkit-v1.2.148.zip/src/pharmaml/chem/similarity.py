"""Molecular similarity (Tanimoto and friends).

Upgrades ``Tanimoto calculator.py`` / ``Tanimoto-edited.py``.  The key
design change: the *math* (Tanimoto coefficient on bit sets) is
separated from the *chemistry* (building fingerprints).  The pure
functions run on any bit representation and are unit-tested without
RDKit; the RDKit-backed scan functions build fingerprints then reuse
the same math.

Examples
--------
>>> from pharmaml.chem.similarity import (
...     tanimoto_from_bitarrays, tanimoto_from_sets)
>>> tanimoto_from_sets({"donor", "aromatic", "acid"}, {"donor", "aromatic", "base"})
0.5
>>> tanimoto_from_sets(set(), set())       # both empty -> identical
1.0
>>> tanimoto_from_sets({"donor"}, set())   # one empty -> nothing in common
0.0
>>> tanimoto_from_bitarrays([1, 1, 0], [1, 0, 0])  # the same math on bits
0.5
>>> tanimoto_from_bitarrays([1, 0], [1, 0, 0])     # unequal lengths rejected
Traceback (most recent call last):
...
pharmaml.exceptions.DataValidationError: bit arrays must have equal length, got (2,) vs (3,)

>>> import numpy as np
>>> from pharmaml.chem.similarity import tanimoto_matrix
>>> reference = np.array([[1, 1, 0, 0], [1, 0, 0, 0]])
>>> targets = np.array([[1, 1, 0, 0], [0, 0, 1, 1], [0, 0, 0, 0]])
>>> sims = tanimoto_matrix(reference, targets)
>>> sims.shape, sims.dtype.name
((2, 3), 'float64')
>>> sims.tolist()   # identical -> 1; disjoint or one-sided-empty -> 0; subset -> 0.5
[[1.0, 0.0, 0.0], [0.5, 0.0, 0.0]]

>>> from pharmaml.chem.similarity import similarity_scan
>>> scan = similarity_scan(["CCO"], ["CCO", "CCC", "c1ccccc1O"], threshold=0.25)
>>> scan["target"].tolist(), scan["target_index"].tolist()  # phenol is dropped
(['CCO', 'CCC'], [0, 1])
>>> scan["similarity"].tolist()   # kept at >= threshold, best first
[1.0, 0.25]
>>> similarity_scan(["CCO"], ["CCO"], threshold=1.5)
Traceback (most recent call last):
...
pharmaml.exceptions.DataValidationError: threshold must be within [0, 1], got 1.5

>>> from pharmaml.chem.similarity import top_matches
>>> matches = top_matches("CCO", ["CCO", "CCC", "c1ccccc1O", "CO"], k=3)
>>> matches["target"].tolist()
['CCO', 'CO', 'CCC']
>>> [round(v, 4) for v in matches["similarity"]]   # ethanol > methanol > propane
[1.0, 0.3333, 0.25]
>>> top_matches("CCO", ["CCO"], k=0)
Traceback (most recent call last):
...
pharmaml.exceptions.DataValidationError: k must be >= 1, got 0
"""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np
import pandas as pd

from pharmaml.chem.descriptors import FingerprintKind
from pharmaml.exceptions import DataValidationError, DependencyError
from pharmaml.logger import get_logger

_LOG = get_logger(__name__)

__all__ = [
    "similarity_scan",
    "tanimoto_from_bitarrays",
    "tanimoto_from_sets",
    "tanimoto_matrix",
    "top_matches",
]


def tanimoto_from_sets(a: set, b: set) -> float:
    """Tanimoto coefficient for two feature sets: |A∩B| / |A∪B|.

    Both sets empty -> 1.0 (identical); one empty -> 0.0.
    """
    union = len(a | b)
    if union == 0:
        return 1.0
    return len(a & b) / union


def tanimoto_from_bitarrays(a: np.ndarray, b: np.ndarray) -> float:
    """Tanimoto coefficient for two equal-length binary arrays.

    Uses vectorised bitwise ops -- ~50x faster than set operations for
    2048-bit fingerprints in benchmarks.  Float inputs must be finite:
    ``astype(bool)`` maps NaN to ``True``, so a NaN would silently count
    as a set bit.

    Raises
    ------
    DataValidationError
        If the arrays differ in shape or contain non-finite float values.
    """
    a = np.asarray(a)
    b = np.asarray(b)
    for label, arr in (("a", a), ("b", b)):
        if arr.dtype.kind == "f" and not np.isfinite(arr).all():
            raise DataValidationError(
                f"bit array {label!r} contains non-finite values (NaN/inf); "
                "expected a binary 0/1 array"
            )
    a = a.astype(bool)
    b = b.astype(bool)
    if a.shape != b.shape:
        raise DataValidationError(
            f"bit arrays must have equal length, got {a.shape} vs {b.shape}"
        )
    union = int(np.logical_or(a, b).sum())
    if union == 0:
        return 1.0
    return int(np.logical_and(a, b).sum()) / union


def tanimoto_matrix(
    reference: np.ndarray, targets: np.ndarray
) -> np.ndarray:
    """All-vs-all Tanimoto similarities between two bit-matrix batches.

    Parameters
    ----------
    reference:
        ``(n_ref, n_bits)`` binary matrix.
    targets:
        ``(n_tgt, n_bits)`` binary matrix.

    Returns
    -------
    numpy.ndarray
        ``(n_ref, n_tgt)`` float64 similarity matrix.

    Raises
    ------
    DataValidationError
        If the matrices are not 2-D with matching bit length, or contain
        non-finite float values (NaN would silently count as a set bit).
    """
    reference = np.asarray(reference)
    targets = np.asarray(targets)
    for label, arr in (("reference", reference), ("targets", targets)):
        if arr.dtype.kind == "f" and not np.isfinite(arr).all():
            raise DataValidationError(
                f"{label!r} contains non-finite values (NaN/inf); "
                "expected a binary 0/1 matrix"
            )
    reference = reference.astype(bool)
    targets = targets.astype(bool)
    if reference.ndim != 2 or targets.ndim != 2 or reference.shape[1] != targets.shape[1]:
        raise DataValidationError(
            "reference/targets must be 2-D with matching bit length, got "
            f"{reference.shape} vs {targets.shape}"
        )
    ref_counts = reference.sum(axis=1)[:, np.newaxis]
    tgt_counts = targets.sum(axis=1)[np.newaxis, :]
    intersections = reference.astype(np.uint32) @ targets.T.astype(np.uint32)
    unions = ref_counts + tgt_counts - intersections
    with np.errstate(divide="ignore", invalid="ignore"):
        result = np.where(unions == 0, 1.0, intersections / np.maximum(unions, 1e-12))
    return result.astype(np.float64)


def _require_rdkit_similarity() -> None:
    try:
        import rdkit  # noqa: F401 -- presence check only
    except ImportError as exc:
        raise DependencyError(
            "RDKit is required for the SMILES-based similarity scan. "
            "Install it with:  pip install 'pharmaml[chem]'"
        ) from exc


def similarity_scan(
    reference_smiles: Sequence[str],
    target_smiles: Sequence[str],
    threshold: float = 0.9,
    fingerprint: FingerprintKind = "rdkit",
    n_bits: int = 2048,
    radius: int = 2,
) -> pd.DataFrame:
    """Scan reference ligands against a target library (Tanimoto >= threshold).

    This is the productionised version of the original workflow that
    read two hardcoded Excel files and wrote a filtered matrix to a
    hardcoded Windows path.  Everything is now explicit parameters and
    the return value is a tidy long-format DataFrame:

    ``reference | target | reference_index | target_index | similarity``

    Parameters
    ----------
    reference_smiles:
        SMILES strings for the reference/seed ligands.
    target_smiles:
        SMILES strings for the screening library.
    threshold:
        Minimum similarity to keep (default 0.9 as in the original).
    fingerprint:
        ``'rdkit'`` (path fingerprint, as originally used) or
        ``'morgan'`` (ECFP-style).
    n_bits:
        Fingerprint bit length.
    radius:
        Morgan radius (only used for ``'morgan'``).

    Returns
    -------
    pandas.DataFrame
        Filtered similarity pairs sorted by descending similarity
        (ties keep library order -- the sort is stable).  A pandas Series
        is accepted for both SMILES arguments; row order is used and the
        Series index is ignored, so the ``reference``/``target`` columns
        always match the positional ``*_index`` columns.

    Raises
    ------
    DataValidationError
        If ``threshold`` is outside [0, 1] or either SMILES argument is
        a bare string (which would otherwise be split into characters).
    """
    if not 0.0 <= threshold <= 1.0:
        raise DataValidationError(f"threshold must be within [0, 1], got {threshold}")
    _require_rdkit_similarity()

    from pharmaml.chem.descriptors import (
        _as_smiles_list,
        compute_fingerprints,
    )

    # Materialise once: keeps positional lookups correct for Series with
    # non-default indexes and for one-shot generators.
    reference_list = _as_smiles_list(reference_smiles, "reference_smiles")
    target_list = _as_smiles_list(target_smiles, "target_smiles")

    ref_matrix, ref_idx = compute_fingerprints(
        reference_list, kind=fingerprint, n_bits=n_bits, radius=radius
    )
    tgt_matrix, tgt_idx = compute_fingerprints(
        target_list, kind=fingerprint, n_bits=n_bits, radius=radius
    )
    _LOG.info(
        "Similarity scan: %d valid references x %d valid targets (threshold=%.2f)",
        len(ref_idx),
        len(tgt_idx),
        threshold,
    )

    similarities = tanimoto_matrix(ref_matrix, tgt_matrix)
    mask = similarities >= threshold

    rows = []
    for ref_row, ref_pos in enumerate(ref_idx):
        for tgt_row, tgt_pos in enumerate(tgt_idx):
            if mask[ref_row, tgt_row]:
                rows.append(
                    {
                        "reference": reference_list[ref_pos],
                        "target": target_list[tgt_pos],
                        "reference_index": int(ref_pos),
                        "target_index": int(tgt_pos),
                        "similarity": float(similarities[ref_row, tgt_row]),
                    }
                )
    frame = pd.DataFrame(
        rows,
        columns=["reference", "target", "reference_index", "target_index", "similarity"],
    )
    return frame.sort_values("similarity", ascending=False, kind="stable").reset_index(drop=True)


def top_matches(
    query: str,
    library: Sequence[str] | pd.Series,
    k: int = 10,
    fingerprint: FingerprintKind = "rdkit",
    n_bits: int = 2048,
    radius: int = 2,
) -> pd.DataFrame:
    """Return the ``k`` library entries most similar to ``query``.

    Convenience wrapper around :func:`similarity_scan` with
    ``threshold=0`` and a head-slice.  ``radius`` is forwarded to the
    Morgan fingerprint (matching :func:`similarity_scan`); equal
    similarities keep library order.

    Raises
    ------
    DataValidationError
        If ``k < 1``, ``library`` is a bare string, or ``query`` is not a
        parseable SMILES (a wrong query must not masquerade as "no
        matches").
    """
    if k < 1:
        raise DataValidationError(f"k must be >= 1, got {k}")
    _require_rdkit_similarity()
    from pharmaml.chem.descriptors import (
        _as_smiles_list,
        _smiles_to_molecules,
    )

    _, _, failures = _smiles_to_molecules([query])
    if failures:
        raise DataValidationError(
            f"query SMILES is not valid: {query!r} -- no matches were computed"
        )
    pairs = similarity_scan(
        [query],
        _as_smiles_list(library, "library"),
        threshold=0.0,
        fingerprint=fingerprint,
        n_bits=n_bits,
        radius=radius,
    )
    return pairs.head(k).reset_index(drop=True)
