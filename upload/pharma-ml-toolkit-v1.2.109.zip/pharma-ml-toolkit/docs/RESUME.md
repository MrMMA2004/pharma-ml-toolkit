# RESUME — the anti-rollback protocol

_Last rebuilt 2026-11-02 after the rollback that ate rounds 180–182._

## What happened

The sandbox can silently revert the whole filesystem to an earlier
snapshot (observed 2026-11-02 ~22:00): the toolkit tree went back to
the round-179 state (v1.2.103, HEAD `8085d76`) while the conversation
carried on — three rounds of work, `tools/checkpoint.py`, this file
and every untracked zip (v1.2.98–v1.2.103) vanished. **What survived:
git history and git-TRACKED files.** That single observation drives
every rule below.

## The standing guard

A cron job fires every 30 minutes (Job `495807`) and runs, minimally:

```
cd /home/z/my-project/pharma-ml-toolkit
pgrep -f checkpoint.py || /home/z/.venv/bin/python tools/checkpoint.py --light
```

`--light` = doctor + commit work-in-progress (a UUID-message commit
under the toolkit tree only).  The guard never develops features; it
only protects them.

## Doctor verdicts

* `ROLLBACK DETECTED` — the working tree's `VERSION` sits below the
  newest surviving archive.  Recovery:
  `/home/z/.venv/bin/python tools/checkpoint.py --restore` (unpacks the
  newest zip over the tree and light-commits), then `--doctor` again.
* `MISSING packages: …` — the venv was reset too.  Install exactly:
  `/home/z/.venv/bin/pip install rdkit selfies shap torch meeko gemmi ruff mypy`
  (run it with `setsid nohup … &` — plain background jobs are reaped
  with the tool session).
* `PROBLEMS: version mismatch` — fix `VERSION` / `pyproject.toml` /
  `src/pharmaml/__init__.py` before shipping.

## Rules (each one earned the hard way)

1. **Commit the shipped zip.**  Tracked zips survived the rollback;
   untracked ones did not.  Retention: newest two stay tracked, older
   ones are `git rm`-ed (history keeps the blobs).
2. **Never run full pytest inside the ship ritual.**  The full suite
   needs 10–15 min on this 2-CPU box; a 590 s ritual timeout once
   killed a ship silently.  The ritual gates are doctests + ruff +
   mypy + GUI self-test only; run full pytest in chunks separately
   when a round touches broad surfaces.
3. **`PYTHONPATH` must be absolute** when the cwd will change
   (`/home/z/my-project/pharma-ml-toolkit/src`) — pytest's
   `pythonpath=["src"]` ini option only holds in-process.
4. **Notebooks print the version at execution time.**  After a version
   bump, re-execute every example notebook or
   `test_notebook_variants` fails on stale outputs.
5. **Background processes die with the tool session.**  Use the
   double-fork daemon recipe (`scratch/xvfb_daemon_158.py`) or
   `setsid nohup … < /dev/null &` for pip/Xvfb/long jobs.
6. **Xvfb on `:99`** is started by `scratch/xvfb_daemon_158.py` when a
   GUI drive or the self-test needs a display.

## Ship ritual (end of every round)

```
/home/z/.venv/bin/python tools/checkpoint.py --commit "round NNN: <message>"
```

Gates (doctests → ruff → mypy → GUI self-test) then version re-pin,
zip build (outside `download/`, testzip'd, moved in), retention sweep
and the round commit.  Before it: bump `VERSION`, write the CHANGELOG
entry, run the round's targeted pytest chunks.

## Verification status after the 23:30 guard (2026-11-02, round 183 / 100x-169)

The four-bug round (v1.2.104) is committed as `c200bd6` (light commit).
Test slices verified green that turn: `test_tuner.py` (exit 0),
`TestTunerCard` (incl. the 3 new card tests), `test_explain.py`
(SHAP +4), `test_rism.py` + `test_features.py` (tqdm wiring).

**CLOSED (the "Continue" turn, same night):**

1. `test_cli_features.py` — exit 0 in its own 590 s window.
2. `test_playground.py` — fully verified in per-class chunks: the
   first ~62% green in the OOM-attempt run, then chunks
   `TestReview130Gui…136Gui`, `137…141`, `148…151`+
   `TestPredictionIntervalsGui`, `TestOverfitGap/Interpretability/
   CrossModelImportance/VarianceFilter/UnsupervisedTab`, and
   `TestDearPyGui*` + `TestShapOptuna/Reinvent4DiffDockAbsorption` —
   all exit 0.  The whole-file OOM at ~62% is a box RAM limit, not a
   code failure; chunking is the standing workaround.
3. `encode_class_target` now has its pytest pair in
   `TestPureHelpers` (multiclass/binary/list + numeric
   pass-through), green.

## Round 184 (2026-11-02, tag 100x-171) — the .exe engine folder

The instruction: *"I want the docking campaign runner to run through
these 3 .exe files"* (vina.exe / autogrid4.exe / autodock4.exe,
uploaded).  Shipped as v1.2.105: `locate_engine_binary` /
`engine_argv` in `docking/workflow.py` (engine folder first, both
name spellings, PATH last, MZ-magic wine routing), `engine_dir=`
threaded through every runner, the GUI's Engine-binaries picker on
the Campaign runner card, and the three exes committed under
`engines/` (checksums in `engines/README.md` — the zip builder does
NOT exclude `.exe`, only `.log`/`.zip`).

Verification (all exit 0): `test_campaign.py` 111 (incl. +15
engine-folder), `test_docking.py` + `test_docking_prep.py`,
`test_features.py` + `test_explain.py` (numpy-1.26.4 sanity),
`test_playground.py` 729 collected in the standing 6 chunks
(76 classes), full doctest gate, ruff 0.17.1, mypy, GUI self-test.

Environment lessons added this round:

7. **The 18th venv reset (mid-round) took rdkit/meeko/gemmi/shap/
   selfies/torch/ruff/mypy AND upgraded numpy to 2.1.3.**  Restore
   the pins, not just the names: `pip install rdkit==2026.9.1
   meeko==0.8.0 gemmi "shap>=0.45,<0.60" "selfies>=2.1,<3"
   "numpy==1.26.4" "ruff==0.17.1" "mypy==2.4.0"` plus CPU torch
   (`--index-url https://download.pytorch.org/whl/cpu`).  numpy 2.x
   alone breaks doctest reprs (`np.float64(...)`); pip's
   "shap requires numpy>=2" conflict warning is spurious — 0.54.1
   computes fine on 1.26.4.
8. **The reset also flipped +x bits on every .py file** (154× ruff
   EXE002 "shebang-missing-executable-file").  Fix is filesystem,
   not code: `rg --files src tests -g "*.py" | xargs chmod -x`.
9. **Xvfb :99 can die mid-session** (it did, between two pytest
   runs).  Restart with the daemon recipe:
   `nohup python scratch/xvfb_daemon_158.py &` — then re-verify with
   a one-line `tkinter.Tk().destroy()`.

Standing environment notes (kept):

10. GUI tests need `DISPLAY=:99` (Xvfb up) and
    `PYTHONPATH=<abs>/src`; without DISPLAY the suite errors en masse
    (not a code failure).
11. Bash-tool output can silently EAT bracket-letter pairs (``[m`` →
    nothing): a line displayed as ``np.asarray(apping[`` was actually
    ``np.asarray([mapping[``.  When Bash output shows impossible code,
    cross-check with the Read tool or an ast/tokenizer dump before
    "fixing" anything.
12. MultiEdit is NOT atomic in practice: a failing edit leaves the
    earlier edits of the same call applied (observed twice this
    round — a duplicated `import os` was the tell).  After any
    "no replacement was performed" error, RE-GREP the file for every
    edit target before retrying; never blindly re-run the batch.


## Round 185 (2026-11-03, tag 100x-172) — the deep-viz absorption round

The instruction: *"Check the contents and files in this GitHub links
completely and one by one and add the missing items to playground.py
(Deep Learning)"* — netron, torchview, pytorchviz, torchlens.  Shipped
as v1.2.106: the Deep Learning tab's **Architecture card** — the
torchlens-style layer table (``layer_table_rows`` dispatching both
engines, totals line with MACs/≈FLOPs), the torchview-style module
tree (``module_tree_lines`` with depth control, session-persisted
depth combo — the DL input pin grew to 19), the pytorchviz-style
``autograd_dot_source`` (make_dot as plain dot text; weight leaves
arrive via ``TBackward0``, weight shape is ``(out, in)``), and the
netron-style ``launch_netron`` (fail-fast: numpy engine → netron
absent → torch absent → only then dialog + ONNX export; onnxscript is
NOT installed here, so the export path degrades to its error dialog
by design).  17 new tests in ``TestDeepVizAbsorptionGui``.

Verification (all green): the new class 17/17, DL regression suites
(``TestDeepLearningTab`` + ``TestDLCheckCSV`` 19 passed), the full
``test_playground.py`` in 11 per-class chunks (77 classes, exit 0
each), playground doctests, ruff clean, mypy at its unchanged
64-error playground baseline (the ritual gates mypy on ``src/``
only), GUI self-test, ship ritual gates + re-pin v1.2.106.zip (765
files) + retention (v1.2.104 retired), repo-level bookkeeping commit
+ round anchor ``94cb730``.

Round-185 environment lessons:

8. **Shallow repo clones for absorption rounds live in
   ``scratch/repos-*/`` and are git-IGNORED** (``scratch/repos-*/``
   in the root .gitignore) — 200 MB of clones must never ride the
   repo; the download/ zip bookkeeping commit stays minimal.
9. **The ritual's final pathspec commit can exit 1** when the light
   WIP commits already took every toolkit change: that is the
   "nothing left in pathspec" case, not a gate failure — finish with
   the repo-level bookkeeping commit and an ``--allow-empty`` round
   anchor so the round message is grep-able.
