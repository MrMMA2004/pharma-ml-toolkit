"""Splice the round-176 cards into playground.py (idempotent).

Round 176 (100x-176): PK-Sim physiology + mrgsolve/rxode2 event grammar +
OSPSuite-R sensitivity.  Three new cards on the PK/PD tab (rows 11-13),
three handlers, and a loud self-test block.  Anchored insertion — re-running
on an already-spliced file is a no-op.
"""

from __future__ import annotations

from pathlib import Path

PLAYGROUND = Path(__file__).resolve().parent.parent / "playground.py"

CARDS_ANCHOR = "        self._uc_dimension_changed()\n\n    def _uc_dimension_changed(self) -> None:"

CARDS = '''        # -- PK-Sim physiology: curves, ontogeny, Kp (100x-176) ----- #
        # the static PKSimDB layer, numpy-native: the ICRP reference
        # individual at any age, the GFR maturation Hill function and
        # BSA, the enzyme ontogeny tables (CYP3A4 rising, the neonatal
        # CYP3A7 switching off) and the published partition-coefficient
        # methods (Willmann / Rodgers-Rowland / Poulin-Theil /
        # Berezhkovskiy) on the real per-organ tissue composition
        physio_card = make_card(
            page.grid,
            "PK-Sim physiology — curves, ontogeny & Kp methods",
            collapsible=True,
            key="pk-physiology",
            row=11,
            column=0,
            span=2,
            subtitle="PK-Sim's static database layer (PKSimDB.sqlite), "
            "numpy-native: the ICRP 2002 European reference individual "
            "at any age (weight, height, hematocrit, liver volume/flow), "
            "the renal GFR maturation Hill function (TM50 44.4 weeks), "
            "Mosteller/Du Bois BSA, the 508-point enzyme ontogeny tables "
            "and the four published partition-coefficient methods on "
            "the real per-organ tissue composition — the Kp calculation "
            "the minimal-PBPK round explicitly left in PK-Sim, now "
            "closed.",
        )
        self._physio_age = ttk.Entry(physio_card, width=10)
        self._physio_age.insert(0, "2")
        form_row(physio_card, "age (years)", self._physio_age)
        self._physio_logp = ttk.Entry(physio_card, width=10)
        self._physio_logp.insert(0, "2.0")
        form_row(physio_card, "LogP", self._physio_logp)
        self._physio_fu = ttk.Entry(physio_card, width=10)
        self._physio_fu.insert(0, "0.05")
        form_row(physio_card, "fu (plasma)", self._physio_fu)
        physio_buttons = ttk.Frame(physio_card, style="Card.TFrame")
        grid_append(physio_card, physio_buttons, sticky="w", pady=(6, 0))
        physio_btn = self._action_button(
            physio_buttons,
            "Individual + Kp methods",
            self._pkpd_physiology_run,
            primary=True,
            tooltip="create_individual (the ICRP curves) + gfr_reference "
            "+ bsa_mosteller + the CYP3A4/3A7/UGT2B7 ontogeny factors at "
            "the given age + Kp for liver across the four methods.",
        )
        physio_btn.pack(side="left")
        ont_btn = self._action_button(
            physio_buttons,
            "Ontogeny curves",
            self._pkpd_ontogeny_run,
            tooltip="The hepatic ontogeny factors over PMA 0-5 years: "
            "CYP3A4 maturing in, the neonatal CYP3A7 switching off, "
            "UGT2B7's slower rise — linear-in-PMA interpolation exactly "
            "as PK-Sim registers it.",
        )
        ont_btn.pack(side="left", padx=(10, 0))
        self._physio_result = ttk.Label(
            physio_card,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=620,
            justify="left",
        )
        grid_append(physio_card, self._physio_result, sticky="w")
        self._physio_host = self._figure_host(physio_card, height=230)
        bind_enter(self._physio_age, physio_btn)

        # -- Event grammar: mrgsolve / rxode2 (100x-176) ------------- #
        # ev()/addl/until/ss over the toolkit's own ODE engine: the
        # infusion whose peak lands exactly at the infusion end
        # (mrgsolve's own acceptance test), the two until conventions,
        # the steady-state jumps and the recsort tie-breaks
        events_card = make_card(
            page.grid,
            "Event grammar — mrgsolve / rxode2",
            collapsible=True,
            key="pk-events",
            row=12,
            column=0,
            span=2,
            subtitle="The dosing-table grammar both R engines are loved "
            "for, executed by the toolkit's own adaptive ODE engine: "
            "ev() with tinf/total/until derivations, addl+ii expansion, "
            "evid codes (dose / reset / replace / off), lag times, "
            "bioavailability shrinking infusion duration (dur = F·amt/"
            "rate), steady-state jumps (ss=1 replace, ss=2 superpose) "
            "and the four-way recsort tie-break of doses against "
            "observations.",
        )
        self._ev_dose = ttk.Entry(events_card, width=10)
        self._ev_dose.insert(0, "3000")
        form_row(events_card, "dose (mg)", self._ev_dose)
        self._ev_rate = ttk.Entry(events_card, width=10)
        self._ev_rate.insert(0, "30")
        form_row(events_card, "rate (mg/h)", self._ev_rate)
        self._ev_addl = ttk.Entry(events_card, width=10)
        self._ev_addl.insert(0, "5")
        form_row(events_card, "addl doses", self._ev_addl)
        self._ev_ii = ttk.Entry(events_card, width=10)
        self._ev_ii.insert(0, "12")
        form_row(events_card, "ii (h)", self._ev_ii)
        events_buttons = ttk.Frame(events_card, style="Card.TFrame")
        grid_append(events_card, events_buttons, sticky="w", pady=(6, 0))
        events_btn = self._action_button(
            events_buttons,
            "Simulate regimen",
            self._pkpd_events_run,
            primary=True,
            tooltip="simulate_regimen on a one-compartment IV model "
            "(V 100 L, CL 3 L/h): the peak lands exactly at the end of "
            "the infusion — mrgsolve's test-infusion.R acceptance "
            "number, re-derived live.",
        )
        events_btn.pack(side="left")
        grammar_btn = self._action_button(
            events_buttons,
            "Grammar demo",
            self._pkpd_grammar_run,
            tooltip="addl_until under both engines' rules (mrgsolve stops "
            "strictly before until, rxode2 schedules the boundary dose), "
            "ev_seq spacers, the weekday schedule and realize_addl.",
        )
        grammar_btn.pack(side="left", padx=(10, 0))
        self._events_result = ttk.Label(
            events_card,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=620,
            justify="left",
        )
        grid_append(events_card, self._events_result, sticky="w")
        self._events_host = self._figure_host(events_card, height=230)
        bind_enter(self._ev_ii, events_btn)

        # -- Sensitivity: OSPSuite-R (100x-176) ---------------------- #
        # the PK-parameter registry (31 entries) and the normalised
        # sensitivity workflow with the OSP defaults: parameters at
        # 90-110 % of reference, the elasticity dln(PK)/dln(p), the
        # cumulative-90 % ranking filter
        sens_card = make_card(
            page.grid,
            "Sensitivity — OSPSuite-R conventions",
            collapsible=True,
            key="pk-sensitivity",
            row=13,
            column=0,
            span=2,
            subtitle="The R API layer's data model: the 31-entry "
            "PK-parameter registry (modes Always/Single/Multi, the "
            "multi-dose tD1-tD2 variants) and the sensitivity workflow "
            "with its exact OSP defaults — numberOfSteps 2, "
            "variationRange 0.1 (the 90/95/105/110 % runs), values as "
            "elasticities where -1 means +10 % parameter -> -10 % PK "
            "parameter, ranked through the cumulative 90 % threshold "
            "filter of allPKParameterSensitivitiesFor.",
        )
        self._sens_dose = ttk.Entry(sens_card, width=10)
        self._sens_dose.insert(0, "100")
        form_row(sens_card, "dose (mg)", self._sens_dose)
        self._sens_cl = ttk.Entry(sens_card, width=10)
        self._sens_cl.insert(0, "5")
        form_row(sens_card, "CL (L/h)", self._sens_cl)
        self._sens_v = ttk.Entry(sens_card, width=10)
        self._sens_v.insert(0, "20")
        form_row(sens_card, "V (L)", self._sens_v)
        sens_buttons = ttk.Frame(sens_card, style="Card.TFrame")
        grid_append(sens_card, sens_buttons, sticky="w", pady=(6, 0))
        sens_btn = self._action_button(
            sens_buttons,
            "Run sensitivity (90–110 %)",
            self._pkpd_sensitivity_run,
            primary=True,
            tooltip="AUC_inf = D/CL and C_max = D/V on a one-compartment "
            "IV bolus: the elasticities come out exactly -1/0 — the "
            "convention's own calibration, verified live.",
        )
        sens_btn.pack(side="left")
        registry_btn = self._action_button(
            sens_buttons,
            "PK registry",
            self._pkpd_registry_run,
            tooltip="pk_parameter_frame(): the 31 shipped parameters with "
            "modes and dimensions, straight from OSPSuite.PKParameters.xml.",
        )
        registry_btn.pack(side="left", padx=(10, 0))
        self._sens_result = ttk.Label(
            sens_card,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=620,
            justify="left",
        )
        grid_append(sens_card, self._sens_result, sticky="w")
        self._sens_host = self._figure_host(sens_card, height=230)
        bind_enter(self._sens_v, sens_btn)

'''

HANDLERS_ANCHOR = "    def _uc_dimension_changed(self) -> None:"

HANDLERS = '''    def _pkpd_physiology_run(self) -> None:
        """The ICRP individual + GFR/BSA + the four Kp methods."""
        if not self._require_pharmaml():
            return
        try:
            age = float(self._physio_age.get())
            log_p = float(self._physio_logp.get())
            fu = float(self._physio_fu.get())
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        def work() -> Any:
            from pharmaml.pkpd.physiology import (
                bsa_mosteller, create_individual, gfr_reference,
                kp_berezhkovskiy, kp_pk_sim_standard, kp_poulin_theil,
                kp_rodgers_rowland, ontogeny_factor,
            )

            ind = create_individual(age_years=age, gender="MALE")
            pma = age + 40.0 * 7.0 / 365.25
            return (
                ind, gfr_reference(age), bsa_mosteller(
                    ind["Organism|Weight"], ind["Organism|Height"] * 10.0
                ),
                ontogeny_factor("CYP3A4", pma), ontogeny_factor("CYP3A7", pma),
                kp_pk_sim_standard(log_p, fu, "Liver"),
                kp_rodgers_rowland(log_p, fu, "Liver"),
                kp_poulin_theil(log_p, fu, "Liver"),
                kp_berezhkovskiy(log_p, fu, "Liver"),
            )

        def render(payload: Any) -> None:
            (ind, gfr, bsa, cyp3a4, cyp3a7, k_pks, k_rr, k_pt, k_bz) = payload
            self._physio_result.configure(
                text=(
                    f"{self._physio_age.get()}-y ICRP male: BW "
                    f"{ind['Organism|Weight']:.4g} kg · HCT "
                    f"{ind['Organism|Hematocrit']:.3g} · liver "
                    f"{ind['Liver|Volume']:.4g} L / {ind['Liver|Blood flow']:.4g} L/h · "
                    f"GFRspec {gfr:.4g} L/min/kg · BSA {bsa:.4g} m²\\n"
                    f"ontogeny @ PMA {float(self._physio_age.get()) + 40 * 7 / 365.25:.2f} y: "
                    f"CYP3A4 {cyp3a4:.3f} · CYP3A7 {cyp3a7:.3f}\\n"
                    f"Kp (liver, LogP {self._physio_logp.get()}, fu "
                    f"{self._physio_fu.get()}): PK-Sim {k_pks:.4f} · "
                    f"Rodgers-Rowland {k_rr:.4f} · Poulin-Theil {k_pt:.4f} · "
                    f"Berezhkovskiy {k_bz:.4f}"
                )
            )

        self._start_job("PK-Sim physiology", work, render)

    def _pkpd_ontogeny_run(self) -> None:
        """The hepatic ontogeny curves over the first five years."""
        if not self._require_pharmaml() or not self._require("matplotlib", "the figure"):
            return

        def work() -> Any:
            import numpy as np

            from pharmaml.pkpd.physiology import ontogeny_factor

            ages = np.linspace(0.0, 5.0, 121)
            pmas = ages + 40.0 * 7.0 / 365.25
            curves = {
                "CYP3A4": [ontogeny_factor("CYP3A4", p) for p in pmas],
                "CYP3A7": [ontogeny_factor("CYP3A7", p) for p in pmas],
                "UGT2B7": [ontogeny_factor("UGT2B7", p) for p in pmas],
            }
            return ages, curves

        def render(payload: Any) -> None:
            ages, curves = payload
            if self.deps.get("matplotlib"):
                try:
                    import matplotlib.pyplot as plt

                    figure, axis = plt.subplots(figsize=(6.4, 3.4), dpi=120)
                    for label, values in curves.items():
                        axis.plot(ages, values, linewidth=2.0, label=label)
                    axis.axhline(1.0, color="0.6", linewidth=0.8, linestyle="--")
                    axis.set_xlabel("post-menstrual age (years)")
                    axis.set_ylabel("ontogeny factor (adult = 1)")
                    axis.set_title("Hepatic enzyme ontogeny — PK-Sim tables")
                    axis.legend(frameon=False, fontsize=8)
                    axis.spines[["top", "right"]].set_visible(False)
                    figure.tight_layout()
                    self._render_figure(self._physio_host, figure)
                except Exception as exc:  # noqa: BLE001
                    self._show_error("Plot failed", exc)

        self._start_job("Ontogeny curves", work, render)

    def _pkpd_events_run(self) -> None:
        """A repeated-infusion regimen through the event grammar."""
        if not self._require_pharmaml() or not self._require("numpy", "the engine"):
            return
        try:
            dose = float(self._ev_dose.get())
            rate = float(self._ev_rate.get())
            addl = int(float(self._ev_addl.get()))
            ii = float(self._ev_ii.get())
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        def work() -> Any:
            import numpy as np

            from pharmaml.pkpd.events import ev, simulate_regimen

            grid = np.arange(0.0, (addl + 1) * ii + 24.0, 0.5)
            sol = simulate_regimen(
                lambda t, y: -0.03 * y, [0.0], grid,
                [ev(dose, rate=rate, ii=ii, addl=addl)],
            )
            conc = sol.concentration(0, volume=100.0)
            auc = float(np.trapezoid(conc, grid)) if hasattr(np, "trapezoid") else float(
                np.trapz(conc, grid)
            )
            return grid, conc, sol, auc

        def render(payload: Any) -> None:
            grid, conc, sol, auc = payload
            peak = int(conc.argmax())
            tmax = float(grid[peak])
            infusion_end = dose / rate
            self._events_result.configure(
                text=(
                    f"{addl + 1} infusions of {dose:g} mg at {rate:g} mg/h "
                    f"(duration {infusion_end:g} h) q{ii:g}h — V 100 L, CL 3 L/h\\n"
                    f"tmax {tmax:g} h (infusion end {infusion_end:g} h: the peak "
                    f"sits exactly at the infusion end, mrgsolve's own "
                    f"acceptance number) · Cmax {conc[peak]:.4g} mg/L · "
                    f"AUC {auc:.5g} mg·h/L · {sol.n_steps} RK45 steps"
                )
            )
            if self.deps.get("matplotlib"):
                try:
                    import matplotlib.pyplot as plt

                    figure, axis = plt.subplots(figsize=(6.4, 3.4), dpi=120)
                    axis.plot(grid, conc, linewidth=2.0)
                    axis.axvline(infusion_end, color="0.6", linewidth=0.8,
                                 linestyle="--")
                    axis.set_xlabel("time (h)")
                    axis.set_ylabel("concentration (mg/L)")
                    axis.set_title("Repeated infusions through the ev() grammar")
                    axis.spines[["top", "right"]].set_visible(False)
                    figure.tight_layout()
                    self._render_figure(self._events_host, figure)
                except Exception as exc:  # noqa: BLE001
                    self._show_error("Plot failed", exc)

        self._start_job("Event grammar", work, render)

    def _pkpd_grammar_run(self) -> None:
        """The grammar derivations, as text."""
        if not self._require_pharmaml():
            return

        def work() -> Any:
            from pharmaml.pkpd.events import addl_until, ev, ev_days, ev_seq, realize_addl

            rows = ev_seq(ev(100.0, ii=24.0, addl=2), ev(50.0), wait=10.0)
            return (
                addl_until(0.0, 24.0, 120.0, convention="mrgsolve"),
                addl_until(0.0, 24.0, 120.0, convention="rxode2"),
                [r.time for r in rows],
                [r.time for r in ev_days(100.0, ["m", "w", "f"])],
                [r.time for r in realize_addl(ev(50.0, ii=12.0, addl=3))],
            )

        def render(payload: Any) -> None:
            mrg, rx, seq_times, days, realized = payload
            self._events_result.configure(
                text=(
                    f"until 120 q24h from t0: addl = {mrg} (mrgsolve — doses "
                    f"stop strictly before until) vs {rx} (rxode2 — the "
                    f"boundary dose is scheduled)\\n"
                    f"ev_seq(ev(100, ii=24, addl=2), ev(50), wait=10): doses "
                    f"at {seq_times}\\n"
                    f"ev_days(100, [m, w, f]): doses at {days}\\n"
                    f"realize_addl(ev(50, ii=12, addl=3)): {realized}"
                )
            )

        self._start_job("Event grammar demo", work, render)

    def _pkpd_sensitivity_run(self) -> None:
        """AUC and Cmax elasticities on a one-compartment IV bolus."""
        if not self._require_pharmaml() or not self._require("numpy", "the engine"):
            return
        try:
            dose = float(self._sens_dose.get())
            cl = float(self._sens_cl.get())
            v = float(self._sens_v.get())
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        def work() -> Any:
            from pharmaml.pkpd.sensitivity import sensitivity_analysis

            def auc(params):
                return dose / params["CL"]

            def cmax(params):
                return dose / params["V"]

            auc_res = sensitivity_analysis(auc, {"CL": cl, "V": v}, "AUC_inf")
            cmax_res = sensitivity_analysis(cmax, {"CL": cl, "V": v}, "C_max")
            return auc_res, cmax_res

        def render(payload: Any) -> None:
            auc_res, cmax_res = payload
            a_cl = auc_res.value_for("CL")
            a_v = auc_res.value_for("V")
            c_cl = cmax_res.value_for("CL")
            c_v = cmax_res.value_for("V")
            kept = list(auc_res.thresholded()["Parameter"])
            self._sens_result.configure(
                text=(
                    f"AUC_inf = D/CL: elasticity(CL) = {a_cl:+.4f} · "
                    f"elasticity(V) = {a_v:+.4f}\\n"
                    f"C_max = D/V: elasticity(CL) = {c_cl:+.4f} · "
                    f"elasticity(V) = {c_v:+.4f}\\n"
                    f"-1 = +10 % parameter → -10 % PK parameter (the OSP "
                    f"value convention); 90 %-threshold keeps {kept}"
                )
            )
            if self.deps.get("matplotlib"):
                try:
                    import matplotlib.pyplot as plt

                    figure, axis = plt.subplots(figsize=(6.4, 3.4), dpi=120)
                    names = ["CL", "V", "CL", "V"]
                    values = [a_cl, a_v, c_cl, c_v]
                    colors = ["#2a9d8f", "#2a9d8f", "#e76f51", "#e76f51"]
                    axis.barh(range(4), values, color=colors, height=0.6)
                    axis.set_yticks(range(4))
                    axis.set_yticklabels(
                        ["AUC·CL", "AUC·V", "Cmax·CL", "Cmax·V"], fontsize=8
                    )
                    axis.axvline(0.0, color="0.3", linewidth=0.8)
                    axis.set_xlabel("normalised sensitivity (elasticity)")
                    axis.set_title("Sensitivities — the OSP 90/95/105/110 % runs")
                    axis.spines[["top", "right"]].set_visible(False)
                    figure.tight_layout()
                    self._render_figure(self._sens_host, figure)
                except Exception as exc:  # noqa: BLE001
                    self._show_error("Plot failed", exc)

        self._start_job("Sensitivity", work, render)

    def _pkpd_registry_run(self) -> None:
        """The 31-entry PK-parameter registry as text."""
        if not self._require_pharmaml():
            return

        def work() -> Any:
            from pharmaml.pkpd.sensitivity import PK_PARAMETER_REGISTRY

            modes = {}
            for entry in PK_PARAMETER_REGISTRY.values():
                modes[entry.mode] = modes.get(entry.mode, 0) + 1
            names = [n for n in PK_PARAMETER_REGISTRY if "tD" in n]
            return len(PK_PARAMETER_REGISTRY), modes, names[:6]

        def render(payload: Any) -> None:
            total, modes, multi = payload
            self._sens_result.configure(
                text=(
                    f"{total} parameters shipped in "
                    f"OSPSuite.PKParameters.xml — modes: "
                    f"{modes}\\n"
                    f"multi-dose variants (tD1-tD2 / tDlast windows): "
                    f"{len(multi)}+, e.g. {', '.join(multi)}"
                )
            )

        self._start_job("PK registry", work, render)

'''

SELFTEST_ANCHOR = "    app.destroy()\n    print(\n        \"self-test: UI built, every tab visited, manual hyperparameters \""

SELFTEST = '''    # -- Round 176: PK-Sim physiology, event grammar, OSPSuite-R ---- #
    # the three engines the new cards carry, exercised headlessly and
    # asserted loudly: the ICRP reference individual, GFR/BSA, the
    # ontogeny interpolation, the four Kp methods, the IVIVE
    # conversions, both until conventions, the regimen semantics and
    # the sensitivity/registry/path machinery
    _phys = _importlib.import_module("pharmaml.pkpd.physiology")
    _ev = _importlib.import_module("pharmaml.pkpd.events")
    _sens = _importlib.import_module("pharmaml.pkpd.sensitivity")

    _ind176 = _phys.create_individual(age_years=30.0, gender="MALE")
    assert abs(_ind176["Organism|Weight"] - 73.0) < 1e-9, _ind176
    assert abs(_ind176["Organism|Hematocrit"] - 0.47) < 1e-9
    assert abs(_ind176["Liver|Volume"] - 2.3578466712) < 1e-6
    assert abs(_phys.gfr_reference(30.0) - 0.266) < 1e-3, "PK-Sim's own pin"
    assert abs(_phys.bsa_mosteller(73.0, 176.0) - 1.8892) < 1e-3
    assert abs(_phys.ontogeny_factor("CYP3A4", 0.8) - 0.136) < 1e-3
    assert abs(_phys.ontogeny_factor("CYP3A7", 2.0) - 0.025) < 1e-3
    assert abs(_phys.kp_poulin_theil(2.0, 1.0, "Liver") - 3.6689) < 1e-3
    assert abs(_phys.kp_rodgers_rowland(2.0, 1.0, "Liver") - 2.7227) < 1e-3
    assert abs(
        _phys.clint_to_clspec(
            clint_per_protein=math.log(1.0 / 0.8) / 20.0,
            liver_to_protein=400.0, fu_mic_value=0.28476, f_cell=0.667,
        ) - 23.497
    ) < 1e-2, "InVitroSpecificClearanceSpecs"
    assert _ev.addl_until(0.0, 24.0, 120.0, convention="mrgsolve") == 4
    assert _ev.addl_until(0.0, 24.0, 120.0, convention="rxode2") == 5
    _grid176 = np.arange(0.0, 121.0, 1.0)
    _sol176 = _ev.simulate_regimen(
        lambda t, y: -0.03 * y, [0.0], _grid176, [_ev.ev(3000.0, rate=30.0)]
    )
    assert float(_grid176[int(np.argmax(_sol176.states[:, 0]))]) == 100.0
    _ss176 = _ev.simulate_regimen(
        lambda t, y: -0.065 * y, [0.0], [6.0],
        [_ev.ev(0.0, rate=25.0, ss=1, ii=12.0)],
    )
    assert abs(float(_ss176.concentration(0, volume=20.0)[0]) - 25.0 / 1.3) < 1e-4
    assert [r.time for r in _ev.ev_days(100.0, ["m", "w", "f"])] == [0.0, 48.0, 96.0]
    assert len(_sens.PK_PARAMETER_REGISTRY) == 31
    _res176 = _sens.sensitivity_analysis(
        lambda p: 100.0 / p["CL"], {"CL": 5.0, "V": 20.0}, "AUC_inf"
    )
    assert abs(_res176.value_for("CL") + 1.0) < 1e-6
    assert abs(_res176.value_for("V")) < 1e-6
    assert list(_res176.thresholded()["Parameter"]) == ["CL"]
    assert _sens.match_paths(
        "Organism|*|Volume",
        ["Organism|Liver|Volume", "Organism|Liver|Plasma|Volume"],
    ) == ["Organism|Liver|Volume"]
    _ic176 = _sens.create_individual_characteristics(
        "Human", population="European_ICRP_2002", age=43.0
    )
    assert _ic176.gestational_age.value == 40.0

'''

PRINT_ANCHOR = '''        "self-test: UI built, every tab visited, manual hyperparameters "
        + progress/ETA verified, PK/PD engines (ODE cross-validation, "
        superposition, FOCEi-lite fit, DDI network, model library, Qt "
        probe) asserted, no errors"'''


def splice_once(text: str, anchor: str, insert: str, before: bool, label: str) -> str:
    if insert[:200] in text:
        print(f"{label}: already present, skipped")
        return text
    if anchor not in text:
        raise SystemExit(f"{label}: ANCHOR NOT FOUND: {anchor[:80]!r}")
    return text.replace(anchor, insert + anchor if before else anchor + insert, 1)


def main() -> None:
    text = PLAYGROUND.read_text(encoding="utf-8")
    text = splice_once(text, CARDS_ANCHOR, CARDS, before=True, label="cards")
    text = splice_once(text, HANDLERS_ANCHOR, HANDLERS, before=True, label="handlers")
    text = splice_once(text, SELFTEST_ANCHOR, SELFTEST, before=True, label="self-test")
    PLAYGROUND.write_text(text, encoding="utf-8")
    print("spliced: cards + handlers + self-test block")


if __name__ == "__main__":
    main()
