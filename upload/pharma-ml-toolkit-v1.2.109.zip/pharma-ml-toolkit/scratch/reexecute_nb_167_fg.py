"""Foreground notebook re-execution: one notebook per invocation.

The sandbox reaps background (setsid) drivers mid-run and the 4 GB
ceiling OOMs concurrent ones, so the 1.2.101 re-execution runs in the
foreground: ``python scratch/reexecute_nb_167_fg.py <notebook.ipynb>``
re-executes exactly one notebook through the reply-first,
iopub-drain-later kernel driving (the reexecute_nb_166.py contract,
including the site-packages scrub), writing the executed file before
exit.

Run: python scratch/reexecute_nb_167_fg.py complete_ml_workflow.ipynb
     python scratch/reexecute_nb_167_fg.py pharmaml_walkthrough.ipynb
"""
from __future__ import annotations

import os
import sys
import sysconfig
import time
from pathlib import Path

for _var in ("LOKY_MAX_CPU_COUNT", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
             "OPENBLAS_NUM_THREADS"):
    os.environ.setdefault(_var, "1")
os.environ.pop("MPLBACKEND", None)

import nbformat
from jupyter_client.manager import KernelManager

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / "examples"
_SITE_PACKAGES = sysconfig.get_paths()["purelib"]


def _execute_notebook(path: Path) -> tuple[int, int, int]:
    """Run every code cell in one fresh kernel, outputs into the nb."""
    nb = nbformat.read(path, as_version=4)
    for cell in nb.cells:
        if cell.cell_type == "code":
            cell.outputs = []
            cell.execution_count = None

    km = KernelManager(kernel_name="python3")
    km.start_kernel(cwd=str(path.parent))
    kc = km.client()
    kc.start_channels()
    try:
        kc.wait_for_ready(timeout=120)
        for cell in nb.cells:
            if cell.cell_type != "code":
                continue
            print(f"  cell: {(cell.source or '').splitlines()[0][:70]}", flush=True)
            msg_id = kc.execute(cell.source)
            outputs: list[dict] = []
            execution_count = None
            reply = kc.get_shell_msg(timeout=3600)
            while reply.get("parent_header", {}).get("msg_id") != msg_id:
                reply = kc.get_shell_msg(timeout=3600)
            deadline = time.monotonic() + 5.0
            while True:
                try:
                    msg = kc.get_iopub_msg(timeout=1.0)
                except Exception:  # noqa: BLE001 - queue drained
                    if time.monotonic() > deadline:
                        break
                    continue
                if msg["parent_header"].get("msg_id") != msg_id:
                    deadline = time.monotonic() + 5.0
                    continue
                kind = msg["msg_type"]
                content = msg["content"]
                if kind == "status":
                    if content["execution_state"] == "idle":
                        break
                    continue
                deadline = time.monotonic() + 5.0
                if kind == "execute_input":
                    execution_count = content["execution_count"]
                elif kind == "error":
                    outputs.append({
                        "output_type": "error",
                        "ename": content["ename"],
                        "evalue": content["evalue"],
                        "traceback": content.get("traceback", []),
                    })
                elif kind == "stream":
                    outputs.append({
                        "output_type": "stream",
                        "name": content["name"],
                        "text": content["text"],
                    })
                elif kind in ("execute_result", "display_data"):
                    entry = {
                        "output_type": kind,
                        "data": content["data"],
                        "metadata": content.get("metadata", {}),
                    }
                    if kind == "execute_result":
                        entry["execution_count"] = execution_count
                    outputs.append(entry)
            cell.outputs = [nbformat.from_dict(o) for o in outputs]
            if execution_count is not None:
                cell.execution_count = execution_count
        for cell in nb.cells:
            for output in cell.get("outputs", []):
                if output.get("output_type") == "stream":
                    raw = output.get("text", "")
                    if isinstance(raw, str):
                        raw = [raw]
                    joined = "".join(
                        t.replace(_SITE_PACKAGES + "/", "site-packages/")
                        for t in raw
                    )
                    output["text"] = joined.splitlines(keepends=True)
        nbformat.write(nb, path)
        code_cells = [c for c in nb.cells if c.cell_type == "code"]
        executed = sum(1 for c in code_cells if c.get("execution_count"))
        errors = [
            o for c in code_cells for o in c.get("outputs", [])
            if o.get("output_type") == "error"
        ]
        return len(code_cells), executed, len(errors)
    finally:
        try:
            kc.stop_channels()
            km.shutdown_kernel(now=True)
        except Exception as exc:  # noqa: BLE001 - best-effort teardown
            print(f"kernel teardown note: {exc}", flush=True)


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: reexecute_nb_167_fg.py <notebook.ipynb>", file=sys.stderr)
        return 2
    path = EXAMPLES / sys.argv[1]
    print(f"== {sys.argv[1]}", flush=True)
    started = time.perf_counter()
    cells, executed, errors = _execute_notebook(path)
    print(
        f"   {executed}/{cells} cells, {errors} error(s), "
        f"{time.perf_counter() - started:.0f}s",
        flush=True,
    )
    return 1 if errors or executed != cells else 0


if __name__ == "__main__":
    sys.exit(main())
