#!/usr/bin/env python3
"""Round-182 verification, part 2: the v1.2.104 restoration.

The second snapshot swap also destroyed the v1.2.104 round (the
descriptor bits/radius knobs and the 3D viewer's scaling fix).  This
script re-verifies the re-applied implementations end to end:

1. backend ``compute_feature_frame`` honours morgan_bits/morgan_radius
   (width exact, six families, ecfp3 radius-invariant, bounds rejected
   before any RDKit call);
2. the feature-factory card carries the two entries and threads them;
   the live width preview honours the bits entry;
3. the Tanimoto card carries bits/radius and threads
   ``compute_fingerprints(radius=..., n_bits=...)``;
4. the 3D viewer draws vdW-proportional zoom-linear discs (no 4px
   floor) and greedy non-overlapping labels (label count < atom count
   on a crowded molecule);
5. the CLI subprocess test is hermetic (PYTHONPATH pinned).
"""
from __future__ import annotations

import inspect
import os
import subprocess
import sys
import time
from pathlib import Path

TOOLKIT = Path(__file__).resolve().parents[1]
os.chdir(TOOLKIT)
sys.path.insert(0, str(TOOLKIT))
sys.path.insert(0, str(TOOLKIT / "src"))

PASS: list[str] = []
FAIL: list[str] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    (PASS if ok else FAIL).append(f"{name}{(' — ' + detail) if detail else ''}")
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail else ""))


def main() -> int:
    # ---- 1. backend knobs ----------------------------------------- #
    from pharmaml.chem.features import compute_feature_frame

    frame, report = compute_feature_frame(
        ["CC(=O)Oc1ccccc1C(=O)O", "CCO"],
        families=("ecfp", "fcfp", "morgan_scaffold"),
        morgan_bits=64,
        morgan_radius=1,
    )
    check("backend reshapes to 64 bits x 3 families", frame.shape == (2, 192),
          f"{frame.shape}")
    check("column names carry the width",
          frame.columns[0] == "ecfp_bit_0" and frame.columns[-1] == "fcfp_bit_63")
    check("family widths reported", set(report.families.values()) == {64})
    frame3, _ = compute_feature_frame(["CCO"], families=("ecfp3",), morgan_bits=128)
    check("ecfp3 width follows bits", frame3.shape[1] == 128)
    import numpy as np

    far, _ = compute_feature_frame(["CCO"], families=("ecfp3",), morgan_radius=0)
    fbar, _ = compute_feature_frame(["CCO"], families=("ecfp3",), morgan_radius=16)
    check("ecfp3 radius-invariant", np.array_equal(far.values, fbar.values))
    for bad in ({"morgan_bits": 31}, {"morgan_bits": 65537}, {"morgan_radius": 17},
                {"morgan_bits": True}):
        try:
            compute_feature_frame(["CCO"], families=("ecfp",), **bad)
            check(f"backend rejects {bad}", False, "no raise")
        except ValueError as exc:
            check(f"backend rejects {bad}", True, str(exc)[:52])

    # ---- 2+3. GUI plumbing (source-verified, display-free) --------- #
    import playground  # noqa: PLC0415

    check("feature_factory_width has morgan_bits",
          "morgan_bits" in inspect.signature(playground.feature_factory_width).parameters)
    check("width helper honours Morgan families",
          playground.feature_factory_width(("ecfp", "maccs"), 43, 64) == 64 + 167
          and playground.feature_factory_width(("descriptors", "ecfp"), 43, 64) == 43 + 64)
    src = inspect.getsource(playground.PlaygroundApp._feat_compute)
    check("_feat_compute parses _feat_bits/_feat_radius",
          "_feat_bits" in src and "_feat_radius" in src and "morgan_bits=morgan_bits" in src)
    build_src = inspect.getsource(playground.PlaygroundApp._build_chemistry_tab)
    check("feature-factory card builds the two entries",
          "_feat_bits" in build_src and "_feat_radius" in build_src)
    tani_src = inspect.getsource(playground.PlaygroundApp._compare_similarity)
    check("Tanimoto threads radius/n_bits",
          "_tani_bits" in tani_src and "n_bits=bits" in tani_src and "radius=radius" in tani_src)

    # ---- 4. the 3D viewer under Xvfb ------------------------------- #
    display = ":92"
    proc = subprocess.Popen(
        ["Xvfb", display, "-screen", "0", "1400x900x24"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    sock = Path(f"/tmp/.X11-unix/X{display[1:]}")
    deadline = time.time() + 10.0
    while time.time() < deadline and not sock.exists():
        time.sleep(0.1)
    os.environ["DISPLAY"] = display
    try:
        app = playground.PlaygroundApp(persist_session=False)
        app.update_idletasks()
        app.update()
        app._view3d_smiles.delete(0, "end")
        app._view3d_smiles.insert(0, "CC(=O)Oc1ccccc1C(=O)O")  # 13 heavy atoms
        app._view3d_build()
        # the build runs off-thread -- pump the Tk loop until the job
        # queue drains (the suite's own probe pattern), then measure.
        deadline = time.time() + 60.0
        while time.time() < deadline and getattr(app, "_busy", False):
            app.update()
            time.sleep(0.02)
        app.update()
        canvas = app._view3d_canvas
        # the app's default selection highlights the oxygens only (4
        # discs) -- for the scaling checks draw EVERY atom: no selection
        # means all atoms, no halos.
        app._view3d_selection_ids = lambda mol, coords: (None, "")
        app._view3d_draw()
        app.update()
        # disc radii: read back the drawn ovals' bbox sizes per atom colour
        # -- aspirin has C (grey) and O (red) discs; their radii must
        # differ by the vdW ratio (1.70/1.52 = 1.118).  Selection halos
        # are outline-only -- excluded via the fill probe.
        def disc_radii(cv):
            sizes = set()
            for i in cv.find_withtag("all"):
                if cv.type(i) == "oval" and str(cv.itemcget(i, "fill")) not in ("", "none"):
                    c = cv.coords(i)
                    sizes.add(round((c[2] - c[0]) / 2, 1))
            return sorted(sizes)

        sizes = disc_radii(canvas)
        check("disc radii vary (no 4px floor)", len(sizes) >= 2, f"radii={sizes}")
        texts = [i for i in canvas.find_withtag("all") if canvas.type(i) == "text"]
        check("labels < atoms (greedy pass)", len(texts) < 13, f"{len(texts)} labels")
        # zoom linearity: redraw at 2x, the C disc must double
        app._view3d_zoom.set("2.0")
        app._view3d_draw()
        app.update()
        sizes2 = disc_radii(canvas)
        ratio = sizes2[-1] / sizes[-1] if sizes and sizes2 else 0.0
        check("zoom 2x doubles the largest disc", abs(ratio - 2.0) < 0.05,
              f"ratio={ratio:.3f}")
        app._view3d_zoom.set("0.5")
        app._view3d_draw()
        app.update()
        sizes3 = disc_radii(canvas)
        ratio_half = sizes3[-1] / sizes[-1] if sizes and sizes3 else 0.0
        check("zoom 0.5x halves the largest disc", abs(ratio_half - 0.5) < 0.05,
              f"ratio={ratio_half:.3f}")
        app.destroy()
    finally:
        proc.terminate()

    # ---- 5. hermetic CLI test -------------------------------------- #
    test_src = (TOOLKIT / "tests" / "test_cli_features.py").read_text(encoding="utf-8")
    check("CLI subprocess test pins PYTHONPATH",
          'env={**os.environ, "PYTHONPATH": toolkit_src}' in test_src)

    print()
    print(f"{len(PASS)} passed, {len(FAIL)} failed")
    if FAIL:
        for line in FAIL:
            print("  FAIL:", line)
        return 1
    print("ALL GREEN")
    return 0


if __name__ == "__main__":
    sys.exit(main())
