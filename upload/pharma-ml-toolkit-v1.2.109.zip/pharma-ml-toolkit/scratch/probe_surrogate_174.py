"""Probe the round-100x-174 surrogate-explanations card end to end."""

from __future__ import annotations

import sys
import time

import playground


def wait_for_job(app: object, timeout_s: float = 90.0) -> None:
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        app.update()
        if not app._busy:  # type: ignore[attr-defined]
            app.update()
            return
        time.sleep(0.02)
    raise TimeoutError("the job never finished")


def main() -> int:
    app = playground.PlaygroundApp(persist_session=False)
    for _ in range(4):
        app.update_idletasks()
        app.update()
    index = app._book.index("end")
    for i in range(index):
        app._book.select(i)
        app.update()
        if "Data & ML" in app._book.tab(i, "text"):
            break
    app.update()

    app._surrogate_run()
    wait_for_job(app)
    text = app._sur_result.cget("text")
    assert "LIME" in text and "break-down" in text and "EBM" in text, text
    assert app._sur_host.winfo_children(), "the surrogate figure rendered"
    print("surrogate card line 1:", text.splitlines()[0][:90])
    print("surrogate card line 2:", text.splitlines()[1][:90])

    # a different seed / strength flows through
    app._sur_seed.delete(0, "end")
    app._sur_seed.insert(0, "21")
    app._sur_strength.delete(0, "end")
    app._sur_strength.insert(0, "8")
    app._surrogate_run()
    wait_for_job(app)
    text2 = app._sur_result.cget("text")
    assert text2 != text, "the card responds to its inputs"
    app.destroy()
    print("probe: surrogate card exercised end to end, no errors")
    return 0


if __name__ == "__main__":
    sys.exit(main())
