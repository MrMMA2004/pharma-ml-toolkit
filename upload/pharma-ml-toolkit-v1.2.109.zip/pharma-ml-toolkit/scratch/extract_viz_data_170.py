"""Extract the visualization color data for viz/_palette_data.py (100x-170).

Provenance machine, not a test: this script is run ONCE in the venv that
has matplotlib (the ``reports`` extra) to materialise the color tables
the five visualization repositories ship as data:

* matplotlib 3.9.2 ``colormaps`` registry -- the five perceptual
  colormaps (viridis/plasma/inferno/magma/cividis, CC0 data by
  Nathaniel Smith & Stéfan van der Walt) sampled at the full 256-step
  lookup resolution, plus the qualitative tab10/tab20 lists and the
  CSS4 (148) + TABLEAU (10) named-color dictionaries;
* bokeh's ``src/bokeh/palettes.py`` (BSD-3-Clause, data itself CC0 /
  Apache-2.0 ColorBrewer) -- the ColorBrewer families we embed;
* seaborn's ``seaborn/palettes.py`` (BSD-3-Clause) -- the six
  SEABORN_PALETTES hex cycles (+ their 6-color subsets);
* plotly.py's ``_plotly_utils/colors/qualitative.py`` (MIT) -- the
  Plotly and D3 default qualitative sequences.

The output is committed as ``src/pharmaml/viz/_palette_data.py`` so the
toolkit never needs matplotlib/bokeh/seaborn/plotly installed to use
the data -- importing them stays optional exactly as before.
"""

from __future__ import annotations


import re
from pathlib import Path

import numpy as np

REPOS = Path("/tmp/viz-repos")
OUT = Path(__file__).resolve().parent.parent / "src" / "pharmaml" / "viz" / "_palette_data.py"

PERCEPTUAL = ("viridis", "plasma", "inferno", "magma", "cividis")
# ColorBrewer families from bokeh's palettes.py: (family, sizes we take)
BREWER_FAMILIES = (
    ("Spectral", 11), ("RdBu", 11), ("RdYlBu", 11), ("BrBG", 11), ("PiYG", 11),
    ("PRGn", 11), ("PuOr", 11), ("RdYlGn", 11), ("RdGy", 11),
    ("Blues", 9), ("Greens", 9), ("Greys", 9), ("Oranges", 9), ("Reds", 9),
    ("Purples", 9), ("BuGn", 9), ("BuPu", 9), ("GnBu", 9), ("OrRd", 9),
    ("PuBu", 9), ("PuBuGn", 9), ("PuRd", 9), ("RdPu", 9), ("YlGn", 9),
    ("YlGnBu", 9), ("YlOrBr", 9), ("YlOrRd", 9),
    ("Set1", 9), ("Set2", 8), ("Set3", 12), ("Paired", 12), ("Accent", 8),
    ("Dark2", 8), ("Pastel1", 9), ("Pastel2", 8),
)


def _rgb_to_hex(rgb: tuple[float, float, float]) -> str:
    return "#{:02x}{:02x}{:02x}".format(*(int(round(c * 255)) for c in rgb[:3]))


def extract_matplotlib() -> dict[str, list[str]]:
    from matplotlib import colormaps

    out: dict[str, list[str]] = {}
    for name in PERCEPTUAL:
        lut = colormaps[name].resampled(256)(np.linspace(0.0, 1.0, 256))
        out[name] = [_rgb_to_hex(tuple(row)) for row in lut]
    for qual in ("tab10", "tab20"):
        out[qual] = [_rgb_to_hex(tuple(c)) for c in colormaps[qual].colors]
    # 11-step coolwarm control points (matplotlib's segment-based map)
    lut = colormaps["coolwarm"].resampled(11)(np.linspace(0.0, 1.0, 11))
    out["coolwarm"] = [_rgb_to_hex(tuple(row)) for row in lut]
    return out


def extract_bokeh() -> dict[str, list[str]]:
    import ast

    tree = ast.parse(
        (REPOS / "bokeh" / "src" / "bokeh" / "palettes.py").read_text(encoding="utf-8")
    )
    values: dict[str, list[str]] = {}
    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        target = node.targets[0]
        if not isinstance(target, ast.Name):
            continue
        literal = node.value
        if isinstance(literal, ast.Tuple) and all(
            isinstance(item, ast.Constant) and isinstance(item.value, str) for item in literal.elts
        ):
            values[target.id] = [item.value for item in literal.elts]
    out: dict[str, list[str]] = {}
    for family, size in BREWER_FAMILIES:
        # bokeh's naming: digit-ending families take an underscore before the size
        sep = "_" if family[-1].isdigit() else ""
        out[family] = values[f"{family}{sep}{size}"]
    return out


def extract_seaborn() -> dict[str, list[str]]:
    text = (REPOS / "seaborn" / "seaborn" / "palettes.py").read_text(encoding="utf-8")
    match = re.search(r"SEABORN_PALETTES = dict\((.*?)\n\)", text, re.DOTALL)
    if match is None:
        raise RuntimeError("SEABORN_PALETTES not found")
    body = match.group(1)
    palettes: dict[str, list[str]] = {}
    for name, values in re.findall(r"(\w+)=\[(.*?)\]", body, re.DOTALL):
        palettes[name] = re.findall(r"[\"'](#[0-9a-fA-F]{6})[\"']", values)
    return palettes


def extract_plotly() -> dict[str, list[str]]:
    import ast

    tree = ast.parse(
        (REPOS / "plotly_py" / "_plotly_utils" / "colors" / "qualitative.py").read_text(
            encoding="utf-8"
        )
    )
    values: dict[str, list[str]] = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name):
            literal = node.value
            if isinstance(literal, (ast.List, ast.Tuple)) and all(
                isinstance(item, ast.Constant) and isinstance(item.value, str)
                for item in literal.elts
            ):
                values[node.targets[0].id] = [item.value for item in literal.elts]
    return {"Plotly": values["Plotly"], "D3": values["D3"]}


def extract_named() -> tuple[dict[str, str], dict[str, str]]:
    from matplotlib import _color_data

    css4 = {k: v.lower() for k, v in _color_data.CSS4_COLORS.items()}
    tableau = {k: v.lower() for k, v in _color_data.TABLEAU_COLORS.items()}
    return css4, tableau


def fmt_seq(colors: list[str], per_line: int = 4) -> str:
    lines = []
    for i in range(0, len(colors), per_line):
        chunk = ", ".join(f'"{c}"' for c in colors[i : i + per_line])
        lines.append(f"    {chunk},")
    return "\n".join(lines)


def main() -> None:
    mpl = extract_matplotlib()
    bokeh = extract_bokeh()
    seaborn = extract_seaborn()
    plotly = extract_plotly()
    css4, tableau = extract_named()

    blocks: list[str] = []
    blocks.append(
        '"""Color data tables for the five visualization repositories (100x-170).\n\n'
        "GENERATED by ``scratch/extract_viz_data_170.py`` -- do not edit by hand;\n"
        "re-run the extractor after upgrading any upstream source.  Every table\n"
        "below is data the source projects ship as literal Python, embedded so\n"
        ":mod:`pharmaml.viz` needs none of them installed:\n\n"
        "* the five perceptual colormaps (256-step lookup tables), ``tab10``/\n"
        "  ``tab20`` and ``coolwarm`` sampled from matplotlib 3.9.2 (PSF-style\n"
        "  license; the perceptual maps themselves are CC0 public domain by\n"
        "  Nathaniel Smith, Eric Firing & Stéfan van der Walt);\n"
        "* ColorBrewer families extracted from bokeh's ``palettes.py``\n"
        "  (BSD-3-Clause; ColorBrewer data (c) Cynthia Brewer, Apache-2.0);\n"
        "* the six seaborn default qualitative cycles from\n"
        "  ``seaborn/palettes.py`` (BSD-3-Clause, Michael Waskom);\n"
        "* the Plotly and D3 qualitative sequences from plotly.py's\n"
        "  ``_plotly_utils/colors/qualitative.py`` (MIT, Plotly);\n"
        "* matplotlib's CSS4 (148) and TABLEAU (10) named colors\n"
        "  (public domain / BSD respectively).\n\n"
        "Attribution requirements are satisfied by this header; the toolkit's\n"
        "BSD-2-Clause redistribution is compatible with every source license\n"
        "listed above.\n"
        '"""'
    )
    blocks.append("\nfrom __future__ import annotations\n")
    blocks.append("\n__all__ = [\n" + "".join(f'    "{n}",\n' for n in (
        "BREWER", "CSS4_COLORS", "D3", "NAMED_COLORS", "PERCEPTUAL_CMAPS", "PLOTLY",
        "SEABORN_PALETTES", "TABLEAU_COLORS", "TAB_CMAPS",
    )) + "]\n")

    blocks.append("\n#: 256-step hex lookup tables (matplotlib perceptual colormaps, CC0).")
    blocks.append("PERCEPTUAL_CMAPS: dict[str, tuple[str, ...]] = {")
    for name in PERCEPTUAL:
        blocks.append(f'    "{name}": (\n{fmt_seq(mpl[name])}\n    ),')
    blocks.append("}")
    blocks.append("\n#: Qualitative matplotlib tables (exact indexed colors).")
    blocks.append("TAB_CMAPS: dict[str, tuple[str, ...]] = {")
    for name in ("tab10", "tab20", "coolwarm"):
        blocks.append(f'    "{name}": (\n{fmt_seq(mpl[name], 6)}\n    ),')
    blocks.append("}")
    blocks.append("\n#: ColorBrewer families (bokeh palettes.py, Apache-2.0 data).")
    blocks.append("BREWER: dict[str, tuple[str, ...]] = {")
    for family, _size in BREWER_FAMILIES:
        blocks.append(f'    "{family}": (\n{fmt_seq(bokeh[family], 6)}\n    ),')
    blocks.append("}")
    blocks.append("\n#: seaborn's six default cycles (BSD-3-Clause).")
    blocks.append("SEABORN_PALETTES: dict[str, tuple[str, ...]] = {")
    for name in sorted(seaborn):
        blocks.append(f'    "{name}": (\n{fmt_seq(seaborn[name], 5)}\n    ),')
    blocks.append("}")
    blocks.append("\n#: plotly.py's default qualitative sequences (MIT).")
    blocks.append("PLOTLY: tuple[str, ...] = (\n" + fmt_seq(plotly["Plotly"], 5) + "\n)")
    blocks.append("D3: tuple[str, ...] = (\n" + fmt_seq(plotly["D3"], 5) + "\n)")
    blocks.append("\n#: Named colors: CSS4 (public domain) + TABLEAU (BSD).")
    blocks.append("CSS4_COLORS: dict[str, str] = {")
    for i in range(0, len(css4), 6):
        chunk = ", ".join(f'"{k}": "{v}"' for k, v in sorted(css4.items())[i : i + 6])
        blocks.append(f"    {chunk},")
    blocks.append("}")
    blocks.append("TABLEAU_COLORS: dict[str, str] = {")
    for k, v in sorted(tableau.items()):
        blocks.append(f'    "{k}": "{v}",')
    blocks.append("}")
    blocks.append(
        "NAMED_COLORS: dict[str, str] = {**CSS4_COLORS, **TABLEAU_COLORS}\n"
    )

    OUT.write_text("\n".join(blocks) + "\n", encoding="utf-8")
    n_brewer = sum(len(v) for v in bokeh.values())
    print(f"wrote {OUT}")
    print(
        f"perceptual 5x{len(mpl['viridis'])} | brewer {len(bokeh)} families/"
        f"{n_brewer} colors | seaborn {len(seaborn)} cycles | "
        f"named {len(css4) + len(tableau)}"
    )


if __name__ == "__main__":
    main()
