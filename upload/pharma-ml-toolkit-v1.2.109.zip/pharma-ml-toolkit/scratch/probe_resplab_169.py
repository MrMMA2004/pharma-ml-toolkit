"""Round-169 probe: exercise every Response Lab card handler headlessly.

The three-repository absorption round (Precily / CaDRReS /
DeepResponse): six cards, six handler runs, assertions on every
table the cards fill.
"""
import sys
import time

sys.path.insert(0, ".")
import playground


def pump_until_idle(app, timeout=300.0):
    deadline = time.monotonic() + timeout
    while app._busy and time.monotonic() < deadline:
        app.update_idletasks()
        app.update()
        time.sleep(0.01)
    assert not app._busy, "job never finished"


def run(app, handler_name, *args):
    getattr(app, handler_name)(*args)
    pump_until_idle(app)


app = playground.PlaygroundApp(persist_session=False)
for _ in range(4):
    app.update_idletasks()
    app.update()

titles = [app._book.tab(i, "text").strip() for i in range(app._book.index("end"))]
assert any("Response Lab" in t for t in titles), f"tab missing: {titles}"
app._book.select(
    next(i for i, t in enumerate(titles) if "Response Lab" in t)
)
app.update()

# 1. GSVA pathway scoring (synthetic expression + demo sets)
run(app, "_resplab_run_gsva")
overview_rows = app._resplab_gsva_overview_tree.get_children()
score_rows = app._resplab_gsva_tree.get_children()
print("GSVA overview rows:", len(overview_rows))
print("GSVA score rows:", len(score_rows))
print("GSVA note:", app._resplab_gsva_note.cget("text")[:120])
assert len(overview_rows) == 3, "three demo sets expected"
assert len(score_rows) == 10, "ten synthetic cell lines expected"
first_score = app._resplab_gsva_tree.item(score_rows[2], "values")
print("cell 03 scores:", first_score)
assert float(first_score[1]) > 0.5, "cell 03 should spike PROLIFERATION"

# 1b. GSVA on the Foundations numeric block (demo sets from columns)
run(app, "_found_load_example")  # the Foundations tab's example dataset
app._resplab_gsva_use_found.set(True)
run(app, "_resplab_run_gsva")
print(
    "GSVA-foundations overview rows:",
    len(app._resplab_gsva_overview_tree.get_children()),
)
assert len(app._resplab_gsva_overview_tree.get_children()) == 3
app._resplab_gsva_use_found.set(False)

# 2. CaDRReS recommender (seeded synthetic screen)
run(app, "_resplab_run_recommender")
fit_rows = app._resplab_fit_tree.get_children()
print("RECOMMENDER rows:", len(fit_rows))
print("RECOMMENDER note:", app._resplab_fit_note.cget("text")[:120])
assert len(fit_rows) == 7
assert app._resplab_model is not None, "model stored for card 3"
assert len(app._resplab_cell_combo["values"]) == 16
tracking = app._resplab_fit_tree.item(fit_rows[5], "values")[1]
print("truth-tracking PCC:", tracking)
assert float(tracking) > 0.7, f"weak fit on synthetic truth: {tracking}"

# 3. repurposing candidates (rides card 2's model)
app._resplab_cell_combo.set(str(app._resplab_features.index[3]))
run(app, "_resplab_run_repurposing")
rank_rows = app._resplab_rank_tree.get_children()
print("REPURPOSING rows:", len(rank_rows))
print("REPURPOSING note:", app._resplab_rank_note.cget("text")[:120])
assert len(rank_rows) == 8
ranks = [
    int(app._resplab_rank_tree.item(row, "values")[0]) for row in rank_rows
]
assert sorted(ranks) == list(range(1, 9)), f"ranks not 1..8: {ranks}"

# 4. split-strategy audit (all five strategies)
run(app, "_resplab_run_audit")
audit_rows = app._resplab_audit_tree.get_children()
print("AUDIT rows:", len(audit_rows))
for row in audit_rows:
    print("  ", app._resplab_audit_tree.item(row, "values"))
print("AUDIT note:", app._resplab_audit_note.cget("text")[:140])
assert len(audit_rows) == 5, "five strategies expected"
strategies = [
    app._resplab_audit_tree.item(row, "values")[0] for row in audit_rows
]
assert strategies == [
    "random",
    "cell_stratified",
    "drug_stratified",
    "drug_cell_stratified",
    "cross_domain",
], strategies
drug_row = app._resplab_audit_tree.item(audit_rows[2], "values")
assert drug_row[3] == "--", f"drug-blind row must be unscoreable: {drug_row}"
drug_cell_row = app._resplab_audit_tree.item(audit_rows[3], "values")
assert drug_cell_row[3] == "--", f"drug-cell row must be unscoreable: {drug_cell_row}"
assert "unseen drugs AND cell lines" in drug_cell_row[5]

# 5. Bayesian sigmoid fit
run(app, "_resplab_run_bayes")
bayes_rows = app._resplab_bayes_tree.get_children()
print("BAYES rows:", len(bayes_rows))
print("BAYES note:", app._resplab_bayes_note.cget("text")[:130])
assert len(bayes_rows) == 4
ic50 = float(app._resplab_bayes_tree.item(bayes_rows[0], "values")[1])
hdi_lo = float(app._resplab_bayes_tree.item(bayes_rows[0], "values")[2])
hdi_hi = float(app._resplab_bayes_tree.item(bayes_rows[0], "values")[3])
print(f"BAYES ic50={ic50:.3f} hdi=({hdi_lo:.3f},{hdi_hi:.3f})")
assert 2.0 <= ic50 <= 8.0, f"IC50 recovery failed: {ic50}"
assert hdi_lo <= 4.0 <= hdi_hi, f"HDI must cover the truth: {hdi_lo}, {hdi_hi}"

# 6. deep ensemble (Foundations target now loaded, or sine fallback)
run(app, "_resplab_run_ensemble")
ens_rows = app._resplab_ens_tree.get_children()
print("ENSEMBLE rows:", len(ens_rows))
print("ENSEMBLE note:", app._resplab_ens_note.cget("text")[:130])
assert len(ens_rows) == 5, "five members expected"
widths = [
    int(app._resplab_ens_tree.item(row, "values")[1]) for row in ens_rows
]
assert len(set(widths)) == 5, f"members must differ in width: {widths}"

app.destroy()
print("PROBE ROUND 169: ALL CARDS OK")
