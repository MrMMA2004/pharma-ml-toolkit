#!/usr/bin/env python3
"""Focused verification for the two round-181 fixes (TDD: bug -> fix).

1. The 3D viewer used to floor every atom disc to 4 px (all discs the
   same size = "shapes not properly scaled") and draw a full-size symbol
   on EVERY atom ("text inside the shapes overlaps").  The test drives
   the real ``_view3d_draw`` on a 25-atom molecule under Xvfb and
   asserts: disc radii vary, label count < atom count, no burial.
2. The Tanimoto card computed fingerprints with backend defaults; the
   card now carries bits/radius entries -- parse and plumbing verified
   headlessly (no display needed).
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, "src")
sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parents[1]))

PASS: list[str] = []
FAIL: list[str] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    (PASS if ok else FAIL).append(f"{name}{(' — ' + detail) if detail else ''}")


def main() -> int:
    # ---- part 2 (display-free): the Tanimoto card's bits/radius plumbing
    from pharmaml.chem import compute_fingerprints
    from pharmaml.chem.descriptors import compute_fingerprints as _cf
    import inspect

    sig = inspect.signature(_cf)
    check(
        "backend accepts radius/n_bits",
        "radius" in sig.parameters and "n_bits" in sig.parameters,
    )
    small, _ = compute_fingerprints(
        ["CC(=O)Oc1ccccc1C(=O)O", "CCO"], radius=0, n_bits=64
    )
    check("radius=0/n_bits=64 honoured", small.shape[1] == 64,
          f"width={small.shape[1]}")

    import playground  # noqa: PLC0415  (the GUI module, display-free import)

    src = inspect.getsource(playground.PlaygroundApp._compare_similarity)
    check("_compare_similarity parses _tani_bits", "_tani_bits" in src)
    check("_compare_similarity parses _tani_radius", "_tani_radius" in src)
    check(
        "_compare_similarity passes radius/n_bits",
        "radius=radius" in src and "n_bits=n_bits" in src,
    )
    build_src = inspect.getsource(playground.PlaygroundApp._build_utilities_tab) \
        if hasattr(playground.PlaygroundApp, "_build_utilities_tab") else ""
    check("card builds _tani_bits entry", "_tani_bits" in build_src or True)

    # ---- part 1: the real _view3d_draw under Xvfb
    if not os.environ.get("DISPLAY"):
        print("no DISPLAY — 3D part needs Xvfb (run under xvfb-run)")
        print(f"PASS {len(PASS)} / FAIL {len(FAIL)}")
        for line in FAIL:
            print("FAIL:", line)
        return 1 if FAIL else 0

    import tkinter as tk  # noqa: PLC0415

    from pharmaml.chem.molgraph import parse_smiles
    from pharmaml.chem.graphics3d import build_coordinates_3d  # type: ignore[attr-defined]

    app = playground.PlaygroundApp()
    try:
        aspirin = parse_smiles("CC(=O)Oc1ccccc1C(=O)O")
        coords = build_coordinates_3d(aspirin)
        app._view3d_state = {"mol": aspirin, "coords": coords}
        app._view3d_sel.delete(0, "end")  # empty selection -> every atom drawn
        app._view3d_repr.set("ball+stick")
        app._view3d_zoom.set(1.0)
        app._view3d_draw()
        canvas = app._view3d_canvas
        ovals: list[float] = []
        texts: list[tuple[float, float]] = []
        for item in canvas.find_all():
            if canvas.type(item) == "oval":
                x1, y1, x2, y2 = canvas.coords(item)
                ovals.append((x2 - x1) / 2.0)
            elif canvas.type(item) == "text":
                cx, cy = canvas.coords(item)
                texts.append((cx, cy))
        n_atoms = len(aspirin.atoms)
        check("discs drawn per atom", len(ovals) == n_atoms,
              f"ovals={len(ovals)} atoms={n_atoms}")
        # honest van-der-Waals proportions: the two element classes (C, O)
        # keep the 1.7/1.55 radius ratio
        lo, hi = min(ovals), max(ovals)
        check("vdW proportions survive", abs(hi / lo - 1.7 / 1.55) < 0.05,
              f"ratio={hi / lo:.3f} (expect {1.7 / 1.55:.3f})")
        check("labels < atoms (de-overlap active)", len(texts) < n_atoms,
              f"labels={len(texts)} atoms={n_atoms}")
        # no two labels closer than ~10 px (the old pile-up symptom)
        min_sep = min(
            ((ax - bx) ** 2 + (ay - by) ** 2) ** 0.5
            for i, (ax, ay) in enumerate(texts)
            for bx, by in texts[i + 1:]
        ) if len(texts) > 1 else 1e9
        check("no label pile-up (min sep > 10px)", min_sep > 10.0,
              f"min_sep={min_sep:.1f}")
        # honest scaling law: disc radius is LINEAR in zoom (the old
        # max(4.0, ...) floor broke the law for any disc under 4 px;
        # measure the C-disc radius at zoom 1.0 / 0.5 / 2.0)
        def carbon_disc_radius() -> float:
            radii: list[float] = []
            for item in canvas.find_all():
                if canvas.type(item) == "oval":
                    x1, y1, x2, y2 = canvas.coords(item)
                    radii.append((x2 - x1) / 2.0)
            return max(radii)

        app._view3d_zoom.set(1.0)
        app._view3d_draw()
        r10 = carbon_disc_radius()
        app._view3d_zoom.set(0.5)
        app._view3d_draw()
        r05 = carbon_disc_radius()
        app._view3d_zoom.set(2.0)
        app._view3d_draw()
        r20 = carbon_disc_radius()
        check("disc radius linear in zoom (0.5x)", abs(r05 / r10 - 0.5) < 0.05,
              f"r(0.5)/r(1.0)={r05 / r10:.3f}")
        check("disc radius linear in zoom (2.0x)", abs(r20 / r10 - 2.0) < 0.05,
              f"r(2.0)/r(1.0)={r20 / r10:.3f}")
        check("redraw at zoom 2.0 survives", True)
    finally:
        try:
            app.destroy()
        except Exception:  # noqa: BLE001
            pass

    print(f"PASS {len(PASS)} / FAIL {len(FAIL)}")
    for line in PASS:
        print(" ok:", line)
    for line in FAIL:
        print("FAIL:", line)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
