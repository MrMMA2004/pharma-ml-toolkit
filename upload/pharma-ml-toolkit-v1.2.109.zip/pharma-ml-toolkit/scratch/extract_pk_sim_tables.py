"""Extract PK-Sim DB tissue tables, ontogenies and standard-individual values.

Round 176 data extraction from PKSimDB_dump.txt.
"""
from __future__ import annotations

import json
import re
from collections import defaultdict
from pathlib import Path

DUMP = Path(__file__).resolve().parents[2] / "repo-clones/PK-Sim/src/Db/Dump/PKSimDB_dump.txt"
OUT = Path("scratch")
OUT.mkdir(parents=True, exist_ok=True)

INSERT_RE = re.compile(r"INSERT INTO (\w+) VALUES\((.*)\);\s*$")


def split_sql_fields(body: str) -> list[str]:
    fields: list[str] = []
    cur = ""
    in_str = False
    for ch in body:
        if ch == "'":
            cur += ch
            in_str = not in_str
        elif ch == "," and not in_str:
            fields.append(cur.strip())
            cur = ""
        else:
            cur += ch
    fields.append(cur.strip())
    return fields


def unq(s: str) -> str:
    return s[1:-1] if len(s) >= 2 and s[0] == "'" and s[-1] == "'" else s


lines = DUMP.read_text(errors="replace").splitlines()

# ---- 1. tissue composition (Human) -----------------------------------------
tissue: dict[str, dict[str, float]] = defaultdict(dict)
for line in lines:
    m = INSERT_RE.match(line)
    if not m:
        continue
    table, body = m.group(1), m.group(2)
    fields = split_sql_fields(body)
    if table == "tab_container_parameter_values" and len(fields) >= 7:
        group, species, _cid, _ptype, parent, pname, value = (unq(x) for x in fields[:7])
        if group == "TissueComposition_PKSim" and species == "Human":
            try:
                tissue[parent][pname] = float(value)
            except ValueError:
                pass

print("organs:", sorted(tissue.keys()))
print("BloodCells:", json.dumps(tissue.get("BloodCells", {}), indent=1))
print("Plasma:", json.dumps(tissue.get("Plasma", {}), indent=1))
print("Organism:", json.dumps(tissue.get("Organism", {}), indent=1))
(OUT / "pk_tissue_composition.json").write_text(json.dumps(tissue, indent=1, sort_keys=True))

# ---- 2. ontogenies (Human) ---------------------------------------------------
onto: dict[str, dict[str, list[list[float]]]] = defaultdict(lambda: defaultdict(list))
onto_re = re.compile(
    r"INSERT INTO tab_ontogenies VALUES\('([^']+)','([^']+)','([^']+)',([^,]+),([^,]+),([^)]+)\)"
)
for line in lines:
    m = onto_re.match(line)
    if m:
        name, species, container, pma, factor, gsd = m.groups()
        if species == "Human":
            onto[name][container].append([float(pma), float(factor), float(gsd)])
for name in onto:
    for container in onto[name]:
        onto[name][container].sort()
print(
    "ontogenies:",
    {k: {c: len(v) for c, v in d.items()} for k, d in sorted(onto.items())},
)
(OUT / "pk_ontogenies.json").write_text(json.dumps(onto, indent=1, sort_keys=True))

# ---- 3. curves: standard individual (European_ICRP_2002, MALE, age 30) ------
curves: dict[tuple[str, str, str], dict[float, tuple[float, float]]] = defaultdict(dict)
curve_re = re.compile(
    r"INSERT INTO tab_container_parameter_curves VALUES\((.*)\);\s*$"
)
for line in lines:
    m = curve_re.match(line)
    if not m:
        continue
    fields = [unq(x) for x in split_sql_fields(m.group(1))]
    if len(fields) < 13:
        continue
    group, species, _cid, ptype, parent, pname, population, gender = fields[:8]
    if group != "Individual_PKSim" or species != "Human":
        continue
    if population not in {"European_ICRP_2002", "Preterm"}:
        continue
    try:
        age_min = float(fields[8])
        mean = float(fields[11])
        sd = float(fields[12])
    except (ValueError, IndexError):
        continue
    key = (parent, pname, f"{population}|{gender}")
    curves[key][age_min] = (mean, sd)

wanted = [
    ("Liver", "Volume"),
    ("Kidney", "Volume"),
    ("Adipose", "Volume"),
    ("Muscle", "Volume"),
    ("Brain", "Volume"),
    ("Heart", "Volume"),
    ("Lung", "Volume"),
    ("Skin", "Volume"),
    ("Bone", "Volume"),
    ("Gut", "Volume"),
    ("Spleen", "Volume"),
    ("Pancreas", "Volume"),
    ("ArterialBlood", "Volume"),
    ("VenousBlood", "Volume"),
    ("Bone", "Fraction vascular"),
    ("Brain", "Fraction vascular"),
    ("Gut", "Fraction vascular"),
    ("Heart", "Fraction vascular"),
    ("Kidney", "Fraction vascular"),
    ("Liver", "Fraction vascular"),
    ("Lung", "Fraction vascular"),
    ("Muscle", "Fraction vascular"),
    ("Pancreas", "Fraction vascular"),
    ("Skin", "Fraction vascular"),
    ("Spleen", "Fraction vascular"),
    ("Adipose", "Fraction vascular"),
    ("Kidney", "TM50 for GFR"),
    ("Kidney", "Hill coefficient for GFR"),
    ("Kidney", "fGFRpremat"),
    ("Kidney", "GFRmat"),
    ("Kidney", "Age of aging onset"),
    ("Kidney", "Aging half-time"),
    ("Kidney", "Hill coefficient for aging GFR"),
    ("Kidney", "Maximal decreasing rate factor"),
    ("Organism", "Hematocrit"),
]
report: dict[str, dict[str, float]] = {}
for parent, pname in wanted:
    for key, aged in curves.items():
        if key[0] == parent and key[1] == pname:
            ages = sorted(aged)
            pick = None
            for a in ages:
                if a <= 30.0:
                    pick = a
            if pick is None:
                pick = ages[0]
            mean, sd = aged[pick]
            report[f"{parent}|{pname}|{key[2]}"] = {"age": pick, "mean": mean, "sd": sd}
print(json.dumps(report, indent=1, sort_keys=True))
flat_curves = {
    "|".join(k): {str(a): list(v) for a, v in aged.items()} for k, aged in curves.items()
}
(OUT / "pk_individual_curves.json").write_text(json.dumps(flat_curves, indent=1, sort_keys=True))
(OUT / "pk_standard_individual.json").write_text(json.dumps(report, indent=1, sort_keys=True))
