#!/usr/bin/env python3
"""Double-fork full-suite runner (the standing orphan recipe, 100x-170).

The sandbox reaps processes left in a tool session's process group, so
a plain `pytest ... &` dies with the session.  This double-fork orphan
runs the 1.2.103 verification suite to /tmp/suite_170_full.log and
survives; poll the log from the tool session.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

LOG = "/tmp/suite_170_full.log"
TOOLKIT = Path(__file__).resolve().parents[1]


def main() -> int:
    if os.fork() > 0:
        print("runner detached; poll", LOG)
        return 0
    os.setsid()
    if os.fork() > 0:
        os._exit(0)
    with open(LOG, "w") as log:
        subprocess.run(
            [
                str(Path.home() / ".venv" / "bin" / "python"), "-m", "pytest",
                "tests/", "src/", "-q", "--tb=short",
                "-o", "addopts=", "--doctest-modules",
                "-p", "no:cacheprovider", "-rf",
            ],
            cwd=str(TOOLKIT),
            stdout=log,
            stderr=subprocess.STDOUT,
            timeout=1500,
        )
    os._exit(0)


if __name__ == "__main__":
    sys.exit(main())
