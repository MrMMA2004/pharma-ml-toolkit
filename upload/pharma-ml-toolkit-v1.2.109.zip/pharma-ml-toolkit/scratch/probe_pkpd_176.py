"""Probe the round-100x-176 PK-tab cards end to end (headless).

Runs the three new handlers — _pbpk_run, _odelab_run, _odelab_lincmt —
on the built app, pumps the event loop until the background jobs land,
and asserts the rendered results and figures.
"""

from __future__ import annotations

import sys
import time

import playground


def wait_for_job(app: object, timeout_s: float = 90.0) -> None:
    """Pump the loop until the app's job machinery goes idle."""
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        app.update()
        if not app._busy:  # type: ignore[attr-defined]
            app.update()
            return
        time.sleep(0.02)
    raise TimeoutError("the job never finished")


def main() -> int:
    app = playground.PlaygroundApp(persist_session=False)
    for _ in range(4):
        app.update_idletasks()
        app.update()
    # jump to the PK tab
    index = app._book.index("end")
    for i in range(index):
        app._book.select(i)
        app.update()
    for i in range(index):
        if "PK" in app._book.tab(i, "text"):
            app._book.select(i)
            break
    app.update()

    # 1) PBPK simulator (defaults: IV 100 mg, clint 50, poulin_theil)
    app._pbpk_run()
    wait_for_job(app)
    text = app._pbpk_result.cget("text")
    assert "mass balance" in text and "Cmax" in text, text
    assert app._pbpk_host.winfo_children(), "the PBPK figure rendered"
    print("pbpk card:", text.splitlines()[1][:100])

    # 2) ODE lab — solve the flagship model
    app._odelab_run()
    wait_for_job(app)
    text = app._odelab_result.cget("text")
    assert "97 rows" in text or "rows" in text, text
    assert app._odelab_host.winfo_children(), "the ODE figure rendered"
    print("ode lab:", text.splitlines()[0])

    # 3) linCmt cross-check
    app._odelab_lincmt()
    wait_for_job(app)
    text = app._odelab_result.cget("text")
    assert "linCmt" in text or "AUC" in text, text
    print("lincmt:", text.splitlines()[0])

    # 4) an edited model (oral route switch on the PBPK card)
    app._pbpk_route.set("oral")
    app._pbpk_run()
    wait_for_job(app)
    text = app._pbpk_result.cget("text")
    assert text.startswith("ORAL"), text
    print("pbpk oral:", text.splitlines()[1][:100])

    app.destroy()
    print("probe: all three cards exercised end to end, no errors")
    return 0


if __name__ == "__main__":
    sys.exit(main())
