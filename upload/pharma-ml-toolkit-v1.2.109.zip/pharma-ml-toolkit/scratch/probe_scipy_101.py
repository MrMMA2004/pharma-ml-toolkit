"""Round-101 probe: exercise every SciPy Lab card handler headlessly."""
import sys
import time

sys.path.insert(0, ".")
import playground


def pump_until_idle(app, timeout=120.0):
    deadline = time.monotonic() + timeout
    while app._busy and time.monotonic() < deadline:
        app.update_idletasks()
        app.update()
        time.sleep(0.01)
    assert not app._busy, "job never finished"


def run(app, handler_name, *args):
    getattr(app, handler_name)(*args)
    pump_until_idle(app)


app = playground.PlaygroundApp(persist_session=False)
for _ in range(4):
    app.update_idletasks()
    app.update()

# tab exists and is visitable
titles = [app._book.tab(i, "text").strip() for i in range(app._book.index("end"))]
assert any("SciPy Lab" in t for t in titles), f"tab missing: {titles}"
app._book.select(next(i for i, t in enumerate(titles) if "SciPy Lab" in t))
app.update()

# 1. peak picking on the synthetic chromatogram fallback
run(app, "_scipy_run_peaks")
rows = app._scipy_peaks_tree.get_children()
print("PEAKS rows:", len(rows))
assert len(rows) == 3, f"expected 3 peaks, got {len(rows)}"
first = app._scipy_peaks_tree.item(rows[0], "values")
print("PEAK 1:", first)
print("PEAKS note:", app._scipy_peaks_note.cget("text")[:110])

# 1b. tighter prominence -> fewer peaks (the ~1.6-prominence tail peak drops)
app._scipy_peak_prominence.delete(0, "end")
app._scipy_peak_prominence.insert(0, "2.0")
run(app, "_scipy_run_peaks")
rows = app._scipy_peaks_tree.get_children()
print("PEAKS rows at prominence 2.0:", len(rows))
assert len(rows) == 2

# 1c. distance filter forces separation
app._scipy_peak_prominence.delete(0, "end")
app._scipy_peak_prominence.insert(0, "0.0")
app._scipy_peak_distance.set("200")
run(app, "_scipy_run_peaks")
rows = app._scipy_peaks_tree.get_children()
print("PEAKS rows at distance 200:", len(rows))
assert len(rows) == 1, "distance filter must keep exactly the tallest peak"

# 2. Savitzky-Golay smoothing on the fallback trace
app._scipy_peak_distance.set("1")
run(app, "_scipy_run_savgol")
note = app._scipy_savgol_note.cget("text")
print("SAVGOL note:", note[:130])
assert "smoother" in note

# 3. interpolation audit on the fallback series
run(app, "_scipy_run_interp")
rows = app._scipy_interp_tree.get_children()
print("INTERP rows:", len(rows))
assert len(rows) == 4, f"expected 3 methods + winner, got {len(rows)}"
print("INTERP note:", app._scipy_interp_note.cget("text")[:120])

# 4. compartment simulation (two-compartment oral default)
run(app, "_scipy_run_compartment")
note = app._scipy_cmt_note.cget("text")
print("CMT note:", note[:150])
assert "Cmax" in note and "AUC" in note

# 4b. one-compartment IV
app._scipy_cmt_model.set("one")
app._scipy_cmt_route.set("iv_bolus")
run(app, "_scipy_run_compartment")
note = app._scipy_cmt_note.cget("text")
print("CMT one-iv note:", note[:110])
assert "6.250" in note, "one-compartment IV must start at C0 = dose/V = 6.25"

# 5. Ki -> dG conversion (sync)
run(app, "_scipy_run_ki_to_dg")
note = app._scipy_ki_note.cget("text")
print("KIDG note:", note[:130])
assert "-10.91" in note, "10 nM must convert to -10.91 kcal/mol"

# 5b. dG -> Ki round trip
app._scipy_ki_value.delete(0, "end")
app._scipy_ki_value.insert(0, "-10.91")
run(app, "_scipy_run_dg_to_ki")
note = app._scipy_ki_note.cget("text")
print("DGKI note:", note[:120])
assert "10." in note, "-10.91 kcal/mol must convert back to ~10 nM"

# 6. pairwise distances needs a loaded dataset first -- load the example
app._found_load_example()
app.update()
assert app._found_frame is not None, "example dataset did not load"
run(app, "_scipy_run_distances")
rows = app._scipy_dist_tree.get_children()
print("DIST rows:", len(rows))
assert len(rows) == 10, f"matrix preview must show 10 rows, got {len(rows)}"
note = app._scipy_dist_note.cget("text")
print("DIST note:", note[:140])
assert "condensed" in note

# 6b. cosine metric
app._scipy_dist_metric.set("cosine")
run(app, "_scipy_run_distances")
note = app._scipy_dist_note.cget("text")
print("DIST cosine note:", note[:110])

# 7. re-run the data cards on the loaded dataset (real columns now)
run(app, "_scipy_run_peaks")
print("PEAKS after load:", app._scipy_peaks_note.cget("text")[:110])
run(app, "_scipy_run_savgol")
print("SAVGOL after load:", app._scipy_savgol_note.cget("text")[:110])
run(app, "_scipy_run_interp")
print("INTERP after load:", app._scipy_interp_note.cget("text")[:110])

app.destroy()
print("PROBE SCIPY LAB: ALL CARDS OK")
