"""Round-169 screenshots: the Response Lab tab, headless."""
import sys
import time

sys.path.insert(0, ".")
import playground


def pump(app, timeout=300.0):
    deadline = time.monotonic() + timeout
    while app._busy and time.monotonic() < deadline:
        app.update_idletasks(); app.update(); time.sleep(0.01)


app = playground.PlaygroundApp(persist_session=False)
for _ in range(6):
    app.update_idletasks(); app.update()

titles = [app._book.tab(i, "text").strip() for i in range(app._book.index("end"))]
app._book.select(next(i for i, t in enumerate(titles) if "Response Lab" in t))
app.update()
app.geometry("1600x1000+0+0")
app.update()

from PIL import ImageGrab

ImageGrab.grab(xdisplay=":98").save("pg169-resplab-top.png")

# run every card, then capture the filled tab
app._resplab_run_gsva(); pump(app)
app._resplab_run_recommender(); pump(app)
app._resplab_cell_combo.set(str(app._resplab_features.index[0]))
app._resplab_run_repurposing(); pump(app)
app._resplab_run_audit(); pump(app)
app._resplab_run_bayes(); pump(app)
app._resplab_run_ensemble(); pump(app)
app.update_idletasks(); app.update()
ImageGrab.grab(xdisplay=":98").save("pg169-resplab-loaded.png")

app._book.select(next(i for i, t in enumerate(titles) if "Response Lab" in t))
app.update()
app.destroy()
print("shots saved")
