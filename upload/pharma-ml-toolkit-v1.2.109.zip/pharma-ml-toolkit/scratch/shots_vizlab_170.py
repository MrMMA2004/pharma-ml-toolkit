"""Round-170 screenshots: the Viz Studio tab, four scrolled views."""
import sys
import time

sys.path.insert(0, ".")
from PIL import ImageGrab

import playground


def pump(app, timeout=300.0):
    deadline = time.monotonic() + timeout
    while app._busy and time.monotonic() < deadline:
        app.update_idletasks()
        app.update()
        time.sleep(0.01)


app = playground.PlaygroundApp(persist_session=False)
for _ in range(6):
    app.update_idletasks()
    app.update()

titles = [app._book.tab(i, "text").strip() for i in range(app._book.index("end"))]
app._book.select(next(i for i, t in enumerate(titles) if "Viz Studio" in t))
app.update()
app.geometry("1440x940+0+0")
app.update()
time.sleep(0.3)

# render every card once
app._vizlab_family.set("viridis")
app._vizlab_run_palette()
pump(app)
app._vizlab_run_norms()
pump(app)
app._vizlab_stat_group.set("class")
app._vizlab_stat_value.set("x1")
app._vizlab_run_stats()
pump(app)
app._vizlab_run_cluster()
pump(app)
app._vizlab_spec_color.set("class")
app._vizlab_run_spec()
pump(app)
app._vizlab_run_dash_filter()
pump(app)
app._vizlab_dash_bins.set(12)
app._vizlab_run_dash_app()
pump(app)
app.update_idletasks()
app.update()
time.sleep(0.4)

page = app._book.nametowidget(app._book.select())
canvas = getattr(page, "_canvas", None)


def shot(path: str, fraction: float) -> None:
    if canvas is not None:
        canvas.yview_moveto(fraction)
    app.update()
    time.sleep(0.35)
    app.update()
    ImageGrab.grab(xdisplay=":99").save(path)
    print("shot:", path)


shot("scratch/vizlab170_top.png", 0.0)
shot("scratch/vizlab170_mid.png", 0.35)
shot("scratch/vizlab170_spec.png", 0.62)
shot("scratch/vizlab170_dash.png", 0.9)

app.destroy()
print("four scrolled screenshots done")
