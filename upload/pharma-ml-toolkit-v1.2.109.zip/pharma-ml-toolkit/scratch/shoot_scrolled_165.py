import os, subprocess, sys, time
from pathlib import Path
TOOLKIT = Path(__file__).resolve().parents[1]
os.chdir(TOOLKIT); sys.path.insert(0, str(TOOLKIT))
DISPLAY = ":95"
proc = subprocess.Popen(["Xvfb", DISPLAY, "-screen", "0", "1600x1000x24"],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sock = Path(f"/tmp/.X11-unix/X{DISPLAY[1:]}")
deadline = time.time() + 10.0
while time.time() < deadline and not sock.exists():
    time.sleep(0.1)
os.environ["DISPLAY"] = DISPLAY
import playground
app = playground.PlaygroundApp(persist_session=False)
app.update_idletasks(); app.update()
TAB_ORDER = ["Home","Chemistry","PK / PD","Cell Lines","Docking","Data & ML","Unsupervised",
             "Deep Learning","Generative","Foundations","Best-of ML","Response AI","Utilities"]
def page_of(title):
    for tab in app._book.tabs():
        p = app._book.nametowidget(tab)
        if str(app._book.tab(p, "text")).strip() == title:
            return p
for tab, fractions in (("Docking", (0.18, 0.42, 0.62)), ("Generative", (0.3,))):
    app._jump_to_tab(TAB_ORDER.index(tab))
    app.update_idletasks(); app.update()
    canvas = getattr(page_of(tab), "_canvas", None)
    for frac in fractions:
        canvas.yview_moveto(frac)
        app.update_idletasks(); app.update()
        time.sleep(0.4)
        tag = str(frac).replace(".", "")
        out = TOOLKIT / "scratch" / f"pg165-scroll-{tab.lower().replace(' ','-')}-{tag}.png"
        from PIL import ImageGrab
        ImageGrab.grab(xdisplay=DISPLAY).save(str(out))
        print("shot", out.name)
app.destroy()
proc.terminate()
