#!/usr/bin/env python3
"""Round-182 verification: sequential-process grouping in playground.py.

The four tabs whose cards form ONE step-after-step process (Docking's
six-step campaign, Deep Learning's five-step training run, the
Unsupervised three-step analysis, Generative's four-step evolution)
now group those cards inside a ``make_workflow`` band with numbered
``step`` badges, and the order-free stand-alone cards sit below a
``make_section`` divider.

Checks (under Xvfb, real widgets):
  1. each band exists, is gridded on the page, and its inner cards are
     its descendants (real nesting, not just styling);
  2. every step badge renders the right number, on the right card, in
     reading order (grid coordinates);
  3. the stand-alone cards sit BELOW the band on the tab grid;
  4. the card finder still resolves every card (master chain intact);
  5. a finder jump to a NESTED card scrolls the canvas further than a
     jump to the band's first card (the rooty-based offset fix);
  6. theme flip retints the band's plain-tk surfaces;
  7. screenshots of the four tabs land in scratch/ for eyeballing.
"""
from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path

TOOLKIT = Path(__file__).resolve().parents[1]
os.chdir(TOOLKIT)
sys.path.insert(0, str(TOOLKIT))

DISPLAY = ":96"
proc = subprocess.Popen(
    ["Xvfb", DISPLAY, "-screen", "0", "1600x1000x24"],
    stdout=subprocess.DEVNULL,
    stderr=subprocess.DEVNULL,
)
sock = Path(f"/tmp/.X11-unix/X{DISPLAY[1:]}")
deadline = time.time() + 10.0
while time.time() < deadline and not sock.exists():
    time.sleep(0.1)
os.environ["DISPLAY"] = DISPLAY

TAB_ORDER = [
    "Home",
    "Chemistry",
    "PK / PD",
    "Cell Lines",
    "Docking",
    "Data & ML",
    "Unsupervised",
    "Deep Learning",
    "Foundations",
    "Best-of ML",
    "Response AI",
    "Generative",
    "Utilities",
]

PASS: list[str] = []
FAIL: list[str] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    (PASS if ok else FAIL).append(f"{name}{(' — ' + detail) if detail else ''}")
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{detail}]" if detail else ""))


def _labels(frame):
    return [
        child for child in frame.winfo_children() if child.winfo_class() in ("TLabel", "Label")
    ]


def _walk_labels(widget):
    """Every label under a card shell, at any nesting depth."""
    found: list = []
    for child in widget.winfo_children():
        if child.winfo_class() in ("TLabel", "Label"):
            found.append(child)
        found.extend(_walk_labels(child))
    return found


def _is_badge(lbl) -> bool:
    try:
        return str(lbl.cget("style")) == "StepBadge.TLabel"
    except Exception:  # pragma: no cover
        return False


try:
    import playground  # noqa: PLC0415

    app = playground.PlaygroundApp(persist_session=False)
    app.update_idletasks()
    app.update()

    def page_of(title: str):
        for tab in app._book.tabs():
            page = app._book.nametowidget(tab)
            if str(app._book.tab(page, "text")).strip() == title:
                return page
        return None

    expectations = {
        "Docking": {
            "band": "Docking campaign — the six-step workflow",
            "steps": [
                ("Ligand library → PDBQT", 0, 0),
                ("Receptor preparation", 0, 1),
                ("Grid box & docking configs", 1, 0),
                ("Campaign runner", 1, 1),
                ("Docking results", 2, 0),
                ("Consensus rescore", 2, 1),
            ],
            "solo_below": [
                "SMILES array docking",
                "Grid, torsion & completion audit",
                "Vina config batch",
                "SMILES → PDBQT (single ligand)",
                "Ligand structures (CSV → PDB + MOL2)",
                "PDB → PDBQT batch (MGLTools)",
                "Pose RMSD & analysis (DiffDock)",
                "Pocket extraction (DiffDock)",
            ],
        },
        "Deep Learning": {
            "band": "Deep-learning run — the five-step workflow",
            "steps": [
                ("Dataset", 0, 0),
                ("Preview (first 12 rows)", 1, 0),
                ("Network & training", 2, 0),
                ("Results", 3, 0),
                ("Training history", 4, 0),
            ],
            "solo_below": [],
        },
        "Unsupervised": {
            "band": "Unsupervised analysis — the three-step workflow",
            "steps": [
                ("Unsupervised dataset", 0, 0),
                ("Method", 1, 0),
                ("Results", 1, 1),
            ],
            "solo_below": [],
        },
        "Generative": {
            "band": "Molecule evolution — the four-step workflow",
            "steps": [
                ("Corpus / seed molecules", 0, 0),
                ("Objective & evolution", 0, 1),
                ("Results", 1, 0),
                ("Pareto front", 2, 0),
            ],
            "solo_below": ["Ring topology moves", "Breed two molecules"],
        },
    }

    shells = {title: shell for title, _sub, shell in playground._CARD_INDEX}
    pages = [app._book.nametowidget(tab) for tab in app._book.tabs()]

    def shell_on(tab_title: str, card_title: str):
        """The card shell whose master chain lands on THIS tab (titles repeat)."""
        page = page_of(tab_title)
        index = pages.index(page)
        for title, _sub, shell in playground._CARD_INDEX:
            if title != card_title:
                continue
            if app._card_tab_index(shell, pages) == index:
                return shell
        return None

    for tab, spec in expectations.items():
        page = page_of(tab)
        check(f"{tab}: page found", page is not None)
        if page is None:
            continue
        grid = page.grid
        bands = [
            child
            for child in grid.winfo_children()
            if child.winfo_class() == "Frame"
            and str(child.cget("background")) == playground.ACCENT_SOFT
        ]
        check(f"{tab}: one workflow band on the grid", len(bands) == 1, f"found {len(bands)}")
        if not bands:
            continue
        band = bands[0]
        info = band.grid_info()
        check(f"{tab}: band at grid row 0", info.get("row") == 0, f"row={info.get('row')}")
        bodies = [
            child
            for child in band.winfo_children()
            if child.winfo_class() == "Frame"
            and str(child.cget("background")) == playground.ACCENT_SOFT
        ]
        check(f"{tab}: band body present", len(bodies) == 1)
        if not bodies:
            continue
        body = bodies[0]
        inner = [
            child
            for child in body.winfo_children()
            if child.winfo_class() == "Frame" and str(child.cget("background")) == playground.CARD
        ]
        check(
            f"{tab}: {len(spec['steps'])} cards inside the band",
            len(inner) == len(spec["steps"]),
            f"found {len(inner)}",
        )
        for index, (title, row, column) in enumerate(spec["steps"], start=1):
            shell = shell_on(tab, title)
            found = shell is not None and shell.master is body
            check(f"{tab}: '{title}' lives inside the band", found)
            if not found:
                continue
            gi = shell.grid_info()
            check(
                f"{tab}: '{title}' at ({row},{column})",
                gi.get("row") == row and gi.get("column") == column,
                f"got ({gi.get('row')},{gi.get('column')})",
            )
            badge_texts = [
                str(lbl.cget("text")) for lbl in _walk_labels(shell) if _is_badge(lbl)
            ]
            check(
                f"{tab}: '{title}' wears step badge {index}",
                badge_texts == [str(index)],
                f"badges={badge_texts}",
            )
        if spec["solo_below"]:
            solo_rows = []
            for title in spec["solo_below"]:
                shell = shell_on(tab, title)
                if shell is None:
                    check(f"{tab}: solo '{title}' exists", False)
                    continue
                gi = shell.grid_info()
                check(f"{tab}: solo '{title}' on the page grid", shell.master is grid)
                solo_rows.append(int(gi.get("row", -1)))
            check(
                f"{tab}: every solo card sits below the band",
                all(r >= 2 for r in solo_rows),
                f"rows={solo_rows}",
            )
            sections = [
                w
                for w in grid.winfo_children()
                if w.winfo_class() == "TLabel" and "Stand-alone tools" in str(w.cget("text"))
            ]
            check(f"{tab}: section divider labels the toolbox", len(sections) == 1)

    # ---- 4. the finder still sees every card ---------------------- #
    live = app._live_cards()
    check("finder directory live", len(live) >= 50, f"{len(live)} live cards")

    # ---- 5. jump to a nested card scrolls deeper than the band top - #
    dock_index = TAB_ORDER.index("Docking")
    app._jump_to_tab(dock_index)
    app.update_idletasks()
    app.update()
    page = page_of("Docking")
    canvas = getattr(page, "_canvas", None)
    check("docking page has a scroll canvas", canvas is not None)
    if canvas is not None:
        app._jump_to_card(dock_index, "Ligand library → PDBQT")
        app.update()
        first = canvas.yview()[0]
        app._jump_to_card(dock_index, "Consensus rescore")
        app.update()
        last = canvas.yview()[0]
        check(
            "jump to step 6 scrolls below step 1",
            last > first,
            f"step1={first:.3f} step6={last:.3f}",
        )

    # ---- 6. theme flip retints the band --------------------------- #
    app._set_theme("dark")
    app.update()
    dark_soft = playground._PALETTES["dark"]["ACCENT_SOFT"]
    page = page_of("Docking")
    dock_bands = [
        child
        for child in page.grid.winfo_children()
        if child.winfo_class() == "Frame" and str(child.cget("background")) == dark_soft
    ]
    check("theme flip retints the band to dark ACCENT_SOFT", len(dock_bands) == 1)
    app._set_theme("light")
    app.update()

    # ---- 7. screenshots for eyeballing (scrolled back to the top) --- #
    for tab in expectations:
        app._jump_to_tab(TAB_ORDER.index(tab))
        app.update_idletasks()
        app.update()
        page = page_of(tab)
        canvas = getattr(page, "_canvas", None)
        if canvas is not None:
            canvas.yview_moveto(0.0)
        app.update_idletasks()
        app.update()
        time.sleep(0.4)
        out = TOOLKIT / "scratch" / f"pg165-{tab.lower().replace(' ', '-')}.png"
        try:
            from PIL import ImageGrab

            ImageGrab.grab(xdisplay=DISPLAY).save(str(out))
            check(f"screenshot {out.name}", out.exists())
        except Exception as exc:  # pragma: no cover - PIL missing
            check(f"screenshot {out.name}", False, str(exc)[:80])

    app.destroy()
finally:
    proc.terminate()

print()
print(f"{len(PASS)} passed, {len(FAIL)} failed")
if FAIL:
    for line in FAIL:
        print("  FAIL:", line)
    sys.exit(1)
print("ALL GREEN")
