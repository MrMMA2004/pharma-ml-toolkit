"""Prototype: verify 2-cmt closed forms vs numerical integration, get golden values."""
import numpy as np
from scipy.integrate import solve_ivp

k10, k12, k21 = 0.1, 3.0, 1.0
ks = k10 + k12 + k21
disc = np.sqrt(ks * ks - 4 * k10 * k21)
alpha = 0.5 * (ks + disc)
beta = 0.5 * (ks - disc)
print("alpha, beta:", repr(alpha), repr(beta))

invD0 = 1.0 / (beta - alpha)
invD1 = 1.0 / (alpha - beta)
c1_00 = (k21 - alpha) * invD0
c1_01 = (k21 - beta) * invD1
c1_10 = k12 * invD0
c1_11 = k12 * invD1
c2_00 = k21 * invD0
c2_01 = k21 * invD1
c2_10 = (k10 + k12 - alpha) * invD0
c2_11 = (k10 + k12 - beta) * invD1
print("C1 (eigen x output, src=central):", c1_00, c1_01, c1_10, c1_11)
print("C2 (src=periph):", c2_00, c2_01, c2_10, c2_11)

# --- verify advance operator vs solve_ivp: central bolus 100 at t=0
def rhs(t, y):
    a1, a2 = y
    return [-(k10 + k12) * a1 + k21 * a2, k12 * a1 - k21 * a2]

sol = solve_ivp(rhs, [0, 5], [100.0, 0.0], t_eval=[2.5], rtol=1e-10, atol=1e-12)
t = 2.5
E0, E1 = np.exp(-alpha * t), np.exp(-beta * t)
x0 = (E0 * c1_00 + E1 * c1_01) * 100.0
x1 = (E0 * c1_10 + E1 * c1_11) * 100.0
print("numeric  A1(2.5) =", sol.y[0, 0], " closed =", x0)
print("numeric  A2(2.5) =", sol.y[1, 0], " closed =", x1)

# --- oral: depot bolus 100, ka=1.2
ka = 1.2
def rhs_oral(t, y):
    d, a1, a2 = y
    return [-ka * d, ka * d - (k10 + k12) * a1 + k21 * a2, k12 * a1 - k21 * a2]

sol = solve_ivp(rhs_oral, [0, 5], [100.0, 0.0, 0.0], t_eval=[2.0], rtol=1e-10, atol=1e-12)
t = 2.0
expa = np.exp(-ka * t)
Ea0 = (E0 if False else np.exp(-alpha * t) - expa) / (ka - alpha)
Ea1 = (np.exp(-beta * t) - expa) / (ka - beta)
xa0 = (Ea0 * c1_00 + Ea1 * c1_01) * ka * 100.0
xa1 = (Ea0 * c1_10 + Ea1 * c1_11) * ka * 100.0
print("oral numeric A1(2) =", sol.y[1, 0], " closed =", xa0)
print("oral numeric A2(2) =", sol.y[2, 0], " closed =", xa1)

# --- infusion rate 10 into central for duration 3
R, dur = 10.0, 3.0
def rhs_inf(t, y):
    a1, a2 = y
    rate = R if t <= dur else 0.0
    return [rate - (k10 + k12) * a1 + k21 * a2, k12 * a1 - k21 * a2]

sol = solve_ivp(rhs_inf, [0, 10], [0.0, 0.0], t_eval=[1.5, 6.0], rtol=1e-10, atol=1e-12)

def inf_contrib(u, dur, R):
    out = {}
    for lam, c in ((alpha, c1_00), (beta, c1_01)):
        term = (1 - np.exp(-lam * np.clip(u, 0, None))) - (1 - np.exp(-lam * np.clip(u - dur, 0, None)))
        out[lam] = R * c * term / lam
    return out

for i, tt in enumerate([1.5, 6.0]):
    cc = inf_contrib(tt, dur, R)
    val = sum(cc.values())
    print(f"inf numeric A1({tt}) = {sol.y[0, i]:.10f}  closed = {val:.10f}")

# --- SS infusion formula check: rate 1, dur 6, tau 24, 1-cmt ke=0.1
ke, tau, d2 = 0.1, 24.0, 6.0
R2 = 1.0
# explicit: sum many cycles
def ss_explicit(x, ncycles=400):
    total = 0.0
    for k in range(ncycles):
        start = -k * tau
        u1 = x - start
        u2 = x - (start + d2)
        h1 = (1 - np.exp(-ke * max(u1, 0))) / ke if u1 > 0 else 0.0
        h2 = (1 - np.exp(-ke * max(u2, 0))) / ke if u2 > 0 else 0.0
        total += R2 * (h1 - h2)
    return total

def ss_closed(x):
    if x <= d2:
        cur = (1 - np.exp(-ke * x)) / ke
        tail = (1 - np.exp(-ke * d2)) * np.exp(-ke * (x - d2)) * np.exp(-ke * tau) / (1 - np.exp(-ke * tau)) / ke
        return R2 * (cur + tail)
    return R2 * (1 - np.exp(-ke * d2)) * np.exp(-ke * (x - d2)) / (1 - np.exp(-ke * tau)) / ke

for x in [0.0, 3.0, 6.0, 12.0, 23.999]:
    print(f"SS x={x}: explicit={ss_explicit(x):.10f} closed={ss_closed(x):.10f}")

# --- SS bolus: dose 100 every tau, 1-cmt
def ss_bolus_explicit(x, ncycles=400):
    return sum(100.0 * np.exp(-ke * (x + k * tau)) for k in range(ncycles))
ss_bolus_closed = 100.0 * np.exp(-ke * 0.0) / (1 - np.exp(-ke * tau))
print("SS bolus trough (x=tau):", ss_bolus_explicit(tau), 100 * np.exp(-ke * tau) / (1 - np.exp(-ke * tau)))
print("SS bolus peak (x=0):", ss_bolus_explicit(0.0), ss_bolus_closed)

# --- AUC via coefficients: 2-cmt IV bolus D=100: AUC = D*(c1_00/alpha + c1_01/beta)
auc = 100 * (c1_00 / alpha + c1_01 / beta)
print("AUC 2-cmt IV:", auc, "CL* AUC =", k10 * auc)  # should equal D since CL=k10*V=... AUC=D/CL with V=1
