#!/usr/bin/env python3
"""Splice the rounds 177+178 PK/PD engine cards into playground.py."""

CARDS = r'''
        bind_enter(self._uc_value, uc_btn)
        bind_enter(self._uc_to, uc_btn)

        # -- PK/PD engines: ODE + compartments (100x-177/178) --------- #
        # the RxODE/linCmt layer absorbed numpy-native: a two-compartment
        # oral model solved EXACTLY by the matrix exponential, cross-
        # validated live against the toolkit's own adaptive RK45 engine
        # (Dormand-Prince 5(4) with dosing events), plus the principle
        # of superposition for the steady state over a dosing interval
        engine_card = make_card(
            page.grid,
            "ODE engine & two-compartment model",
            collapsible=True,
            key="pk-engine",
            row=8,
            column=0,
            span=2,
            subtitle="The RxODE/linCmt layer, numpy-native: a two-compartment "
            "oral model (depot \u2192 central \u2194 peripheral) solved "
            "EXACTLY by the matrix exponential, cross-validated against "
            "the toolkit's own adaptive RK45 ODE engine with dosing "
            "events -- plus the superposition steady state over a "
            "regular dosing interval.",
        )
        self._pkpd_cl = ttk.Entry(engine_card, width=10)
        self._pkpd_cl.insert(0, "5")
        form_row(engine_card, "CL (L/h)", self._pkpd_cl)
        self._pkpd_v2 = ttk.Entry(engine_card, width=10)
        self._pkpd_v2.insert(0, "50")
        form_row(engine_card, "V2 (L)", self._pkpd_v2)
        self._pkpd_q = ttk.Entry(engine_card, width=10)
        self._pkpd_q.insert(0, "3")
        form_row(engine_card, "Q (L/h)", self._pkpd_q)
        self._pkpd_v3 = ttk.Entry(engine_card, width=10)
        self._pkpd_v3.insert(0, "100")
        form_row(engine_card, "V3 (L)", self._pkpd_v3)
        self._pkpd_ka = ttk.Entry(engine_card, width=10)
        self._pkpd_ka.insert(0, "1.2")
        form_row(engine_card, "Ka (1/h)", self._pkpd_ka)
        self._pkpd_dose = ttk.Entry(engine_card, width=10)
        self._pkpd_dose.insert(0, "100")
        form_row(engine_card, "dose (mg)", self._pkpd_dose)
        self._pkpd_tau = ttk.Entry(engine_card, width=10)
        self._pkpd_tau.insert(0, "12")
        form_row(engine_card, "tau (h, steady state)", self._pkpd_tau)
        engine_buttons = ttk.Frame(engine_card, style="Card.TFrame")
        grid_append(engine_card, engine_buttons, sticky="w", pady=(6, 0))
        engine_btn = self._action_button(
            engine_buttons,
            "Solve & cross-validate",
            self._pkpd_engine_run,
            primary=True,
            tooltip="TwoCompartment.concentrations (the exact matrix-"
            "exponential linCmt route) vs solve_ode RK45 on the same "
            "model -- the agreement number IS the demo.",
        )
        engine_btn.pack(side="left")
        steady_btn = self._action_button(
            engine_buttons,
            "Steady state (superposition)",
            self._pkpd_steady_state_run,
            tooltip="The principle of superposition over one dosing "
            "interval: Cmax/Ctrough at steady state, the predicted "
            "accumulation ratio from the fitted terminal lambda-z.",
        )
        steady_btn.pack(side="left", padx=(10, 0))
        self._pkpd_result = ttk.Label(
            engine_card,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=620,
            justify="left",
        )
        grid_append(engine_card, self._pkpd_result, sticky="w")
        self._pkpd_host = self._figure_host(engine_card, height=230)
        bind_enter(self._pkpd_ka, engine_btn)

        # -- Population PK: FOCEi-lite (100x-177, nlmixr2) ------------- #
        # one card, one study: simulate a popPK dataset (IIV on ka/CL,
        # combined residual error), fit it with the FOCEi-lite engine,
        # and read the nlmixr2-style report -- thetas, omega, sigma,
        # objf/AIC/BIC, the shrinkage table and the DV-vs-IPRED scatter
        pop_card = make_card(
            page.grid,
            "Population PK — FOCEi-lite (nlmixr2)",
            collapsible=True,
            key="pk-nlme",
            row=9,
            column=0,
            subtitle="Nonlinear mixed effects on a one-compartment oral "
            "model: per-subject MAP etas by damped Gauss–Newton, the "
            "FOCEi objective over V = R + G·Ω·G', Nelder–Mead outside "
            "-- reported nlmixr2-style (logLik = −(objf + nobs·ln2π)/2, "
            "shrinkage, CWRES).",
        )
        self._nlme_n = ttk.Entry(pop_card, width=8)
        self._nlme_n.insert(0, "8")
        form_row(pop_card, "subjects", self._nlme_n)
        self._nlme_seed = ttk.Entry(pop_card, width=8)
        self._nlme_seed.insert(0, "7")
        form_row(pop_card, "seed", self._nlme_seed)
        self._nlme_ka = ttk.Entry(pop_card, width=8)
        self._nlme_ka.insert(0, "1.0")
        form_row(pop_card, "true Ka (1/h)", self._nlme_ka)
        self._nlme_cl = ttk.Entry(pop_card, width=8)
        self._nlme_cl.insert(0, "3.0")
        form_row(pop_card, "true CL (L/h)", self._nlme_cl)
        self._nlme_v = ttk.Entry(pop_card, width=8)
        self._nlme_v.insert(0, "20")
        form_row(pop_card, "V (L)", self._nlme_v)
        nlme_btn = self._action_button(
            pop_card,
            "Simulate & fit",
            self._nlme_card_run,
            primary=True,
            tooltip="simulate_population + fit_nlme: the whole FOCEi "
            "ladder in one click (a few seconds -- the outer "
            "Nelder–Mead is honest work).",
        )
        nlme_btn.grid(row=pop_card.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._nlme_result = ttk.Label(
            pop_card,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=340,
            justify="left",
        )
        grid_append(pop_card, self._nlme_result, sticky="w")
        self._nlme_host = self._figure_host(pop_card, height=220)

        # -- Minimal PBPK & DDI qualification (100x-178, OSP) ---------- #
        # the five-compartment minimal PBPK model on ICRP physiology
        # (the toolkit's own RK45 under it), the IVIVE/well-stirred
        # DDI math, and the REAL 34-record digoxin P-gp network from
        # the OSP qualification database
        pbpk_card = make_card(
            page.grid,
            "Minimal PBPK & DDI qualification (OSP)",
            collapsible=True,
            key="pk-pbpk",
            row=9,
            column=1,
            subtitle="Five compartments (venous/lung/liver/kidney/rest) "
            "on ICRP 2002 physiology, integrated by the toolkit's own "
            "RK45; IVIVE microsomal \u2192 in-vivo CLint; the "
            "well-stirred liver; the competitive-inhibition AUC ratio; "
            "and the real 34-record digoxin P-gp DDI network "
            "(Database-for-observed-data v1.7).",
        )
        self._pbpk_bw = ttk.Entry(pbpk_card, width=8)
        self._pbpk_bw.insert(0, "70")
        form_row(pbpk_card, "BW (kg)", self._pbpk_bw)
        self._pbpk_fu = ttk.Entry(pbpk_card, width=8)
        self._pbpk_fu.insert(0, "0.1")
        form_row(pbpk_card, "fu (plasma)", self._pbpk_fu)
        self._pbpk_clint = ttk.Entry(pbpk_card, width=8)
        self._pbpk_clint.insert(0, "50")
        form_row(pbpk_card, "CLint (µL/min/mg)", self._pbpk_clint)
        self._pbpk_ki = ttk.Entry(pbpk_card, width=8)
        self._pbpk_ki.insert(0, "5")
        form_row(pbpk_card, "Ki (µmol/L)", self._pbpk_ki)
        self._pbpk_iconc = ttk.Entry(pbpk_card, width=8)
        self._pbpk_iconc.insert(0, "10")
        form_row(pbpk_card, "inhibitor I (µmol/L)", self._pbpk_iconc)
        pbpk_buttons = ttk.Frame(pbpk_card, style="Card.TFrame")
        grid_append(pbpk_card, pbpk_buttons, sticky="w", pady=(6, 0))
        pbpk_btn = self._action_button(
            pbpk_buttons,
            "PBPK profile",
            self._pbpk_profile_run,
            primary=True,
            tooltip="MinimalPBPK.solve_dataframe on the toolkit's own "
            "ODE engine: the plasma curve and its AUC.",
        )
        pbpk_btn.pack(side="left")
        pbpk_ddi_btn = self._action_button(
            pbpk_buttons,
            "DDI AUC ratio",
            self._pbpk_ddi_run,
            tooltip="hepatic_ddi_auc_ratio: the well-stirred AUC ratio "
            "under competitive inhibition, with its FDA 2020 category.",
        )
        pbpk_ddi_btn.pack(side="left", padx=(8, 0))
        pgp_btn = self._action_button(
            pbpk_buttons,
            "P-gp network",
            self._pgp_network_run,
            tooltip="The real observed digoxin DDI ratios (34 records, "
            "5 perpetrators) grouped by perpetrator and route.",
        )
        pgp_btn.pack(side="left", padx=(8, 0))
        self._pbpk_result = ttk.Label(
            pbpk_card,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=340,
            justify="left",
        )
        grid_append(pbpk_card, self._pbpk_result, sticky="w")
        self._pbpk_host = self._figure_host(pbpk_card, height=180)
        pgp_tree_frame = ttk.Frame(pbpk_card, style="Card.TFrame")
        grid_append(pbpk_card, pgp_tree_frame, sticky="nsew", pady=(6, 0), weight=True)
        self._pgp_tree = ttk.Treeview(
            pgp_tree_frame,
            columns=("perpetrator", "route", "n", "median", "min", "max"),
            show="headings",
            height=6,
        )
        for column, width, label in (
            ("perpetrator", 110, "perpetrator"),
            ("route", 46, "route"),
            ("n", 30, "n"),
            ("median", 70, "median AUCR"),
            ("min", 62, "min"),
            ("max", 62, "max"),
        ):
            self._pgp_tree.heading(column, text=label)
            self._pgp_tree.column(column, width=width, minwidth=40, stretch=False)
        pgp_bar = ttk.Scrollbar(pgp_tree_frame, orient="vertical", command=self._pgp_tree.yview)
        self._pgp_tree.configure(yscrollcommand=pgp_bar.set)
        self._pgp_tree.pack(side="left", fill="both", expand=True)
        pgp_bar.pack(side="right", fill="y")

        # -- OSP PBPK model library (100x-178) ------------------------- #
        # the released-catalogue browser: 40 models with versions and
        # documented GMFE values, the qualification-metric demo on the
        # real network, and the PySide6 optional-backend probe
        lib_card = make_card(
            page.grid,
            "OSP PBPK model library (40 released models)",
            collapsible=True,
            key="pk-osplib",
            row=10,
            column=0,
            span=2,
            subtitle="The Open-Systems-Pharmacology library registry: "
            "every released substance model with its version, "
            "pediatric variant and documented GMFE -- plus the "
            "GMFE/Guest qualification demo on the real network and "
            "the PySide6 optional-backend probe (pyside-setup's "
            "runtime pattern, absorbed).",
        )
        self._osplib_combo = ttk.Combobox(
            lib_card, state="readonly", width=26, values=_OSPLIB_NAMES
        )
        self._osplib_combo.set(_OSPLIB_NAMES[9])     # Digoxin
        form_row(lib_card, "model", self._osplib_combo)
        lib_buttons = ttk.Frame(lib_card, style="Card.TFrame")
        grid_append(lib_card, lib_buttons, sticky="w", pady=(6, 0))
        lib_btn = self._action_button(
            lib_buttons,
            "Show entry",
            self._osplib_show,
            primary=True,
            tooltip="find_model + the documented GMFE table from the "
            "released evaluation report.",
        )
        lib_btn.pack(side="left")
        gmfe_btn = self._action_button(
            lib_buttons,
            "GMFE qualification demo",
            self._gmfe_demo_run,
            tooltip="qualification_metrics on the real 34 observed "
            "ratios: a perfect model (GMFE = 1.0) vs a seeded ±20 % "
            "miss (GMFE ≈ 1.2) -- the acceptance counting the OSP "
            "workflow reports.",
        )
        gmfe_btn.pack(side="left", padx=(10, 0))
        qt_btn = self._action_button(
            lib_buttons,
            "Qt backend probe",
            self._qt_probe_run,
            tooltip="probe_qt_backend: the PySide6 __init__ pattern of "
            "discovering the optional Qt stack without importing it "
            "-- pyside-pyside-setup's honest boundary, absorbed.",
        )
        qt_btn.pack(side="left", padx=(10, 0))
        self._osplib_result = ttk.Label(
            lib_card,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=620,
            justify="left",
        )
        grid_append(lib_card, self._osplib_result, sticky="w")
'''

HANDLERS = r'''    def _pkpd_params(self) -> tuple[float, float, float, float, float, float]:
        """Parse + validate the engine card's six parameters."""
        values = []
        for entry, name, minimum in (
            (self._pkpd_cl, "CL", 1e-9),
            (self._pkpd_v2, "V2", 1e-9),
            (self._pkpd_q, "Q", 0.0),
            (self._pkpd_v3, "V3", 1e-9),
            (self._pkpd_ka, "Ka", 1e-9),
            (self._pkpd_dose, "dose", 1e-9),
        ):
            values.append(parse_float(entry.get(), name, minimum=minimum))
        return tuple(values)  # type: ignore[return-value]

    def _pkpd_engine_run(self) -> None:
        """Exact linCmt vs adaptive RK45 on the two-compartment model."""
        if not self._require_pharmaml() or not self._require("numpy", "the ODE engine"):
            return
        try:
            ka, cl, v2, q, v3, dose = None, None, None, None, None, None
            cl, v2, q, v3, ka, dose = self._pkpd_params()
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        def work() -> Any:
            from pharmaml.pkpd import DosingEvent, TwoCompartment, solve_ode

            model = TwoCompartment(ka=ka, cl=cl, v2=v2, q=q, v3=v3)
            times = np.linspace(0.0, 24.0, 97)
            exact = model.concentrations(times, dose)
            ode = solve_ode(
                model.rhs(), times, [0.0, 0.0, 0.0],
                [DosingEvent(0.0, dose, compartment=0)],
            )
            rk45 = ode.states[:, 1] / v2
            max_diff = float(np.max(np.abs(exact - rk45)))
            auc = float(np.trapezoid(exact, times)) if hasattr(np, "trapezoid") else float(
                np.trapz(exact, times)
            )
            plot_times = np.linspace(0.0, 24.0, 25)
            plot_exact = model.concentrations(plot_times, dose)
            return model, times, exact, max_diff, auc, plot_times, plot_exact, ode

        def render(payload: Any) -> None:
            model, times, exact, max_diff, auc, plot_times, plot_exact, ode = payload
            c_max = float(exact.max())
            t_max = float(times[int(exact.argmax())])
            self._pkpd_result.configure(
                text=(
                    f"linCmt (expm) vs RK45: max |ΔC| = {max_diff:.2e} mg/L · "
                    f"Cmax {c_max:.4g} @ {t_max:g} h · "
                    f"AUC {auc:.4g} mg·h/L · "
                    f"RK45 steps {ode.n_steps} (rejected {ode.n_rejected})"
                )
            )
            if self.deps.get("matplotlib"):
                try:
                    from pharmaml.viz import plot_concentration_profile

                    figure = plot_concentration_profile(
                        plot_times, plot_exact,
                        title="Two-compartment oral — exact expm route",
                    )
                    self._render_figure(self._pkpd_host, figure)
                except Exception as exc:  # noqa: BLE001
                    self._show_error("Plot failed", exc)

        self._start_job("ODE cross-validation", work, render)

    def _pkpd_steady_state_run(self) -> None:
        """Superposition steady state over the card's dosing interval."""
        if not self._require_pharmaml() or not self._require("numpy", "superposition"):
            return
        try:
            cl, v2, q, v3, ka, dose = self._pkpd_params()
            tau = parse_float(self._pkpd_tau.get(), "tau", minimum=1e-6)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        def work() -> Any:
            from pharmaml.pkpd import TwoCompartment, fit_terminal_phase, superposition

            model = TwoCompartment(ka=ka, cl=cl, v2=v2, q=q, v3=v3)
            grid = np.linspace(0.0, 24.0, 97)
            single = model.concentrations(grid, dose)
            fit = fit_terminal_phase(grid, single)
            n_doses = int(np.ceil(5.0 * fit.half_life / tau)) + 1
            n_doses = min(n_doses, 60)
            span = np.linspace(0.0, n_doses * tau, 400)
            curve = superposition(
                span,
                lambda t: np.where(
                    np.asarray(t) >= 0.0,
                    np.interp(np.maximum(np.asarray(t), 0.0), grid, single),
                    0.0,
                ),
                tau=tau,
                n_doses=n_doses,
            )
            interval = (span >= (n_doses - 1) * tau) & (span <= n_doses * tau)
            c_max_ss = float(curve[interval].max())
            c_trough = float(curve[interval][0])
            auc_tau = float(
                np.trapezoid(curve[interval], span[interval])
                if hasattr(np, "trapezoid")
                else np.trapz(curve[interval], span[interval])
            )
            return (span, curve, single, grid, n_doses, c_max_ss, c_trough,
                    auc_tau, fit)

        def render(payload: Any) -> None:
            span, curve, single, grid, n_doses, c_max_ss, c_trough, auc_tau, fit = payload
            from pharmaml.pharma.pk import accumulation_ratio

            ratio = accumulation_ratio(tau, fit.half_life)
            self._pkpd_result.configure(
                text=(
                    f"{n_doses} doses × τ={tau:g} h · Cmax,ss {c_max_ss:.4g} · "
                    f"trough {c_trough:.4g} mg/L · AUC_τ {auc_tau:.4g} mg·h/L · "
                    f"R_pred {ratio:.3g} (λz {fit.lambda_z:.3g} 1/h, "
                    f"span {fit.span_half_lives:.1f} t½)"
                )
            )
            if self.deps.get("matplotlib"):
                try:
                    import matplotlib.pyplot as plt

                    from pharmaml.viz import close_figure, new_figure

                    figure, ax = new_figure(figsize=(8.6, 3.9))
                    ax.plot(grid, single, lw=1.6, ls="--", label="single dose")
                    ax.plot(span, curve, lw=1.9, label=f"{n_doses} doses (superposition)")
                    ax.axvline((n_doses - 1) * tau, color="#999999", ls=":", lw=1.0)
                    ax.set_xlabel("time (h)")
                    ax.set_ylabel("concentration (mg/L)")
                    ax.set_title("Superposition approach to steady state")
                    ax.legend(fontsize=9)
                    self._render_figure(self._pkpd_host, figure)
                    close_figure(figure)
                    _ = plt
                except Exception as exc:  # noqa: BLE001
                    self._show_error("Plot failed", exc)

        self._start_job("superposition steady state", work, render)

    def _nlme_card_run(self) -> None:
        """Simulate a popPK dataset and fit it with FOCEi-lite."""
        if not self._require_pharmaml() or not self._require("numpy", "the NLME fit"):
            return
        try:
            n_subjects = int(parse_float(self._nlme_n.get(), "subjects", minimum=2))
            seed = int(parse_float(self._nlme_seed.get(), "seed"))
            ka_true = parse_float(self._nlme_ka.get(), "true Ka", minimum=1e-6)
            cl_true = parse_float(self._nlme_cl.get(), "true CL", minimum=1e-6)
            v_true = parse_float(self._nlme_v.get(), "V", minimum=1e-6)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        def work() -> Any:
            from pharmaml.pkpd import (
                SubjectObservations,
                fit_nlme,
                simulate_population,
            )

            def predict(theta, eta, times):
                ka = np.exp(theta[0] + eta[0])
                cl = np.exp(theta[1] + eta[1])
                ke = cl / v_true
                gap = ka - ke
                if abs(gap) < 1e-9:
                    return 100.0 * ka * times * np.exp(-ke * times) / v_true
                return (
                    100.0 * ka / (v_true * gap)
                    * (np.exp(-ke * times) - np.exp(-ka * times))
                )

            times = np.array([0.5, 1.0, 2.0, 4.0, 8.0, 12.0])
            profiles = simulate_population(
                predict,
                theta=np.log([ka_true, cl_true]),
                omega_diag=[0.09, 0.04],
                times=times,
                n_subjects=n_subjects,
                seed=seed,
                sigma_add=0.03,
                sigma_prop=0.05,
            )
            subjects = [SubjectObservations(times, values) for values in profiles]
            fit = fit_nlme(
                predict,
                subjects,
                theta0=np.log([0.8 * ka_true, 0.9 * cl_true]),
                omega0=[0.06, 0.03],
                error_model="combined",
                sigma0=(0.05, 0.06),
            )
            ipred_parts = []
            for subject, eta in zip(subjects, fit.eta):
                ipred_parts.append(
                    np.asarray(predict(fit.theta, eta, subject.times)).reshape(-1)
                )
            return fit, profiles, times, ipred_parts

        def render(payload: Any) -> None:
            fit, profiles, times, ipred_parts = payload
            shrink = " · ".join(
                f"{name} {vals['sd_shrink_percent']:.1f}%"
                for name, vals in fit.shrinkage.items()
            )
            self._nlme_result.configure(
                text=(
                    f"Ka {np.exp(fit.theta[0]):.3g} · CL {np.exp(fit.theta[1]):.3g} "
                    f"(true {ka_true:g}/{cl_true:g})\n"
                    f"Ω {np.round(fit.omega_diag, 3)} · σ {np.round(fit.sigma, 3)} · "
                    f"objf {fit.objf:.1f} · AIC {fit.aic:.1f}\n"
                    f"shrinkage: {shrink}"
                )
            )
            if self.deps.get("matplotlib"):
                try:
                    from pharmaml.viz import close_figure, new_figure

                    figure, ax = new_figure(figsize=(6.4, 4.2))
                    for values, ipred in zip(profiles, ipred_parts):
                        ax.scatter(values, ipred, s=22, alpha=0.75,
                                   edgecolor="none")
                    lo = min(min(v.min() for v in profiles),
                             min(i.min() for i in ipred_parts))
                    hi = max(max(v.max() for v in profiles),
                             max(i.max() for i in ipred_parts))
                    ax.plot([lo, hi], [lo, hi], lw=1.4, ls="--", color="#333333")
                    ax.set_xlabel("observed DV")
                    ax.set_ylabel("individual prediction (IPRED)")
                    ax.set_title("DV vs IPRED — FOCEi-lite")
                    self._render_figure(self._nlme_host, figure)
                    close_figure(figure)
                except Exception as exc:  # noqa: BLE001
                    self._show_error("Plot failed", exc)

        self._start_job("FOCEi population fit", work, render)

    def _pbpk_inputs(self) -> tuple[float, float, float]:
        """Parse the PBPK card's body weight, fu and microsomal CLint."""
        return (
            parse_float(self._pbpk_bw.get(), "BW", minimum=1.0),
            parse_float(self._pbpk_fu.get(), "fu", minimum=1e-6, maximum=1.0),
            parse_float(self._pbpk_clint.get(), "CLint", minimum=1e-9),
        )

    def _pbpk_profile_run(self) -> None:
        """One IV bolus through the minimal PBPK model."""
        if not self._require_pharmaml() or not self._require("numpy", "PBPK"):
            return
        try:
            bw, fu, clint = self._pbpk_inputs()
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        def work() -> Any:
            from pharmaml.pkpd import MinimalPBPK

            params = MinimalPBPK.build_params(bw=bw, clint=clint, fu=fu)
            model = MinimalPBPK(params)
            times = np.linspace(0.0, 48.0, 97)
            frame = model.solve_dataframe(times, dose_mg=70.0, route="iv")
            auc = float(
                np.trapezoid(frame["C_plasma"], times)
                if hasattr(np, "trapezoid")
                else np.trapz(frame["C_plasma"], times)
            )
            return frame, params, auc

        def render(payload: Any) -> None:
            frame, params, auc = payload
            self._pbpk_result.configure(
                text=(
                    f"70 mg IV · QC {params['QC']:.4g} L/h · CLint,invivo "
                    f"{params['CLint']:.4g} L/h\nC0 {frame['C_plasma'].iloc[0]:.4g} · "
                    f"AUC {auc:.4g} mg·h/L · CL = 70/AUC = {70.0 / auc:.4g} L/h"
                )
            )
            if self.deps.get("matplotlib"):
                try:
                    from pharmaml.viz import close_figure, new_figure

                    figure, ax = new_figure(figsize=(7.4, 3.6))
                    ax.plot(frame["time"], frame["C_plasma"], lw=1.9,
                            label="C_plasma (venous/BP)")
                    ax.plot(frame["time"], frame["liver"], lw=1.2, ls="--",
                            label="liver")
                    ax.plot(frame["time"], frame["kidney"], lw=1.2, ls=":",
                            label="kidney")
                    ax.set_xlabel("time (h)")
                    ax.set_ylabel("concentration (mg/L)")
                    ax.set_yscale("log")
                    ax.set_title("Minimal PBPK — five compartments, ICRP 70 kg")
                    ax.legend(fontsize=9)
                    self._render_figure(self._pbpk_host, figure)
                    close_figure(figure)
                except Exception as exc:  # noqa: BLE001
                    self._show_error("Plot failed", exc)

        self._start_job("minimal PBPK profile", work, render)

    def _pbpk_ddi_run(self) -> None:
        """The competitive-inhibition AUC ratio through the well-stirred liver."""
        if not self._require_pharmaml():
            return
        try:
            bw, fu, clint = self._pbpk_inputs()
            ki = parse_float(self._pbpk_ki.get(), "Ki", minimum=1e-12)
            inhibitor = parse_float(self._pbpk_iconc.get(), "inhibitor I", minimum=0.0)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return
        try:
            from pharmaml.pkpd import (
                MinimalPBPK,
                ddi_classification,
                guest_et_al_limits,
                hepatic_ddi_auc_ratio,
                well_stirred_clearance,
            )

            params = MinimalPBPK.build_params(bw=bw, clint=clint, fu=fu)
            fu_b = fu / params["BP"]
            ratio = hepatic_ddi_auc_ratio(
                q_h=params["Q_liver"], fu_b=fu_b, clint=params["CLint"],
                inhibitor_conc=inhibitor, ki=ki,
            )
            control = well_stirred_clearance(
                q_h=params["Q_liver"], fu_b=fu_b, clint=params["CLint"]
            )
            low, high = guest_et_al_limits(ratio)
            category = ddi_classification(ratio)
        except Exception as exc:  # noqa: BLE001
            self._show_error("DDI computation failed", exc)
            return
        self._pbpk_result.configure(
            text=(
                f"I/Ki = {inhibitor / ki:.3g} · CLh {control:.4g} → "
                f"{control / ratio:.4g} L/h\nAUCR = {ratio:.3g} "
                f"({category}) · Guest limits for that observed ratio: "
                f"[{low:.3g}, {high:.3g}]"
            )
        )

    def _pgp_network_run(self) -> None:
        """The real 34-record digoxin P-gp DDI network, grouped."""
        if not self._require_pharmaml():
            return

        def work() -> Any:
            from pharmaml.pkpd import P_GP_DDI_RECORDS, ddi_classification, ddi_network_summary

            summary = ddi_network_summary()
            rows = []
            for (perpetrator, route), stats in sorted(summary.items()):
                rows.append(
                    (
                        perpetrator,
                        route,
                        int(stats["n"]),
                        f"{stats.get('median_auc_ratio', float('nan')):.3g}",
                        f"{stats.get('min_auc_ratio', float('nan')):.3g}",
                        f"{stats.get('max_auc_ratio', float('nan')):.3g}",
                    )
                )
            return rows, summary

        def render(payload: Any) -> None:
            rows, summary = payload
            self._pgp_tree.delete(*self._pgp_tree.get_children())
            for row in rows:
                self._pgp_tree.insert("", "end", values=row)
            meds = ", ".join(
                f"{key[0]} {stats.get('median_auc_ratio', float('nan')):.2g}"
                for key, stats in sorted(summary.items())
                if "median_auc_ratio" in stats
            )
            self._pbpk_result.configure(
                text=(
                    f"{sum(int(s['n']) for s in summary.values())} observed records "
                    f"({len(summary)} perpetrator×route groups) · median AUCRs: {meds}"
                )
            )

        self._start_job("P-gp DDI network", work, render)

    def _osplib_show(self) -> None:
        """One library entry: version, category, notes, documented GMFE."""
        if not self._require_pharmaml():
            return
        name = self._osplib_combo.get()
        try:
            from pharmaml.pkpd import (
                DOCUMENTED_GMFE,
                OSP_SUITE_VERSION,
                QUALIFICATION_FRAMEWORK_VERSION,
                find_model,
            )

            entry = find_model(name)
        except Exception as exc:  # noqa: BLE001
            self._show_error("Library lookup failed", exc)
            return
        gmfe = DOCUMENTED_GMFE.get(entry.name)
        lines = [
            f"{entry.name} · v{entry.version} · {entry.category}"
            + (" · pediatric variant" if entry.pediatric else ""),
            entry.notes,
            f"OSP Suite {OSP_SUITE_VERSION} · Qualification Framework "
            f"{QUALIFICATION_FRAMEWORK_VERSION}",
        ]
        if gmfe:
            pretty = " · ".join(f"{k} {v:.3g}" for k, v in gmfe.items())
            lines.append(f"documented GMFE: {pretty}")
        else:
            lines.append("no GMFE documented in this round's absorbed reports")
        self._osplib_result.configure(text="\n".join(lines))

    def _gmfe_demo_run(self) -> None:
        """Qualification metrics on the real network: perfect vs ±20 %."""
        if not self._require_pharmaml() or not self._require("numpy", "GMFE"):
            return
        try:
            from pharmaml.pkpd import P_GP_DDI_RECORDS, qualification_metrics

            observed = [
                record.auc_ratio for record in P_GP_DDI_RECORDS
                if record.auc_ratio is not None
            ]
            perfect = qualification_metrics(observed, observed)
            rng = np.random.default_rng(5)
            noisy = [
                value * float(np.exp(rng.normal(0.0, 0.20)))
                for value in observed
            ]
            perturbed = qualification_metrics(observed, noisy)
        except Exception as exc:  # noqa: BLE001
            self._show_error("GMFE demo failed", exc)
            return
        self._osplib_result.configure(
            text=(
                f"perfect model: GMFE {perfect['gmfe']:.3g} · "
                f"2-fold {perfect['fraction_within_twofold'] * 100:.0f}% · "
                f"Guest {perfect['fraction_within_guest'] * 100:.0f}%\n"
                f"±20 % misses:  GMFE {perturbed['gmfe']:.3g} · "
                f"2-fold {perturbed['fraction_within_twofold'] * 100:.0f}% · "
                f"Guest {perturbed['fraction_within_guest'] * 100:.0f}% "
                f"(n = {int(perfect['n'])})"
            )
        )

    def _qt_probe_run(self) -> None:
        """The PySide6-style optional-backend probe (pyside-setup)."""
        try:
            from pharmaml.viz.qt_backend import describe_qt_backend, probe_qt_backend

            info = probe_qt_backend()
            text = describe_qt_backend() + "\n" + info.note
        except Exception as exc:  # noqa: BLE001
            self._osplib_result.configure(text=f"Qt probe failed: {exc}")
            return
        self._osplib_result.configure(text=text)

'''

SELFTEST = r'''    app._busy = False
    app._report_progress(9, 10, "straggler")  # dropped when idle
    app._poll_progress()
    assert app._job_label.cget("text") == "probe — 2"

    # -- PK/PD engines (100x-177/178) --------------------------------- #
    # the four new cards' engines, exercised headlessly: the ODE cross-
    # validation, superposition, the hybrid AUC, the DDI math on the
    # real network, the library registry, a small FOCEi fit and the Qt
    # probe -- loudly asserted, not trusted
    import importlib as _importlib

    _pkpd = _importlib.import_module("pharmaml.pkpd")
    _times = np.linspace(0.0, 24.0, 49)
    _model = _pkpd.TwoCompartment(ka=1.2, cl=5.0, v2=50.0, q=3.0, v3=100.0)
    _exact = _model.concentrations(_times, 100.0)
    _ode = _pkpd.solve_ode(
        _model.rhs(), _times, [0.0, 0.0, 0.0],
        [_pkpd.DosingEvent(0.0, 100.0, compartment=0)],
    )
    _diff = float(np.max(np.abs(_exact - _ode.states[:, 1] / 50.0)))
    assert _diff < 1e-4, f"linCmt vs RK45 disagree: {_diff}"
    _single = lambda t: np.where(  # noqa: E731
        np.asarray(t) >= 0.0, np.exp(-0.5 * np.asarray(t)), 0.0
    )
    _peaks = _pkpd.superposition(np.array([38.0]), _single, tau=2.0, n_doses=20)
    assert abs(float(_peaks[0]) - 1.0 / (1.0 - np.exp(-1.0))) < 1e-6
    assert abs(_pkpd.bateman(2.0, 0.5, 0.5, 1.0)
               - _pkpd.bateman(2.0, 0.5 + 1e-12, 0.5, 1.0)) < 1e-9
    assert abs(_pkpd.auc_linear_log([0.0, 1.0, 2.0], [0.0, 10.0, 5.0]) - 12.2135) < 1e-3
    assert _pkpd.guest_et_al_limits(2.0) == (1.8, 2.25)
    assert abs(_pkpd.chen_prusoff(ic50=7.0, substrate_conc=1.0, km=2.73) - 5.1239) < 1e-3
    assert len(_pkpd.P_GP_DDI_RECORDS) == 34
    _summary = _pkpd.ddi_network_summary()
    assert int(_summary[("Rifampicin", "PO")]["n"]) == 11
    assert int(_summary[("Itraconazole", "PO")]["n"]) == 3
    assert _pkpd.ddi_classification(3.0) == "moderate inhibitor"
    assert len(_pkpd.OSP_PBPK_LIBRARY) == 40
    assert _pkpd.find_model("digoxin").version == "2.0"
    _observed = [r.auc_ratio for r in _pkpd.P_GP_DDI_RECORDS if r.auc_ratio is not None]
    assert _pkpd.gmfe(_observed, _observed) == 1.0
    assert abs(_pkpd.weibull_dissolution(406.3001802552, t50=406.3001802552,
                                         shape=1.43) - 0.5) < 1e-9

    # a small FOCEi fit (4 subjects, 4 samples) must recover CL within
    # 35 % and produce finite nlmixr2-style reporting fields
    def _predict(theta, eta, times):
        ka = np.exp(theta[0] + eta[0])
        cl = np.exp(theta[1] + eta[1])
        ke = cl / 20.0
        gap = ka - ke
        return 100.0 * ka / (20.0 * gap) * (np.exp(-ke * times) - np.exp(-ka * times))

    _times4 = np.array([0.5, 1.0, 2.0, 4.0])
    _profiles = _pkpd.simulate_population(
        _predict, np.log([1.0, 3.0]), [0.09, 0.04], _times4, 4,
        seed=7, sigma_add=0.03, sigma_prop=0.05,
    )
    _subjects = [_pkpd.SubjectObservations(_times4, v) for v in _profiles]
    _fit = _pkpd.fit_nlme(
        _predict, _subjects, np.log([0.9, 2.8]), [0.06, 0.03],
        error_model="combined", sigma0=(0.05, 0.06), outer_maxiter=150,
    )
    assert 2.0 < float(np.exp(_fit.theta[1])) < 4.5, _fit.theta
    assert math.isfinite(_fit.objf) and math.isfinite(_fit.log_lik)
    assert _fit.n_obs == 16 and _fit.n_subjects == 4
    assert set(_fit.residuals) >= {"PRED", "IPRED", "IWRES", "CWRES"}

    _params = _pkpd.MinimalPBPK.build_params(bw=70.0, clint=50.0, fu=0.10)
    assert abs(_params["V_blood"] - 0.079 * 70.0) < 1e-9
    assert abs(_pkpd.ivive_clint_invivo(clint_ul_min_mg=50.0, liver_weight_g=1820.0)
               - 218.4) < 1e-6
    from pharmaml.viz.qt_backend import describe_qt_backend as _describe_qt

    assert _describe_qt().startswith("Qt backend:")

'''

DOCSTRING_ADD = r'''  aware unit converter (mass / volume / amount / concentration / time)
  -- and (100x-177/178) the PK/PD engine layer: the ODE engine card
  (two-compartment model solved exactly by the matrix exponential,
  cross-validated live against the toolkit's own adaptive RK45 ODE
  engine with dosing events, plus the superposition steady state),
  the FOCEi-lite population-PK card (nlmixr2-style thetas / omega /
  shrinkage / objf with a DV-vs-IPRED scatter), the minimal-PBPK & DDI
  card (five compartments on ICRP physiology, IVIVE, the well-stirred
  liver, the competitive-inhibition AUC ratio, and the REAL 34-record
  digoxin P-gp DDI network from the OSP observed-data database), and
  the OSP model library browser (40 released models, documented GMFE
  values, the Guest-limits qualification demo, the PySide6 optional-
  backend probe).'''

OSPLIB_CONST = r'''
#: OSP PBPK model library combobox: the 40 released substance models
#: (Open-Systems-Pharmacology/OSP-PBPK-Model-Library v12.3.1).
_OSPLIB_NAMES: tuple[str, ...] = (
    "7E3", "Alfentanil", "Alprazolam", "Amikacin", "Atazanavir",
    "BAY794620", "CDA1", "Carbamazepine", "Cimetidine", "Clarithromycin",
    "Dapagliflozin", "Digoxin", "dAb2", "Efavirenz", "Erythromycin",
    "Ethinylestradiol", "Felodipine", "Fluconazole", "Fluvoxamine", "Inulin",
    "Itraconazole", "MEDI524", "MEDI524YTE", "Mefenamic_acid", "Mexiletine",
    "Midazolam", "Moclobemide", "Montelukast", "Omeprazole", "Propofol",
    "Raltegravir", "Rifampicin", "S-Mephenytoin", "Sildenafil", "Sufentanil",
    "Tefibazumab", "Tizanidine", "Triazolam", "Vancomycin", "Verapamil",
)
'''


def main() -> None:
    path = "playground.py"
    with open(path) as handle:
        src = handle.read()

    anchor_cards = """        bind_enter(self._uc_value, uc_btn)
        bind_enter(self._uc_to, uc_btn)
"""
    assert src.count(anchor_cards) == 1, "cards anchor not unique"
    src = src.replace(anchor_cards, CARDS.lstrip("\n") + "\n")

    anchor_handlers = "    def _halflife_math(self) -> None:"
    assert src.count(anchor_handlers) == 1, "handler anchor not unique"
    src = src.replace(anchor_handlers, HANDLERS + anchor_handlers)

    anchor_selftest = '''    app._busy = False
    app._report_progress(9, 10, "straggler")  # dropped when idle
    app._poll_progress()
    assert app._job_label.cget("text") == "probe — 2"
'''
    assert src.count(anchor_selftest) == 1, "selftest anchor not unique"
    src = src.replace(anchor_selftest, SELFTEST.rstrip("\n") + "\n")

    anchor_doc = "  aware unit converter (mass / volume / amount / concentration / time)."
    assert src.count(anchor_doc) == 1, "docstring anchor not unique"
    src = src.replace(anchor_doc, DOCSTRING_ADD)

    # _OSPLIB_NAMES constant: park it next to the other card constants
    anchor_const = "#: NCA card: a one-compartment IV bolus"
    assert src.count(anchor_const) == 1, "const anchor not unique"
    src = src.replace(anchor_const, OSPLIB_CONST.strip("\n") + "\n\n" + anchor_const)

    with open(path, "w") as handle:
        handle.write(src)
    print("spliced: cards, handlers, self-test, docstring, constants")


if __name__ == "__main__":
    main()
