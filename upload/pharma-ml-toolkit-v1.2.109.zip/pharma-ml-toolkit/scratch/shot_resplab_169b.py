"""Round-169 screenshots part 2: the scrolled-down cards."""
import sys
import time

sys.path.insert(0, ".")
import playground


def pump(app, timeout=300.0):
    deadline = time.monotonic() + timeout
    while app._busy and time.monotonic() < deadline:
        app.update_idletasks(); app.update(); time.sleep(0.01)


app = playground.PlaygroundApp(persist_session=False)
for _ in range(6):
    app.update_idletasks(); app.update()

titles = [app._book.tab(i, "text").strip() for i in range(app._book.index("end"))]
app._book.select(next(i for i, t in enumerate(titles) if "Response Lab" in t))
app.update()
app.geometry("1600x1000+0+0")

app._resplab_run_gsva(); pump(app)
app._resplab_run_recommender(); pump(app)
app._resplab_cell_combo.set(str(app._resplab_features.index[0]))
app._resplab_run_repurposing(); pump(app)
app._resplab_run_audit(); pump(app)
app._resplab_run_bayes(); pump(app)
app._resplab_run_ensemble(); pump(app)
app.update_idletasks(); app.update(); time.sleep(0.4)

from PIL import ImageGrab

page = app._book.nametowidget(app._book.select())
canvas = getattr(page, "_canvas", None)
if canvas is not None:
    canvas.yview_moveto(0.5)
    app.update(); time.sleep(0.3)
    ImageGrab.grab(xdisplay=":98").save("pg169-resplab-mid.png")
    canvas.yview_moveto(0.85)
    app.update(); time.sleep(0.3)
    ImageGrab.grab(xdisplay=":98").save("pg169-resplab-bottom.png")

app.destroy()
print("shots b saved")
