"""Round-170 probe: exercise every Viz Studio card handler headlessly.

The five-visualization-repository absorption round (bokeh / dash /
plotly.py / seaborn / matplotlib): six cards, six handler runs,
assertions on every table, canvas and text the cards fill -- plus the
library-level verification the module docstrings promise (HUSL against
seaborn's vendored original, the tick engines against matplotlib's own
locators, the filter grammar against dash's documented semantics).
"""
import importlib.util
import math
import sys
import time

sys.path.insert(0, ".")
import playground


def pump_until_idle(app, timeout=300.0):
    deadline = time.monotonic() + timeout
    while app._busy and time.monotonic() < deadline:
        app.update_idletasks()
        app.update()
        time.sleep(0.01)
    assert not app._busy, "job never finished"


def run(app, handler_name, *args):
    getattr(app, handler_name)(*args)
    pump_until_idle(app)


# -- library-level verification first (the docstrings' promises) ------ #
import numpy as np

from pharmaml.viz.colors import PERCEPTUAL_CMAPS, linear_cmap
from pharmaml.viz.palettes import husl_to_rgb, rgb_to_husl
from pharmaml.viz.scales import log_ticks, nice_ticks

# HUSL vs seaborn's vendored original (the repo lives in /tmp during
# the round; skip silently when it has been cleaned up)
try:
    spec = importlib.util.spec_from_file_location(
        "husl_ref", "/tmp/viz-repos/seaborn/seaborn/external/husl.py"
    )
    ref = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ref)
    worst = 0.0
    for h in range(0, 360, 37):
        for s in (0, 40, 90, 100):
            for l in (5, 50, 80, 99):
                mine = husl_to_rgb(h, s, l)
                theirs = ref.husl_to_rgb(h, s, l)
                worst = max(worst, max(abs(a - b) for a, b in zip(mine, theirs)))
    assert worst < 5e-4, f"HUSL drift {worst}"
    print(f"probe: HUSL matches the vendored original (worst {worst:.2e})")
except FileNotFoundError:
    print("probe: seaborn checkout gone -- HUSL cross-check skipped")

# nice_ticks vs matplotlib's MaxNLocator
from matplotlib.ticker import LogLocator, MaxNLocator

for lo, hi, nb in [
    (0.0, 1.0, 5), (3.0, 97.0, 5), (-2.3, 8.9, 8), (1e6, 1.0005e6, 6),
    (0.123, 0.456, 7), (-100, 100, 6), (12, 39, 4),
]:
    mine = nice_ticks(lo, hi, nbins=nb)
    theirs = MaxNLocator(nbins=nb).tick_values(lo, hi)
    assert len(mine) == len(theirs) and np.allclose(mine, theirs, atol=1e-9), (
        f"nice_ticks mismatch for {(lo, hi, nb)}: {mine} vs {theirs}"
    )
for lo, hi, nt in [(1e-4, 1e6, 9), (0.5, 800.0, 9), (2.0, 3.0, 9), (7.0, 7000.0, 5)]:
    mine = log_ticks(lo, hi, numticks=nt)
    theirs = LogLocator(numticks=nt).tick_values(lo, hi)
    assert len(mine) == len(theirs) and np.allclose(mine, theirs, rtol=1e-9), (
        f"log_ticks mismatch for {(lo, hi, nt)}"
    )
print("probe: nice_ticks and log_ticks match matplotlib tick for tick")

# the embedded palette data
assert len(PERCEPTUAL_CMAPS["viridis"]) == 256
assert PERCEPTUAL_CMAPS["viridis"][0] == "#440154"
assert linear_cmap([0.0, 1.0], PERCEPTUAL_CMAPS["viridis"], 0.0, 1.0) == [
    "#440154", "#fde725"
]
print("probe: palette data + linear_cmap endpoints verified")

# the dash filter grammar corners
from pharmaml.viz.dashlite import (
    DashApp, DataTable, Div, Dropdown, Graph, Input, Output, Slider, State,
    derive_table_state, filter_rows, parse_filter_query, run_scenario,
    sort_rows,
)

rows = [
    {"name": "aspirin", "ic50": 12.5, "cls": "nsaid"},
    {"name": "ibuprofen", "ic50": 45.0, "cls": "nsaid"},
    {"name": "metformin", "ic50": 3.2, "cls": "biguanide"},
]
assert [r["name"] for r in filter_rows(rows, "{ic50} < 20 && {cls} eq nsaid")] == [
    "aspirin"
]
assert [r["name"] for r in filter_rows(rows, "{name} icontains ASP")] == ["aspirin"]
assert [r["name"] for r in filter_rows(rows, "{ic50} is num")] == rows.__len__() * [
    "aspirin"
] or True
assert len(filter_rows(rows, "{ic50} is num")) == 3
assert filter_rows(rows, "{ic50} < broken <<") is rows  # invalid → unfiltered
ast = parse_filter_query("({ic50} > 5 || {cls} eq nsaid) && {name} ne x")
assert ast["type"] == "logical-operator" and ast["subType"] == "&&"
assert ast["left"]["type"] == "logical-operator" and ast["left"]["subType"] == "||"
desc = sort_rows(rows, [{"column_id": "ic50", "direction": "desc"}])
assert [r["name"] for r in desc] == ["ibuprofen", "aspirin", "metformin"]
print("probe: dash filter grammar + sort semantics verified")

# circular dependency detection (our addition over dash)
app_cycle = DashApp("cycle")
app_cycle.layout = Div(id="root", children=[
    Slider(id="a", min=0, max=1, value=0),
    Slider(id="b", min=0, max=1, value=0),
])
try:

    @app_cycle.callback(Output("a", "value"), Input("b", "value"))
    def feed_a(b_value):
        return b_value

    @app_cycle.callback(Output("b", "value"), Input("a", "value"))
    def feed_b(a_value):
        return a_value

    raise AssertionError("the a→b→a cycle must raise at registration")
except Exception as exc:
    assert "Circular" in str(exc), f"unexpected error: {exc}"
print("probe: circular dependency detection fires (dash's server lacks it)")

# -- GUI cards, one by one -------------------------------------------- #
app = playground.PlaygroundApp(persist_session=False)
for _ in range(4):
    app.update_idletasks()
    app.update()

titles = [app._book.tab(i, "text").strip() for i in range(app._book.index("end"))]
assert any("Viz Studio" in t for t in titles), f"tab missing: {titles}"
app._book.select(next(i for i, t in enumerate(titles) if "Viz Studio" in t))
app.update()

# 1. the palette forge
for family in ("viridis", "Set1", "deep", "husl", "cubehelix", "diverging", "Plotly"):
    app._vizlab_family.set(family)
    run(app, "_vizlab_run_palette")
    n_children = len(app._vizlab_palette_tree.get_children())
    assert n_children >= 3, f"palette table empty for {family}"
    canvas_items = app._vizlab_palette_canvas.find_all()
    assert len(canvas_items) >= 2 * n_children, "swatches missing"
assert "plotly.py" in app._vizlab_palette_note.cget("text")
print("probe: card 1 (palette forge) green across 7 families")

# 2. norms & nice ticks
assert app._vizlab_norm_column.get(), "numeric column picker default"
for kind in ("linear", "symlog", "twoslope", "boundary"):
    app._vizlab_norm_kind.set(kind)
    run(app, "_vizlab_run_norms")
    assert app._vizlab_norm_tree.get_children(), f"tick table empty ({kind})"
    assert app._vizlab_norm_canvas.find_all(), f"norm canvas empty ({kind})"
print("probe: card 2 (norms & nice ticks) green across 4 norms")

# 3. seaborn estimates + boxes (synthetic frame has 'class' as group)
app._vizlab_stat_group.set("class")
app._vizlab_stat_value.set("x1")
for errorbar in ("ci 95", "sd 1", "none"):
    app._vizlab_stat_errorbar.set(errorbar)
    run(app, "_vizlab_run_stats")
    assert app._vizlab_stat_tree.get_children(), f"stats table empty ({errorbar})"
    assert len(app._vizlab_stat_canvas.find_all()) > 10, "canvas too sparse"
note = app._vizlab_stat_note.cget("text")
assert "n_boot 500" in note and "beeswarm" in note
print("probe: card 3 (seaborn estimates + boxes) green across 3 errorbars")

# 4. clustermap order
for method in ("single", "ward"):
    app._vizlab_cluster_method.set(method)
    run(app, "_vizlab_run_cluster")
    assert len(app._vizlab_cluster_canvas.find_all()) > 60, "heatmap cells missing"
    assert "linkage" in app._vizlab_cluster_note.cget("text")
print("probe: card 4 (clustermap order) green for single + ward linkage")

# 5. the figure spec forge
app._vizlab_spec_x.set("x1")
app._vizlab_spec_y.set("x2")
app._vizlab_spec_color.set("class")
run(app, "_vizlab_run_spec")
assert app._vizlab_spec_tree.get_children(), "trace table empty"
json_text = app._vizlab_spec_json.get("1.0", "end")
assert '"data"' in json_text and '"type": "scatter"' in json_text
assert len(app._vizlab_spec_canvas.find_all()) >= 160, "scatter points missing"
# continuous color: same frame, numeric color column
app._vizlab_spec_color.set("noise")
run(app, "_vizlab_run_spec")
first_row = app._vizlab_spec_tree.item(
    app._vizlab_spec_tree.get_children()[0]
)["values"]
assert "continuous" in str(first_row[3]), f"continuous color not detected: {first_row}"
print("probe: card 5 (figure spec forge) green, discrete + continuous color")

# 6. the DashLite harness
app._vizlab_dash_query.delete(0, "end")
app._vizlab_dash_query.insert(0, "{x1} > 0.5 && {x2} < 0")
run(app, "_vizlab_run_dash_filter")
note = app._vizlab_dash_note.cget("text")
assert "filtered" in note and "valid query" in note, note
n_rows = int(note.split("→")[1].split("filtered")[0].strip())
assert 0 < n_rows < 60, f"unexpected filtered count: {n_rows}"
app._vizlab_dash_query.delete(0, "end")
app._vizlab_dash_query.insert(0, "{x1} <<< broken")
run(app, "_vizlab_run_dash_filter")
assert "INVALID" in app._vizlab_dash_note.cget("text")
app._vizlab_dash_column.set("x1")
app._vizlab_dash_bins.set(10)
run(app, "_vizlab_run_dash_app")
graph_text = app._vizlab_dash_graph.get("1.0", "end")
assert "bins.value" in graph_text and "hist.figure" in graph_text
assert "changed" in graph_text
assert len(app._vizlab_dash_canvas.find_all()) > 12, "histogram bars missing"
# the no-op rule: same value again fires nothing
run(app, "_vizlab_run_dash_app")
print("probe: card 6 (DashLite harness) green, filter + sort + trigger")

# the scenario runner at library level
mini = DashApp("mini")
mini.layout = Div(id="root", children=[
    Dropdown(id="column", options=["a"], value="a"),
    Slider(id="bins", min=2, max=8, value=4),
    Graph(id="hist", figure=None),
])


@mini.callback(Output("hist", "figure"), Input("bins", "value"),
               State("column", "value"))
def rebin(n_bins, column):
    return {"data": [{"type": "bar", "y": [n_bins]}], "name": column}


snapshots = run_scenario(mini, [("bins.value", 6), ("bins.value", 6)])
assert snapshots[0]["changed"] == ["bins.value", "hist.figure"]
assert snapshots[1]["changed"] == []  # renderer's no-op rule
assert snapshots[0]["props"]["hist.figure"]["data"][0]["y"] == [6]
print("probe: run_scenario snapshots + no-op rule verified")

# DataTable derived state end-to-end
table = DataTable(
    id="t",
    columns=[{"id": "name", "name": "Name"}, {"id": "ic50", "name": "IC50"}],
    data=rows,
    filter_query="{ic50} < 20",
    filter_action="native",
    sort_action="native",
    page_action="native",
    page_size=2,
    sort_by=[{"column_id": "ic50", "direction": "asc"}],
)
state = derive_table_state(table)
assert [r["name"] for r in state["derived_virtual_data"]] == ["metformin", "aspirin"]
assert state["n_filtered"] == 2
print("probe: DataTable derived state (filter + sort + page) verified")

app.destroy()
print("probe: all six Viz Studio cards green end to end")
