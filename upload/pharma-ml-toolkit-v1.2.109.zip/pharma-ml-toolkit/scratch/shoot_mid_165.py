import os, subprocess, sys, time
from pathlib import Path
TOOLKIT = Path(__file__).resolve().parents[1]
os.chdir(TOOLKIT); sys.path.insert(0, str(TOOLKIT))
DISPLAY = ":94"
proc = subprocess.Popen(["Xvfb", DISPLAY, "-screen", "0", "1600x1000x24"],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sock = Path(f"/tmp/.X11-unix/X{DISPLAY[1:]}")
deadline = time.time() + 10.0
while time.time() < deadline and not sock.exists():
    time.sleep(0.1)
os.environ["DISPLAY"] = DISPLAY
import playground
app = playground.PlaygroundApp(persist_session=False)
app.update_idletasks(); app.update()
for tab in ("Docking", "Deep Learning", "Unsupervised", "Generative"):
    for i in range(app._book.index("end")):
        p = app._book.nametowidget(app._book.tabs()[i])
        if str(app._book.tab(p, "text")).strip() == tab:
            app._jump_to_tab(i)
for tab, frac in (("Docking", 0.09), ("Deep Learning", 0.12), ("Unsupervised", 0.0), ("Generative", 0.22)):
    for i in range(app._book.index("end")):
        p = app._book.nametowidget(app._book.tabs()[i])
        if str(app._book.tab(p, "text")).strip() == tab:
            app._jump_to_tab(i)
    app.update_idletasks(); app.update()
    canvas = getattr(app._book.nametowidget(app._book.select()), "_canvas", None)
    if canvas is not None:
        canvas.yview_moveto(frac)
    app.update_idletasks(); app.update()
    time.sleep(0.4)
    from PIL import ImageGrab
    out = TOOLKIT / "scratch" / f"pg165-mid-{tab.lower().replace(' ','-')}.png"
    ImageGrab.grab(xdisplay=DISPLAY).save(str(out))
    print("shot", out.name)
app.destroy()
proc.terminate()
