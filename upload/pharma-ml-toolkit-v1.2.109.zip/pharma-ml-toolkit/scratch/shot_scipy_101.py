"""Round-101 screenshots: the SciPy Lab tab, top and cards views."""
import sys

sys.path.insert(0, ".")
import playground

app = playground.PlaygroundApp(persist_session=False)
for _ in range(6):
    app.update_idletasks()
    app.update()

titles = [app._book.tab(i, "text").strip() for i in range(app._book.index("end"))]
app._book.select(next(i for i, t in enumerate(titles) if "SciPy Lab" in t))
for _ in range(8):
    app.update_idletasks()
    app.update()

from PIL import ImageGrab


def shot(name: str) -> None:
    image = ImageGrab.grab(xdisplay=":98")
    image.save(f"pg101-scipy-{name}.png")
    print("saved", name, image.size)

# 1. the tab top (cards 1-2 area)
shot("top")

# 2. run the peak card so the table populates, then re-shoot
app._scipy_run_peaks()
import time

deadline = time.monotonic() + 60
while app._busy and time.monotonic() < deadline:
    app.update_idletasks()
    app.update()
    time.sleep(0.01)
shot("peaks")

# 3. scroll to the bottom cards (compartment + distances + binding)
page = app._book.nametowidget(app._book.tabs()[titles.index("SciPy Lab") if False else next(i for i, t in enumerate(titles) if "SciPy Lab" in t)])
canvas = None
for widget in app._walk_widgets(page):
    if widget.winfo_class() == "Canvas":
        canvas = widget
        break
if canvas is not None:
    canvas.yview_moveto(1.0)
    for _ in range(8):
        app.update_idletasks()
        app.update()
shot("bottom")

app.destroy()
print("SHOTS SCIPY 101 DONE")
