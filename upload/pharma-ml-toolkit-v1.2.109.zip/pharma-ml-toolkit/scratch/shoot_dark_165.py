import os, subprocess, sys, time
from pathlib import Path
TOOLKIT = Path(__file__).resolve().parents[1]
os.chdir(TOOLKIT); sys.path.insert(0, str(TOOLKIT))
DISPLAY = ":93"
proc = subprocess.Popen(["Xvfb", DISPLAY, "-screen", "0", "1600x1000x24"],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sock = Path(f"/tmp/.X11-unix/X{DISPLAY[1:]}")
deadline = time.time() + 10.0
while time.time() < deadline and not sock.exists():
    time.sleep(0.1)
os.environ["DISPLAY"] = DISPLAY
import playground
app = playground.PlaygroundApp(persist_session=False)
app.update_idletasks(); app.update()
app._set_theme("dark")
app.update_idletasks(); app.update()
for i in range(app._book.index("end")):
    p = app._book.nametowidget(app._book.tabs()[i])
    if str(app._book.tab(p, "text")).strip() == "Docking":
        app._jump_to_tab(i)
app.update_idletasks(); app.update()
time.sleep(0.5)
from PIL import ImageGrab
ImageGrab.grab(xdisplay=DISPLAY).save(str(TOOLKIT / "scratch" / "pg165-dark-docking.png"))
print("shot dark docking")
app.destroy()
proc.terminate()
