"""Generate ``src/pharmaml/pkpd/_physiology_data.py`` from PKSimDB.sqlite.

Round 176 (100x-176): the PK-Sim static physiology layer.  This script
extracts the exact tables out of the cloned repository
``repo-clones/PK-Sim/src/Db/PKSimDB.sqlite`` (Open-Systems-Pharmacology,
develop @ fcb896d) and emits them as typed Python literals so the values
are transcription-faithful by construction.  Re-run after bumping the
clone; the module header records the row counts.

Usage::

    PYTHONPATH=src python scratch/build_physiology_data.py
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

# The PK-Sim clone lives one level above the toolkit tree (the session's
# shared ``repo-clones/`` directory); resolve it relative to this script so
# no absolute home path ever enters the shipped tree.
DB = (
    Path(__file__).resolve().parent.parent.parent
    / "repo-clones"
    / "PK-Sim"
    / "src"
    / "Db"
    / "PKSimDB.sqlite"
)
OUT = Path(__file__).resolve().parent.parent / "src" / "pharmaml" / "pkpd" / "_physiology_data.py"

# The organs whose composition feeds the partition-coefficient methods.
TISSUE_ORGANS = [
    "Bone", "Brain", "Fat", "Gonads", "Heart", "Kidney", "Liver", "Lung",
    "Muscle", "Pancreas", "Skin", "Spleen", "Stomach",
]

# container parameter name -> our key
LIVER_KEYS = {
    "Volume": "volume_l",
    "Specific blood flow rate": "qspec_l_min_kg",
    "Fraction vascular": "f_vas",
    "Fraction interstitial": "f_int",
    "Microsomal protein mass/g tissue": "mppgl_mg_g",
    "Number of cells/g tissue": "cells_per_g",
}

TISSUE_KEYS = {
    "Vf (water)": "f_water",
    "Vf (lipid)": "f_lipid",
    "Vf (protein)": "f_protein",
    "Vf (intracellular water)-RR": "f_iw",
    "Vf (extracellular water)-RR": "f_ew",
    "Vf (neutral lipid)-RR": "f_nl_rr",
    "Vf (neutral phospholipid)-RR": "f_np_rr",
    "Vf (water)-PT": "v_wt",
    "Vf (neutral lipid)-PT": "v_nlt",
    "Vf (phospholipid)-PT": "v_pht",
    "Vf (water)-WS": "f_water_ws",
    "Vf (neutral lipid)-WS": "f_nl_ws",
    "Vf (protein)-WS": "f_prot_ws",
    "Vf (acidic phospholipids)-WS": "f_ap_ws",
    "Albumin ratio (tissue/plasma)": "albumin_ratio",
    "Lipoprotein ratio (tissue/plasma)": "lipoprotein_ratio",
    "Acidic phospholipids [mg/g] - RR": "acidic_phospholipids_rr",
    "Fraction vascular": "f_vas",
    "Fraction interstitial": "f_int",
}

ORGANISM_KEYS = {
    "Vf (water,plasma)": "f_water_plasma",
    "Vf (protein,plasma)": "f_protein_plasma",
    "Vf (lipid, plasma)": "f_lipid_plasma",
    "Vf (water,plasma)-PT": "v_wp",
    "Vf (neutral lipid, plasma)-PT": "v_nlp",
    "Vf (phospholipid, plasma)-PT": "v_php",
    "Vf (neutral lipid, plasma)-RR": "f_nl_p",
    "Vf (neutral phospholipid, plasma)-RR": "f_np_p",
    "Vf (water,blood cells)": "f_water_rbc",
    "Vf (lipid, blood cells)": "f_lipid_rbc",
    "Vf (protein,blood cells)": "f_protein_rbc",
    "Vf (intracellular water, blood cells)-RR": "f_iw_bc",
    "Vf (neutral lipid, blood cells)-RR": "f_nl_bc",
    "Vf (neutral phospholipid, blood cells)-RR": "f_np_bc",
    "Vf (neutral lipid, blood cells)-WS": "f_nl_bc_ws",
    "Vf (neutral phospholipid, blood cells)-WS": "f_np_bc_ws",
    "Vf (acidic phospholipids, blood cells)-WS": "f_ap_bc_ws",
    "Vf (water,interstitial)": "f_water_int",
    "Acidic phospholipids (blood cells) [mg/g] - RR": "acidic_phospholipids_bc_rr",
    "pH (plasma)": "ph_plasma",
    "pH (interstitial)": "ph_interstitial",
    "pH (intracellular)": "ph_intracellular",
    "pH (blood cells)": "ph_blood_cells",
    "Protein ratio (interstial/plasma)": "protein_ratio_int_plasma",
}

KIDNEY_GFR_KEYS = {
    "TM50 for GFR": "tm50_weeks",
    "Hill coefficient for GFR": "hill",
    "GFR maturation fraction at birth": "premat_floor",
}

AGE_CURVES = [
    ("Liver", "Volume", "liver_volume"),
    ("Liver", "Specific blood flow rate", "liver_qspec"),
    ("Organism", "MeanBW", "mean_bw"),
    ("Organism", "MeanHeight", "mean_height_dm"),
    ("Organism", "Hematocrit", "hematocrit"),
]


def fmt(v: float) -> str:
    """Compact but exact repr (shortest round-trip form)."""
    s = repr(float(v))
    if s.endswith(".0"):
        s = s[:-2]
    return s


def rows_literal(rows: list[tuple], indent: str = "    ") -> list[str]:
    lines = []
    for r in rows:
        parts = ", ".join(fmt(v) if isinstance(v, float) else repr(v) for v in r)
        lines.append(f"{indent}({parts}),")
    return lines


def main() -> None:
    con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    cur = con.cursor()

    # ---- ontogeny ------------------------------------------------------
    onto: dict[str, dict[str, list[tuple[float, float, float]]]] = {}
    n_onto = 0
    for mol, group, pma, factor, dev in cur.execute(
        "SELECT molecule, group_name, postmenstrual_age, ontogeny_factor, deviation "
        "FROM tab_ontogenies ORDER BY molecule, group_name, postmenstrual_age"
    ):
        onto.setdefault(mol, {}).setdefault(group, []).append((pma, factor, dev))
        n_onto += 1

    # ---- species liver physiology --------------------------------------
    species: dict[str, dict[str, float]] = {}
    for sp, pname, value in cur.execute(
        "SELECT species, parameter_name, default_value FROM tab_container_parameter_values "
        "WHERE container_name='Liver' AND parameter_name IN ({}) "
        "ORDER BY species, parameter_name".format(",".join("?" * len(LIVER_KEYS))),
        tuple(LIVER_KEYS),
    ):
        if value is None:
            continue
        species.setdefault(sp, {})[LIVER_KEYS[pname]] = float(value)

    # ---- human kidney / GFR constants ----------------------------------
    kidney: dict[str, float] = {}
    for cname, pname, value in cur.execute(
        "SELECT container_name, parameter_name, default_value FROM tab_container_parameter_values "
        "WHERE species='Human' AND container_name IN ('Kidney', 'Organism') "
        "AND parameter_name IN ('TM50 for GFR', 'Hill coefficient for GFR', "
        "'fGFRpremat', 'GFRmat', 'Volume (standard kidney)', 'Fraction of blood for GFR')"
    ):
        if value is not None:
            kidney[pname] = float(value)
    # GFRmat is a 1-point curve in the DB (every standard population, both
    # genders): 0.11704 L/min at the adult reference.
    gfr_mat = cur.execute(
        "SELECT mean_value FROM tab_container_parameter_curves "
        "WHERE species='Human' AND container_name='Kidney' AND parameter_name='GFRmat' "
        "AND population='European_ICRP_2002' AND gender='MALE' ORDER BY age LIMIT 1"
    ).fetchone()
    if gfr_mat and gfr_mat[0] is not None:
        kidney["GFRmat"] = float(gfr_mat[0])

    # ---- human age curves (European ICRP 2002, both genders) ------------
    curves: dict[str, dict[str, list[tuple[float, float]]]] = {}
    for container, param, key in AGE_CURVES:
        for gender in ("MALE", "FEMALE"):
            pts = cur.execute(
                "SELECT age, mean_value FROM tab_container_parameter_curves "
                "WHERE species='Human' AND container_name=? AND parameter_name=? "
                "AND population='European_ICRP_2002' AND gender=? ORDER BY age",
                (container, param, gender),
            ).fetchall()
            if pts:
                curves.setdefault(key, {})[gender] = [(a, m) for a, m in pts]

    # ---- tissue composition (Human) -------------------------------------
    tissue: dict[str, dict[str, float]] = {}
    for organ in TISSUE_ORGANS:
        for pname, value in cur.execute(
            "SELECT parameter_name, default_value FROM tab_container_parameter_values "
            "WHERE species='Human' AND container_name=? AND parameter_name IN ({}) "
            "ORDER BY parameter_name".format(",".join("?" * len(TISSUE_KEYS))),
            (organ, *tuple(TISSUE_KEYS)),
        ):
            if value is not None:
                tissue.setdefault(organ, {})[TISSUE_KEYS[pname]] = float(value)

    # ---- plasma / blood-cell composition (Organism level) ---------------
    plasma: dict[str, float] = {}
    for pname, value in cur.execute(
        "SELECT parameter_name, default_value FROM tab_container_parameter_values "
        "WHERE species='Human' AND container_name='Organism' "
        "AND parameter_name IN ({}) ORDER BY parameter_name".format(",".join("?" * len(ORGANISM_KEYS))),
        tuple(ORGANISM_KEYS),
    ):
        if value is not None:
            plasma[ORGANISM_KEYS[pname]] = float(value)

    # ---- molecule defaults ------------------------------------------------
    molecules: dict[str, dict[str, float]] = {}
    for mol, pname, value in cur.execute(
        "SELECT molecule, parameter_name, mean_value FROM tab_molecule_parameters "
        "WHERE parameter_name IN ('Reference concentration', 't1/2 (liver)', 't1/2 (intestine)') "
        "ORDER BY molecule, parameter_name"
    ):
        if value is None:
            continue
        key = {
            "Reference concentration": "reference_concentration_umol_l",
            "t1/2 (liver)": "t_half_liver_min",
            "t1/2 (intestine)": "t_half_intestine_min",
        }[pname]
        molecules.setdefault(mol, {})[key] = float(value)

    # ---- transporter ontology ---------------------------------------------
    transporters: dict[str, str] = {}
    for gene, sp, ttype in cur.execute(
        "SELECT gene, species, transport_type FROM tab_known_transporters ORDER BY gene"
    ):
        if sp == "Human":
            transporters[gene] = ttype

    n_tissue = sum(len(v) for v in tissue.values())
    n_curves = sum(len(p) for g in curves.values() for p in g.values())
    n_species = sum(len(v) for v in species.values())
    n_mol = sum(len(v) for v in molecules.values())

    # ---- emit --------------------------------------------------------------
    header = (
        f"Row counts: {n_onto} ontogeny points over {len(onto)} molecules / "
        f"{n_species} species-liver values over {len(species)} species / "
        f"{n_curves} age-curve points / {n_tissue} tissue-composition values "
        f"over {len(tissue)} organs / {n_mol} molecule defaults / "
        f"{len(transporters)} human transporters."
    )
    text = []
    a = text.append
    a('"""Static PK-Sim physiology tables — generated, do not edit by hand.')
    a("")
    a("Extracted verbatim from the Open-Systems-Pharmacology PK-Sim")
    a("repository's ``src/Db/PKSimDB.sqlite`` (develop @ fcb896d) by")
    a("``scratch/build_physiology_data.py`` — the generator is the provenance")
    a("record; editing this file by hand breaks the contract.  Regenerate with")
    a("``PYTHONPATH=src python scratch/build_physiology_data.py``.")
    a("")
    a(header)
    a('"""')
    a("")
    a("from __future__ import annotations")
    a("")
    a("__all__ = [")
    for name in (
        "GFR_CONSTANTS", "HUMAN_AGE_CURVES", "MOLECULE_DEFAULTS", "ONTOGENY_TABLE",
        "PLASMA_COMPOSITION", "SPECIES_PHYSIOLOGY", "TISSUE_COMPOSITION",
        "TRANSPORTER_TYPES",
    ):
        a(f'    "{name}",')
    a("]")
    a("")
    a("")
    a("# Kidney GFR maturation constants (PKSimDB tab_container_parameter_values,")
    a("# Human Kidney/Organism): TM50 and Hill for the postmenstrual-age Hill")
    a("# function, the premature floor, the standard-kidney volume the spec is")
    a("# normalised to, and the filtration fraction.")
    a("GFR_CONSTANTS: dict[str, float] = {")
    for k in sorted(kidney):
        a(f'    "{k}": {fmt(kidney[k])},')
    a("}")
    a("")
    a("# Enzyme/transporter ontogeny: molecule -> group -> [(PMA years, factor,")
    a("# geometric SD)].  Groups are PK-Sim's ONTOGENY_* keys; the liver groups")
    a("# differ in whether GI-wall ontogeny is folded into the liver factor.")
    a("ONTOGENY_TABLE: dict[str, dict[str, list[tuple[float, float, float]]]] = {")
    for mol in sorted(onto):
        a(f'    "{mol}": {{')
        for group in sorted(onto[mol]):
            a(f'        "{group}": [')
            text.extend(rows_literal(onto[mol][group], "            "))
            a("        ],")
        a("    },")
    a("}")
    a("")
    a("# Static liver physiology per species (PKSimDB tab_container_parameter_")
    a("# values).  Human liver volume/flow are age curves instead — see")
    a("# HUMAN_AGE_CURVES — so only the fractions and microsomal scaling are")
    a("# static here.  Qspec is the liver's DIRECT (arterial) specific blood")
    a("# flow; the portal-vein contribution arrives from the GI organs in the")
    a("# full PK-Sim topology and is not part of this column.")
    a("SPECIES_PHYSIOLOGY: dict[str, dict[str, float]] = {")
    for sp in sorted(species):
        a(f'    "{sp}": {{')
        for k in sorted(species[sp]):
            a(f'        "{k}": {fmt(species[sp][k])},')
        a("    },")
    a("}")
    a("")
    a("# ICRP 2002 European reference age curves (mean values; the DB carries")
    a("# distribution metadata we drop): curve -> gender -> [(age years, mean)].")
    a("# MeanHeight is in decimetres (17.6 dm = 176 cm) exactly as PK-Sim")
    a("# stores it; Hematocrit is the Discrete curve.")
    a("HUMAN_AGE_CURVES: dict[str, dict[str, list[tuple[float, float]]]] = {")
    for key in ("liver_volume", "liver_qspec", "mean_bw", "mean_height_dm", "hematocrit"):
        a(f'    "{key}": {{')
        for gender in ("MALE", "FEMALE"):
            pts = curves.get(key, {}).get(gender)
            if pts:
                a(f'        "{gender}": [')
                text.extend(rows_literal(pts, "            "))
                a("        ],")
        a("    },")
    a("}")
    a("")
    a("# Human tissue composition — the volume-fraction inputs of the five")
    a("# partition-coefficient methods (base / -RR / -PT / -WS variants,")
    a("# albumin + lipoprotein ratios, acidic phospholipids in g/g, vascular")
    a("# and interstitial fractions).  Fat's lipid fraction is an age curve in")
    a("# PK-Sim so only its static keys appear here.")
    a("TISSUE_COMPOSITION: dict[str, dict[str, float]] = {")
    for organ in sorted(tissue):
        a(f'    "{organ}": {{')
        for k in sorted(tissue[organ]):
            a(f'        "{k}": {fmt(tissue[organ][k])},')
        a("    },")
    a("}")
    a("")
    a("# Plasma / blood-cell / interstitial composition (Organism-level")
    a("# parameters) plus the four pH values the ionic terms need.")
    a("PLASMA_COMPOSITION: dict[str, float] = {")
    for k in sorted(plasma):
        a(f'    "{k}": {fmt(plasma[k])},')
    a("}")
    a("")
    a("# Enzyme/transporter molecule defaults: reference concentration")
    a("# (µmol/L) and turnover half-lives (min) for liver and intestine wall.")
    a("MOLECULE_DEFAULTS: dict[str, dict[str, float]] = {")
    for mol in sorted(molecules):
        a(f'    "{mol}": {{')
        for k in sorted(molecules[mol]):
            a(f'        "{k}": {fmt(molecules[mol][k])},')
        a("    },")
    a("}")
    a("")
    a("# Human transporter ontology (PKSimDB tab_known_transporters): gene ->")
    a("# efflux or influx direction default.")
    a("TRANSPORTER_TYPES: dict[str, str] = {")
    for gene in sorted(transporters):
        a(f'    "{gene}": "{transporters[gene]}",')
    a("}")
    a("")

    OUT.write_text("\n".join(text), encoding="utf-8")
    print(
        f"wrote {OUT} — ontogeny {n_onto} pts/{len(onto)} molecules, "
        f"species {n_species} values/{len(species)} species, "
        f"curves {n_curves} pts, tissue {n_tissue} values/{len(tissue)} organs, "
        f"molecules {n_mol}/{len(molecules)}, transporters {len(transporters)}, "
        f"GFR constants {kidney}"
    )
    con.close()


if __name__ == "__main__":
    main()
