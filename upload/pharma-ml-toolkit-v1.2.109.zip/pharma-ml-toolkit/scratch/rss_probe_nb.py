"""Instrumented re-execution: kernel RSS sampled after every cell."""
from __future__ import annotations

import os
import sys
import time
from pathlib import Path

for _var in ("LOKY_MAX_CPU_COUNT", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
             "OPENBLAS_NUM_THREADS"):
    os.environ.setdefault(_var, "1")

import nbformat
from jupyter_client.manager import KernelManager

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / "examples" / "complete_ml_workflow.ipynb"
nb = nbformat.read(path, as_version=4)

km = KernelManager(kernel_name="python3")
km.start_kernel(cwd=str(path.parent))
kc = km.client()
kc.start_channels()


def kernel_rss() -> int:
    pid = km.provisioner.pid if km.provisioner else None
    if pid is None:
        return -1
    try:
        with open(f"/proc/{pid}/status") as handle:
            for line in handle:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1])
    except OSError:
        return -1
    return -1


try:
    kc.wait_for_ready(timeout=120)
    n = 0
    for cell in nb.cells:
        if cell.cell_type != "code":
            continue
        n += 1
        first = (cell.source or "").splitlines()[0][:48] if cell.source else ""
        msg_id = kc.execute(cell.source)
        reply = kc.get_shell_msg(timeout=3600)
        while reply.get("parent_header", {}).get("msg_id") != msg_id:
            reply = kc.get_shell_msg(timeout=3600)
        deadline = time.monotonic() + 3.0
        while True:
            try:
                msg = kc.get_iopub_msg(timeout=0.5)
            except Exception:
                if time.monotonic() > deadline:
                    break
                continue
            if msg["parent_header"].get("msg_id") != msg_id:
                deadline = time.monotonic() + 3.0
                continue
            if msg["msg_type"] == "status" and msg["content"]["execution_state"] == "idle":
                break
        status = reply["content"].get("status", "?")
        print(f"code#{n:2d} [{status}] rss={kernel_rss():7d} kB | {first}", flush=True)
finally:
    try:
        kc.stop_channels()
        km.shutdown_kernel(now=True)
    except Exception:
        pass
