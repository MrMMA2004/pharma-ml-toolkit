"""Applicability domain analysis — is a prediction trustworthy?

The user's uploaded ``Applicability_domain_analysis.py`` (2026-10) asked
the two questions every QSAR readout deserves before anyone acts on it:

1. **Distance applicability domain** — is the query compound inside the
   training descriptor space at all?  Measured as the mean k-nearest-
   neighbour distance in the standardised descriptor space, thresholded
   at a percentile of the training set's own distances (the script's
   ``k = 5`` / 95th percentile convention).
2. **Prediction uncertainty** — how much does the model's answer wobble
   when its own training set is bootstrap-resampled?  The script
   re-fitted 30 fresh ``CatBoostRegressor`` models (30 more again for
   the training-side threshold — 60 fits total) and took the ensemble's
   per-compound standard deviation, thresholded at the 95th percentile
   of the training uncertainty.

This module ships both halves as composable, estimator-agnostic
functions with three deliberate engineering upgrades over the upload:

* **any estimator, not just CatBoost** — the bootstrap ensemble is
  ``clone(model)`` of whatever fitted pipeline the caller hands in (the
  toolkit's own trained model, a loaded persistence bundle, ...), so a
  ridge, a random forest or a stacking ensemble all work unchanged;
* **half the fits** — every bootstrap model predicts on the test set
  AND the training set in one pass, so the training-side uncertainty
  threshold costs zero extra fits (the upload ran 2×30 CatBoost fits);
* **deterministic** — ``resample`` is seeded through ``random_state``
  (the upload sampled unseeded: two runs of the "same" analysis
  produced different reliability verdicts).

A fourth upgrade is behavioural, not structural: the training kNN
distances **exclude each point's own zero self-distance** (the upload
queried the fitted neighbour index with the training matrix itself,
which always counts the point as its own first neighbour and deflates
the mean by roughly ``distance/k`` — every threshold was slightly too
small, every domain slightly too tight).

A third uncertainty readout joins the two domain questions in
100x-151: :func:`quantile_prediction_intervals` — the ``D2.py``
upload's prediction-interval block, ported honestly (its shipped code
fit three IDENTICAL plain forests, so the advertised 90% interval had
width zero; this module fits the quantile-regression trio the upload
meant).  Where the bootstrap spread asks how much the *model* wobbles
under resampled training data, the quantile bounds bracket where the
*residual noise* puts the true value.

Examples
--------
>>> import numpy as np, pandas as pd
>>> from sklearn.linear_model import Ridge
>>> x = pd.DataFrame({"a": np.linspace(0.0, 10.0, 60)})
>>> y = pd.Series(2.0 * x["a"] + 1.0)
>>> model = Ridge().fit(x, y)
>>> inside = applicability_domain(model, x, y, x.iloc[::4], k=5, n_models=8)
>>> bool(inside.inside_ad.all())           # interpolation stays inside
True
>>> far = pd.DataFrame({"a": [1000.0]})    # wild extrapolation
>>> out = applicability_domain(model, x, y, far, k=5, n_models=4)
>>> bool(out.inside_ad[0]), bool(out.reliable[0])
(False, False)
>>> out.distance_threshold > 0.0 and out.uncertainty_threshold >= 0.0
True
>>> frame = out.to_frame(names=["far-away compound"])
>>> list(frame.columns)                    # the upload's reliability table
['name', 'predicted', 'prediction_sd', 'knn_distance', 'inside_ad', 'low_uncertainty', 'reliable']
>>> float(frame.loc[0, "knn_distance"]) > float(out.distance_threshold)
True

Descriptor alignment: when both inputs are DataFrames, their unique column
labels must match exactly in the same order; mismatches are rejected rather
than silently reordering. When either input is an array, columns are matched
by position and the caller must ensure their meanings and order agree. This
check does not verify descriptor units, preprocessing or provenance.

The kNN half alone (no bootstrap fits) is the quick pass:

>>> quick = knn_applicability_domain(x, far, k=5)
>>> bool(quick.inside_ad[0])
False
>>> quick.pred_mean is None and quick.reliable is None
True
>>> bool(quick.to_frame(names=["far-away compound"])["reliable"].isna().all())
True

Classification models get their honest path too — the ensemble spread
of the positive-class probability:

>>> from sklearn.linear_model import LogisticRegression
>>> xc = pd.DataFrame({"a": [0.0, 0.1, 0.2, 0.3, 9.7, 9.8, 9.9, 10.0]})
>>> yc = pd.Series([0, 0, 0, 0, 1, 1, 1, 1])
>>> clf = LogisticRegression().fit(xc, yc)
>>> res = applicability_domain(clf, xc, yc, pd.DataFrame({"a": [0.15, 5.0]}),
...                            k=3, n_models=6)
>>> res.uncertainty_kind
'positive-class probability'
>>> bool(res.inside_ad[0]), bool(res.inside_ad[1])   # mid-gap is far from both clusters
(True, False)

Error contracts (the house style):

>>> knn_applicability_domain(x, far, k=0)
Traceback (most recent call last):
...
pharmaml.exceptions.ModelError: k must be >= 1, got 0
>>> knn_applicability_domain(x, far, k=60)            # more neighbours than training rows
Traceback (most recent call last):
...
pharmaml.exceptions.ModelError: k=60 needs at least 61 training rows to exclude each point's own self-distance, got 60
>>> knn_applicability_domain(x, far, percentile=101.0)
Traceback (most recent call last):
...
pharmaml.exceptions.ModelError: percentile must be in (0, 100], got 101.0
>>> two = pd.DataFrame({"a": np.linspace(0.0, 1.0, 40),
...                     "b": np.linspace(1.0, 2.0, 40)})
>>> knn_applicability_domain(two, far)
Traceback (most recent call last):
...
pharmaml.exceptions.ModelError: X_test has 1 feature(s) but X_train has 2 — the descriptor spaces must match
>>> bad = pd.DataFrame({"a": [0.0, np.nan]})
>>> knn_applicability_domain(bad, far)
Traceback (most recent call last):
...
pharmaml.exceptions.DataValidationError: X_train contains 1 NaN value(s) — applicability domain needs finite descriptors
>>> applicability_domain(model, x, y, far, n_models=0)
Traceback (most recent call last):
...
pharmaml.exceptions.ModelError: n_models must be >= 1, got 0 — pass uncertainty=False for a kNN-only pass
>>> xm = pd.DataFrame({"a": [0.0, 5.0, 10.0] * 4})
>>> ym = pd.Series([0, 1, 2] * 4)
>>> three = LogisticRegression().fit(xm, ym)          # multiclass proba: no honest std
>>> applicability_domain(three, xm, ym, pd.DataFrame({"a": [1.0]}), k=3)
Traceback (most recent call last):
...
pharmaml.exceptions.ModelError: bootstrap_uncertainty needs numeric predictions or a binary predict_proba — this estimator exposes 3 classes
>>> applicability_domain("not a model", x, y, far)
Traceback (most recent call last):
...
pharmaml.exceptions.ModelError: model must be a fitted estimator with predict(), got str
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler
from sklearn.utils import resample

from pharmaml.exceptions import DataValidationError, ModelError
from pharmaml.logger import get_logger

_LOG = get_logger(__name__)

__all__ = [
    "ApplicabilityDomainResult",
    "BootstrapUncertainty",
    "QuantileIntervals",
    "WilliamsResult",
    "applicability_domain",
    "bootstrap_uncertainty",
    "knn_applicability_domain",
    "leverage_williams",
    "quantile_prediction_intervals",
]

#: Progress callback contract: ``report(done, total)`` after each
#: bootstrap fit (``done`` counts fitted ensemble members).
ProgressCallback = Callable[[int, int], None]

_UNCERTAINTY_SURFACE = (
    "bootstrap_uncertainty needs numeric predictions or a binary "
    "predict_proba"
)


def _numeric_matrix(X: pd.DataFrame | np.ndarray, name: str) -> np.ndarray:
    """Coerce a feature frame/array to a finite float matrix.

    Raises
    ------
    DataValidationError
        When ``X`` carries non-numeric columns (DataFrame) or values
        that refuse to float, or contains NaN/±inf entries — the
        applicability domain needs finite descriptors, and a NaN
        distance would silently poison every threshold downstream.
    """
    if isinstance(X, pd.DataFrame):
        if not X.columns.is_unique:
            raise DataValidationError(f"{name} has duplicate feature names; columns must be unique")
        bad = [str(col) for col in X.columns
               if X[col].dtype.kind not in "fiub"]
        if bad:
            raise DataValidationError(
                f"{name} carries non-numeric column(s) {', '.join(bad)} — "
                "compute descriptors / clean the frame first "
                "(the ML tab's numeric cleanup)"
            )
        try:
            matrix = X.to_numpy(dtype=float)
        except (TypeError, ValueError) as exc:
            raise DataValidationError(
                f"{name} could not be converted to a numeric matrix: {exc}"
            ) from exc
    else:
        try:
            matrix = np.asarray(X, dtype=float)
        except (TypeError, ValueError) as exc:
            raise DataValidationError(
                f"{name} could not be converted to a numeric matrix: {exc}"
            ) from exc
    if matrix.ndim != 2:
        raise DataValidationError(
            f"{name} must be a 2-D feature matrix, got shape {matrix.shape}"
        )
    if matrix.shape[0] == 0:
        raise DataValidationError(f"{name} is empty — nothing to analyse")
    if matrix.shape[1] == 0:
        raise DataValidationError(f"{name} has zero feature columns")
    n_nan = int(np.isnan(matrix).sum())
    if n_nan:
        raise DataValidationError(
            f"{name} contains {n_nan} NaN value(s) — applicability domain "
            "needs finite descriptors"
        )
    n_inf = int(np.isinf(matrix).sum())
    if n_inf:
        raise DataValidationError(
            f"{name} contains {n_inf} infinite value(s) — applicability "
            "domain needs finite descriptors"
        )
    return matrix


def _validate_descriptor_schema(
    X_train: pd.DataFrame | np.ndarray,
    X_test: pd.DataFrame | np.ndarray,
    train: np.ndarray,
    test: np.ndarray,
) -> None:
    """Require matching dimensions and, when available, matching column order."""
    if train.shape[1] != test.shape[1]:
        raise ModelError(
            f"X_test has {test.shape[1]} feature(s) but X_train has "
            f"{train.shape[1]} — the descriptor spaces must match"
        )
    if (
        isinstance(X_train, pd.DataFrame)
        and isinstance(X_test, pd.DataFrame)
        and not X_train.columns.equals(X_test.columns)
    ):
        raise ModelError(
            "X_train and X_test feature names and order must match exactly; "
            "align query columns to the training descriptors"
        )


def _feature_names(X: pd.DataFrame | np.ndarray) -> list[str]:
    if isinstance(X, pd.DataFrame):
        return [str(col) for col in X.columns]
    return [f"f{i}" for i in range(np.asarray(X).shape[1])]


@dataclass(slots=True)
class ApplicabilityDomainResult:
    """Outcome of a full applicability-domain analysis.

    Attributes
    ----------
    k:
        Neighbour count of the distance domain.
    percentile:
        The percentile both thresholds are taken at.
    distance_threshold:
        Training-set kNN-distance cut-off (in standardised units).
    train_knn_mean / test_knn_mean:
        Per-row mean kNN distance of the training / query rows
        (training distances exclude each point's own self-match).
    inside_ad:
        Boolean mask — query rows inside the distance domain.
    feature_names:
        The descriptor columns the domain was measured in.
    n_models:
        Bootstrap ensemble size (``None`` when skipped).
    pred_mean / pred_std:
        Ensemble mean / per-row standard deviation on the query rows.
    train_pred_std:
        Per-row ensemble std on the TRAINING rows — the yardstick the
        uncertainty threshold is cut from.
    uncertainty_threshold:
        Percentile of ``train_pred_std`` (``None`` when skipped).
    low_uncertainty:
        Boolean mask — query rows under the uncertainty threshold.
    reliable:
        ``inside_ad & low_uncertainty`` — the upload's final verdict
        (``None`` when the bootstrap half was skipped).
    uncertainty_kind:
        ``'predictions'`` or ``'positive-class probability'``.
    fit_seconds:
        Wall-clock cost of the bootstrap fits (0.0 when skipped).
    """

    k: int
    percentile: float
    distance_threshold: float
    train_knn_mean: np.ndarray
    test_knn_mean: np.ndarray
    inside_ad: np.ndarray
    feature_names: list[str]
    n_models: int | None = None
    pred_mean: np.ndarray | None = None
    pred_std: np.ndarray | None = None
    train_pred_std: np.ndarray | None = None
    uncertainty_threshold: float | None = None
    low_uncertainty: np.ndarray | None = None
    reliable: np.ndarray | None = None
    uncertainty_kind: str | None = None
    fit_seconds: float = 0.0

    def as_dict(self) -> dict[str, Any]:
        """Flat dict summary (no per-row arrays) for logs and reports."""
        return {
            "k": self.k,
            "percentile": self.percentile,
            "distance_threshold": self.distance_threshold,
            "n_train": int(self.train_knn_mean.size),
            "n_test": int(self.test_knn_mean.size),
            "inside_ad": int(self.inside_ad.sum()),
            "n_models": self.n_models,
            "uncertainty_threshold": self.uncertainty_threshold,
            "low_uncertainty": None if self.low_uncertainty is None
            else int(self.low_uncertainty.sum()),
            "reliable": None if self.reliable is None else int(self.reliable.sum()),
            "uncertainty_kind": self.uncertainty_kind,
            "fit_seconds": self.fit_seconds,
        }

    def to_frame(self, names: list[str] | pd.Series | None = None) -> pd.DataFrame:
        """The upload's reliability table, one row per query compound.

        Columns: ``name, predicted, prediction_sd, knn_distance,
        inside_ad, low_uncertainty, reliable`` — the uncertainty
        columns carry ``NaN``/``NA`` when the bootstrap half was
        skipped (the verdict honestly degrades to distance-only).
        """
        n = int(self.test_knn_mean.size)
        if names is None:
            labels = [f"compound_{i}" for i in range(n)]
        else:
            labels = [str(v) for v in list(names)[:n]]
            labels += [f"compound_{i}" for i in range(len(labels), n)]
        data: dict[str, Any] = {
            "name": labels,
            "predicted": self.pred_mean if self.pred_mean is not None
            else np.full(n, np.nan),
            "prediction_sd": self.pred_std if self.pred_std is not None
            else np.full(n, np.nan),
            "knn_distance": self.test_knn_mean,
            "inside_ad": self.inside_ad,
        }
        if self.low_uncertainty is not None and self.reliable is not None:
            data["low_uncertainty"] = self.low_uncertainty
            data["reliable"] = self.reliable
        else:
            data["low_uncertainty"] = pd.array([pd.NA] * n, dtype="boolean")
            data["reliable"] = pd.array([pd.NA] * n, dtype="boolean")
        return pd.DataFrame(data)

    def __str__(self) -> str:  # pragma: no cover - presentation only
        inside = int(self.inside_ad.sum())
        n = int(self.inside_ad.size)
        text = (f"k={self.k} distance_threshold={self.distance_threshold:.4g} "
                f"inside_ad={inside}/{n}")
        if self.reliable is not None:
            text += (f" uncertainty_threshold={self.uncertainty_threshold:.4g} "
                     f"reliable={int(self.reliable.sum())}/{n}")
        return text


@dataclass(slots=True)
class BootstrapUncertainty:
    """Bootstrap-ensemble uncertainty of a fitted estimator.

    Attributes
    ----------
    pred_mean / pred_std:
        Ensemble mean / per-row std on the query rows.
    train_pred_std:
        Per-row std on the training rows (the threshold yardstick).
    n_models:
        Ensemble size actually fitted.
    kind:
        ``'predictions'`` (numeric regressor output) or
        ``'positive-class probability'`` (binary classifier proba).
    fit_seconds:
        Wall-clock cost of the whole ensemble.
    """

    pred_mean: np.ndarray
    pred_std: np.ndarray
    train_pred_std: np.ndarray
    n_models: int
    kind: str
    fit_seconds: float = 0.0


def knn_applicability_domain(
    X_train: pd.DataFrame | np.ndarray,
    X_test: pd.DataFrame | np.ndarray,
    *,
    k: int = 5,
    percentile: float = 95.0,
    metric: str = "euclidean",
) -> ApplicabilityDomainResult:
    """kNN-distance applicability domain (the upload's step 4-5).

    The descriptor space is standardised (``StandardScaler`` fitted on
    the training matrix — the upload's own convention), a
    ``NearestNeighbors`` index with ``k`` neighbours is fitted on it,
    and a row counts as **inside the domain** when its mean neighbour
    distance stays under the ``percentile``-th percentile of the
    training rows' own mean distances.

    Training distances exclude each point's own self-match: the
    training matrix is queried with ``k + 1`` neighbours and the zero
    first column dropped (see the module docstring for why the
    upload's thresholds were slightly too tight).

    Parameters
    ----------
    X_train:
        Training descriptor matrix (numeric, finite, unique DataFrame columns).
    X_test:
        Query descriptor matrix — same columns in the same order as
        ``X_train``. If either input is an array, alignment is positional.
    k:
        Neighbour count (default 5, the upload's value).
    percentile:
        Distance cut-off percentile in ``(0, 100]`` (default 95).
    metric:
        NearestNeighbors metric (default ``'euclidean'``, the upload's).

    Returns
    -------
    ApplicabilityDomainResult
        The distance half only — ``n_models`` is ``None`` and the
        uncertainty fields stay unset.

    Raises
    ------
    ModelError
        On invalid ``k`` / ``percentile``, a feature-count mismatch,
        or too few training rows for the self-exclusion query.
    DataValidationError
        On non-numeric / non-finite descriptor matrices.
    """
    train = _numeric_matrix(X_train, "X_train")
    test = _numeric_matrix(X_test, "X_test")
    if k < 1:
        raise ModelError(f"k must be >= 1, got {k}")
    if k > train.shape[0] - 1:
        raise ModelError(
            f"k={k} needs at least {k + 1} training rows to exclude each "
            f"point's own self-distance, got {train.shape[0]}"
        )
    if not 0.0 < percentile <= 100.0:
        raise ModelError(f"percentile must be in (0, 100], got {percentile}")
    _validate_descriptor_schema(X_train, X_test, train, test)

    scaler = StandardScaler()
    train_scaled = scaler.fit_transform(train)
    test_scaled = scaler.transform(test)

    nbrs = NearestNeighbors(n_neighbors=k, metric=metric)
    nbrs.fit(train_scaled)

    # training distances WITHOUT the self-match: query k+1, drop col 0
    train_distances, _ = nbrs.kneighbors(train_scaled, n_neighbors=k + 1)
    train_knn_mean = train_distances[:, 1:].mean(axis=1)

    threshold = float(np.percentile(train_knn_mean, percentile))
    test_distances, _ = nbrs.kneighbors(test_scaled)
    test_knn_mean = test_distances.mean(axis=1)
    inside = test_knn_mean <= threshold
    _LOG.debug(
        "kNN AD: k=%d threshold=%.4g inside=%d/%d",
        k, threshold, int(inside.sum()), int(inside.size),
    )
    return ApplicabilityDomainResult(
        k=k,
        percentile=percentile,
        distance_threshold=threshold,
        train_knn_mean=train_knn_mean,
        test_knn_mean=test_knn_mean,
        inside_ad=inside,
        feature_names=_feature_names(X_train),
    )


def _probe_prediction_kind(model: Any, X_train: pd.DataFrame | np.ndarray) -> str:
    """Classify the estimator's prediction surface for bootstrapping.

    Returns ``'predictions'`` for float-valued ``predict()`` output
    (regressors), ``'positive-class probability'`` for binary
    classifiers with ``predict_proba``, and raises otherwise — integer
    or string class labels have no honest per-row standard deviation.
    """
    if not callable(getattr(model, "predict", None)):
        raise ModelError(
            "model must be a fitted estimator with predict(), got "
            f"{type(model).__name__}"
        )
    probe = np.asarray(model.predict(X_train[:1])).reshape(-1)
    if probe.dtype.kind == "f":
        return "predictions"
    proba = getattr(model, "predict_proba", None)
    if callable(proba):
        width = np.asarray(proba(X_train[:1])).shape[1]
        if width == 2:
            return "positive-class probability"
        raise ModelError(
            f"{_UNCERTAINTY_SURFACE} — this estimator exposes {width} classes"
        )
    raise ModelError(
        f"{_UNCERTAINTY_SURFACE} — this estimator predicts class labels"
    )


def bootstrap_uncertainty(
    model: Any,
    X_train: pd.DataFrame | np.ndarray,
    y_train: pd.Series | np.ndarray | list,
    X_test: pd.DataFrame | np.ndarray,
    *,
    n_models: int = 30,
    random_state: int = 0,
    progress: ProgressCallback | None = None,
) -> BootstrapUncertainty:
    """Bootstrap-ensemble prediction uncertainty (the upload's step 6).

    ``n_models`` clones of ``model`` are fitted on bootstrap resamples
    of the training data and predict on BOTH the query rows and the
    training rows — the per-row standard deviation across the ensemble
    is the uncertainty readout, and the training-side std comes from
    the same fits (the upload spent a second, separate 30-model round
    on it).

    Deterministic: resample ``i`` is seeded with ``random_state + i``
    (the upload sampled unseeded).

    Parameters
    ----------
    model:
        Any fitted sklearn-compatible estimator — pipelines included.
    X_train, y_train:
        The training data ``model`` was fitted on.
    X_test:
        Query rows for the uncertainty readout. DataFrame columns must match
        training names and order; arrays are matched by position.
    n_models:
        Ensemble size (default 30, the upload's value).
    random_state:
        Seed of the first resample.
    progress:
        Optional ``report(done, total)`` callback fired after each fit
        (a broken reporter is logged and swallowed — it must never be
        able to kill a running analysis).

    Returns
    -------
    BootstrapUncertainty

    Raises
    ------
    ModelError
        When ``n_models < 1``, the row counts disagree, or the
        estimator's prediction surface has no honest per-row std.
    DataValidationError
        On non-numeric / non-finite descriptor matrices.
    """
    if n_models < 1:
        raise ModelError(
            f"n_models must be >= 1, got {n_models} — pass uncertainty=False "
            "for a kNN-only pass"
        )
    train = _numeric_matrix(X_train, "X_train")
    test = _numeric_matrix(X_test, "X_test")
    _validate_descriptor_schema(X_train, X_test, train, test)
    y = np.asarray(y_train)
    if y.shape[0] != train.shape[0]:
        raise ModelError(
            f"y_train has {y.shape[0]} value(s) but X_train has "
            f"{train.shape[0]} rows"
        )
    kind = _probe_prediction_kind(model, X_train)

    started = time.perf_counter()
    test_preds: list[np.ndarray] = []
    train_preds: list[np.ndarray] = []
    for index in range(n_models):
        X_boot, y_boot = resample(X_train, y_train,
                                  random_state=random_state + index)
        member = clone(model)
        member.fit(X_boot, y_boot)
        if kind == "predictions":
            test_preds.append(
                np.asarray(member.predict(X_test), dtype=float).reshape(-1))
            train_preds.append(
                np.asarray(member.predict(X_train), dtype=float).reshape(-1))
        else:
            test_preds.append(
                np.asarray(member.predict_proba(X_test), dtype=float)[:, 1])
            train_preds.append(
                np.asarray(member.predict_proba(X_train), dtype=float)[:, 1])
        if progress is not None:
            try:
                progress(index + 1, n_models)
            except Exception:  # noqa: BLE001 — a broken reporter must not kill the run
                _LOG.debug("progress callback failed", exc_info=True)
    fit_seconds = time.perf_counter() - started

    test_matrix = np.vstack(test_preds)
    train_matrix = np.vstack(train_preds)
    _LOG.debug(
        "bootstrap uncertainty: %d member(s) in %.2fs (%s)",
        n_models, fit_seconds, kind,
    )
    return BootstrapUncertainty(
        pred_mean=test_matrix.mean(axis=0),
        pred_std=test_matrix.std(axis=0),
        train_pred_std=train_matrix.std(axis=0),
        n_models=n_models,
        kind=kind,
        fit_seconds=fit_seconds,
    )


@dataclass(slots=True)
class QuantileIntervals:
    """Prediction intervals from gradient-boosted quantile regression.

    The third uncertainty readout (the ``D2.py`` upload's
    ``generate_uncertainty_quantification``, ported honestly in
    100x-151): two quantile-regression fits bracket every prediction
    with a central-``1 - alpha`` interval, and the median fit carries
    the point estimate.

    Attributes
    ----------
    alpha:
        The interval's tail mass — the bounds target the
        ``alpha/2`` and ``1 - alpha/2`` quantiles (default 0.1, the
        upload's 90% interval).
    lower / median / upper:
        Per-row interval bound / median prediction / upper bound on
        the query rows.  The bounds are the CROSSING-REPAIRED pair:
        separately-fit quantile models can cross on individual rows
        (``lower > upper``), every crossing is counted in
        ``n_crossing`` and the exported pair is swapped so
        ``lower <= upper`` always holds.
    coverage:
        Share of query rows whose true value falls inside the interval
        (``None`` when no ``y_test`` was supplied).
    mean_width:
        Mean of ``upper - lower`` across the query rows.
    n_test:
        Number of query rows.
    n_covered:
        Rows inside the interval (``None`` without ``y_test``).
    n_crossing:
        Rows where the raw quantile pair crossed (swapped in the
        exported bounds — quantile crossing is a known pathology of
        independently fit quantile models, reported not hidden).
    fit_seconds:
        Wall-clock cost of the three fits.
    """

    alpha: float
    lower: np.ndarray
    median: np.ndarray
    upper: np.ndarray
    n_test: int
    mean_width: float
    n_crossing: int
    coverage: float | None = None
    n_covered: int | None = None
    fit_seconds: float = 0.0

    def as_frame(self, y_test: object = None) -> pd.DataFrame:
        """The upload's interval table, one row per query compound.

        Columns: ``actual, pred_median, pred_lower, pred_upper,
        interval_width`` — the ``actual`` column appears only when the
        true values are supplied (mirrors the coverage being optional).
        """
        data: dict[str, Any] = {}
        if y_test is not None:
            data["actual"] = np.asarray(y_test, dtype=float)
        data["pred_median"] = self.median
        data["pred_lower"] = self.lower
        data["pred_upper"] = self.upper
        data["interval_width"] = self.upper - self.lower
        return pd.DataFrame(data)

    def __str__(self) -> str:  # pragma: no cover - presentation only
        text = (f"alpha={self.alpha:g} n_test={self.n_test} "
                f"mean_width={self.mean_width:.4g} "
                f"crossing={self.n_crossing}")
        if self.coverage is not None:
            text += f" coverage={self.coverage:.1%}"
        return text


def quantile_prediction_intervals(
    X_train: pd.DataFrame | np.ndarray,
    y_train: pd.Series | np.ndarray | list,
    X_test: pd.DataFrame | np.ndarray,
    y_test: pd.Series | np.ndarray | list | None = None,
    *,
    alpha: float = 0.1,
    n_estimators: int = 200,
    learning_rate: float = 0.1,
    max_depth: int | None = 3,
    subsample: float = 1.0,
    random_state: int = 42,
    progress: ProgressCallback | None = None,
) -> QuantileIntervals:
    """Central-``1 - alpha`` prediction intervals via quantile regression.

    The honest port of ``D2.py``'s uncertainty block, whose shipped
    code was structurally broken: it fit THREE plain
    ``RandomForestRegressor`` instances on the same data with no
    quantile loss, so the three forests were bit-for-bit identical —
    interval width 0.0 on every row, empirical coverage 0.0%, and the
    "90% Prediction Interval" the plot legend advertised did not exist
    (``RandomForestRegressor`` has no quantile mode in scikit-learn at
    all — probed on 1.5.2).  This function fits what the upload
    *meant*: ``GradientBoostingRegressor(loss="quantile")`` at the
    ``alpha/2`` / ``0.5`` / ``1 - alpha/2`` quantiles — the classic
    scikit-learn quantile-regression route (probed: a 5/50/95% trio
    returns ~90% empirical coverage on noisy synthetic data, with
    non-degenerate widths and correct ordering).

    The ensemble-std sibling of this readout is
    :func:`bootstrap_uncertainty`; the two answer different questions —
    the bootstrap spread measures how much the *model* wobbles under
    resampled training data, the quantile bounds bracket where the
    *residual noise* puts the true value.

    Deterministic by default: with ``subsample=1.0`` (the default)
    the gradient-boosting fits carry no stochastic element at all, so
    two runs agree bit-for-bit whatever the seed; a stochastic
    configuration (``subsample < 1.0``) is seeded through
    ``random_state`` (the upload's forests were seeded but
    identical-by-construction, a stronger and less useful guarantee).

    Parameters
    ----------
    X_train, y_train:
        Training descriptors and target (finite; ``y_train`` may not
        carry NaN — a quantile loss has no honest answer for a missing
        target).
    X_test:
        Query rows — DataFrame columns must match training names and order;
        arrays are matched by position.
    y_test:
        Optional true values for the coverage statistic.
    alpha:
        Tail mass (default 0.1 — the upload's 90% interval); must lie
        in ``(0, 0.5)``.
    n_estimators / learning_rate / max_depth / subsample:
        The gradient-boosting knobs shared by all three quantile fits
        (``subsample < 1.0`` turns on stochastic gradient boosting —
        seeded through ``random_state``).
    random_state:
        Seed of every fit (the knob behind the stochastic
        configuration's determinism).
    progress:
        Optional ``report(done, total)`` fired after each of the three
        fits (a broken reporter is logged and swallowed — it must
        never be able to kill a running analysis).

    Returns
    -------
    QuantileIntervals

    Raises
    ------
    ModelError
        On an out-of-range ``alpha``, non-positive ``n_estimators`` /
        ``learning_rate``, or disagreeing row / feature counts.
    DataValidationError
        On non-numeric / non-finite descriptor matrices or targets.

    Examples
    --------
    >>> import numpy as np, pandas as pd
    >>> rng = np.random.default_rng(42)
    >>> x = pd.DataFrame({"a": rng.uniform(0.0, 10.0, 80)})
    >>> y = pd.Series(2.0 * x["a"] + 1.0 + rng.normal(0.0, 0.5, 80))
    >>> res = quantile_prediction_intervals(
    ...     x, y, x.iloc[::4], y.iloc[::4], alpha=0.2, n_estimators=60)
    >>> bool((res.lower <= res.upper).all())   # bounds never cross
    True
    >>> 0.0 <= res.coverage <= 1.0
    True
    >>> res.n_test, res.mean_width > 0.0
    (20, True)
    >>> frame = res.as_frame(y.iloc[::4])
    >>> list(frame.columns)
    ['actual', 'pred_median', 'pred_lower', 'pred_upper', 'interval_width']
    >>> no_truth = quantile_prediction_intervals(x, y, x.iloc[::4],
    ...     alpha=0.2, n_estimators=60)
    >>> no_truth.coverage is None and no_truth.n_covered is None
    True

    Error contracts (the house style):

    >>> quantile_prediction_intervals(x, y, x.iloc[:2], alpha=0.5)
    Traceback (most recent call last):
    ...
    pharmaml.exceptions.ModelError: alpha must be in (0, 0.5) -- 0.5 would collapse the interval onto the median, got 0.5
    >>> quantile_prediction_intervals(x, y, x.iloc[:2], n_estimators=0)
    Traceback (most recent call last):
    ...
    pharmaml.exceptions.ModelError: n_estimators must be >= 1, got 0
    >>> x2 = pd.DataFrame({"a": x["a"], "b": 10.0 - x["a"]})
    >>> quantile_prediction_intervals(x2, y, pd.DataFrame({"b": [1.0]}))
    Traceback (most recent call last):
    ...
    pharmaml.exceptions.ModelError: X_test has 1 feature(s) but X_train has 2 — the descriptor spaces must match
    >>> quantile_prediction_intervals(x, y, x.iloc[:2], y.iloc[:3])
    Traceback (most recent call last):
    ...
    pharmaml.exceptions.ModelError: y_test has 3 value(s) but X_test has 2 rows
    """
    if not 0.0 < alpha < 0.5:
        raise ModelError(
            f"alpha must be in (0, 0.5) -- 0.5 would collapse the "
            f"interval onto the median, got {alpha!r}"
        )
    if n_estimators < 1:
        raise ModelError(f"n_estimators must be >= 1, got {n_estimators}")
    if not (learning_rate > 0.0 and np.isfinite(learning_rate)):
        raise ModelError(
            f"learning_rate must be a positive finite number, got "
            f"{learning_rate!r}"
        )
    if not 0.0 < subsample <= 1.0:
        raise ModelError(
            f"subsample must be in (0, 1], got {subsample!r}"
        )
    train = _numeric_matrix(X_train, "X_train")
    test = _numeric_matrix(X_test, "X_test")
    _validate_descriptor_schema(X_train, X_test, train, test)
    y = _numeric_vector(y_train, "y_train", finite=True)
    if y.shape[0] != train.shape[0]:
        raise ModelError(
            f"y_train has {y.shape[0]} value(s) but X_train has "
            f"{train.shape[0]} rows"
        )
    truth: np.ndarray | None = None
    if y_test is not None:
        truth = _numeric_vector(y_test, "y_test", finite=True)
        if truth.shape[0] != test.shape[0]:
            raise ModelError(
                f"y_test has {truth.shape[0]} value(s) but X_test has "
                f"{test.shape[0]} rows"
            )

    started = time.perf_counter()
    lower = median = upper = np.zeros(0)
    for index, quantile in enumerate((alpha / 2.0, 0.5, 1.0 - alpha / 2.0)):
        model = GradientBoostingRegressor(
            loss="quantile",
            alpha=quantile,
            n_estimators=n_estimators,
            learning_rate=learning_rate,
            max_depth=max_depth,
            subsample=subsample,
            random_state=random_state,
        )
        model.fit(train, y)
        prediction = np.asarray(model.predict(test), dtype=float).reshape(-1)
        if index == 0:
            lower = prediction
        elif index == 1:
            median = prediction
        else:
            upper = prediction
        if progress is not None:
            try:
                progress(index + 1, 3)
            except Exception:  # noqa: BLE001 — a broken reporter must not kill the run
                _LOG.debug("progress callback failed", exc_info=True)
    fit_seconds = time.perf_counter() - started

    # Quantile crossing (a known pathology of separately fit quantile
    # models): count it, then swap the crossed pairs so the exported
    # bounds always satisfy lower <= upper.  minimum/maximum (not a
    # sequential pair of np.where swaps) so the repair can never
    # reference its own output.
    crossed = lower > upper
    n_crossing = int(crossed.sum())
    if n_crossing:
        _LOG.debug(
            "quantile crossing on %d/%d row(s) -- bounds swapped",
            n_crossing, int(lower.size),
        )
        lower, upper = np.minimum(lower, upper), np.maximum(lower, upper)

    coverage: float | None = None
    n_covered: int | None = None
    if truth is not None:
        inside = (truth >= lower) & (truth <= upper)
        n_covered = int(inside.sum())
        coverage = float(inside.mean())
    mean_width = float((upper - lower).mean())
    _LOG.debug(
        "quantile intervals: alpha=%g n_test=%d coverage=%s width=%.4g "
        "crossing=%d in %.2fs",
        alpha, int(lower.size),
        "n/a" if coverage is None else f"{coverage:.1%}",
        mean_width, n_crossing, fit_seconds,
    )
    return QuantileIntervals(
        alpha=float(alpha),
        lower=lower,
        median=median,
        upper=upper,
        n_test=int(lower.size),
        mean_width=mean_width,
        n_crossing=n_crossing,
        coverage=coverage,
        n_covered=n_covered,
        fit_seconds=fit_seconds,
    )


def _numeric_vector(
    values: object, name: str, *, finite: bool
) -> np.ndarray:
    """Coerce a target sequence to a flat float array (house guards).

    ``ValueError``/``TypeError`` from the coercion become
    :class:`DataValidationError`; when ``finite`` is set the result may
    not carry NaN either (a quantile loss has no honest answer for a
    missing target).
    """
    try:
        array = np.asarray(values, dtype=float).reshape(-1)
    except (TypeError, ValueError) as error:
        raise DataValidationError(
            f"{name} must be numeric, got non-numeric value(s): {error}"
        ) from error
    if finite and array.size and not np.isfinite(array).all():
        bad = int((~np.isfinite(array)).sum())
        raise DataValidationError(
            f"{name} contains {bad} NaN/inf value(s) -- quantile "
            "regression needs finite targets"
        )
    return array


def applicability_domain(
    model: Any,
    X_train: pd.DataFrame | np.ndarray,
    y_train: pd.Series | np.ndarray | list,
    X_test: pd.DataFrame | np.ndarray,
    *,
    k: int = 5,
    percentile: float = 95.0,
    n_models: int = 30,
    random_state: int = 0,
    uncertainty: bool = True,
    progress: ProgressCallback | None = None,
) -> ApplicabilityDomainResult:
    """The uploaded workflow end-to-end, one call.

    Composes :func:`knn_applicability_domain` (steps 4-5 of the upload:
    standardised descriptor space, mean kNN distance, percentile
    threshold) with :func:`bootstrap_uncertainty` (step 6: ensemble
    spread over bootstrap resamples, its own percentile threshold on
    the training-side std), then folds both into the final reliability
    verdict per query row (step 7 of the upload):
    ``reliable = inside_ad & low_uncertainty``.

    Parameters
    ----------
    model:
        A fitted estimator — the toolkit's own ``train_model`` result,
        a persistence bundle's model, or any sklearn-compatible fit.
    X_train, y_train:
        The training data (descriptors + target).
    X_test:
        The query compounds, same descriptor columns.
    k, percentile:
        Distance-domain knobs (defaults 5 / 95 — the upload's).
    n_models:
        Bootstrap ensemble size (default 30 — the upload's); pass
        ``uncertainty=False`` to skip the bootstrap half entirely.
    random_state:
        Bootstrap seeding (determinism the upload lacked).
    uncertainty:
        Run the bootstrap half at all.
    progress:
        Optional ``report(done, total)`` fired per bootstrap fit.

    Returns
    -------
    ApplicabilityDomainResult
        With the reliability table available as ``result.to_frame()``.

    Raises
    ------
    ModelError
        From either half — invalid knobs, feature mismatches, or an
        estimator without an honest uncertainty surface.
    DataValidationError
        On non-numeric / non-finite descriptor matrices.
    """
    result = knn_applicability_domain(X_train, X_test, k=k, percentile=percentile)
    if not uncertainty:
        return result
    boot = bootstrap_uncertainty(
        model, X_train, y_train, X_test,
        n_models=n_models, random_state=random_state, progress=progress,
    )
    uncertainty_threshold = float(np.percentile(boot.train_pred_std, percentile))
    low = boot.pred_std <= uncertainty_threshold
    result.n_models = boot.n_models
    result.pred_mean = boot.pred_mean
    result.pred_std = boot.pred_std
    result.train_pred_std = boot.train_pred_std
    result.uncertainty_threshold = uncertainty_threshold
    result.low_uncertainty = low
    result.reliable = result.inside_ad & low
    result.uncertainty_kind = boot.kind
    result.fit_seconds = boot.fit_seconds
    return result


@dataclass(slots=True)
class WilliamsResult:
    """Outcome of a leverage/Williams applicability-domain analysis.

    The regression-domain companion to the kNN-distance half
    (part12 PART 11's "Leverage / Williams plot where implemented"):
    the hat-matrix leverage of every row against the warning cut-off
    ``h* = 3(p+1)/n`` plus the standardized-residual ±3σ band that
    separates good leverage from outliers.

    Attributes
    ----------
    n_train / n_features:
        Training rows ``n`` and descriptor columns ``p``.
    leverage_threshold:
        ``h* = 3(p+1)/n`` — the warning leverage (three times the mean
        hat value ``(p+1)/n``, the trace identity's own centre).
    residual_limit:
        The standardized-residual band (default 3.0 — the Williams
        convention; pass it through the caller to change).
    train_leverage:
        Hat diagonal ``h_i`` per training row (clipped at 0 — the
        eigensum can return a -1e-17 numerical ghost).
    train_std_residuals:
        ``r_i = (y_i - ŷ_i) / rmse`` per training row.
    train_inside:
        ``h_i <= h*`` AND ``|r_i| <= residual_limit`` — the Williams
        plot's in-domain population.
    test_leverage / test_inside:
        Hat values of the query rows (no ground truth, so the verdict
        is leverage-only) — ``None`` when no query rows were passed.
    test_predicted:
        The model's own predictions on the query rows (the
        extrapolation panel's ``y`` axis) — ``None`` likewise.
    rmse:
        The residual scale the standardization divides by.
    feature_names:
        The descriptor columns the leverages were measured in.
    """

    n_train: int
    n_features: int
    leverage_threshold: float
    residual_limit: float
    train_leverage: np.ndarray
    train_std_residuals: np.ndarray
    train_inside: np.ndarray
    rmse: float
    feature_names: list[str]
    test_leverage: np.ndarray | None = None
    test_inside: np.ndarray | None = None
    test_predicted: np.ndarray | None = None

    def as_dict(self) -> dict[str, Any]:
        """Flat dict summary (no per-row arrays) for logs and reports."""
        return {
            "n_train": int(self.n_train),
            "n_features": int(self.n_features),
            "leverage_threshold": float(self.leverage_threshold),
            "residual_limit": float(self.residual_limit),
            "rmse": float(self.rmse),
            "train_inside": int(np.count_nonzero(self.train_inside)),
            "n_train_outlier_leverage": int(
                np.count_nonzero(self.train_leverage > self.leverage_threshold)
            ),
            "n_train_outlier_residual": int(
                np.count_nonzero(
                    np.abs(self.train_std_residuals) > self.residual_limit
                )
            ),
            "n_test": None if self.test_leverage is None
            else int(self.test_leverage.size),
            "test_inside": None if self.test_inside is None
            else int(np.count_nonzero(self.test_inside)),
        }

    def to_frame(self, names: list[str] | pd.Series | None = None) -> pd.DataFrame:
        """The Williams table, one row per TRAINING compound.

        Columns: ``name, leverage, std_residual, inside`` — the plot's
        own population (the query rows carry no ground truth and live
        in ``test_leverage`` / ``test_predicted``).
        """
        n = int(self.train_leverage.size)
        if names is None:
            labels = [f"compound_{i}" for i in range(n)]
        else:
            labels = [str(v) for v in list(names)[:n]]
            labels += [f"compound_{i}" for i in range(len(labels), n)]
        return pd.DataFrame(
            {
                "name": labels,
                "leverage": self.train_leverage,
                "std_residual": self.train_std_residuals,
                "inside": self.train_inside,
            }
        )

    def __str__(self) -> str:  # pragma: no cover - presentation only
        inside = int(np.count_nonzero(self.train_inside))
        text = (f"p={self.n_features} h*={self.leverage_threshold:.4g} "
                f"train_inside={inside}/{self.n_train}")
        if self.test_leverage is not None and self.test_inside is not None:
            t_in = int(np.count_nonzero(self.test_inside))
            text += f" test_inside={t_in}/{self.test_leverage.size}"
        return text


def leverage_williams(
    model: Any,
    X_train: pd.DataFrame | np.ndarray,
    y_train: pd.Series | np.ndarray | list,
    X_test: pd.DataFrame | np.ndarray | None = None,
    *,
    residual_limit: float = 3.0,
) -> WilliamsResult:
    """Leverage/Williams applicability domain (the regression companion).

    Mathematical definition
    ----------------------
    With the intercept-augmented design matrix ``A = [1 | X]``
    (``n`` rows, ``p+1`` columns), the hat matrix
    ``H = A (AᵀA)⁻¹ Aᵀ`` has diagonal

    ``h_i = a_i (AᵀA)⁻¹ a_iᵀ``

    — the leverage of row ``i``: its pull on the fitted plane and the
    Mahalanobis-style distance of its descriptors from the training
    centroid, in one number.  Leverage is invariant to any
    nonsingular rescaling of the descriptors (a StandardScaler
    changes nothing), so the raw design matrix is used directly.

    Thresholds
    ----------
    * warning leverage ``h* = 3(p+1)/n`` — three times the mean
      leverage ``(p+1)/n`` (the trace identity ``Σh_i = p+1``);
      rows beyond it extrapolate the model's own regression plane.
    * standardized residuals ``r_i = (y_i - ŷ_i)/rmse`` with the
      ±3 band (the ``residual_limit`` knob) separating response
      outliers from the population.

    Assumptions / limitations
    -------------------------
    * **Regression task types** — the residual axis needs a numeric
      target and numeric predictions (a classifier's labels have no
      honest residual scale).
    * The hat matrix is a LINEAR-model geometry: for nonlinear
      models the leverages still describe the descriptor space
      (where the rows sit), while ``rmse`` remains the model's own
      in-sample scale — the standard QSAR usage of the Williams
      plot as a domain-readout regardless of the fitted estimator.
    * Requires ``n >= p+2`` (at least one residual degree of
      freedom) and a full-rank design; collinear descriptors are
      refused rather than silently pseudo-inverted.

    Examples
    --------
    >>> import numpy as np, pandas as pd
    >>> from sklearn.linear_model import LinearRegression
    >>> rng = np.random.default_rng(0)
    >>> x = pd.DataFrame({"a": rng.normal(size=60), "b": rng.normal(size=60)})
    >>> y = pd.Series(2.0 * x["a"] - x["b"] + 0.05 * rng.normal(size=60))
    >>> model = LinearRegression().fit(x, y)
    >>> res = leverage_williams(model, x, y)
    >>> res.n_train, res.n_features, res.leverage_threshold
    (60, 2, 0.15)
    >>> float(res.train_leverage.sum()) >= 3.0 - 1e-9   # trace identity: p+1
    True
    >>> far = pd.DataFrame({"a": [50.0], "b": [0.0]})
    >>> out = leverage_williams(model, x, y, far)
    >>> bool(out.test_inside[0])                        # wild extrapolation
    False
    >>> mid = pd.DataFrame({"a": [0.1], "b": [-0.2]})
    >>> bool(leverage_williams(model, x, y, mid).test_inside[0])
    True

    Error contracts (the house style):

    >>> leverage_williams(model, x, y, residual_limit=0)
    Traceback (most recent call last):
    ...
    pharmaml.exceptions.ModelError: residual_limit must be > 0, got 0
    >>> tiny = pd.DataFrame({"a": [1.0], "b": [2.0]})          # n < p+2
    >>> leverage_williams(model, tiny, pd.Series([1.0]), residual_limit=3)
    Traceback (most recent call last):
    ...
    pharmaml.exceptions.ModelError: leverage/Williams needs at least p+2 = 4 training rows (p=2), got 1
    >>> collinear = pd.DataFrame({"a": x["a"], "b": x["a"]})   # rank-deficient
    >>> leverage_williams(model, collinear, y)
    Traceback (most recent call last):
    ...
    pharmaml.exceptions.ModelError: the design matrix is rank-deficient (rank 2 < p+1 = 3) — drop the collinear descriptors
    >>> zero_y = pd.Series(np.zeros(60))                        # perfect fit
    >>> zero_model = LinearRegression().fit(x, zero_y)
    >>> leverage_williams(zero_model, x, zero_y)
    Traceback (most recent call last):
    ...
    pharmaml.exceptions.ModelError: the model fits the training set exactly (rmse=0) — the residual scale cannot standardize; use a model with honest in-sample error
    >>> leverage_williams("not a model", x, y)
    Traceback (most recent call last):
    ...
    pharmaml.exceptions.ModelError: model must be a fitted estimator with predict(), got str
    """
    if (
        isinstance(residual_limit, bool)
        or not isinstance(residual_limit, (int, float, np.floating))
        or not float(residual_limit) > 0.0
    ):
        raise ModelError(f"residual_limit must be > 0, got {residual_limit!r}")
    if not hasattr(model, "predict"):
        raise ModelError(
            f"model must be a fitted estimator with predict(), got {type(model).__name__}"
        )
    train = _numeric_matrix(X_train, "X_train")
    y = _numeric_vector(y_train, "y_train", finite=True)
    n, p = train.shape
    if y.size != n:
        raise ModelError(
            f"X_train has {n} row(s) but y_train has {y.size} — they must align"
        )
    if n < p + 2:
        raise ModelError(
            f"leverage/Williams needs at least p+2 = {p + 2} training rows "
            f"(p={p}), got {n}"
        )

    design = np.column_stack([np.ones(n), train])
    gram = design.T @ design
    rank = int(np.linalg.matrix_rank(gram))
    if rank < p + 1:
        raise ModelError(
            f"the design matrix is rank-deficient (rank {rank} < p+1 = {p + 1}) "
            "— drop the collinear descriptors"
        )
    try:
        gram_inv = np.linalg.inv(gram)
    except np.linalg.LinAlgError as exc:  # pragma: no cover - rank guard above
        raise ModelError(f"the design matrix is singular: {exc}") from exc
    train_leverage = np.clip(
        np.einsum("ij,jk,ik->i", design, gram_inv, design), 0.0, None
    )

    try:
        fitted = np.asarray(model.predict(X_train), dtype=float).reshape(-1)
    except (TypeError, ValueError) as exc:
        raise DataValidationError(
            "leverage/Williams is a regression companion — the model's "
            f"training predictions must be numeric: {exc}"
        ) from exc
    if fitted.size != n:
        raise ModelError(
            f"the model returned {fitted.size} training prediction(s) for {n} row(s)"
        )
    residuals = y - fitted
    rmse = float(np.sqrt(np.mean(residuals**2)))
    if rmse == 0.0:
        raise ModelError(
            "the model fits the training set exactly (rmse=0) — the residual "
            "scale cannot standardize; use a model with honest in-sample error"
        )
    std_residuals = residuals / rmse

    h_star = 3.0 * (p + 1) / n
    train_inside = (train_leverage <= h_star) & (np.abs(std_residuals) <= residual_limit)

    test_leverage: np.ndarray | None = None
    test_inside: np.ndarray | None = None
    test_predicted: np.ndarray | None = None
    if X_test is not None:
        test = _numeric_matrix(X_test, "X_test")
        _validate_descriptor_schema(X_train, X_test, train, test)
        m = test.shape[0]
        query_design = np.column_stack([np.ones(m), test])
        test_leverage = np.clip(
            np.einsum("ij,jk,ik->i", query_design, gram_inv, query_design), 0.0, None
        )
        test_inside = test_leverage <= h_star
        try:
            test_predicted = np.asarray(model.predict(X_test), dtype=float).reshape(-1)
        except (TypeError, ValueError) as exc:
            raise DataValidationError(
                "leverage/Williams is a regression companion — the model's "
                f"query predictions must be numeric: {exc}"
            ) from exc
        if test_predicted.size != m:
            raise ModelError(
                f"the model returned {test_predicted.size} query prediction(s) "
                f"for {m} row(s)"
            )

    return WilliamsResult(
        n_train=int(n),
        n_features=int(p),
        leverage_threshold=float(h_star),
        residual_limit=float(residual_limit),
        train_leverage=train_leverage,
        train_std_residuals=std_residuals,
        train_inside=train_inside,
        rmse=rmse,
        feature_names=_feature_names(X_train),
        test_leverage=test_leverage,
        test_inside=test_inside,
        test_predicted=test_predicted,
    )


@dataclass(slots=True)
class DomainBox:
    """The per-feature min/max box a model was fitted inside.

    A cheap, first-pass applicability domain: a query row is
    ``in_domain`` when every recorded feature falls within the training
    range (inclusive).  This is the box a bundle can carry without
    keeping the training data — a full kNN/leverage domain
    (:func:`knn_applicability_domain`) is stricter but needs the
    training descriptors at hand.

    Attributes
    ----------
    ranges:
        ``{feature: {"min": lo, "max": hi}}`` for the features recorded.
    n_features:
        Number of features in the box.
    """

    ranges: dict[str, dict[str, float]]
    n_features: int

    @classmethod
    def from_metadata(cls, metadata: dict[str, Any]) -> DomainBox | None:
        """Build the box from a bundle's metadata, or ``None`` if absent."""
        ranges = metadata.get("feature_ranges")
        if not isinstance(ranges, dict) or not ranges:
            return None
        clean: dict[str, dict[str, float]] = {}
        for name, bounds in ranges.items():
            if (
                isinstance(bounds, dict)
                and isinstance(bounds.get("min"), (int, float))
                and isinstance(bounds.get("max"), (int, float))
            ):
                clean[str(name)] = {
                    "min": float(bounds["min"]),
                    "max": float(bounds["max"]),
                }
        if not clean:
            return None
        return cls(ranges=clean, n_features=len(clean))

    def check(self, frame: pd.DataFrame) -> DomainReport:
        """Flag every row of ``frame`` outside the box.

        A row is out-of-domain when any recorded feature is below its
        training minimum or above its maximum.  Features absent from
        ``frame`` are ignored (the bundle's feature contract handles
        those separately); ``NaN`` in a present feature counts as
        out-of-domain, since a missing descriptor cannot be shown to be
        inside the box.
        """
        import pandas as pd

        n_rows = len(frame)
        below: dict[str, int] = {}
        above: dict[str, int] = {}
        out_mask = np.zeros(n_rows, dtype=bool)
        for name, bounds in self.ranges.items():
            if name not in frame.columns:
                continue
            values = pd.to_numeric(frame[name], errors="coerce").to_numpy(dtype=float)
            low = values < bounds["min"]
            high = values > bounds["max"]
            nan = np.isnan(values)
            if low.any():
                below[name] = int(low.sum())
            if high.any():
                above[name] = int(high.sum())
            out_mask |= low | high | nan
        n_out = int(out_mask.sum())
        return DomainReport(
            n_rows=n_rows,
            n_out=int(n_out),
            out_mask=out_mask,
            below=below,
            above=above,
            box=self,
        )


@dataclass(slots=True)
class DomainReport:
    """Outcome of checking a frame against a :class:`DomainBox`."""

    n_rows: int
    n_out: int
    out_mask: np.ndarray
    below: dict[str, int]
    above: dict[str, int]
    box: DomainBox

    @property
    def in_domain(self) -> np.ndarray:
        """Boolean mask: ``True`` where the row is inside the box."""
        return ~self.out_mask

    @property
    def fraction_out(self) -> float:
        return self.n_out / self.n_rows if self.n_rows else 0.0

    def __str__(self) -> str:
        if self.n_out == 0:
            return (
                f"applicability: all {self.n_rows} row(s) inside the "
                f"{self.box.n_features}-feature training box"
            )
        offenders: list[str] = []
        for name, _count in sorted(
            {**self.below, **self.above}.items(), key=lambda item: -item[1]
        ):
            parts = []
            if name in self.below:
                parts.append(f"{self.below[name]} below")
            if name in self.above:
                parts.append(f"{self.above[name]} above")
            offenders.append(f"{name} ({', '.join(parts)})")
        head = (
            f"applicability: {self.n_out}/{self.n_rows} row(s) "
            f"({self.fraction_out:.0%}) outside the training box"
        )
        return head + "\n  " + "\n  ".join(offenders[:8])


def check_domain_box(metadata: dict[str, Any], frame: pd.DataFrame) -> DomainReport | None:
    """Check ``frame`` against a bundle's recorded box, if it has one.

    Returns ``None`` when the bundle predates box recording (no
    ``feature_ranges`` in its metadata), so callers can stay silent
    rather than imply a check that did not run.
    """
    box = DomainBox.from_metadata(metadata)
    if box is None:
        return None
    return box.check(frame)
