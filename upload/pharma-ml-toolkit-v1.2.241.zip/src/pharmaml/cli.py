"""Command-line interface — the scaffolding entry point of PharmaML.

Replaces the legacy workflow of "open a per-algorithm .py file, edit
the hardcoded CSV filename at the bottom, run it".  One command covers
training, comparison, splitting, conversion, PK analysis and docking
scans::

    pharmaml ml train    --data qsar.csv --target Target --model rf --plots
    pharmaml ml train    --data qsar.csv --pdf-report           # bundle + report.pdf
    pharmaml ml train    --data qsar.csv --task auto        # infer classification/regression
    pharmaml ml train    --data qsar.csv --keep-categorical  # one-hot string features
    pharmaml ml compare  --data qsar.csv --target Target --task classification --plot
    pharmaml ml compare  --data qsar.csv --pdf-report         # leaderboard + report.pdf
    pharmaml ml check   --model artifacts/x.joblib --data new.csv  # round-trip audit
    pharmaml data inspect --data qsar.csv                  # audit your own file
    pharmaml data split  --data qsar.csv --test-size 0.2 --val-size 0.1
    pharmaml data audit-splits --partition train=train.csv --partition test=test.csv --key compound_id
    pharmaml data convert --data ligands.csv --to sdf      # .smi/.csv/.sdf round-trip
    pharmaml chem pic50  --data activity.xlsx --column "IC50 (nM)"
    pharmaml pharma pk   --data profile.csv --time time_h --conc conc_ng_ml
    pharmaml docking prep-ligands --ligands ligands.csv --out ligand_folders/
    pharmaml docking prep-protein --protein protein.pdb --out r.pdbqt
    pharmaml docking scan --directory docking_run/
    pharmaml docking dpf --ligand ligand_folders/1/l.pdbqt --ga-runs 50
    pharmaml docking collect --dir docking_run/ --pattern '^\\d+\\.pdbqt$'
    pharmaml docking torsion --dir ligand_folders/
    pharmaml docking gpf-scan --dir docking_run/
    pharmaml docking vina-scan --dir vina_results/
    pharmaml docking rescore --data summary.csv --columns best_lowest_energy,cluster_size
    pharmaml biology response-audit --data screen.csv --metric LN_IC50
    pharmaml biology top-biomarkers --expression expr.csv --response resp.csv --response-column pIC50
    pharmaml generative run --recipe qed --method ga --iterations 20 --seed 42
    pharmaml generative run --recipe similar --seeds examples/data/seed_molecules.csv
    pharmaml generative run --method ga --recipe novel --scaffold --seed 42
    pharmaml generative run --method ga --recipe qed --scaffold-hop --seed 42
    pharmaml generative run --method ga --adaptive-operators --plot operators.png
    pharmaml generative run --method rl --recipe qed --plot drift.png
    pharmaml generative run --recipe druglike --pareto --pareto-plot front.png
    pharmaml generative run --recipe druglike --pareto --pareto-keep 8
    pharmaml generative corpus
    pharmaml models list

``--model`` accepts registry names and their aliases (``rf``,
``logistic``, ``xgb`` ... — see ``pharmaml.ml.MODEL_ALIASES``).
"""

from __future__ import annotations

import argparse
import logging
import math
import sys
from pathlib import Path
from typing import Any

from pharmaml import __version__
from pharmaml.logger import configure_logging, get_logger

_LOG = get_logger("cli")


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pharmaml",
        description="PharmaML toolkit — QSAR ML, pharma calculations, docking.",
    )
    parser.add_argument("--version", action="version", version=f"pharmaml {__version__}")
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="enable debug logging"
    )
    parser.add_argument(
        "--log-file", type=Path, default=None, help="also write logs to this file"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # ---- models list ------------------------------------------------
    models_parser = subparsers.add_parser("models", help="model registry utilities")
    models_parser.add_argument("action", choices=["list"], help="list available models")

    # ---- data --------------------------------------------------------
    data_parser = subparsers.add_parser(
        "data", help="bring-your-own-data utilities (inspect user files)"
    )
    data_sub = data_parser.add_subparsers(dest="data_command", required=True)

    inspect = data_sub.add_parser(
        "inspect", help="audit a user CSV/Excel file before training"
    )
    inspect.add_argument("--data", required=True, help="CSV/TSV/Excel file to inspect")
    inspect.add_argument(
        "--target", default=None, help="target column (auto-detected when omitted)"
    )
    inspect.add_argument(
        "--head", type=int, default=0, metavar="N",
        help="also print the first N rows of the table",
    )

    split = data_sub.add_parser(
        "split",
        help="split a table into stratified train/val/test files "
        "(upgrades 'Split CSV file.py')",
    )
    split.add_argument("--data", required=True, help="CSV/TSV/Excel file to split")
    split.add_argument(
        "--target", default=None,
        help="column to stratify on (auto-detected when omitted)",
    )
    split.add_argument("--test-size", type=float, default=0.2, metavar="FRAC")
    split.add_argument(
        "--val-size", type=float, default=None, metavar="FRAC",
        help="also carve a validation set of this fraction",
    )
    split.add_argument(
        "--no-stratify", action="store_true",
        help="plain random split (no class balancing)",
    )
    split.add_argument("--seed", type=int, default=42)
    split.add_argument(
        "--out-dir", default=None,
        help="output directory (default: alongside --data)",
    )
    split.add_argument(
        "--prefix", default=None,
        help="output filename prefix (default: input file stem)",
    )

    audit_splits = data_sub.add_parser(
        "audit-splits", help="audit exact identifier overlap across named split files",
    )
    audit_splits.add_argument(
        "--partition", action="append", required=True, metavar="NAME=PATH",
        help="named CSV/TSV/Excel split file; repeat for at least two partitions",
    )
    audit_splits.add_argument(
        "--key", action="append", required=True, metavar="COLUMN",
        help="identifier column; repeat for a composite key",
    )
    audit_splits.add_argument(
        "--delimiter", choices=("comma", "tab", "semicolon"), default=None,
        help="delimiter for text files (default: tab for .tsv, comma otherwise)",
    )
    audit_splits.add_argument(
        "--details-json", default=None, metavar="PATH",
        help="write shared raw identifiers to a new JSON file (may contain sensitive data)",
    )

    convert = data_sub.add_parser(
        "convert",
        help="convert molecular file formats (.smi / .csv / .tsv / .xlsx / .sdf)",
    )
    convert.add_argument(
        "--data", required=True,
        help="input file: .smi, a CSV/TSV/Excel table, or .sdf",
    )
    convert.add_argument(
        "--to", required=True, choices=("csv", "sdf", "smi"),
        help="target format",
    )
    convert.add_argument("--smiles-col", default="SMILES", help="SMILES column name")
    convert.add_argument(
        "--name-col", default=None,
        help="molecule name column (default: none -> ligand_N titles)",
    )
    convert.add_argument(
        "--no-3d", action="store_true",
        help="skip 3D embedding + UFF optimisation (table -> SDF only)",
    )
    convert.add_argument(
        "--out", default=None,
        help="output path (default: input stem + target extension)",
    )

    # ---- research diagnostics (read-only output) ----------------------
    research_parser = subparsers.add_parser("research", help="read-only provenance and environment diagnostics")
    research_sub = research_parser.add_subparsers(dest="research_command", required=True)
    manifest = research_sub.add_parser("manifest", help="fingerprint a dataset and declare a run setup")
    manifest.add_argument("--data", required=True)
    manifest.add_argument("--split-strategy", required=True)
    manifest.add_argument("--parameter", action="append", default=[], metavar="NAME=VALUE")
    comparison = research_sub.add_parser("compare", help="compare two saved manifest JSON documents")
    comparison.add_argument("first")
    comparison.add_argument("second")
    run_comparison = research_sub.add_parser("compare-uncertainty", help="compare two file-based uncertainty reports")
    run_comparison.add_argument("first")
    run_comparison.add_argument("second")
    training_comparison = research_sub.add_parser("compare-training", help="compare two observed CLI training records")
    training_comparison.add_argument("first")
    training_comparison.add_argument("second")
    research_sub.add_parser("environment", help="print selected runtime and numerical environment details")
    checkpoint = research_sub.add_parser("checkpoint", help="read-only checkpoint and input fingerprint inspection")
    checkpoint.add_argument("path", help="existing checkpoint JSON")
    checkpoint.add_argument("--input", action="append", default=[], help="complete set of recorded input files; repeat")

    # ---- ml ----------------------------------------------------------
    ml_parser = subparsers.add_parser("ml", help="machine-learning workflows")
    ml_sub = ml_parser.add_subparsers(dest="ml_command", required=True)

    for name, description in (("nested-ridge", "nested ridge regression cross-validation"),
                              ("nested-logistic", "nested logistic classification cross-validation")):
        nested = ml_sub.add_parser(name, help=description)
        nested.add_argument("--data", required=True)
        nested.add_argument("--features", nargs="+", required=True)
        nested.add_argument("--target", required=True)
        nested.add_argument("--group", default=None, help="optional leakage-unit grouping column")
        nested.add_argument("--outer-folds", type=int, default=3)
        nested.add_argument("--inner-folds", type=int, default=3)
        nested.add_argument("--seed", type=int, default=42)

    for command, description in (
        ("conformal-report", "held-out ridge regression intervals and subgroup coverage"),
        ("conformal-classification", "held-out logistic prediction sets and subgroup coverage"),
    ):
        uncertainty = ml_sub.add_parser(command, help=description)
        for split_name in ("train", "calibration", "test"):
            uncertainty.add_argument(f"--{split_name}", required=True, help=f"{split_name} CSV/TSV/Excel")
        uncertainty.add_argument("--features", nargs="+", required=True, help="numeric feature columns")
        uncertainty.add_argument("--target", required=True)
        uncertainty.add_argument("--key", required=True, help="exact leakage-unit ID; must be disjoint")
        uncertainty.add_argument("--group", default=None, help="optional prespecified test subgroup column")
        uncertainty.add_argument("--alpha", type=float, default=0.1)
        uncertainty.add_argument("--diagnostics", action="store_true",
                                 help="include optional held-out probability and kNN distance diagnostics")

    recalibrate = ml_sub.add_parser("calibrate-binary", help="held-out binary probability recalibration report")
    for part in ("train", "calibration", "test"):
        recalibrate.add_argument(f"--{part}", required=True, help=f"independent {part} CSV/TSV/Excel")
    recalibrate.add_argument("--features", nargs="+", required=True, help="numeric feature columns")
    recalibrate.add_argument("--target", required=True)
    recalibrate.add_argument("--key", required=True, help="exact leakage-unit ID; must be disjoint")
    recalibrate.add_argument("--positive-label", required=True, help="exact text of positive class")

    train = ml_sub.add_parser("train", help="train one model end-to-end")
    train.add_argument("--data", required=True, help="CSV/Excel with features+target")
    train.add_argument("--target", default=None, help="target column (auto-detected)")
    train.add_argument(
        "--model", default="random_forest",
        help="registry model name or alias (rf, logistic, xgb, ...)",
    )
    train.add_argument(
        "--task", choices=["classification", "regression", "auto"], default="auto",
        help="task type; 'auto' infers it from the target column (default)",
    )
    train.add_argument("--test-size", type=float, default=0.2)
    train.add_argument("--cv", type=int, default=5)
    train.add_argument("--no-tune", action="store_true", help="skip grid search")
    train.add_argument("--run-record", default=None, metavar="NEW_JSON",
                       help="opt in to an observed training record at a new JSON path (never replaces it)")
    train.add_argument(
        "--keep-categorical", action="store_true",
        help="keep string feature columns and one-hot encode them "
        "(default: numeric columns only)",
    )
    train.add_argument(
        "--plots", action="store_true",
        help="emit the full visual bundle (report.html + figures + "
        "tables) into <out>/report/ — requires pharmaml[reports]",
    )
    train.add_argument(
        "--pdf-report", action="store_true",
        help="with the visual bundle, also write report.pdf — the "
        "multi-page document (one page per table/figure); implies "
        "--plots — requires pharmaml[reports]",
    )
    train.add_argument(
        "--out", default="artifacts",
        help="plots/report output directory (the trained model itself is "
        "always saved under ./artifacts/)",
    )

    compare = ml_sub.add_parser("compare", help="cross-validated model leaderboard")
    compare.add_argument("--data", required=True)
    compare.add_argument("--target", default=None)
    compare.add_argument(
        "--task", choices=["classification", "regression", "auto"], default="auto"
    )
    compare.add_argument("--cv", type=int, default=5)
    compare.add_argument("--models", nargs="*", default=None, help="subset of models")
    compare.add_argument(
        "--keep-categorical", action="store_true",
        help="keep string feature columns and one-hot encode them",
    )
    compare.add_argument(
        "--out", default=None,
        help="write the leaderboard table to this path (csv/tsv/md/json/html)",
    )
    compare.add_argument(
        "--plot", action="store_true",
        help="save the leaderboard bar chart + report bundle into <out-dir>/ "
        "— requires pharmaml[reports]",
    )
    compare.add_argument(
        "--pdf-report", action="store_true",
        help="with the report bundle, also write report.pdf — the "
        "multi-page document; implies --plot — requires pharmaml[reports]",
    )
    compare.add_argument(
        "--out-dir", default="reports", help="directory for --plot artifacts"
    )
    compare.add_argument(
        "--significance", action="store_true",
        help="also test every model against the leaderboard leader, paired on "
        "the per-fold scores and corrected for multiplicity — is the lead real?",
    )
    compare.add_argument(
        "--significance-test", choices=["paired_t", "wilcoxon"], default="paired_t",
        help="with --significance: the paired test (default: paired_t)",
    )
    compare.add_argument(
        "--correction", choices=["fdr_bh", "bonferroni", "holm"], default="fdr_bh",
        help="with --significance: the multiplicity correction across the "
        "challenger family (default: fdr_bh)",
    )
    compare.add_argument(
        "--alpha", type=float, default=0.05,
        help="with --significance: the family-wide significance level "
        "(default: 0.05)",
    )
    compare.add_argument(
        "--power", action="store_true",
        help="with --significance: also report the fold-count power — the "
        "minimum detectable effect and whether the panel had the power to "
        "resolve what it saw (answers 'how many folds would I need?')",
    )
    compare.add_argument(
        "--target-power", type=float, default=0.8,
        help="with --power: the power the minimum detectable effect is read "
        "at (default: 0.8)",
    )


    check = ml_sub.add_parser(
        "check", help="audit a saved model against a new dataset"
    )
    check.add_argument(
        "--model", required=True,
        help="a .joblib bundle written by a previous `ml train` run",
    )
    check.add_argument(
        "--data", required=True,
        help="the new CSV/Excel to validate against the bundle's feature "
        "contract before inference",
    )
    check.add_argument(
        "--target", default=None,
        help="drop this column (the training target) before the audit — "
        "handy when re-checking the very CSV the model was trained on",
    )

    predict = ml_sub.add_parser(
        "predict", help="apply a saved model to new data (batch scoring)"
    )
    predict.add_argument(
        "--model", required=True,
        help="a .joblib bundle written by a previous `ml train` run",
    )
    predict.add_argument(
        "--data", required=True,
        help="the CSV/Excel to score (feature columns only)",
    )
    predict.add_argument(
        "--target", default=None,
        help="optional true-label column to also score against (adds the "
        "held-out metrics for that column); dropped before prediction. "
        "With --calibration-data it instead names the label column of the "
        "calibration table",
    )
    predict.add_argument(
        "--out", default=None,
        help="write the scored table to this path (csv/xlsx); "
        "default <data-stem>_predictions.csv beside the input",
    )
    predict.add_argument(
        "--conformal", type=float, default=None, metavar="ALPHA",
        help="also emit split-conformal prediction intervals/sets at "
        "miscoverage ALPHA (e.g. 0.1 for 90%%): --data is split into "
        "calibration/query halves, the intervals are calibrated on one "
        "and the empirical coverage is measured on the other",
    )
    predict.add_argument(
        "--calibration-data", default=None,
        help="with --conformal: a separate labelled CSV/Excel to calibrate "
        "on (target required) instead of splitting --data",
    )
    predict.add_argument("--seed", type=int, default=42, help="split seed")
    predict.add_argument(
        "--no-domain-check", action="store_true",
        help="skip the applicability-domain check (the bundle records the "
        "training feature box; by default rows outside it are flagged in an "
        "in_domain column)",
    )
    predict.add_argument(
        "--no-drift-check", action="store_true",
        help="skip the distribution-shift check (the bundle records a "
        "per-feature training sketch; by default the batch's PSI drift "
        "against it is printed)",
    )

    card = ml_sub.add_parser(
        "card", help="generate a model card (provenance + limitations) for a bundle"
    )
    card.add_argument(
        "--model", required=True,
        help="a .joblib bundle written by a previous `ml train` run",
    )
    card.add_argument(
        "--out", default=None,
        help="write the card to this path (.md/.html/.json); default "
        "<model-stem>_card.md beside the bundle",
    )
    card.add_argument(
        "--train-data", default=None,
        help="optional training CSV/Excel: records the per-feature "
        "applicability-domain box and the training row count",
    )
    card.add_argument("--target", default=None, help="target column (auto-detected)")

    drift = ml_sub.add_parser(
        "drift",
        help="distribution shift — has a new batch moved away from the training data?",
    )
    drift.add_argument(
        "--model", default=None,
        help="a .joblib bundle: compare --data against the per-feature "
        "sketch it recorded at train time (PSI only, no training frame "
        "needed)",
    )
    drift.add_argument(
        "--train-data", default=None,
        help="the original training table: compare --data against it "
        "directly (PSI + two-sample KS); give either this or --model",
    )
    drift.add_argument(
        "--data", required=True,
        help="the new batch to check (CSV/Excel)",
    )
    drift.add_argument(
        "--target", default=None,
        help="target column to drop from both sides before comparing "
        "(auto-dropped when --model recorded one)",
    )
    drift.add_argument(
        "--bins", type=int, default=10,
        help="PSI quantile bins over the reference (default 10)",
    )
    drift.add_argument(
        "--warn-psi", type=float, default=0.1,
        help="PSI at or above which a feature reads 'moderate' (default 0.1)",
    )
    drift.add_argument(
        "--shift-psi", type=float, default=0.2,
        help="PSI at or above which a feature reads 'shifted' (default 0.2)",
    )
    drift.add_argument(
        "--out", default=None,
        help="write the per-feature drift table to this path (csv/tsv/md/json/html)",
    )

    calibrate = ml_sub.add_parser(
        "calibrate",
        help="probability calibration — are a classifier's probabilities honest?",
    )
    calibrate.add_argument(
        "--model", default=None,
        help="a .joblib bundle written by a previous `ml train` run; the "
        "calibration is measured on --data (or --calibration-data) and, "
        "with --out-model, the bundle is recalibrated and re-saved",
    )
    calibrate.add_argument(
        "--data", default=None,
        help="labelled CSV/Excel to measure calibration on (and, without "
        "--calibration-data, the rows the recalibration is fitted on)",
    )
    calibrate.add_argument(
        "--estimator", default="random_forest",
        help="without --model: the classifier family to train on --data and "
        "measure on a held-out split (default random_forest)",
    )
    calibrate.add_argument(
        "--calibration-data", default=None,
        help="with --model: a separate labelled table to fit the "
        "recalibration on, so the report stays on held-out --data",
    )
    calibrate.add_argument(
        "--target", default=None,
        help="the label column (auto-detected from the bundle, or the "
        "last column when training a fresh model)",
    )
    calibrate.add_argument(
        "--method", choices=["isotonic", "sigmoid"], default="isotonic",
        help="recalibration map (isotonic needs a few hundred rows; "
        "sigmoid/Platt is steadier on small sets)",
    )
    calibrate.add_argument(
        "--bins", type=int, default=10,
        help="equal-width probability bins for the reliability table (default 10)",
    )
    calibrate.add_argument(
        "--out", default=None,
        help="write the reliability table to this path (csv/tsv/md/json/html)",
    )
    calibrate.add_argument(
        "--out-model", default=None,
        help="write a recalibrated bundle to this path (.joblib)",
    )
    calibrate.add_argument(
        "--plot", default=None,
        help="save the reliability diagram (predicted vs observed) to this "
        "path (.png/.svg/.pdf)",
    )

    decide = ml_sub.add_parser(
        "decide",
        help="decision-curve analysis — does acting on the model beat the defaults?",
    )
    decide.add_argument(
        "--model", required=True,
        help="a .joblib classification bundle written by a previous `ml train` run",
    )
    decide.add_argument(
        "--data", required=True,
        help="labelled CSV/Excel to score and analyse (CSV/Excel)",
    )
    decide.add_argument(
        "--target", default=None,
        help="the label column (auto-detected from the bundle)",
    )
    decide.add_argument(
        "--cost-ratio", type=float, default=1.0,
        help="false-positive : true-positive cost ratio (default 1; e.g. 5 "
        "means one missed positive is worth five false alarms)",
    )
    decide.add_argument(
        "--threshold", type=float, default=None,
        help="report the net benefit at this single threshold probability "
        "instead of a swept grid",
    )
    decide.add_argument(
        "--thresholds", default=None,
        help="comma-separated explicit threshold grid (each in [0, 1))",
    )
    decide.add_argument(
        "--points", type=int, default=100,
        help="number of grid points when neither --threshold nor "
        "--thresholds is given (default 100)",
    )
    decide.add_argument(
        "--criterion", choices=["youden", "f1", "cost"], default=None,
        help="also report the held-out optimal threshold for this criterion "
        "(youden: sensitivity+specificity-1; f1; cost: expected value)",
    )
    decide.add_argument(
        "--out", default=None,
        help="write the net-benefit table to this path (csv/tsv/md/json/html)",
    )
    decide.add_argument(
        "--plot", default=None,
        help="save the decision curve (net benefit vs threshold) to this path",
    )

    subgroup = ml_sub.add_parser(
        "subgroup",
        help="stratified performance audit — which subgroups does the model fail?",
    )
    subgroup.add_argument(
        "--model", required=True,
        help="a .joblib bundle written by a previous `ml train` run",
    )
    subgroup.add_argument(
        "--data", required=True,
        help="labelled CSV/Excel to score and stratify (CSV/Excel)",
    )
    subgroup.add_argument(
        "--by", required=True,
        help="the column to stratify by (e.g. assay, series, site, batch)",
    )
    subgroup.add_argument(
        "--target", default=None,
        help="the label column (auto-detected from the bundle)",
    )
    subgroup.add_argument(
        "--min-group-size", type=int, default=10,
        help="subgroups smaller than this are reported but flagged "
        "insufficient (default 10)",
    )
    subgroup.add_argument(
        "--metric", default=None,
        help="also name the worst group for this metric (e.g. accuracy, "
        "rmse); default is chosen per task",
    )
    subgroup.add_argument(
        "--scan", action="store_true",
        help="test every subgroup's gap versus the rest and correct for "
        "multiple comparisons (reports raw and adjusted p-values)",
    )
    subgroup.add_argument(
        "--correction", default="fdr_bh",
        choices=["fdr_bh", "bonferroni", "holm"],
        help="multiple-comparison method for --scan (default fdr_bh)",
    )
    subgroup.add_argument(
        "--out", default=None,
        help="write the per-subgroup table to this path (csv/tsv/md/json/html)",
    )
    subgroup.add_argument(
        "--plot", default=None,
        help="save the subgroup bar chart for --metric (or the task default)",
    )


    tune = ml_sub.add_parser(
        "tune", help="keras-tuner-style hyperparameter search (RandomSearch/Hyperband)"
    )
    tune.add_argument("--data", required=True, help="CSV/Excel with features+target")
    tune.add_argument("--target", default=None, help="target column (auto-detected)")
    tune.add_argument(
        "--task", choices=["classification", "regression", "auto"], default="auto",
        help="task type; 'auto' infers it from the target column (default)",
    )
    tune.add_argument(
        "--estimator", default="ann",
        help="hypermodel family: ann (sklearn MLP), dnn (PyTorch deep "
        "network, batchnorm searchable), hsvr (hierarchical SVR, "
        "regression only), or ANY grid-bearing registry family "
        "(random_forest, svm, knn, xgboost, ridge, ... -- its declared "
        "param_grid becomes the searchable space)",
    )
    tune.add_argument(
        "--searcher", choices=["random", "hyperband", "tpe"], default="random",
        help="search strategy: uniform random sampling, successive-halving "
        "Hyperband over the resource hyperparameter, or tpe = Optuna-style "
        "Tree-structured Parzen Estimator",
    )
    tune.add_argument(
        "--max-trials", type=int, default=10,
        help="trial count for --searcher random (default 10)",
    )
    tune.add_argument(
        "--objective", default="auto",
        help="sklearn scorer name ('r2', 'accuracy', 'roc_auc', ...) or 'auto' "
        "(r2 for regression, accuracy for classification)",
    )
    tune.add_argument("--cv", type=int, default=3, help="cross-validation folds")
    tune.add_argument("--seed", type=int, default=42, help="sampling/seed")
    tune.add_argument(
        "--min-resource", type=int, default=1,
        help="hyperband: smallest resource budget (default 1)",
    )
    tune.add_argument(
        "--max-resource", type=int, default=27,
        help="hyperband: largest resource budget (default 27)",
    )
    tune.add_argument(
        "--eta", type=int, default=3,
        help="hyperband: promotion factor between rungs (default 3)",
    )
    tune.add_argument(
        "--out", default=None,
        help="write the trials table to this path (csv/tsv/md/json/html)",
    )
    tune.add_argument(
        "--save-best", default=None,
        help="save the best estimator as a .joblib bundle (ml check compatible)",
    )

    ad = ml_sub.add_parser(
        "ad",
        help="applicability-domain analysis — is a prediction reliable?",
    )
    ad.add_argument(
        "--data", default=None,
        help="single CSV/Excel: split 80/20, train --model, judge the "
        "held-out rows (the convenient mode)",
    )
    ad.add_argument(
        "--bundle", default=None,
        help="a .joblib bundle written by a previous `ml train` run — "
        "with --train-data/--test-data this is the uploaded "
        "Applicability_domain_analysis.py flow verbatim",
    )
    ad.add_argument(
        "--train-data", default=None,
        help="with --bundle: the original training table (target column "
        "required — the bootstrap ensemble refits on it)",
    )
    ad.add_argument(
        "--test-data", default=None,
        help="with --bundle: the query table to judge inside/outside the "
        "domain",
    )
    ad.add_argument("--target", default=None, help="target column (auto-detected)")
    ad.add_argument(
        "--model", default="random_forest",
        help="registry model name for the --data mode (default random_forest)",
    )
    ad.add_argument(
        "--task", choices=["classification", "regression", "auto"], default="auto",
        help="task type; 'auto' infers it from the target column (default)",
    )
    ad.add_argument(
        "--keep-categorical", action="store_true",
        help="keep string feature columns and one-hot encode them",
    )
    ad.add_argument(
        "--k", type=int, default=5,
        help="nearest neighbours of the distance domain (default 5, the "
        "upload's value)",
    )
    ad.add_argument(
        "--percentile", type=float, default=95.0,
        help="percentile of the training distances AND the training-side "
        "ensemble spread both thresholds are cut at (default 95)",
    )
    ad.add_argument(
        "--n-models", type=int, default=30,
        help="bootstrap ensemble size for the uncertainty half (default "
        "30, the upload's value; every member predicts on the query AND "
        "training rows in one pass — half the upload's 2 x n fits)",
    )
    ad.add_argument(
        "--no-uncertainty", action="store_true",
        help="skip the bootstrap half — a kNN-distance-only quick pass",
    )
    ad.add_argument(
        "--out", default=None,
        help="write the reliability table to this path (csv/tsv/md/json/"
        "html); the upload's Applicability_Domain_Results.csv",
    )
    ad.add_argument(
        "--plot", action="store_true",
        help="save the combined two-panel AD figure into the current "
        "directory (ad_applicability_domain.png) — requires "
        "pharmaml[reports]",
    )

    # ---- chem --------------------------------------------------------
    chem_parser = subparsers.add_parser("chem", help="cheminformatics utilities")
    chem_sub = chem_parser.add_subparsers(dest="chem_command", required=True)

    pic50 = chem_sub.add_parser("pic50", help="add a pIC50 column to a table")
    pic50.add_argument("--data", required=True)
    pic50.add_argument("--column", default="IC50 (nM)")
    pic50.add_argument("--unit", default="nM", choices=["M", "mM", "uM", "nM", "pM"])
    pic50.add_argument("--out", default=None, help="output path (default: <stem>_pic50.csv)")

    descriptors = chem_sub.add_parser(
        "descriptors", help="compute RDKit descriptors for a SMILES table"
    )
    descriptors.add_argument("--data", required=True)
    descriptors.add_argument("--smiles-col", default="SMILES")
    descriptors.add_argument(
        "--set", dest="descriptor_set",
        choices=["rdkit_all", "morgan", "mordred"], default="rdkit_all",
    )
    descriptors.add_argument("--out", default=None)

    rism = chem_sub.add_parser(
        "rism",
        help="compute 3D-RISM-KH-inspired solvation descriptors for a SMILES table",
    )
    rism.add_argument("--data", required=True)
    rism.add_argument("--smiles-col", default="SMILES")
    rism.add_argument(
        "--solvent", choices=["spc", "tip3p"], default="spc",
        help="solvent site model for the pairwise KH surrogate",
    )
    rism.add_argument(
        "--temperature", type=float, default=298.15,
        help="absolute temperature in kelvin (default 298.15)",
    )
    rism.add_argument("--out", default=None)

    chem_compare = chem_sub.add_parser(
        "compare", help="reconcile a ligand column across two tables"
    )
    chem_compare.add_argument("--data-a", required=True, help="first table (csv/xlsx)")
    chem_compare.add_argument("--data-b", required=True, help="second table (csv/xlsx)")
    chem_compare.add_argument("--column", required=True, help="ligand-name column")
    chem_compare.add_argument(
        "--keep-case", action="store_true",
        help="do not fold names to lowercase before comparing",
    )
    chem_compare.add_argument(
        "--keep-extension", action="store_true",
        help="do not strip file extensions (.pdbqt, ...) before comparing",
    )
    chem_compare.add_argument(
        "--out", default=None, help="optional CSV path for the differences report"
    )
    chem_compare.add_argument(
        "--figure", default=None,
        help="optional figure path (png/svg/pdf) for the overlap breakdown",
    )

    chem_merge = chem_sub.add_parser(
        "merge", help="merge every table of one folder into a single file"
    )
    chem_merge.add_argument("--dir", required=True, help="folder to scan (non-recursive)")
    chem_merge.add_argument("--extension", default=".csv")
    chem_merge.add_argument(
        "--first-columns", default=None,
        help="comma-separated column names to move to the front",
    )
    chem_merge.add_argument("--out", default=None, help="output path (default: <dir>/merged_output.csv)")

    # ---- pharma ------------------------------------------------------
    pharma_parser = subparsers.add_parser("pharma", help="pharmaceutical calculations")
    pharma_sub = pharma_parser.add_subparsers(dest="pharma_command", required=True)

    pk = pharma_sub.add_parser("pk", help="non-compartmental PK summary")
    pk.add_argument("--data", required=True, help="CSV with time & concentration columns")
    pk.add_argument("--time", default="time", help="time column name")
    pk.add_argument("--conc", default="conc", help="concentration column name")
    pk.add_argument("--out", default=None, help="optional JSON output path")

    dose = pharma_sub.add_parser("dose", help="design a dosing regimen")
    dose.add_argument("--cl", type=float, required=True, help="clearance (L/h)")
    dose.add_argument("--vd", type=float, required=True, help="volume (L)")
    dose.add_argument("--target-css", type=float, required=True, help="target avg Css")
    dose.add_argument("--tau", type=float, default=12.0, help="interval (h)")
    dose.add_argument("--f", type=float, default=1.0, help="bioavailability fraction")

    approvals = pharma_sub.add_parser(
        "approvals", help="collect approved drug names from DGIdb-style exports"
    )
    approvals.add_argument(
        "--data", required=True, action="append",
        help="csv/tsv export (repeat the flag for several files)",
    )
    approvals.add_argument("--drug-column", default="drug")
    approvals.add_argument("--approval-column", default="regulatory approval")
    approvals.add_argument("--status", default="approved")
    approvals.add_argument("--out", default=None, help="optional single-column CSV output")

    # ---- docking -----------------------------------------------------
    docking_parser = subparsers.add_parser("docking", help="docking utilities")
    docking_sub = docking_parser.add_subparsers(dest="docking_command", required=True)

    scan = docking_sub.add_parser("scan", help="summarise a docking run directory")
    scan.add_argument("--directory", required=True)
    scan.add_argument("--log-name", default="r.dlg")
    scan.add_argument("--out", default=None, help="output CSV path")

    check = docking_sub.add_parser("check", help="audit docking completion")
    check.add_argument("--directory", required=True)
    check.add_argument("--log-name", default="r.dlg")
    check.add_argument("--out", default=None)

    prep_ligands = docking_sub.add_parser(
        "prep-ligands",
        help="import a ligand CSV and prepare PDBQT folders",
    )
    prep_ligands.add_argument("--ligands", required=True, help="ligand table (CSV/TSV/Excel)")
    prep_ligands.add_argument("--out", required=True, help="campaign output directory")
    prep_ligands.add_argument("--smiles-col", default=None, help="SMILES column (auto-detected)")
    prep_ligands.add_argument("--name-col", default=None, help="ligand name column (auto-detected)")
    prep_ligands.add_argument(
        "--naming",
        default="index_name",
        choices=("index", "index_name", "name"),
        help="folder naming scheme (index reproduces the legacy scripts)",
    )

    prep_protein = docking_sub.add_parser(
        "prep-protein",
        help="import a protein PDB and prepare a receptor PDBQT",
    )
    prep_protein.add_argument("--protein", required=True, help="protein file (.pdb or .pdbqt)")
    prep_protein.add_argument("--out", default=None, help="receptor PDBQT path (default <stem>.pdbqt)")
    prep_protein.add_argument("--keep-hetatm", action="store_true", help="keep non-water HETATM records")
    prep_protein.add_argument("--chain", default=None, help="keep only this chain (e.g. A)")
    prep_protein.add_argument(
        "--altloc",
        default="first",
        help="alternate-location conformer: 'first' or a letter like A",
    )

    dpf = docking_sub.add_parser(
        "dpf",
        help="write an AutoDock4 docking parameter file (r.dpf) for a ligand",
    )
    dpf.add_argument("--ligand", required=True, help="ligand PDBQT to dock")
    dpf.add_argument(
        "--receptor", default="r.pdbqt",
        help="receptor PDBQT filename (parity with the GPF generator)",
    )
    dpf.add_argument("--ga-runs", type=int, default=100, help="number of GA runs (ga_run)")
    dpf.add_argument("--out", default=None, help="DPF path (default <ligand_dir>/r.dpf)")

    collect = docking_sub.add_parser(
        "collect",
        help="collect matching files (r.dlg dialogs, numbered PDBQTs) into one folder",
    )
    collect.add_argument("--dir", required=True, help="campaign directory to scan recursively")
    collect.add_argument(
        "--filename",
        default=None,
        help="exact filename to collect (default r.dlg when no pattern is given)",
    )
    collect.add_argument(
        "--pattern",
        default=None,
        help="regex the filename must match, e.g. '^\\d+\\.pdbqt$'",
    )
    collect.add_argument("--out", default=None, help="output folder (default <dir>/collected)")
    collect.add_argument(
        "--dry-run", action="store_true",
        help="report the copies without performing them",
    )

    torsion = docking_sub.add_parser(
        "torsion",
        help="audit TORSDOF / active REMARK / BRANCH consistency of ligand PDBQTs",
    )
    torsion.add_argument("--dir", required=True, help="directory tree with .pdbqt ligands")

    gpf_scan = docking_sub.add_parser(
        "gpf-scan",
        help="report the ligand_types line of every sub-directory's r.gpf",
    )
    gpf_scan.add_argument("--dir", required=True, help="campaign directory")

    vina_scan = docking_sub.add_parser(
        "vina-scan",
        help="rank Vina .log files of a results tree by best affinity",
    )
    vina_scan.add_argument("--dir", required=True, help="directory tree with Vina logs")

    rescore = docking_sub.add_parser(
        "rescore",
        help="combine evidence columns of a summary CSV into a 0-1 consensus",
    )
    rescore.add_argument(
        "--data", required=True,
        help="docking summary table (CSV/TSV; scan --out or vina-scan exports)",
    )
    rescore.add_argument(
        "--columns", required=True,
        help="comma-separated evidence columns to combine",
    )
    rescore.add_argument(
        "--weights", default=None,
        help="comma-separated per-column weights (uniform when omitted)",
    )
    rescore.add_argument(
        "--higher", default=None,
        help="comma-separated columns to treat as higher-is-better (override)",
    )
    rescore.add_argument(
        "--lower", default=None,
        help="comma-separated columns to treat as lower-is-better (override)",
    )
    rescore.add_argument(
        "--out", default=None,
        help="output CSV (default <stem>_rescored.csv next to the input)",
    )
    rescore.add_argument(
        "--top", type=int, default=15,
        help="leaderboard rows to print (default 15)",
    )
    rescore.add_argument(
        "--plots", action="store_true",
        help="emit the visual bundle (report.html + consensus ranking "
        "figure + the breakdown table) into --out-dir — requires "
        "pharmaml[reports]",
    )
    rescore.add_argument(
        "--pdf-report", action="store_true",
        help="with the visual bundle, also write report.pdf — the "
        "multi-page document (one page per table/figure); implies "
        "--plots — requires pharmaml[reports]",
    )
    rescore.add_argument(
        "--out-dir", default="reports",
        help="visual bundle output directory (default ./reports)",
    )

    status = docking_sub.add_parser("campaign-status", help="read-only reviewed Vina campaign inspection")
    status.add_argument("--dir", required=True, help="reviewed Vina campaign output directory")
    status.add_argument("--check-originals", action="store_true",
                        help="also read/hash original input and engine paths recorded in the manifest")

    campaign = docking_sub.add_parser(
        "campaign",
        help="campaign-tree file management (distribute / cleanup / delete-named / list / reindex)",
    )
    campaign_sub = campaign.add_subparsers(dest="campaign_command", required=True)

    campaign_list = campaign_sub.add_parser(
        "list", help="list file stems of one folder (optionally to a CSV)"
    )
    campaign_list.add_argument("--dir", required=True, help="folder whose files are listed")
    campaign_list.add_argument(
        "--ext", default=".csv", help="file extension to filter by (default .csv)"
    )
    campaign_list.add_argument(
        "--out", default=None, help="optional single-column CSV (name header)"
    )

    campaign_distribute = campaign_sub.add_parser(
        "distribute",
        help="copy files into every immediate sub-directory (receptor/binaries push)",
    )
    campaign_distribute.add_argument(
        "--dir", required=True, help="target directory whose sub-directories receive copies"
    )
    campaign_distribute.add_argument(
        "--file",
        action="append",
        required=True,
        dest="files",
        help="source file to distribute (repeatable)",
    )
    campaign_distribute.add_argument(
        "--overwrite", action="store_true", help="replace existing destination files"
    )

    campaign_cleanup = campaign_sub.add_parser(
        "cleanup",
        help="delete every file not on the keep-list (allowlist + regex)",
    )
    campaign_cleanup.add_argument("--dir", required=True, help="tree to clean")
    campaign_cleanup.add_argument(
        "--keep",
        action="append",
        default=[],
        help="filename to preserve (repeatable)",
    )
    campaign_cleanup.add_argument(
        "--keep-pattern",
        default=None,
        help="regex filenames must match to survive, e.g. '^\\d+\\.pdbqt$'",
    )
    campaign_cleanup.add_argument(
        "--remove-empty",
        action="store_true",
        help="also remove directories left (or already) empty",
    )
    campaign_cleanup.add_argument(
        "--dry-run", action="store_true", help="preview without deleting anything"
    )

    campaign_delete = campaign_sub.add_parser(
        "delete-named",
        help="delete every file with one name anywhere under a tree",
    )
    campaign_delete.add_argument("--dir", required=True, help="tree to sweep")
    campaign_delete.add_argument("--name", required=True, help="filename to remove")
    campaign_delete.add_argument(
        "--dry-run", action="store_true", help="count without deleting"
    )

    campaign_reindex = campaign_sub.add_parser(
        "reindex",
        help="reindex a results table onto the full ligand-number range "
        "(missing ligands appear as blank rows instead of silently absent)",
    )
    campaign_reindex.add_argument(
        "--data", required=True, help="results table to reindex (CSV/XLSX)"
    )
    campaign_reindex.add_argument(
        "--column",
        required=True,
        help="column whose values embed the ligand number (e.g. '5_result.dlg')",
    )
    campaign_reindex.add_argument(
        "--start", type=int, default=0, help="first ligand number (default 0)"
    )
    campaign_reindex.add_argument(
        "--stop", type=int, default=300, help="last ligand number (default 300)"
    )
    campaign_reindex.add_argument(
        "--pattern",
        default=r"(\d+)",
        help="regex whose first capture group extracts the number (default r'(\\d+)')",
    )
    campaign_reindex.add_argument(
        "--out",
        default=None,
        help="optional output CSV/XLSX (index written as a 'number' column)",
    )

    # ---- biology -----------------------------------------------------
    biology_parser = subparsers.add_parser(
        "biology", help="cell line data utilities (drug-response screens, omics)"
    )
    biology_sub = biology_parser.add_subparsers(
        dest="biology_command", required=True
    )

    bio_audit = biology_sub.add_parser(
        "response-audit",
        help="audit a GDSC/CCLE-style drug-response table",
    )
    bio_audit.add_argument(
        "--data", required=True,
        help="long-format response table (CSV/TSV/Excel), one row per "
        "(cell line, compound) pair",
    )
    bio_audit.add_argument(
        "--cell-column", default="cell_line", help="cell line column name",
    )
    bio_audit.add_argument(
        "--compound-column", default="compound", help="compound column name",
    )
    bio_audit.add_argument(
        "--tissue-column", default=None,
        help="optional tissue annotation column (kept out of the metrics)",
    )
    bio_audit.add_argument(
        "--metric", default=None,
        help="metric for the per-compound summary (default: first metric)",
    )
    bio_audit.add_argument(
        "--replicate-cv", action="store_true",
        help="also report the pre-collapse spread of duplicated "
        "(cell line, compound) pairs: replicate count, median, mean, "
        "std, spread and CV%% (std / |mean|)",
    )

    bio_top = biology_sub.add_parser(
        "top-biomarkers",
        help="correlate gene expression with one drug's response",
    )
    bio_top.add_argument(
        "--expression", required=True,
        help="expression table: rows = cell lines, columns = genes "
        "(first column may hold the cell-line identifiers)",
    )
    bio_top.add_argument(
        "--response", required=True,
        help="long-format response table (cell line, compound, metric)",
    )
    bio_top.add_argument(
        "--response-column", required=True,
        help="metric column in the response table (e.g. pIC50 or LN_IC50)",
    )
    bio_top.add_argument(
        "--compound", default=None,
        help="compound to analyse (required when the table holds several)",
    )
    bio_top.add_argument(
        "--cell-column", default="cell_line",
        help="cell line column name in both tables",
    )
    bio_top.add_argument(
        "--compound-column", default="compound",
        help="compound column name in the response table",
    )
    bio_top.add_argument(
        "--method", choices=("spearman", "pearson"), default="spearman",
        help="correlation method (default spearman)",
    )
    bio_top.add_argument(
        "--lower-is-sensitive", action="store_true",
        help="low response values mean sensitive (LN_IC50 style, default)",
    )
    bio_top.add_argument(
        "--higher-is-sensitive", action="store_true",
        help="high response values mean sensitive (pIC50 style)",
    )
    bio_top.add_argument(
        "--top", type=int, default=15, metavar="N",
        help="number of biomarkers to report (default 15)",
    )
    bio_top.add_argument(
        "--out", default=None,
        help="write the hits table to this path (csv/tsv/xlsx)",
    )

    generative_parser = subparsers.add_parser(
        "generative",
        help="de novo molecule generation (genetic algorithm / reinforcement learning)",
    )
    generative_sub = generative_parser.add_subparsers(
        dest="generative_command", required=True
    )

    gen_run = generative_sub.add_parser(
        "run",
        help="optimise molecules toward a recipe objective",
    )
    gen_run.add_argument(
        "--method", choices=("ga", "rl"), default="ga",
        help="optimiser: 'ga' = SMILES genetic algorithm (CPU-strong, no torch "
        "needed), 'rl' = REINVENT-style reinforcement learning (requires torch)",
    )
    gen_run.add_argument(
        "--recipe", choices=("qed", "logp", "druglike", "similar", "novel"),
        default="qed",
        help="objective preset: qed (QED drug-likeness), logp (LogP 1-3 window), "
        "'druglike' (QED x MW x TPSA multi-objective), 'novel' (druglike x "
        "structural novelty vs the bundled corpus), 'similar' (similarity to "
        "your seed molecules -- requires --seeds/--seed-smiles)",
    )
    gen_run.add_argument(
        "--sa-weight", type=float, default=None, metavar="WEIGHT",
        help="opt in to the SA reward during GA or RL optimization, with this "
        "positive weight relative to the recipe's existing objective weights. "
        "The sa_score breakdown is a 0-1 reward (not the raw 1-10 SA score); "
        "this is not a synthesis guarantee or an independent hard filter",
    )
    gen_run.add_argument(
        "--scaffold", action="store_true", default=False,
        help="GA only: scaffold-preserving mutations -- keep each parent's "
        "Murcko framework verbatim and resample its decorations from the "
        "corpus-derived vocabulary (lead-optimisation mode; the character "
        "splice crossover is bypassed -- pair with --scaffold-hop for "
        "structural recombination)",
    )
    gen_run.add_argument(
        "--scaffold-hop", action="store_true", default=False,
        help="GA only: BREED-style scaffold-hop crossover -- cut two parents "
        "at a pair of homologous single bonds and recombine them "
        "(fragments swapped, rings merged, a two-ended linker -- a "
        "single atom or a short acyclic path -- transplanted into a cut "
        "ring bond, a whole ring excised between its two anchor bonds "
        "and spliced across the cut into a fused bicyclic, a whole "
        "ring spliced INTO a cut acyclic bond as the linker, or a "
        "two-point segment swap exchanging one parent's bounded "
        "acyclic middle for the other's homologous middle -- the "
        "linker / bioisostere exchange), so ring "
        "systems survive and the offspring's "
        "framework can differ from both parents",
    )
    gen_run.add_argument(
        "--topology", action="store_true", default=False,
        help="GA only: ring-topology mutations -- each offspring undergoes "
        "one ring contraction (an atom removed from a saturated ring, "
        "its ring neighbours rejoined) or expansion (a methylene "
        "inserted into a saturated single ring bond) within the 5..8 "
        "ring-size window (piperidine <-> pyrrolidine/azepane, decalin "
        "-> hydrindane); acyclic or aromatic-only parents fall back to "
        "character mutation -- pair with --scaffold-hop for the full "
        "structural move set",
    )
    gen_run.add_argument(
        "--adaptive-operators", action="store_true", default=False,
        help="GA only: adaptive operator selection -- the crossover-vs-clone "
        "choice, every scaffold-hop recombination geometry and the "
        "mutation family draw themselves by per-operator credit (a "
        "sliding-window reward against the parents' mean score, softmax "
        "selection with an exploration floor) instead of staying at fixed "
        "rates; the run reports per-operator statistics in its metadata",
    )
    gen_run.add_argument(
        "--seeds", default=None,
        help="seeded mode: CSV/TSV/Excel table with a SMILES column (a "
        "smiles/smile/canonical_smiles-style header is auto-detected; other "
        "columns such as 'name' are ignored); initialises the GA population "
        "from your molecules and biases the RL prior's corpus toward them",
    )
    gen_run.add_argument(
        "--seed-smiles", default=None, metavar="SMILES",
        help="seeded mode: comma-separated SMILES (e.g. \"CCO,CCN\"); combined "
        "with --seeds when both are given",
    )
    gen_run.add_argument(
        "--iterations", type=int, default=20, metavar="N",
        help="GA generations or RL iterations (default 20)",
    )
    gen_run.add_argument(
        "--population", type=int, default=48, metavar="N",
        help="GA population size (default 48)",
    )
    gen_run.add_argument(
        "--batch-size", type=int, default=32, metavar="N",
        help="RL: molecules sampled per iteration (default 32)",
    )
    gen_run.add_argument(
        "--prior-epochs", type=int, default=8, metavar="N",
        help="RL: epochs for the on-the-fly corpus prior (default 8)",
    )
    gen_run.add_argument(
        "--seed", type=int, default=42,
        help="random seed (two runs with the same seed are identical)",
    )
    gen_run.add_argument(
        "--top", type=int, default=10, metavar="N",
        help="leaderboard rows to print (default 10)",
    )
    gen_run.add_argument(
        "--out", default=None,
        help="write the full ranked leaderboard to this path (csv/tsv/xlsx)",
    )
    gen_run.add_argument(
        "--plot", default=None, metavar="PATH",
        help="save the run's own learning-curve figure to this path "
        "(png/svg/pdf): GA + --adaptive-operators -> the operator-trajectory "
        "figure (the run's score curve plus the per-generation operator mix "
        "learning its way, plot_operator_trajectory); RL -> the prior-drift "
        "introspection (agent-vs-prior log-probabilities, the squared drift "
        "the anchor penalises, the exploration entropy — "
        "plot_rl_introspection)",
    )
    gen_run.add_argument(
        "--pareto", action="store_true", default=False,
        help="multi-objective recipes (druglike/novel/similar), or qed/logp "
        "with --sa-weight: after "
        "the leaderboard, extract and print the Pareto front -- the "
        "non-dominated molecules (improving one objective necessarily "
        "sacrifices another; front members can sit arbitrarily deep in "
        "the leaderboard -- the trade-offs the blended ranking hides)",
    )
    gen_run.add_argument(
        "--pareto-plot", default=None, metavar="PATH",
        help="with --pareto: save the trade-off scatter (dominated molecules "
        "muted, the non-dominated front highlighted over the recipe's "
        "first two objectives, plot_pareto_front) to this path (png/svg/pdf)",
    )
    gen_run.add_argument(
        "--pareto-keep", default=None, metavar="N", type=int,
        help="with --pareto: prune the front to the N most isolated members "
        "(NSGA-II crowding distance -- the trade-off corners always "
        "survive; real three-objective runs can leave 40+ non-dominated "
        "molecules, and rank-truncation would drop the very corners the "
        "front exists to show). The un-pruned size is kept in the summary",
    )

    gen_corpus = generative_sub.add_parser(
        "corpus",
        help="print the bundled generation corpus (canonical drug-like SMILES)",
    )
    gen_corpus.add_argument(
        "--out", default=None,
        help="write the corpus to this path (csv/tsv/xlsx)",
    )

    return parser


def _cmd_models(args: argparse.Namespace) -> int:
    from pharmaml.ml.models import list_models

    entries = list_models(only_available=False)
    print(f"{'model':<22} {'task':<16} {'available':<10} notes")
    print("-" * 78)
    for entry in entries:
        flag = "yes" if entry["available"] else f"needs {entry['requires']}"
        print(f"{entry['name']:<22} {entry['task']:<16} {flag:<10} {entry['notes']}")
    return 0


def _load_cli_dataset(args: argparse.Namespace):
    """Load the ``--data`` file via :mod:`pharmaml.data` with task inference.

    Both ``ml train`` and ``ml compare`` accept ``--task auto`` (the
    default), which lets :func:`pharmaml.data.load_dataset` decide
    classification (2+ classes) vs regression from the target column,
    and ``--keep-categorical`` to keep string feature columns for
    one-hot encoding.
    """
    from pharmaml.data import load_dataset

    task = None if getattr(args, "task", "auto") == "auto" else args.task
    return load_dataset(
        args.data,
        target=getattr(args, "target", None),
        task=task,
        keep_categorical=getattr(args, "keep_categorical", False),
    )


def _cmd_data_inspect(args: argparse.Namespace) -> int:
    from pharmaml.data import load_dataset

    dataset = load_dataset(args.data, target=args.target)
    print(dataset.summary())
    if args.head > 0:
        print(f"\nfirst {args.head} row(s):")
        print(dataset.frame.head(args.head).to_string(index=False))
    return 0


def _cmd_data_split(args: argparse.Namespace) -> int:
    from pharmaml.data import split_table

    result = split_table(
        path=args.data,
        target=args.target,
        test_size=args.test_size,
        val_size=args.val_size,
        stratify=not args.no_stratify,
        random_state=args.seed,
    )
    out_dir = args.out_dir or str(Path(args.data).parent)
    prefix = args.prefix or Path(args.data).stem
    result.write(out_dir, prefix)
    print(result)
    return 0


def _read_split_audit_table(path: Path, delimiter: str | None):
    """Compatibility wrapper around the identifier-preserving reader."""
    from pharmaml.utils.identifier_table import read_identifier_table

    return read_identifier_table(path, delimiter)


def _cmd_research(args: argparse.Namespace) -> int:
    """Print diagnostics only; the user may redirect the JSON themselves."""
    import json

    from pharmaml.exceptions import DataValidationError
    from pharmaml.ml.provenance import (
        compare_manifests,
        compare_uncertainty_reports,
        environment_snapshot,
        experiment_manifest,
    )

    if args.research_command == "checkpoint":
        from pharmaml.ml.checkpoint_diagnostics import inspect_checkpoint

        result = inspect_checkpoint(args.path, inputs=args.input)
    elif args.research_command == "environment":
        result = environment_snapshot()
    elif args.research_command == "manifest":
        parameters = {}
        for item in args.parameter:
            name, sep, value = item.partition("=")
            if not sep or not name.strip() or name in parameters:
                raise DataValidationError("parameters must have unique nonempty NAME=VALUE entries")
            parameters[name] = value
        result = experiment_manifest(args.data, parameters=parameters, split_strategy=args.split_strategy)
    else:
        with Path(args.first).open(encoding="utf-8") as handle:
            first = json.load(handle)
        with Path(args.second).open(encoding="utf-8") as handle:
            second = json.load(handle)
        if args.research_command == "compare-training":
            from pharmaml.ml.training_provenance import compare_training_records

            result = compare_training_records(first, second)
        elif args.research_command == "compare-uncertainty":
            result = compare_uncertainty_reports(first, second)
        else:
            result = compare_manifests(first, second)
    print(json.dumps(result, indent=2, allow_nan=False))
    if (args.research_command == "checkpoint"
            and (not result["valid_envelope"] or result["input_status"].startswith("changed")
                 or result["implementation_status"].startswith("changed"))):
        return 1
    return 0


def _cmd_ml_nested_ridge(args: argparse.Namespace) -> int:
    import json

    from pharmaml.ml.nested_classification import nested_logistic_from_file
    from pharmaml.ml.validation_workbench import nested_ridge_from_file

    evaluate = nested_logistic_from_file if args.ml_command == "nested-logistic" else nested_ridge_from_file
    result = evaluate(args.data, features=args.features, target=args.target,
                                    group=args.group, outer_folds=args.outer_folds,
                                    inner_folds=args.inner_folds, seed=args.seed)
    print(json.dumps(result, indent=2, allow_nan=False))
    return 0


def _cmd_ml_calibrate_binary(args: argparse.Namespace) -> int:
    import json

    from pharmaml.ml.probability_calibration import binary_probability_calibration_from_files

    report = binary_probability_calibration_from_files(
        args.train, args.calibration, args.test, features=args.features, target=args.target,
        key=args.key, positive_label=args.positive_label,
    )
    print(json.dumps(report, indent=2, allow_nan=False))
    return 0


def _cmd_ml_conformal_report(args: argparse.Namespace) -> int:
    """Evaluate a fixed model on independently supplied calibration and test files."""
    import json

    from pharmaml.ml.uncertainty_workbench import (
        classification_uncertainty_from_files,
        regression_uncertainty_from_files,
    )

    evaluate = (classification_uncertainty_from_files if args.ml_command == "conformal-classification"
                else regression_uncertainty_from_files)
    report = evaluate(
        args.train, args.calibration, args.test, features=args.features, target=args.target,
        key=args.key, group=args.group, alpha=args.alpha, diagnostics=args.diagnostics,
    )
    print(json.dumps(report, indent=2, default=str, allow_nan=False))
    return 0


def _cmd_data_audit_splits(args: argparse.Namespace) -> int:
    """Audit exact identifier overlaps without printing raw identifiers."""
    import json
    import os
    import re

    from pharmaml.exceptions import DataValidationError
    from pharmaml.ml.split_audit import audit_split_overlap

    if len(args.partition) < 2:
        raise DataValidationError("at least two --partition NAME=PATH arguments are required")
    if len(set(args.key)) != len(args.key) or any(not key.strip() for key in args.key):
        raise DataValidationError("--key columns must be nonempty and unique")
    partitions: dict[str, list[Any]] = {}
    for specification in args.partition:
        name, separator, path_text = specification.partition("=")
        if not separator or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]*", name) or not path_text:
            raise DataValidationError("--partition must be NAME=PATH with a simple nonempty name")
        if name in partitions:
            raise DataValidationError(f"duplicate partition name: {name}")
        frame = _read_split_audit_table(Path(path_text), args.delimiter)
        missing = [key for key in args.key if key not in frame.columns]
        if missing:
            raise DataValidationError(f"partition {name!r} is missing key column(s): {', '.join(missing)}")
        selected = frame.loc[:, args.key]
        partitions[name] = (selected.iloc[:, 0].tolist() if len(args.key) == 1
                            else list(selected.itertuples(index=False, name=None)))
    report = audit_split_overlap(partitions)
    if args.details_json:
        output = Path(args.details_json)
        if output.suffix.lower() != ".json":
            raise DataValidationError("--details-json must end in .json")
        payload = {
            "key_columns": args.key,
            "partition_names": list(report.partition_names),
            "shared_keys": [
                {"key": item.key, "counts": dict(zip(report.partition_names, item.counts, strict=True))}
                for item in report.shared_keys
            ],
        }
        try:
            fd = os.open(output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
        except OSError as exc:
            raise DataValidationError(f"Cannot write new details file {output}: {exc}") from exc
    print(f"shared keys: {report.n_shared_keys}")
    for name, rows, duplicate, overlap in zip(
        report.partition_names, report.partition_rows, report.duplicate_rows,
        report.overlap_rows, strict=True,
    ):
        print(f"{name}: rows={rows} duplicate_rows={duplicate} overlap_rows={overlap}")
    print("pairwise shared unique keys:")
    print(report.pairwise_dataframe().to_string())
    if args.details_json:
        print(f"details: {args.details_json} (contains raw identifiers)")
    return 3 if report.has_overlap else 0


def _smi_bridge_frame(path: Path):
    """Read a ``.smi`` file into a SMILES/ID table (CLI-internal bridge).

    Lets ``--data x.smi --to sdf|smi`` reuse the table converters
    without a temporary CSV on disk (the legacy two-step workflow).
    """
    import pandas as pd

    from pharmaml.exceptions import DataValidationError

    rows: list[tuple[str, str]] = []
    with open(path, "r", encoding="utf-8", errors="ignore") as handle:
        for line in handle:
            parts = line.strip().split()
            if not parts:
                continue
            rows.append((parts[0], " ".join(parts[1:])))
    frame = pd.DataFrame(rows, columns=["SMILES", "ID"])
    if frame.empty:
        raise DataValidationError(f"no SMILES lines found in {path}")
    return frame


def _sdf_drop_exit(frame: Any) -> int:
    """Exit code for an SDF -> table conversion that dropped records.

    Mirrors the ``table_to_sdf`` CLI convention: any dropped record is
    reported on stderr and makes the command exit 1 -- surviving rows
    were converted, but data was lost and the user must know.
    """
    dropped = int(frame.attrs.get("sdf_dropped_records", 0))
    total = int(frame.attrs.get("sdf_total_records", 0))
    if dropped:
        print(
            f"{dropped} of {total} SDF records unparseable and dropped",
            file=sys.stderr,
        )
        return 1
    return 0


def _cmd_data_convert(args: argparse.Namespace) -> int:
    from pharmaml.chem.converters import (
        sdf_to_table,
        smi_to_csv,
        table_to_sdf,
        table_to_smi,
    )
    from pharmaml.exceptions import DataValidationError
    from pharmaml.utils.io import read_table, write_table

    src = Path(args.data)
    target = args.to
    suffix = src.suffix.lower()
    out = Path(args.out) if args.out else src.with_suffix(f".{target}")

    if suffix == ".smi":
        if target == "csv":
            written = smi_to_csv(src, out)
            print(f"converted {src.name} -> {written}")
            return 0
        if target == "smi":
            raise DataValidationError(
                f"input {src.name} is already a .smi file -- nothing to convert"
            )
        frame = _smi_bridge_frame(src)
        report = table_to_sdf(
            frame,
            out,
            smiles_col=args.smiles_col,
            name_col=args.name_col,
            embed3d=not args.no_3d,
        )
    elif suffix == ".sdf":
        if target == "sdf":
            raise DataValidationError(
                f"input {src.name} is already an SDF file -- use --to csv or --to smi"
            )
        if target == "csv":
            frame = sdf_to_table(src, out=out, smiles_col=args.smiles_col)
            print(f"converted {src.name} -> {out} ({len(frame)} molecules)")
            return _sdf_drop_exit(frame)
        frame = sdf_to_table(src, smiles_col=args.smiles_col)
        name_col = args.name_col or ("name" if "name" in frame.columns else None)
        written = table_to_smi(
            frame, out, smiles_col=args.smiles_col, name_col=name_col
        )
        print(f"converted {src.name} -> {written} ({len(frame)} molecules)")
        return _sdf_drop_exit(frame)
    else:  # CSV/TSV/Excel table input
        if target == "smi":
            written = table_to_smi(
                src, out, smiles_col=args.smiles_col, name_col=args.name_col
            )
            print(f"converted {src.name} -> {written}")
            return 0
        if target == "csv":
            if suffix == ".csv":
                # same-format guard (26-R5): csv -> csv used to rewrite the
                # INPUT in place (semicolon -> comma, exit 0)
                raise DataValidationError(
                    f"input {src.name} is already a CSV file -- nothing to convert"
                )
            frame = read_table(src)
            written = write_table(frame, out)
            print(f"converted {src.name} -> {written} ({len(frame)} rows)")
            return 0
        report = table_to_sdf(
            src,
            out,
            smiles_col=args.smiles_col,
            name_col=args.name_col,
            embed3d=not args.no_3d,
        )

    # --to sdf: full audit + output path; invalid SMILES -> exit 1
    print(report)
    print(f"output -> {report.output_sdf}")
    if report.failures:
        print(
            f"{report.failures} invalid SMILES skipped: "
            f"{report.failed_smiles}",
            file=sys.stderr,
        )
        return 1
    return 0


def _train_figure_bundle(result, report, dataset, X_test, y_test):
    """Collect the standard figure/table set for ``ml train --plots``."""
    import pandas as pd

    from pharmaml.exceptions import DataValidationError
    from pharmaml.viz import metrics_to_dataframe, ml_plots

    figures: dict[str, Any] = {}
    tables: dict[str, Any] = {}

    if dataset.task == "classification":
        figures["confusion_matrix"] = ml_plots.plot_confusion_matrix(report)
        if hasattr(result.model, "predict_proba"):
            figures["roc_curves"] = ml_plots.plot_roc_curves(
                result.model, X_test, y_test
            )
        if dataset.class_counts:
            figures["class_distribution"] = ml_plots.plot_class_distribution(
                dataset.class_counts
            )
            tables["class_counts"] = pd.DataFrame(
                {"class": list(dataset.class_counts),
                 "count": list(dataset.class_counts.values())}
            )
    else:
        y_pred = result.model.predict(X_test)
        figures["predicted_vs_actual"] = ml_plots.plot_predicted_vs_actual(
            y_test, y_pred, metrics=report.as_dict()
        )
        figures["residuals"] = ml_plots.plot_residuals(y_test, y_pred)

    if result.cv_scores is not None:
        figures["cv_scores"] = ml_plots.plot_cv_scores(result)
    try:
        figures["feature_importance"] = ml_plots.plot_feature_importance(result.model)
    except DataValidationError:  # kernel SVM / KNN — importance plot simply skipped
        pass

    tables.setdefault(
        "held_out_metrics", metrics_to_dataframe(report)
    )
    return figures, tables


def _cmd_ml_train(args: argparse.Namespace) -> int:
    from pharmaml.config import PipelineConfig
    from pharmaml.ml.evaluation import evaluate_model
    from pharmaml.ml.persistence import save_model
    from pharmaml.ml.preprocessing import make_train_test_split
    from pharmaml.ml.training import train_model

    record_path = None
    before = None
    actual_stratification: list[bool] = []
    if args.run_record:
        from pharmaml.ml.provenance import fingerprint_file
        from pharmaml.ml.training_provenance import prepare_record_path

        record_path = prepare_record_path(args.run_record)
        before = fingerprint_file(args.data)
    dataset = _load_cli_dataset(args)
    if record_path is not None:
        from pharmaml.exceptions import DataValidationError

        after = fingerprint_file(args.data)
        if before != after:
            raise DataValidationError("training input changed while reading; retry with a stable file")
    X_train, X_test, y_train, y_test = make_train_test_split(
        dataset.X, dataset.y, test_size=args.test_size,
        on_split=actual_stratification.append if record_path is not None else None,
    )

    result = train_model(
        args.model, dataset.task, X_train, y_train, tune=not args.no_tune, cv=args.cv
    )
    report = evaluate_model(result.model, X_test, y_test, dataset.task)

    # (r13) the provenance the predict/card/drift/calibrate/decide/subgroup
    # subcommands consume: the training target column, the per-feature
    # training box, and the drift quantile sketch.
    from pharmaml.ml.drift import feature_distributions_from_frame
    from pharmaml.ml.persistence import feature_ranges_from_frame

    config = PipelineConfig()
    model_path = config.output_path(f"{result.name}_{dataset.task}.joblib")
    save_model(
        result.model,
        model_path,
        name=result.name,
        task=dataset.task,
        features=dataset.feature_names,
        best_params=result.best_params,
        metrics=report.as_dict(),
        target=dataset.target,
        feature_ranges=feature_ranges_from_frame(X_train, dataset.feature_names),
        feature_distributions=feature_distributions_from_frame(
            X_train, dataset.feature_names
        ),
    )
    print(f"dataset:  {dataset.n_samples} rows x {dataset.n_features} features")
    if dataset.class_counts:
        print(f"classes:  {dataset.class_counts}")
    print(f"task:     {dataset.task}")
    print(f"model:    {result.name}")
    print(f"best:     {result.best_params or '(defaults)'}")
    print(f"held-out: {report}")
    print(f"saved:    {model_path}")

    if args.plots or args.pdf_report:
        from pharmaml.viz import save_visual_bundle

        figures, tables = _train_figure_bundle(result, report, dataset, X_test, y_test)
        bundle_dir = Path(args.out) / "report"
        written = save_visual_bundle(
            figures,
            tables,
            metrics=report,
            out_dir=bundle_dir,
            title=f"pharmaml ml train — {result.name} ({dataset.task})",
            subtitle=str(args.data),
            pdf_report=args.pdf_report,
        )
        print(f"plots:    {bundle_dir / 'report.html'} (+{len(written) - 1} files)")
        if args.pdf_report:
            print(f"pdf:      {bundle_dir / 'report.pdf'}")
    if record_path is not None:
        from pharmaml.exceptions import DataValidationError
        from pharmaml.ml.training_provenance import make_training_record, write_new_record

        record = make_training_record(
            dataset=dataset, dataset_fingerprint=after, model_path=model_path, result=result, report=report,
            requested_model=args.model, requested_task=args.task, keep_categorical=args.keep_categorical,
            test_size=args.test_size, cv=args.cv, tune_requested=not args.no_tune,
            stratified=actual_stratification[0], X_train=X_train, X_test=X_test,
        )
        try:
            final_input = fingerprint_file(args.data)
            record["source_status_after_run"] = "match" if final_input == after else "changed"
        except DataValidationError:
            record["source_status_after_run"] = "unavailable"
        if record["source_status_after_run"] != "match":
            print("warning: training source changed or became unavailable after parsing; inspect run record",
                  file=sys.stderr)
        write_new_record(record_path, record)
        print(f"run record: {record_path}")
    return 0


def _cmd_ml_compare(args: argparse.Namespace) -> int:
    from pharmaml.ml.models import list_models
    from pharmaml.ml.training import compare_models

    dataset = _load_cli_dataset(args)
    if args.significance:
        return _compare_with_significance(args, dataset)

    leaderboard = compare_models(
        dataset.X, dataset.y, dataset.task, models=args.models, cv=args.cv
    )
    print(leaderboard.to_string(index=False))

    if args.out:
        from pharmaml.utils.io import write_table

        path = write_table(leaderboard, args.out)
        print(f"\nleaderboard -> {path}")

    if args.plot or args.pdf_report:
        from pharmaml.viz import ml_plots, save_visual_bundle

        figure = ml_plots.plot_model_comparison(leaderboard)
        written = save_visual_bundle(
            figures={"model_comparison": figure},
            tables={"leaderboard": leaderboard},
            out_dir=args.out_dir,
            title="pharmaml ml compare",
            subtitle=str(args.data),
            pdf_report=args.pdf_report,
        )
        print(f"plot:     {Path(args.out_dir) / 'report.html'} (+{len(written) - 1} files)")
        if args.pdf_report:
            print(f"pdf:      {Path(args.out_dir) / 'report.pdf'}")

    if not args.models:
        unavailable = [e["name"] for e in list_models(only_available=False) if not e["available"]]
        if unavailable:
            print(f"\n(skipped, optional deps missing: {', '.join(unavailable)})")
    return 0



#: Hypermodel registry for `ml tune`: (estimator token, task) -> builder.
def _tune_hypermodels() -> dict[tuple[str, str], Any]:
    """Lazily import the tuner hypermodels (keeps CLI import path lean).

    (100x-169) the five bespoke builders (ann / dnn / hsvr) plus a
    generated hypermodel for EVERY grid-bearing registry family --
    the "hyperparameter optimization is only available for limited
    models" report closed: the searchable space of a generated family
    IS its own ``MODEL_REGISTRY`` ``param_grid``.
    """
    from pharmaml.ml.tuner import (
        build_ann_classifier,
        build_ann_regressor,
        build_deep_classifier,
        build_deep_regressor,
        build_hsvr,
        registry_hypermodels,
    )

    merged: dict[tuple[str, str], Any] = {
        ("ann", "regression"): build_ann_regressor,
        ("ann", "classification"): build_ann_classifier,
        ("dnn", "regression"): build_deep_regressor,
        ("dnn", "classification"): build_deep_classifier,
        ("hsvr", "regression"): build_hsvr,
    }
    merged.update(registry_hypermodels())
    return merged


#: The resource slot each Hyperband-able family halves over --
#: ``max_iter`` for the sklearn ann, ``epochs`` for the torch dnn;
#: every other family declares none, so hyperband refuses up front.
_TUNE_RESOURCES: dict[str, str] = {"ann": "max_iter", "dnn": "epochs"}




def _compare_with_significance(args: argparse.Namespace, dataset) -> int:
    """The ``--significance`` branch of `ml compare`.

    Runs the richer §19 CV panel (:func:`compare_models_cv`, which keeps
    the per-fold scores), prints its leaderboard, then the paired verdict
    of every challenger against the leader — corrected across the
    challenger family so a model that looks ahead alone can be demoted.
    """
    from pharmaml.ml.comparison import model_comparison_test
    from pharmaml.ml.cv_results import compare_models_cv

    results, board = compare_models_cv(
        dataset.X, dataset.y, dataset.task, args.models, n_folds=args.cv
    )
    print(board.to_string(index=False))

    comparison = model_comparison_test(
        results,
        alpha=args.alpha,
        correction=args.correction,
        test=args.significance_test,
    )
    print()
    print(f"leader:   {comparison.leader}  ({comparison.label} {comparison.leader_mean:.4f})")
    print(
        f"{'model':<22} {'mean':>10}  {'diff':>9}  {'verdict':<8} q"
        f"   ({comparison.correction}, α {comparison.alpha:g})"
    )
    for row in comparison.rows:
        print(row.line())
    for note in comparison.notes:
        print(f"note: {note}")
    print(f"\n{comparison.summary()}")

    power_line: str | None = None
    if args.power:
        if comparison.test == "wilcoxon":
            print(
                "\nnote: the power figures assume the paired t-test; the "
                "signed-rank panel is a different curve — run 'paired_t' for a "
                "power reading"
            )
        else:
            report = comparison.power(target_power=args.target_power)
            power_line = report.line()
            print(f"\npower: {power_line}")
            if report.observed_effect is not None and not report.sufficient:
                print(
                    "       the observed effect is below the panel's detection "
                    "floor — an 'on par' verdict here is underpowered, not "
                    "evidence of equivalence"
                )

    if args.out:
        from pharmaml.utils.io import write_table

        path = write_table(board, args.out)
        print(f"\nleaderboard -> {path}")
        verdict_path = write_table(
            comparison.to_frame(), Path(args.out).with_name("verdicts.csv")
        )
        print(f"verdicts    -> {verdict_path}")

    if args.plot or args.pdf_report:
        from pharmaml.viz import ml_plots, save_visual_bundle

        figure = ml_plots.plot_model_comparison(board)
        subtitle = str(args.data)
        if power_line:
            subtitle = f"{subtitle} · {power_line}"
        written = save_visual_bundle(
            figures={"model_comparison": figure},
            tables={"leaderboard": board, "verdicts": comparison.to_frame()},
            out_dir=args.out_dir,
            title="pharmaml ml compare --significance",
            subtitle=subtitle,
            pdf_report=args.pdf_report,
        )
        print(f"plot:     {Path(args.out_dir) / 'report.html'} (+{len(written) - 1} files)")
        if args.pdf_report:
            print(f"pdf:      {Path(args.out_dir) / 'report.pdf'}")
    return 0


def _cmd_ml_check(args: argparse.Namespace) -> int:
    """`ml check` — the round-trip audit before inference.

    Prints the bundle's provenance block, then the feature-contract
    verdict; exit 1 when the audit fails (CI-friendly: run it between
    a regenerated CSV and a predict step).  ``--target`` drops the
    training-label column first, so re-checking the original training
    CSV works out of the box.
    """
    from pharmaml.ml.persistence import load_model, validate_bundle_input
    from pharmaml.utils.io import read_table

    _, metadata = load_model(args.model)
    print(f"model:    {metadata.get('name', '<unknown>')} ({metadata.get('task', '?')})")
    print(
        f"trained:  {metadata.get('trained_at', '?')} "
        f"(pharmaml {metadata.get('pharmaml_version', '?')}, "
        f"sklearn {metadata.get('sklearn_version', '?')})"
    )
    features = metadata.get("features")
    if isinstance(features, list) and features:
        preview = ", ".join(str(name) for name in features[:6])
        more = "…" if len(features) > 6 else ""
        print(f"features: {len(features)} ({preview}{more})")
    else:
        print("features: (not recorded — the count contract is checked)")

    frame = read_table(args.data)
    if args.target is not None:
        if args.target not in frame.columns:
            print(
                f"error: --target {args.target!r} is not a column of "
                f"{args.data} (columns: {', '.join(map(str, frame.columns))})",
                file=sys.stderr,
            )
            return 1
        frame = frame.drop(columns=[args.target])
    report = validate_bundle_input(args.model, frame)
    print(f"data:     {Path(args.data).name} — {len(frame):,} rows x "
          f"{len(frame.columns)} columns")
    print(report)
    if not report.ok and report.extra and args.target is None:
        print(
            "hint: if one of the extra columns is the training target, "
            "pass --target <column> to drop it before the audit"
        )
    return 0 if report.ok else 1


def _bundle_feature_frame(frame, metadata):
    """Select and order a raw table's columns to a bundle's feature contract.

    Returns ``(X, missing, extra)``.  ``missing`` columns are the bundle
    features absent from ``frame`` (a hard error at the call site);
    ``extra`` columns are present in ``frame`` but not used by the model
    (kept in the output table, never fed to the estimator).
    """
    features = metadata.get("features")
    if isinstance(features, list) and features:
        missing = [name for name in features if name not in frame.columns]
        extra = [name for name in frame.columns if name not in features]
        if missing:
            return frame, missing, extra
        return frame.loc[:, features], missing, extra
    # No recorded names (older bundle): fall back to the numeric columns,
    # which is exactly what training consumed by default.
    numeric = frame.select_dtypes(include="number")
    if numeric.shape[1] == 0:
        return numeric, list(frame.columns), []
    return numeric, [], [name for name in frame.columns if name not in numeric.columns]


def _cmd_ml_predict(args: argparse.Namespace) -> int:
    """`ml predict` — apply a saved bundle to a fresh table.

    Loads the bundle, aligns the input columns to the bundle's recorded
    feature contract (the same contract `ml check` audits), predicts, and
    writes a scored table.  ``--target`` optionally scores against a true
    label; ``--conformal`` adds split-conformal prediction intervals
    (regression) or prediction sets (classification) with a reported
    empirical coverage.
    """
    import numpy as np

    from pharmaml.ml.persistence import load_model
    from pharmaml.utils.io import read_table

    model, metadata = load_model(args.model)
    task = metadata.get("task", "regression")
    name = metadata.get("name", Path(args.model).stem)
    frame = read_table(args.data)

    truth = None
    # With --calibration-data, --target names the *calibration* label, so it
    # must not be validated against (or dropped from) the query table here.
    if args.calibration_data is None and args.target is not None:
        if args.target not in frame.columns:
            print(
                f"error: --target {args.target!r} is not a column of "
                f"{args.data} (columns: {', '.join(map(str, frame.columns))})",
                file=sys.stderr,
            )
            return 1
        truth = frame[args.target].to_numpy()
        frame = frame.drop(columns=[args.target])
    else:
        recorded = metadata.get("target")
        if recorded and recorded in frame.columns:
            frame = frame.drop(columns=[recorded])
            print(f"dropped:  {recorded!r} (the recorded training target)")

    X, missing, extra = _bundle_feature_frame(frame, metadata)
    if missing:
        print(
            f"error: the bundle needs feature(s) missing from {args.data}: "
            f"{', '.join(map(str, missing))}",
            file=sys.stderr,
        )
        return 1

    if args.conformal is None:
        predictions = np.asarray(model.predict(X))
        out = frame.copy()
        out["prediction"] = predictions
        if truth is not None:
            print(f"model:    {name} ({task})")
            print(f"rows:     {len(frame):,} x {X.shape[1]} feature(s)")
            _print_predict_metrics(model, X, truth, task)
        else:
            print(f"model:    {name} ({task})")
            print(f"rows:     {len(frame):,} x {X.shape[1]} feature(s)")
        _annotate_domain(out, metadata, frame, args)
        _annotate_drift(metadata, frame, args)
        if extra:
            print(f"note:     {len(extra)} input column(s) not used by the "
                  f"model kept in the output: {', '.join(map(str, extra[:6]))}"
                  + ("…" if len(extra) > 6 else ""))
        return _write_predictions(out, args)

    return _predict_with_conformal(args, model, metadata, X, frame, truth)


def _annotate_domain(out, metadata, frame, args) -> None:
    """Add an ``in_domain`` column and print the applicability verdict.

    Uses the box the bundle recorded at train time (``feature_ranges``);
    bundles saved before that get no column and no message, so the
    absence of a check is never mistaken for a passing one.
    """
    if getattr(args, "no_domain_check", False):
        return
    from pharmaml.ml.applicability import check_domain_box

    report = check_domain_box(metadata, frame)
    if report is None:
        return
    out["in_domain"] = report.in_domain
    print(f"{report}")


def _annotate_drift(metadata, frame, args) -> None:
    """Print the batch-level distribution-shift verdict, if recorded.

    The per-row ``in_domain`` flag says whether each compound sits inside
    the training box; this says whether the *batch* as a whole has drifted
    from the training distribution.  Uses the quantile sketch the bundle
    recorded (``feature_distributions``); bundles saved before that get no
    message, so the absence of a check is never mistaken for a passing one.
    """
    if getattr(args, "no_drift_check", False):
        return
    from pharmaml.ml.drift import drift_from_metadata

    report = drift_from_metadata(metadata, frame)
    if report is None:
        return
    print(f"{report}")


def _print_predict_metrics(model, X, truth, task) -> None:
    """Print held-out metrics for `--target` rows (best-effort)."""
    from pharmaml.ml.evaluation import evaluate_model

    try:
        report = evaluate_model(model, X, truth, task)
    except Exception as exc:  # noqa: BLE001 — scoring is a bonus, not the task
        print(f"metrics:  (skipped — {exc})")
        return
    print(f"metrics:  {report}")


def _write_predictions(out, args) -> int:
    """Write the scored table and return the exit code."""
    from pharmaml.utils.io import write_table

    if args.out:
        path = args.out
    else:
        source = Path(args.data)
        path = str(source.with_name(f"{source.stem}_predictions.csv"))
    written = write_table(out, path)
    print(f"scored:   {written}")
    return 0


def _predict_with_conformal(args, model, metadata, X, frame, truth) -> int:
    """The ``--conformal ALPHA`` branch of `ml predict`."""
    import numpy as np

    from pharmaml.ml.conformal import ConformalClassifier, ConformalRegressor
    from pharmaml.utils.io import read_table

    alpha = float(args.conformal)
    task = metadata.get("task", "regression")
    held_out_truth = None

    if args.calibration_data:
        cal_frame = read_table(args.calibration_data)
        # With --calibration-data, --target names the label in the
        # *calibration* table (per the parser help) — not the query's.
        if args.target is None or args.target not in cal_frame.columns:
            print(
                "error: --calibration-data needs the true label; pass "
                "--target naming the calibration table's label column",
                file=sys.stderr,
            )
            return 1
        y_cal = cal_frame[args.target].to_numpy()
        X_cal, cal_missing, _ = _bundle_feature_frame(cal_frame, metadata)
        if cal_missing:
            print(
                f"error: the bundle needs feature(s) missing from "
                f"{args.calibration_data}: {', '.join(map(str, cal_missing))}",
                file=sys.stderr,
            )
            return 1
        X_query = X
        if truth is not None:
            held_out_truth = truth
    else:
        if truth is None:
            print(
                "error: --conformal needs labelled rows to calibrate on — "
                "pass --target (naming the label column of --data) or "
                "--calibration-data",
                file=sys.stderr,
            )
            return 1
        from sklearn.model_selection import train_test_split

        # Keep the DataFrame (not a bare array) so a fitted sklearn
        # Pipeline sees the same feature names it was trained with.
        X_cal, X_query, y_cal, y_query = train_test_split(
            X, np.asarray(truth), test_size=0.5, random_state=args.seed
        )
        held_out_truth = y_query

    if task == "classification":
        classifier = ConformalClassifier(model, alpha=alpha).calibrate(X_cal, y_cal)
        sets = classifier.predict_set(X_query)
        coverage = (
            classifier.coverage(X_query, held_out_truth)
            if held_out_truth is not None else None
        )
        out = frame.loc[X_query.index].copy()
        out["prediction_set"] = [", ".join(map(str, s)) for s in sets]
        out["set_size"] = [len(s) for s in sets]
        width_note = f"mean set size: {np.mean([len(s) for s in sets]):.2f}"
    else:
        regressor = ConformalRegressor(model, alpha=alpha).calibrate(X_cal, y_cal)
        lower, upper = regressor.predict_interval(X_query)
        out = frame.loc[X_query.index].copy()
        out["prediction"] = np.asarray(model.predict(X_query))
        out["lower"] = lower
        out["upper"] = upper
        coverage = (
            regressor.coverage(X_query, held_out_truth)
            if held_out_truth is not None else None
        )
        width_note = f"mean width:   {np.mean(upper - lower):.3f}"

    print(f"model:    {metadata.get('name', Path(args.model).stem)} ({task})")
    print(f"conformal: alpha={alpha:.2f} (target coverage {1 - alpha:.0%})")
    if coverage is not None:
        print(f"coverage: {coverage:.1%} empirical on the held-out half")
    elif args.calibration_data:
        print("coverage: (not measured — the query is scored against a "
              "separate calibration table)")
    else:
        print("coverage: (not measured — the query carries no true labels; "
              "pass --target to check the guarantee)")
    print(f"{width_note}")
    if args.calibration_data:
        print(f"scored:   {len(out):,} row(s) "
              f"(calibrated on {len(y_cal):,} separate row(s))")
    else:
        print(f"scored:   {len(out):,} row(s) "
              f"(the calibration half is withheld from the output)")
    _annotate_domain(out, metadata, frame.loc[X_query.index], args)
    _annotate_drift(metadata, frame.loc[X_query.index], args)
    return _write_predictions(out, args)


def _cmd_ml_card(args: argparse.Namespace) -> int:
    """`ml card` — render a model card for a saved bundle."""
    from pharmaml.ml.model_card import write_model_card
    from pharmaml.ml.persistence import load_model
    from pharmaml.utils.io import read_table

    training_frame = None
    if args.train_data:
        frame = read_table(args.train_data)
        # Never let the label column leak into the applicability-domain box:
        # prefer the explicit --target, else the target the bundle recorded.
        _, metadata = load_model(args.model)
        target = args.target or metadata.get("target")
        if target is not None and target in frame.columns:
            frame = frame.drop(columns=[target])
        training_frame = frame

    out = args.out or str(Path(args.model).with_name(f"{Path(args.model).stem}_card.md"))
    written = write_model_card(args.model, out, training_frame=training_frame)
    print(f"card:     {written}")
    if training_frame is None:
        print("note:     pass --train-data to record the applicability-domain box")
    return 0


def _cmd_ml_drift(args: argparse.Namespace) -> int:
    """`ml drift` — distribution shift between a new batch and the training data.

    Two reference sources, mirroring `ml check`/`ml predict`:
    ``--model`` uses the per-feature quantile sketch the bundle recorded
    at train time (PSI only, no training frame needed); ``--train-data``
    compares against the raw training table (PSI + two-sample KS).  The
    exit code is 0 whether or not a shift is found — drift is a warning
    to act on, not an audit failure.
    """
    from pharmaml.ml.drift import detect_drift, drift_from_metadata
    from pharmaml.ml.persistence import load_model
    from pharmaml.utils.io import read_table

    if bool(args.model) == bool(args.train_data):
        print(
            "error: pass exactly one of --model (the bundle's sketch) or "
            "--train-data (the raw training table)",
            file=sys.stderr,
        )
        return 1

    frame = read_table(args.data)

    def _drop_target(table, target):
        if target is not None and target in table.columns:
            return table.drop(columns=[target]), str(target)
        return table, None

    if args.model:
        _, metadata = load_model(args.model)
        target = args.target or metadata.get("target")
        frame, dropped = _drop_target(frame, target)
        report = drift_from_metadata(
            metadata, frame, warn_psi=args.warn_psi, shift_psi=args.shift_psi
        )
        if report is None:
            print(
                "error: this bundle carries no distribution sketch — retrain "
                "with this version, or pass --train-data for the raw comparison",
                file=sys.stderr,
            )
            return 1
        label = f"bundle {metadata.get('name', Path(args.model).stem)}"
    else:
        reference = read_table(args.train_data)
        reference, _ = _drop_target(reference, args.target)
        frame, dropped = _drop_target(frame, args.target)
        report = detect_drift(
            reference,
            frame,
            bins=args.bins,
            warn_psi=args.warn_psi,
            shift_psi=args.shift_psi,
        )
        label = Path(args.train_data).name

    print(f"model:    {label}")
    print(f"batch:    {Path(args.data).name} — {report.n_rows:,} row(s)")
    if dropped:
        print(f"dropped:  '{dropped}' before comparing")
    print(f"{report}")

    if args.out:
        from pharmaml.utils.io import write_table

        written = write_table(report.to_frame(), args.out)
        print(f"table:    {written}")
    return 0


def _cmd_ml_calibrate(args: argparse.Namespace) -> int:
    """`ml calibrate` — measure (and optionally fix) probability calibration.

    Two flows, mirroring `ml drift`:

    * ``--model`` loads a bundle, predicts on ``--data`` (labelled) and
      reports Brier / ECE / MCE; with ``--out-model`` it fits a
      recalibration map (isotonic or Platt) on ``--calibration-data``
      (or ``--data``) and saves the wrapped estimator.
    * no ``--model`` trains a fresh classifier on ``--data`` and measures
      its calibration on a held-out split — the quick "is this family
      honest out of the box?" probe.

    Binary targets only (calibration is defined per class); the exit code
    is 0 whether or not the model is miscalibrated — this is a diagnostic.
    """
    from pharmaml.ml.calibration import calibration_report, recalibrate
    from pharmaml.ml.persistence import load_model, save_model
    from pharmaml.utils.io import read_table

    plot_model = plot_X = plot_y = None
    if args.model:
        model, metadata = load_model(args.model)
        if str(metadata.get("task", "regression")) != "classification":
            print(
                "error: calibration needs a classification bundle (this one "
                f"is {metadata.get('task', 'regression')!r})",
                file=sys.stderr,
            )
            return 1
        frame = read_table(args.data)
        target = args.target or metadata.get("target")
        if target is None or target not in frame.columns:
            print(
                f"error: the label column {target!r} is not in {args.data} — "
                "pass --target",
                file=sys.stderr,
            )
            return 1
        y_true = frame[target].to_numpy()
        features = metadata.get("features")
        X = frame[list(features)] if features else frame.select_dtypes("number")
        report = calibration_report(model, X, y_true, n_bins=args.bins)
        plot_model, plot_X, plot_y = model, X, y_true
        print(f"model:    {metadata.get('name', Path(args.model).stem)} (classification)")
        print(f"data:     {Path(args.data).name} — {report.n_samples:,} row(s)")
        print(f"{report}")

        if args.out_model:
            cal_frame = read_table(args.calibration_data) if args.calibration_data else frame
            if target not in cal_frame.columns:
                print(
                    f"error: --calibration-data has no {target!r} column",
                    file=sys.stderr,
                )
                return 1
            y_cal = cal_frame[target].to_numpy()
            X_cal = cal_frame[list(features)] if features else cal_frame.select_dtypes("number")
            calibrated = recalibrate(model, X_cal, y_cal, method=args.method)
            out = Path(args.out_model)
            save_model(
                calibrated, out,
                name=str(metadata.get("name", Path(args.model).stem)) + "_calibrated",
                task="classification",
                features=features,
                target=target,
                metrics={"calibration_method": args.method},
            )
            print(f"recal:    {args.method} map fitted on "
                  f"{len(cal_frame):,} row(s) -> {out}")
    else:
        if not args.data:
            print("error: pass --model or --data", file=sys.stderr)
            return 1
        dataset = _load_cli_dataset(args)
        if dataset.task != "classification":
            print(
                "error: calibration needs a classification target; "
                f"{args.data} was read as {dataset.task!r}",
                file=sys.stderr,
            )
            return 1
        from pharmaml.ml.preprocessing import make_train_test_split

        x_train, x_test, y_train, y_test = make_train_test_split(dataset.X, dataset.y)
        from pharmaml.ml.training import train_model

        trained = train_model(args.estimator, "classification", x_train, y_train,
                              tune=False, cv=2)
        report = calibration_report(trained.model, x_test, y_test, n_bins=args.bins)
        plot_model, plot_X, plot_y = trained.model, x_test, y_test
        print(f"model:    {args.estimator} (trained on the 80% split)")
        print(f"data:     {Path(args.data).name} — {report.n_samples:,} held-out row(s)")
        print(f"{report}")
        if args.out_model:
            # Fit the map on the held-out split: those are the only rows the
            # base model did not train on, so its predictions there are the
            # out-of-sample ones a calibration map must learn from.
            calibrated = recalibrate(
                trained.model, x_test, y_test, method=args.method
            )
            out = Path(args.out_model)
            save_model(
                calibrated, out,
                name=f"{args.estimator}_calibrated",
                task="classification",
                features=dataset.feature_names,
                target=dataset.target,
                metrics={"calibration_method": args.method},
            )
            print(f"recal:    {args.method} map fitted on the held-out split -> {out}")

    if args.out:
        from pharmaml.utils.io import write_table

        written = write_table(report.to_frame(), args.out)
        print(f"table:    {written}")
    if args.plot and plot_model is not None:
        from pharmaml.viz import close_figure, save_figure
        from pharmaml.viz.ml_plots import plot_calibration_curve

        figure = plot_calibration_curve(plot_model, plot_X, plot_y, n_bins=args.bins)
        written = save_figure(figure, args.plot)
        close_figure(figure)
        print(f"figure:   {written} (reliability diagram)")
    return 0


def _cmd_ml_decide(args: argparse.Namespace) -> int:
    """`ml decide` — decision-curve analysis: is acting on the model worth it?

    Loads a classification bundle, scores a labelled table, and reports the
    net benefit (net true positives per subject) against the "treat all"
    and "treat none" defaults — at one threshold, an explicit grid, or a
    swept grid.  The honest verdict is which threshold range, if any, the
    model's curve clears "treat all"; when it never does, the command says
    so.  `--criterion` adds the held-out optimal threshold.  Exit code 0
    either way — this is a diagnostic, like `ml drift` / `ml calibrate`.
    """
    import numpy as np

    from pharmaml.ml.decision import decision_curve_from_scores, optimal_threshold
    from pharmaml.ml.persistence import load_model
    from pharmaml.utils.io import read_table

    model, metadata = load_model(args.model)
    if str(metadata.get("task", "regression")) != "classification":
        print(
            "error: decision-curve analysis needs a classification bundle "
            f"(this one is {metadata.get('task', 'regression')!r})",
            file=sys.stderr,
        )
        return 1
    if not hasattr(model, "predict_proba"):
        print(
            "error: the bundle's model exposes no predict_proba — decision "
            "analysis needs calibrated probabilities",
            file=sys.stderr,
        )
        return 1

    frame = read_table(args.data)
    target = args.target or metadata.get("target")
    if target is None or target not in frame.columns:
        print(
            f"error: the label column {target!r} is not in {args.data} — "
            "pass --target",
            file=sys.stderr,
        )
        return 1
    features = metadata.get("features")
    X = frame[list(features)] if features else frame.select_dtypes("number")
    proba = np.asarray(model.predict_proba(X))
    if proba.ndim != 2 or proba.shape[1] != 2:
        print(
            "error: decision-curve analysis is binary; the model's "
            "predict_proba is not 2-column",
            file=sys.stderr,
        )
        return 1
    y_true = frame[target].to_numpy()
    classes = getattr(model, "classes_", None)
    positive = classes[1] if classes is not None and len(classes) == 2 else np.unique(y_true)[-1]
    y_binary = (y_true == positive).astype(int)
    scores = proba[:, 1]

    if args.threshold is not None and args.thresholds is not None:
        print("error: pass --threshold or --thresholds, not both", file=sys.stderr)
        return 1
    if args.threshold is not None:
        thresholds = [args.threshold]
    elif args.thresholds is not None:
        try:
            thresholds = [float(t) for t in args.thresholds.split(",") if t.strip()]
        except ValueError:
            print("error: --thresholds must be comma-separated numbers", file=sys.stderr)
            return 1
    else:
        thresholds = None

    curve = decision_curve_from_scores(
        y_binary, scores, thresholds=thresholds, n_points=args.points,
        cost_ratio=args.cost_ratio,
    )
    label = metadata.get("name", Path(args.model).stem)
    print(f"model:    {label} (classification)")
    print(f"data:     {Path(args.data).name} — {curve.n_samples:,} row(s)")
    print(f"{curve}")

    if args.criterion is not None:
        chosen = optimal_threshold(
            y_binary, scores, criterion=args.criterion, cost_ratio=args.cost_ratio
        )
        nb = curve.net_benefit_at(chosen)
        print(
            f"optimal:  {args.criterion} threshold {chosen:.4f} "
            f"(net benefit {nb:+.4f} at the nearest grid point)"
        )

    if args.out:
        from pharmaml.utils.io import write_table

        written = write_table(curve.to_frame(), args.out)
        print(f"table:    {written}")
    if args.plot:
        from pharmaml.viz import close_figure, save_figure
        from pharmaml.viz.ml_plots import plot_decision_curve

        figure = plot_decision_curve(
            curve, title=f"Decision curve — {label}"
        )
        written = save_figure(figure, args.plot)
        close_figure(figure)
        print(f"figure:   {written} (decision curve)")
    return 0




def _report_uniform(report, metric: str) -> None:
    """Note when every subgroup scored alike — so "no worst group" is explicit."""
    values = [
        group.metrics[metric]
        for group in report.subgroups
        if group.sufficient and group.metrics.get(metric) is not None
    ]
    if len(values) >= 2 and max(values) - min(values) < 1e-12:
        print(f"note:     every sufficient subgroup scored {metric}={values[0]:.4f} "
              "(no dispersion to report)")


#: Hypermodel registry for `ml tune`: (estimator token, task) -> builder.
def _cmd_ml_subgroup(args: argparse.Namespace) -> int:
    """`ml subgroup` — stratified performance: which groups does the model fail?

    Loads a bundle, scores a labelled table, and reports the headline
    metrics per value of ``--by`` alongside the overall row, so a subgroup
    that underperforms the aggregate is read off, not assumed.  ``--metric``
    names the worst group for that metric; ``--plot`` draws the bar chart.
    Exit code 0 either way — this is a diagnostic, like `ml drift`.
    """
    from pharmaml.exceptions import DataValidationError
    from pharmaml.ml.persistence import load_model
    from pharmaml.ml.subgroups import subgroup_report
    from pharmaml.utils.io import read_table

    model, metadata = load_model(args.model)
    task = str(metadata.get("task", "regression"))
    frame = read_table(args.data)
    target = args.target or metadata.get("target")
    if target is None or target not in frame.columns:
        print(
            f"error: the label column {target!r} is not in {args.data} — "
            "pass --target",
            file=sys.stderr,
        )
        return 1
    if args.by not in frame.columns:
        print(
            f"error: --by {args.by!r} is not a column of {args.data} "
            f"(columns: {', '.join(map(str, frame.columns))})",
            file=sys.stderr,
        )
        return 1

    features = metadata.get("features")
    X = frame[list(features)] if features else frame.select_dtypes("number")
    y_true = frame[target].to_numpy()
    groups = frame[args.by].to_numpy()
    report = subgroup_report(
        model, X, y_true, groups,
        task=task, min_group_size=args.min_group_size, column=args.by,
    )
    label = metadata.get("name", Path(args.model).stem)
    print(f"model:    {label} ({task})")
    print(f"data:     {Path(args.data).name} — {report.overall.get('n_samples'):,} row(s)")
    print(f"{report}")

    default_metric = "accuracy" if task == "classification" else "rmse"
    metric = args.metric or default_metric
    try:
        worst = report.worst_group(metric)
    except DataValidationError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    flag = "" if worst.sufficient else " (insufficient — n below --min-group-size)"
    print(f"worst:    {worst.value!r} by {metric} "
          f"({worst.metrics.get(metric):.4f}, n={worst.n}){flag}")
    _report_uniform(report, metric)

    if args.scan:
        from pharmaml.ml.subgroups import subgroup_gap_scan

        gaps = subgroup_gap_scan(
            model, X, y_true, groups,
            task=task, metric=metric, min_group_size=args.min_group_size,
            correction=args.correction,
        )
        print(f"scan:     {len(gaps)} subgroup(s), {args.correction} correction")
        for gap in gaps:
            print(f"  {gap}")
        survivors = [gap.value for gap in gaps if gap.fdr_significant]
        if survivors:
            print(f"  significant after correction: {', '.join(survivors)}")
        else:
            print("  no subgroup is significant after correction")

    if args.out:
        from pharmaml.utils.io import write_table

        written = write_table(report.to_frame(), args.out)
        print(f"table:    {written}")
    if args.plot:
        from pharmaml.viz import close_figure, save_figure
        from pharmaml.viz.ml_plots import plot_subgroup_performance

        figure = plot_subgroup_performance(report, metric, title=f"{metric} by {args.by}")
        written = save_figure(figure, args.plot)
        close_figure(figure)
        print(f"figure:   {written} (subgroup bars)")
    return 0
def _cmd_ml_tune(args: argparse.Namespace) -> int:
    """`ml tune` — keras-tuner-style hyperparameter search.

    Runs RandomSearch or Hyperband over the chosen hypermodel family,
    prints the leaderboard + best configuration, optionally writes the
    trials table (``--out``) and saves the refit best estimator as a
    ``ml check``-compatible bundle (``--save-best``).
    """
    from pharmaml.ml.persistence import save_model
    from pharmaml.ml.tuner import Hyperband, RandomSearch, TPESearch

    dataset = _load_cli_dataset(args)
    tune_task = dataset.task
    if args.task == "auto" and tune_task == "classification":
        # The loader's class-count heuristic calls small numeric targets
        # classification; a NON-INTEGER float target with > 10 distinct
        # values is a measurement column (pIC50-style), so the tuner
        # should search the regression hypermodel and score r2. Integer-
        # coded labels keep the loader's classification verdict.
        import numpy as np

        y_arr = np.asarray(dataset.y)
        if (
            np.issubdtype(y_arr.dtype, np.floating)
            and not bool(np.equal(np.mod(y_arr, 1), 0).all())
            and np.unique(y_arr).size > 10
        ):
            tune_task = "regression"
    hypermodels = _tune_hypermodels()
    tokens = sorted({key[0] for key in hypermodels})
    if args.estimator not in tokens:
        print(
            f"error: estimator {args.estimator!r} has no hypermodel (valid: "
            f"{', '.join(tokens)})",
            file=sys.stderr,
        )
        return 1
    key = (args.estimator, tune_task)
    hypermodel = hypermodels.get(key)
    if hypermodel is None:
        # (100x-169) the honest, general wording: which task the
        # family actually supports (hsvr is regression-only; a
        # classification-only family names classification).
        other = "classification" if tune_task == "regression" else "regression"
        print(
            f"error: estimator {args.estimator!r} has no hypermodel for task "
            f"{tune_task!r} (the family supports {other!r} only)",
            file=sys.stderr,
        )
        return 1

    objective = args.objective
    if objective == "auto":
        objective = "r2" if tune_task == "regression" else "accuracy"

    if args.searcher == "random":
        tuner: Any = RandomSearch(
            hypermodel,
            objective=objective,
            max_trials=args.max_trials,
            cv=args.cv,
            task=tune_task,
            seed=args.seed,
        )
    elif args.searcher == "tpe":
        # No pruner on the CLI this round — the playground GUI owns
        # the pruner choice (Task 6 wires it into the Tune card).
        tuner = TPESearch(
            hypermodel,
            objective=objective,
            max_trials=args.max_trials,
            cv=args.cv,
            task=tune_task,
            seed=args.seed,
        )
    else:
        # (100x-169) hyperband halves a DECLARED resource budget --
        # only ann (max_iter) and dnn (epochs) carry one; every other
        # family is refused up front instead of raising from inside
        # the first bracket.
        resource = _TUNE_RESOURCES.get(args.estimator)
        if resource is None:
            print(
                f"error: estimator {args.estimator!r} has no resource slot "
                "for hyperband to halve (ann: max_iter, dnn: epochs) -- use "
                "--searcher random or tpe instead",
                file=sys.stderr,
            )
            return 1
        tuner = Hyperband(
            hypermodel,
            objective=objective,
            resource=resource,
            max_resource=args.max_resource,
            min_resource=args.min_resource,
            eta=args.eta,
            cv=args.cv,
            task=tune_task,
            seed=args.seed,
        )

    results = tuner.search(dataset.X, dataset.y)
    print(f"dataset:  {dataset.n_samples} rows x {dataset.n_features} features")
    print(f"task:     {tune_task}")
    print(f"tuner:    {args.searcher} over {args.estimator} (objective={objective})")
    print(results.summary())
    print(f"best:     {results.best_params}")
    print(
        f"score:    {results.best_score:.4f} "
        f"+/- {results.best_trial.score_std:.4f} (cv={args.cv})"
    )

    if args.out:
        from pharmaml.utils.io import write_table

        path = write_table(results.trials_frame(), args.out)
        print(f"trials:   {path}")
    if args.save_best:
        model_path = Path(args.save_best)
        save_model(
            results.best_estimator,
            model_path,
            name=f"{args.estimator}_tuned",
            task=tune_task,
            features=dataset.feature_names,
            best_params=results.best_params,
            metrics={
                "objective": objective,
                "cv_score": results.best_score,
                "cv_std": results.best_trial.score_std,
            },
        )
        print(f"saved:    {model_path}")
    return 0


def _cmd_ml_ad(args: argparse.Namespace) -> int:
    """Applicability-domain analysis — the uploaded workflow as a command."""
    from pharmaml.ml import applicability_domain
    from pharmaml.ml.persistence import load_model
    from pharmaml.ml.preprocessing import make_train_test_split
    from pharmaml.ml.training import train_model

    if bool(args.data) == bool(args.bundle):
        print(
            "error: give exactly one of --data (train + judge the held-out "
            "rows) or --bundle (with --train-data/--test-data, the "
            "upload's flow)",
            file=sys.stderr,
        )
        return 1

    names: list[str] | None = None
    if args.bundle:
        if not args.train_data or not args.test_data:
            print(
                "error: --bundle needs --train-data and --test-data (the "
                "original tables the bundle was trained on / the query "
                "compounds)",
                file=sys.stderr,
            )
            return 1
        model, metadata = load_model(Path(args.bundle))
        from pharmaml.data import load_dataset
        from pharmaml.utils.io import read_table

        train = load_dataset(args.train_data, target=args.target)
        target = train.target
        features = metadata.get("features")
        if features:
            missing = [c for c in features if c not in train.X.columns]
            if missing:
                print(
                    f"error: --train-data is missing feature column(s): "
                    f"{', '.join(missing)}",
                    file=sys.stderr,
                )
                return 1
            x_train = train.X[list(features)]
        else:
            x_train = train.X
        y_train = train.y
        # the query table needs no target — only the feature columns
        test_frame = read_table(args.test_data)
        if features:
            missing = [c for c in features if c not in test_frame.columns]
            if missing:
                print(
                    f"error: --test-data is missing feature column(s): "
                    f"{', '.join(missing)}",
                    file=sys.stderr,
                )
                return 1
            x_test = test_frame[list(features)]
        else:
            x_test = test_frame.select_dtypes("number")
        # the name column: the query table's SMILES (the upload's
        # test_df.iloc[:, 0]) when it carries one
        smiles = next(
            (c for c in test_frame.columns if str(c).upper() == "SMILES"), None)
        if smiles is not None:
            names = test_frame[smiles].astype(str).tolist()
        label = str(metadata.get("name", Path(args.bundle).stem))
        task = str(metadata.get("task", "regression"))
        head = [
            ("bundle", str(args.bundle)),
            ("model", label),
            ("task", task),
            ("train", f"{len(x_train)} rows x {x_train.shape[1]} features"),
            ("query", f"{len(x_test)} rows"),
        ]
    else:
        dataset = _load_cli_dataset(args)
        x_train, x_test, y_train, _y_test = make_train_test_split(dataset.X, dataset.y)
        trained = train_model(
            args.model, dataset.task, x_train, y_train, tune=False, cv=2
        )
        model = trained.model
        target = dataset.target
        task = dataset.task
        smiles = next(
            (c for c in dataset.frame.columns if str(c).upper() == "SMILES"), None)
        if smiles is not None:
            names = dataset.frame.loc[x_test.index, smiles].astype(str).tolist()
        label = f"{args.model} (trained on the 80% split)"
        head = [
            ("dataset", f"{dataset.n_samples} rows x {dataset.n_features} features"),
            ("model", label),
            ("task", task),
            ("query", f"{len(x_test)} held-out rows"),
        ]

    result = applicability_domain(
        model, x_train, y_train, x_test,
        k=args.k, percentile=args.percentile,
        n_models=args.n_models, uncertainty=not args.no_uncertainty,
    )
    for key, value in head:
        print(f"{key + ':':9} {value}")
    print(
        f"domain:   k={result.k} distance threshold "
        f"{result.distance_threshold:.4g} (p{args.percentile:g})"
    )
    inside = int(result.inside_ad.sum())
    print(f"inside:   {inside}/{result.inside_ad.size} query compounds inside the domain")
    if result.reliable is not None:
        print(
            f"ensemble: {result.n_models} bootstrap members in "
            f"{result.fit_seconds:.1f} s ({result.uncertainty_kind})"
        )
        print(
            f"sigma:    uncertainty threshold {result.uncertainty_threshold:.4g}"
        )
        print(
            f"reliable: {int(result.reliable.sum())}/{result.reliable.size} "
            "compounds (inside AD & low uncertainty)"
        )
    else:
        print("ensemble: skipped (--no-uncertainty: distance-only verdict)")

    if args.out:
        from pharmaml.viz import export_table

        table = result.to_frame(names=names)
        written = export_table(table, args.out)
        print(f"table:    {written}")
    if args.plot:
        from pharmaml.viz import plot_applicability_domain, save_figure

        figure = plot_applicability_domain(
            result,
            y_label=f"predicted {target}" if task == "regression"
            else "predicted P(positive)",
            title=f"Applicability domain — {label}",
        )
        out = Path("ad_applicability_domain.png")
        save_figure(figure, out)
        print(f"figure:   {out}")
    return 0


def _cmd_chem_pic50(args: argparse.Namespace) -> int:
    from pharmaml.chem.converters import add_pic50_column
    from pharmaml.utils.io import read_table, write_table

    frame = read_table(args.data)
    converted = add_pic50_column(frame, source_col=args.column, unit=args.unit)
    out = Path(args.out) if args.out else Path(args.data).with_name(
        Path(args.data).stem + "_pic50.csv"
    )
    written = write_table(converted, out)
    print(f"pIC50 column added -> {written} ({len(converted)} rows)")
    return 0


def _cmd_chem_descriptors(args: argparse.Namespace) -> int:
    from pharmaml.chem.descriptors import compute_descriptors
    from pharmaml.utils.io import read_table, write_table

    frame = read_table(args.data)
    if args.smiles_col not in frame.columns:
        print(f"error: column {args.smiles_col!r} not found", file=sys.stderr)
        # 26-R5: exit 1, the convention every other CLI failure follows
        return 1
    descriptors = compute_descriptors(frame[args.smiles_col], descriptor_set=args.descriptor_set)
    # ``descriptors`` is indexed by *position* in the SMILES column, so the
    # join must be positional: aligning on the caller frame's index labels
    # would silently attach the wrong row's descriptors to any frame that
    # lacks a default RangeIndex.
    merged = frame.reset_index(drop=True).join(
        descriptors.drop(columns=["SMILES"]), how="left"
    )
    merged.index = frame.index
    out = Path(args.out) if args.out else Path(args.data).with_name(
        Path(args.data).stem + "_descriptors.csv"
    )
    # write_table falls back to CSV for unknown extensions (.dat -> .csv):
    # report the path it RETURNS, not the one the user typed (26-R5).
    written = write_table(merged, out)
    print(f"descriptors -> {written} ({descriptors.shape[1] - 1} columns)")
    return 0


def _cmd_chem_rism(args: argparse.Namespace) -> int:
    """`chem rism` — the 3D-RISM-KH solvation descriptor table.

    Mirrors ``chem descriptors`` (positional join, default
    ``<stem>_rism.csv`` output) so the two descriptor pipelines behave
    identically from the shell.
    """
    from pharmaml.chem.rism import RISM_DESCRIPTORS, compute_rism_descriptors
    from pharmaml.utils.io import read_table, write_table

    frame = read_table(args.data)
    if args.smiles_col not in frame.columns:
        print(f"error: column {args.smiles_col!r} not found", file=sys.stderr)
        return 1
    descriptors = compute_rism_descriptors(
        frame[args.smiles_col],
        solvent=args.solvent,
        temperature=args.temperature,
    )
    merged = frame.reset_index(drop=True).join(
        descriptors.drop(columns=["SMILES"]), how="left"
    )
    merged.index = frame.index
    out = Path(args.out) if args.out else Path(args.data).with_name(
        Path(args.data).stem + "_rism.csv"
    )
    written = write_table(merged, out)
    print(
        f"3D-RISM-KH descriptors -> {written} "
        f"({len(RISM_DESCRIPTORS)} columns, solvent={args.solvent}, "
        f"T={args.temperature:g} K, {len(descriptors)} valid molecules)"
    )
    return 0


def _cmd_chem_compare(args: argparse.Namespace) -> int:
    import pandas as pd

    from pharmaml.chem.tables import compare_tables

    comparison = compare_tables(
        args.data_a,
        args.data_b,
        column=args.column,
        strip_extension=not args.keep_extension,
        lowercase=not args.keep_case,
    )
    counts = comparison.summary()
    print(f"column {comparison.column!r}: " + ", ".join(
        f"{key}={counts[key]}" for key in ("common", "only_in_a", "only_in_b")
    ))
    for label, values in (
        ("common", comparison.common),
        ("only in A", comparison.only_in_a),
        ("only in B", comparison.only_in_b),
    ):
        if values:
            print(f"\n{label} ({len(values)}):")
            print("  " + "\n  ".join(values))
    if args.out:
        frame = pd.DataFrame(
            {
                f"only in {Path(args.data_a).name}": pd.Series(comparison.only_in_a),
                f"only in {Path(args.data_b).name}": pd.Series(comparison.only_in_b),
                "common": pd.Series(comparison.common),
            }
        )
        frame.to_csv(args.out, index=False)
        print(f"\ndifferences report -> {args.out}")
    if args.figure:
        from pharmaml.viz import close_figure, plot_table_comparison, save_figure

        fig = plot_table_comparison(
            comparison,
            labels=(Path(args.data_a).name, Path(args.data_b).name),
            title=f"Ligand-set reconciliation — column {comparison.column!r}",
        )
        figure_path = save_figure(fig, args.figure)
        close_figure(fig)
        print(f"overlap figure -> {figure_path}")
    return 0


def _cmd_chem_merge(args: argparse.Namespace) -> int:
    from pharmaml.chem.tables import merge_table_folder

    first_columns = (
        [c.strip() for c in args.first_columns.split(",") if c.strip()]
        if args.first_columns
        else None
    )
    merged = merge_table_folder(
        args.dir, extension=args.extension, out_path=args.out,
        first_columns=first_columns,
    )
    out = Path(args.out) if args.out else Path(args.dir) / "merged_output.csv"
    print(f"merged {len(merged)} rows x {merged.shape[1]} columns -> {out}")
    return 0


def _cmd_pharma_approvals(args: argparse.Namespace) -> int:
    from pharmaml.pharma.approvals import filter_approved_drugs

    names = filter_approved_drugs(
        list(args.data),
        drug_column=args.drug_column,
        approval_column=args.approval_column,
        approval_status=args.status,
        out_path=args.out,
    )
    print(f"{len(names)} unique drug name(s) with status {args.status!r}")
    for name in names:
        print(f"  {name}")
    if args.out:
        print(f"\ndrug list -> {args.out}")
    return 0


def _cmd_pharma_pk(args: argparse.Namespace) -> int:
    import json

    from pharmaml.pharma.pk import nca_summary
    from pharmaml.utils.io import read_table
    from pharmaml.utils.validation import require_columns

    frame = read_table(args.data)
    require_columns(frame, [args.time, args.conc])
    summary = nca_summary(frame[args.time].to_numpy(), frame[args.conc].to_numpy())
    payload = {
        k: (None if isinstance(v, float) and math.isnan(v) else v)
        for k, v in summary.as_dict().items()
    }
    print(json.dumps(payload, indent=2))
    if args.out:
        Path(args.out).write_text(json.dumps(payload, indent=2), encoding="utf-8")
        print(f"saved -> {args.out}")
    return 0


def _cmd_pharma_dose(args: argparse.Namespace) -> int:
    from pharmaml.pharma.dosage import loading_dose, maintenance_dose
    from pharmaml.pharma.pk import half_life, volume_of_distribution

    md = maintenance_dose(args.cl, args.target_css, args.tau, f=args.f)
    ld = loading_dose(args.vd, args.target_css, f=args.f)
    ke = args.cl / args.vd
    print(f"maintenance dose : {md:.2f} per {args.tau:g} h")
    print(f"loading dose     : {ld:.2f}")
    print(f"ke               : {ke:.4f} 1/h   (t1/2 = {half_life(ke):.2f} h)")
    print(f"Vd               : {volume_of_distribution(args.cl, ke):.2f} L")
    return 0


def _cmd_docking_scan(args: argparse.Namespace) -> int:
    from pharmaml.docking.parsing import scan_docking_directory
    from pharmaml.utils.io import write_table

    summary = scan_docking_directory(args.directory, log_name=args.log_name)
    print(summary.head(20).to_string(index=False))
    if args.out:
        # write_table falls back to CSV for unknown extensions: report
        # the path it RETURNS (26-R5).
        written = write_table(summary, args.out)
        print(f"saved -> {written}")
    return 0


def _cmd_docking_check(args: argparse.Namespace) -> int:
    from pharmaml.docking.parsing import check_docking_completion
    from pharmaml.utils.io import write_table

    audit = check_docking_completion(args.directory, log_name=args.log_name)
    print(audit.to_string(index=False))
    problems = int((audit["status"] != "OK").sum())
    if args.out:
        # write_table falls back to CSV for unknown extensions: report
        # the path it RETURNS (26-R5).
        written = write_table(audit, args.out)
        print(f"saved -> {written}")
    return 1 if problems else 0


def _cmd_docking_prep_ligands(args: argparse.Namespace) -> int:
    from pharmaml.docking import prepare_ligand_library

    report = prepare_ligand_library(
        args.ligands,
        args.out,
        smiles_col=args.smiles_col,
        name_col=args.name_col,
        folder_naming=args.naming,
    )
    print(report.library)
    print()
    print(report)
    if report.n_failed:
        # prepare_ligand_library already wrote failed_smiles.csv next to
        # the campaign (rar parity); just point the user at it.
        print(f"failed ligands -> {report.root / 'failed_smiles.csv'}")
        return 1
    return 0


def _cmd_docking_prep_protein(args: argparse.Namespace) -> int:
    from pharmaml.docking import prepare_protein

    altloc = args.altloc
    if altloc and altloc.lower() != "first":
        altloc = altloc.strip().upper()  # accept 'b' as 'B'
    report = prepare_protein(
        args.protein,
        args.out,
        keep_hetatm=args.keep_hetatm,
        chain=args.chain,
        default_altloc=altloc,
    )
    print(report)
    print(f"receptor -> {report.output_pdbqt}")
    return 0


def _cmd_docking_dpf(args: argparse.Namespace) -> int:
    from pharmaml.docking import write_dpf

    dpf_path = write_dpf(
        args.ligand,
        receptor_file=args.receptor,
        output_path=args.out,
        ga_run=args.ga_runs,
    )
    print(f"dpf -> {dpf_path}")
    return 0


def _cmd_docking_collect(args: argparse.Namespace) -> int:
    from pharmaml.docking import collect_files

    filename = args.filename
    if filename is None and args.pattern is None:
        filename = "r.dlg"  # rar default (extaacer.py / dlg_extracter.py)
    report = collect_files(
        args.dir,
        filename=filename,
        pattern=args.pattern,
        out_dir=args.out,
        dry_run=args.dry_run,
    )
    print(report.to_string(index=False))
    n_copied = int(report["copied"].sum()) if not report.empty else 0
    print(
        f"{len(report)} match(es), {n_copied} copied"
        + (" (dry run)" if args.dry_run else "")
    )
    return 0


def _cmd_docking_torsion(args: argparse.Namespace) -> int:
    from pharmaml.docking import scan_torsion_consistency

    report = scan_torsion_consistency(args.dir)
    print(report.to_string(index=False))
    return 0


def _cmd_docking_gpf_scan(args: argparse.Namespace) -> int:
    from pharmaml.docking import scan_gpf_ligand_types

    report = scan_gpf_ligand_types(args.dir)
    print(report.to_string(index=False))
    return 0


def _cmd_docking_vina_scan(args: argparse.Namespace) -> int:
    from pharmaml.docking import scan_vina_directory

    report = scan_vina_directory(args.dir)
    print(report.to_string(index=False))
    return 0


def _cmd_docking_rescore(args: argparse.Namespace) -> int:
    """Combine a summary table's evidence columns into a consensus ranking."""
    from pathlib import Path

    from pharmaml.docking import consensus_breakdown
    from pharmaml.exceptions import DataValidationError
    from pharmaml.utils.io import read_table, write_table

    frame = read_table(args.data)
    columns = [c.strip() for c in args.columns.split(",") if c.strip()]
    weights: list[float] | None = None
    if args.weights:
        try:
            weights = [float(w) for w in args.weights.split(",")]
        except ValueError as exc:
            raise DataValidationError(
                f"--weights must be comma-separated numbers ({args.weights!r})"
            ) from exc
    higher_is_better: dict[str, bool] = {}
    for names, value in ((args.higher, True), (args.lower, False)):
        if names:
            higher_is_better.update(
                {n.strip(): value for n in names.split(",") if n.strip()}
            )

    breakdown = consensus_breakdown(
        frame, columns, weights=weights,
        higher_is_better=higher_is_better or None,
    )
    rescored = frame.copy()
    for column in breakdown.columns:
        rescored[column] = breakdown[column].to_numpy()
    rescored = rescored.sort_values(
        "consensus", ascending=False, na_position="last"
    ).reset_index(drop=True)

    source = Path(args.data)
    out = Path(args.out) if args.out else source.with_name(f"{source.stem}_rescored.csv")
    written = write_table(rescored, out)

    # the introspection lines: which evidence, which direction, which weight.
    directions = higher_is_better or {}
    recipe = ", ".join(
        f"{col} ({'higher' if directions.get(col, not col.endswith(('energy', 'affinity'))) else 'lower'}=better"
        + (f", weight {w:g}" if weights else "")
        + ")"
        for col, w in zip(columns, weights or [1.0] * len(columns))
    )
    print(rescored.head(max(args.top, 0)).to_string(index=False))
    print(f"\nevidence: {recipe}")
    print(
        f"{len(rescored)} ligand(s) rescored -> {written} "
        "(consensus = weighted mean of the _norm columns, higher is better)"
    )

    if args.plots or args.pdf_report:
        from pharmaml.viz import plot_consensus_ranking, save_visual_bundle

        figures: dict[str, Any] = {
            "consensus_ranking": plot_consensus_ranking(rescored)
        }
        try:
            # scan-shaped tables also carry the energy landscape; a
            # consensus-only table simply skips it (the feature_importance
            # skip pattern from ml train --plots).
            from pharmaml.viz import plot_energy_distribution

            figures["energy_distribution"] = plot_energy_distribution(rescored)
        except DataValidationError:
            pass
        written_bundle = save_visual_bundle(
            figures,
            tables={"consensus_breakdown": rescored},
            out_dir=args.out_dir,
            title=f"pharmaml docking rescore — {len(columns)} evidence column(s)",
            subtitle=f"{recipe} — {source.name}",
            pdf_report=args.pdf_report,
        )
        bundle_dir = Path(args.out_dir)
        print(f"plots:    {bundle_dir / 'report.html'} (+{len(written_bundle) - 1} files)")
        if args.pdf_report:
            print(f"pdf:      {bundle_dir / 'report.pdf'}")
    return 0


def _cmd_docking_campaign_status(args: argparse.Namespace) -> int:
    import json

    from pharmaml.docking.campaign_status import inspect_vina_campaign

    result = inspect_vina_campaign(args.dir, check_originals=args.check_originals)
    print(json.dumps(result, indent=2, allow_nan=False))
    return 0  # Readable inspection, not an assertion that the campaign is complete or safe.


def _cmd_docking_campaign(args: argparse.Namespace) -> int:
    """Dispatch ``pharmaml docking campaign <verb>`` sub-commands."""
    from pharmaml.docking import (
        cleanup_tree,
        delete_named_files,
        distribute_files,
        list_file_names,
        reindex_by_number,
    )

    verb = args.campaign_command
    if verb == "list":
        names = list_file_names(args.dir, extension=args.ext, out_path=args.out)
        for name in names:
            print(name)
        print(f"{len(names)} file stem(s)")
        return 0
    if verb == "distribute":
        written = distribute_files(args.files, args.dir, overwrite=args.overwrite)
        for destination in written:
            print(destination)
        print(
            f"{len(written)} cop(y/ies) written"
            + (" (overwrite on)" if args.overwrite else "")
        )
        return 0
    if verb == "cleanup":
        report = cleanup_tree(
            args.dir,
            keep=args.keep,
            keep_pattern=args.keep_pattern,
            remove_empty=args.remove_empty,
            dry_run=args.dry_run,
        )
        print(report.to_string(index=False))
        n_deleted = int((report["action"] == "deleted").sum())
        n_dirs = int((report["action"] == "removed_dir").sum())
        print(
            f"{n_deleted} file(s) deleted, {n_dirs} director(y/ies) removed"
            + (" (dry run)" if args.dry_run else "")
        )
        return 0
    if verb == "delete-named":
        deleted = delete_named_files(args.dir, filename=args.name, dry_run=args.dry_run)
        print(
            f"{deleted} file(s) named {args.name!r} "
            + ("would be deleted (dry run)" if args.dry_run else "deleted")
        )
        return 0
    if verb == "reindex":
        from pharmaml.utils.io import read_table, write_table

        frame = read_table(args.data)
        result = reindex_by_number(
            frame,
            column=args.column,
            start=args.start,
            stop=args.stop,
            pattern=args.pattern,
        ).rename_axis("number")
        total = len(result)
        present = int(result[args.column].notna().sum())
        print(
            f"{present}/{total} ligand number(s) present in range "
            f"{args.start}..{args.stop}"
        )
        missing = [int(n) for n in result.index[result[args.column].isna()]]
        if missing and len(missing) <= 20:
            print("missing numbers: " + ", ".join(str(n) for n in missing))
        elif missing:
            print(f"{len(missing)} missing number(s) (not listed; more than 20)")
        if args.out:
            out_path = write_table(result, args.out, index=True)
            print(f"reindexed table -> {out_path}")
        else:
            print(result.to_string())
        return 0
    return 2  # pragma: no cover - argparse guards this


def _cmd_biology_response_audit(args: argparse.Namespace) -> int:
    """``pharmaml biology response-audit``: screen summary + audit + stats."""
    from pharmaml.biology import (
        audit_response_table,
        load_response_table,
        replicate_variability,
        summarize_compounds,
    )

    screen = load_response_table(
        args.data,
        cell_column=args.cell_column,
        compound_column=args.compound_column,
        tissue_column=args.tissue_column,
    )
    print(screen.summary())
    print("\naudit:")
    print(audit_response_table(screen).to_string(index=False))
    if args.replicate_cv:
        variability = replicate_variability(screen)
        if variability.empty:
            print(
                "\nreplicate variability: no duplicated "
                "(cell line, compound) pairs -- nothing to collapse"
            )
        else:
            print(
                "\nreplicate variability of duplicated pairs "
                "(pre-collapse; cv_pct = std / |mean| * 100):"
            )
            print(variability.to_string(index=False))
    metric = args.metric if args.metric is not None else screen.metrics[0]
    print(f"\nper-compound summary (metric {metric!r}):")
    print(summarize_compounds(screen, metric).to_string())
    return 0


def _cmd_biology_top_biomarkers(args: argparse.Namespace) -> int:
    """``pharmaml biology top-biomarkers``: expression vs. one drug."""
    import pandas as pd

    from pharmaml.biology import (
        direction_of_association,
        sensitivity_associations,
        top_biomarkers,
    )
    from pharmaml.biology.response import load_response_table
    from pharmaml.exceptions import DataValidationError
    from pharmaml.utils.io import read_table, write_table

    if args.lower_is_sensitive and args.higher_is_sensitive:
        raise DataValidationError(
            "pass at most one of --lower-is-sensitive / "
            "--higher-is-sensitive (they are opposites)"
        )
    lower_is_sensitive = not args.higher_is_sensitive

    screen = load_response_table(
        args.response,
        cell_column=args.cell_column,
        compound_column=args.compound_column,
        metrics=[args.response_column],
    )
    compounds = screen.compounds
    if args.compound is not None:
        if args.compound not in compounds:
            raise DataValidationError(
                f"compound {args.compound!r} not found in the response table "
                f"-- available compounds: {compounds}"
            )
        chosen = args.compound
    elif len(compounds) == 1:
        chosen = compounds[0]
    else:
        shown = ", ".join(compounds[:5])
        more = " ..." if len(compounds) > 5 else ""
        raise DataValidationError(
            f"response table holds {len(compounds)} compound(s) ({shown}{more}) "
            "-- pass --compound to pick one"
        )

    subset = screen.frame[screen.frame[screen.compound_col] == chosen]
    if subset[screen.cell_col].duplicated().any():
        n_dup = int(subset[screen.cell_col].duplicated().sum())
        _LOG.warning(
            "%d replicate row(s) for compound %r -- collapsed by median",
            n_dup,
            chosen,
        )
        # dropna=False keeps rows whose cell-line identifier is missing
        # as their own group (warn-don't-drop); the correlation
        # alignment then reports them as unmatched.
        subset = subset.groupby(
            screen.cell_col, as_index=False, dropna=False
        ).agg({args.response_column: "median"})
    response = subset.set_index(screen.cell_col)[args.response_column]
    if int(response.notna().sum()) < 3:
        raise DataValidationError(
            f"only {int(response.notna().sum())} non-NaN response value(s) for "
            f"compound {chosen!r} -- at least 3 are needed to correlate"
        )

    expression = read_table(args.expression)
    if args.cell_column in expression.columns:
        expression = expression.set_index(args.cell_column)
    elif not pd.api.types.is_numeric_dtype(expression[expression.columns[0]]):
        first = expression.columns[0]
        _LOG.debug(
            "Using expression column %r as the cell-line index", first
        )
        expression = expression.set_index(first)
    else:
        raise DataValidationError(
            "cannot identify a cell-line column in the expression table -- "
            f"name it {args.cell_column!r} or make the first column hold the "
            "cell-line identifiers"
        )

    associations = sensitivity_associations(
        expression, response, method=args.method
    )
    hits = top_biomarkers(associations, n=args.top).copy()
    hits["direction"] = [
        direction_of_association(rho, lower_is_sensitive=lower_is_sensitive)
        for rho in hits["rho"]
    ]
    print(f"compound : {chosen} ({len(response)} cell line(s))")
    print(f"response : column {args.response_column!r}, method {args.method}")
    print(
        f"genes    : {expression.shape[1]} correlated, "
        f"{int(associations['significant'].sum())} significant (FDR)"
    )
    print()
    print(hits.to_string(index=False))
    if args.out:
        written = write_table(hits, args.out)
        print(f"\nbiomarkers -> {written}")
    return 0


#: Column names accepted for the generative ``--seeds`` table (case-insensitive;
#: mirrors ``pharmaml.docking.ligands.SMILES_COLUMN_CANDIDATES``).
_GENERATIVE_SMILES_COLUMNS = (
    "smiles",
    "smile",
    "canonical_smiles",
    "smiles_nostereo",
    "smiles_no_stereo",
    "smiles_string",
    "canonical",
)


def _generative_seed_smiles(args: argparse.Namespace) -> list[str] | None:
    """Collect seed molecules from ``--seeds`` (table) + ``--seed-smiles``."""
    from pharmaml.exceptions import DataValidationError
    from pharmaml.utils.io import read_table

    seeds: list[str] = []
    if args.seeds:
        frame = read_table(args.seeds)
        lowered = {str(col).strip().lower(): col for col in frame.columns}
        smiles_col = next(
            (lowered[candidate] for candidate in _GENERATIVE_SMILES_COLUMNS
             if candidate in lowered),
            None,
        )
        if smiles_col is None:
            # Silent first-column guessing produced baffling downstream
            # errors (drug *names* parsed as SMILES); name the columns instead.
            raise DataValidationError(
                f"no SMILES column found in {args.seeds} -- available "
                f"columns: {list(frame.columns)} (expected one of "
                f"{list(_GENERATIVE_SMILES_COLUMNS)})"
            )
        seeds.extend(str(value) for value in frame[smiles_col].dropna().tolist())
    if args.seed_smiles:
        seeds.extend(
            part.strip() for part in args.seed_smiles.split(",") if part.strip()
        )
    return seeds or None


def _generative_objective(recipe: str, seeds: list[str] | None) -> tuple[Any, str]:
    """Build the recipe's scoring objective (plus a one-line description)."""
    from pharmaml.generative import (
        LogPBandObjective,
        MolecularWeightBandObjective,
        MultiObjective,
        NoveltyObjective,
        QedObjective,
        SimilarityObjective,
        TpsaBandObjective,
    )

    if recipe == "qed":
        return QedObjective(), "QED drug-likeness"
    if recipe == "logp":
        return LogPBandObjective(1.0, 3.0), "Crippen LogP band [1, 3]"
    if recipe == "druglike":
        objective = MultiObjective(
            [
                QedObjective(),
                MolecularWeightBandObjective(150, 450),
                TpsaBandObjective(30, 90),
            ]
        )
        return objective, "QED x MW(150-450) x TPSA(30-90) multi-objective"
    if recipe == "novel":
        # the 'druglike' recipe plus a hard anti-rediscovery constraint:
        # any corpus look-alike (novelty 0) vetoes the whole molecule.
        objective = MultiObjective(
            [
                QedObjective(),
                MolecularWeightBandObjective(150, 450),
                TpsaBandObjective(30, 90),
                NoveltyObjective(),
            ]
        )
        return (
            objective,
            "QED x MW(150-450) x TPSA(30-90) x novelty multi-objective",
        )
    from pharmaml.exceptions import DataValidationError

    if not seeds:
        raise DataValidationError(
            "the 'similar' recipe needs seed molecules -- pass "
            "--seeds PATH.csv (a table with a SMILES column) or "
            "--seed-smiles \"CCO,CCN\""
        )
    objective = MultiObjective(
        [SimilarityObjective(seeds[0]), QedObjective()], weights=[0.7, 0.3]
    )
    return objective, f"0.7 x similarity to {seeds[0]!r} + 0.3 x QED"


def _cmd_generative_run(args: argparse.Namespace) -> int:
    """``pharmaml generative run``: optimise molecules toward a recipe.

    With ``--plot PATH`` the run's own learning-curve figure is saved
    alongside the leaderboard: the GA's operator trajectory (needs
    ``--adaptive-operators``) or the RL run's prior-drift introspection
    (agent-vs-prior log-probabilities, the squared drift the anchor
    penalises, the exploration entropy).  With ``--pareto``
    (multi-objective recipes) the Pareto front -- the non-dominated
    trade-off molecules -- is extracted and printed after it,
    ``--pareto-plot PATH`` saves the trade-off scatter, and
    ``--pareto-keep N`` prunes an unwieldy front to its most isolated
    members (NSGA-II crowding distance).
    """
    from pharmaml.exceptions import DataValidationError
    from pharmaml.generative import DEFAULT_CORPUS, GeneticOptimizer, ReinventOptimizer
    from pharmaml.utils.io import write_table

    scaffold = bool(getattr(args, "scaffold", False))
    if scaffold and args.method != "ga":
        raise DataValidationError(
            "--scaffold selects the GA's scaffold-preserving mutation mode and "
            f"applies to --method ga only (got --method {args.method!r})"
        )
    scaffold_hop = bool(getattr(args, "scaffold_hop", False))
    if scaffold_hop and args.method != "ga":
        raise DataValidationError(
            "--scaffold-hop selects the GA's BREED-style scaffold-hop "
            "crossover and applies to --method ga only (got --method "
            f"{args.method!r})"
        )
    topology = bool(getattr(args, "topology", False))
    if topology and args.method != "ga":
        raise DataValidationError(
            "--topology selects the GA's ring-topology mutation mode and "
            f"applies to --method ga only (got --method {args.method!r})"
        )
    if topology and scaffold:
        raise DataValidationError(
            "--topology and --scaffold select different GA mutation modes "
            "-- pick one (topology: ring-size moves; scaffold: Murcko "
            "decoration resampling)"
        )
    adaptive_operators = bool(getattr(args, "adaptive_operators", False))
    if adaptive_operators and args.method != "ga":
        raise DataValidationError(
            "--adaptive-operators selects the GA's adaptive operator "
            "selection and applies to --method ga only (got --method "
            f"{args.method!r})"
        )
    plot_path = getattr(args, "plot", None)
    if plot_path and args.method == "ga" and not adaptive_operators:
        raise DataValidationError(
            "--plot draws the operator trajectory an adaptive run collects "
            "-- re-run with --adaptive-operators (a uniform run's operator "
            "mix is fixed, so it has no trajectory to draw; an RL run's "
            "--plot draws its prior-drift introspection instead)"
        )
    sa_weight = getattr(args, "sa_weight", None)
    if sa_weight is not None and (not math.isfinite(sa_weight) or sa_weight <= 0):
        raise DataValidationError("--sa-weight must be a finite positive number")
    pareto = bool(getattr(args, "pareto", False))
    pareto_plot_path = getattr(args, "pareto_plot", None)
    if pareto_plot_path and not pareto:
        raise DataValidationError(
            "--pareto-plot saves the trade-off scatter --pareto extracts; "
            "re-run with --pareto"
        )
    if pareto and args.recipe in ("qed", "logp") and sa_weight is None:
        raise DataValidationError(
            f"the {args.recipe!r} recipe optimises a single objective -- a "
            "Pareto front needs a multi-objective recipe (druglike, novel "
            "or similar), where the leaderboard's blended ranking hides "
            "the trade-offs"
        )
    pareto_keep = getattr(args, "pareto_keep", None)
    if pareto_keep is not None and not pareto:
        raise DataValidationError(
            "--pareto-keep prunes the front --pareto extracts; re-run "
            "with --pareto"
        )
    if pareto_keep is not None and pareto_keep < 1:
        raise DataValidationError(
            f"--pareto-keep must be at least 1, got {pareto_keep}"
        )

    seeds = _generative_seed_smiles(args)
    objective, description = _generative_objective(args.recipe, seeds)
    if sa_weight is not None:
        from pharmaml.generative import MultiObjective, SAScoreObjective

        if isinstance(objective, MultiObjective):
            objective = MultiObjective(
                [*objective.objectives, SAScoreObjective()],
                weights=[*objective.weights, sa_weight],
            )
        else:
            objective = MultiObjective([objective, SAScoreObjective()], weights=[1.0, sa_weight])
        description += f" + SA reward (weight {sa_weight:g})"

    print(f"method   : {args.method} (objective: {description})")
    print(f"budget   : {args.iterations} iteration(s), seed {args.seed}")
    if sa_weight is not None:
        print("SA       : sa_score is a 0-1 reward, not raw SA; "
              "it estimates complexity, not synthesis feasibility")
    if scaffold:
        print("scaffold : on (Murcko framework kept, decorations resampled)")
    if scaffold_hop:
        print("hop      : on (BREED-style homologous-cut recombination)")
    if topology:
        print("topology : on (ring contraction/expansion mutations)")
    if adaptive_operators:
        print("adaptive : on (operator draws follow per-operator credit)")
    if seeds:
        print(f"seeds    : {len(seeds)} molecule(s) anchor the search")

    if args.method == "ga":
        result = GeneticOptimizer(
            objective,
            population_size=args.population,
            generations=args.iterations,
            mutation="topology" if topology else ("scaffold" if scaffold else "uniform"),
            crossover="scaffold_hop" if scaffold_hop else "splice",
            operator_selection="adaptive" if adaptive_operators else "uniform",
            seed=args.seed,
        ).optimize(seed_smiles=seeds)
    else:
        # Seeded RL: bias the on-the-fly prior's corpus toward the user's
        # molecules (de novo corpora stay untouched).
        corpus = list(dict.fromkeys([*seeds, *DEFAULT_CORPUS])) if seeds else None
        result = ReinventOptimizer(
            objective,
            corpus=corpus,
            iterations=args.iterations,
            batch_size=args.batch_size,
            prior_epochs=args.prior_epochs,
            seed=args.seed,
        ).optimize()

    print()
    print(result.summary())
    meta = result.metadata
    print(
        f"valid    : {meta.get('valid_generated', 0)} valid molecule(s), "
        f"{meta.get('unique_generated', 0)} unique, "
        f"{meta.get('elapsed_s', float('nan')):.1f}s"
    )
    if plot_path:
        # the run's own learning curve (the chem compare --figure idiom:
        # build, save via save_figure, close, echo the artifact) -- the
        # GA's operator trajectory, or the RL run's prior-drift story
        from pharmaml.viz import close_figure, save_figure
        from pharmaml.viz.generative_plots import (
            plot_operator_trajectory,
            plot_rl_introspection,
        )

        if args.method == "ga":
            figure = plot_operator_trajectory(result)
            caption = "adaptive operator trajectory"
        else:
            figure = plot_rl_introspection(result)
            caption = "RL prior-drift introspection"
        written_figure = save_figure(figure, plot_path)
        close_figure(figure)
        print(f"plot     : {written_figure} ({caption})")
    if result.is_empty():
        print("\nno valid molecule generated -- try more iterations "
              "or a higher --prior-epochs")
        return 0

    leaderboard = result.to_dataframe()
    shown = leaderboard.head(max(args.top, 0))
    print()
    print(shown.to_string(index=False))
    if args.out:
        written = write_table(leaderboard, args.out)
        print(f"\nleaderboard ({len(leaderboard)} molecules) -> {written}")
    if pareto and not result.is_empty():
        from pharmaml.generative import pareto_front

        front = pareto_front(result)
        if pareto_keep is not None:
            # NSGA-II crowding-distance selection: keep the trade-off
            # corners + the most isolated interiors, drop the crowd
            front = front.prune(pareto_keep)
        print()
        print(f"pareto   : {front}")
        deepest = max(
            (result.smiles.index(smiles) for smiles in front.smiles),
            default=0,
        ) + 1
        if deepest > 1:
            print(
                f"           deepest front member sits at leaderboard rank "
                f"{deepest} of {len(result)} -- a trade-off the blended "
                "ranking hides"
            )
        front_rows = max(args.top, 0)
        shown_front = front.to_dataframe().head(front_rows)
        print()
        print(shown_front.to_string(index=False))
        if len(front) > front_rows:
            print(
                f"\n(front truncated to {front_rows} of {len(front)} "
                "non-dominated molecules; raise --top or use --out for more)"
            )
        if pareto_plot_path:
            from pharmaml.viz import close_figure, save_figure
            from pharmaml.viz.generative_plots import plot_pareto_front

            x, y = front.objectives[0], front.objectives[1]
            figure = plot_pareto_front(result, x=x, y=y)
            written_figure = save_figure(figure, pareto_plot_path)
            close_figure(figure)
            print(
                f"\npareto plot: {written_figure} (front over {x} x {y}, "
                "dominated molecules muted)"
            )
    return 0


def _cmd_generative_corpus(args: argparse.Namespace) -> int:
    """``pharmaml generative corpus``: dump the bundled generation corpus."""
    import pandas as pd

    from pharmaml.generative import DEFAULT_CORPUS
    from pharmaml.utils.io import write_table

    frame = pd.DataFrame(
        {"index": range(len(DEFAULT_CORPUS)), "smiles": DEFAULT_CORPUS}
    )
    print(f"bundled generation corpus: {len(DEFAULT_CORPUS)} canonical SMILES")
    print(frame.to_string(index=False))
    if args.out:
        written = write_table(frame, args.out)
        print(f"\ncorpus -> {written}")
    return 0


_HANDLERS = {
    ("models", None): _cmd_models,
    ("data", "inspect"): _cmd_data_inspect,
    ("data", "split"): _cmd_data_split,
    ("data", "audit-splits"): _cmd_data_audit_splits,
    ("data", "convert"): _cmd_data_convert,
    ("research", "manifest"): _cmd_research,
    ("research", "compare"): _cmd_research,
    ("research", "compare-uncertainty"): _cmd_research,
    ("research", "compare-training"): _cmd_research,
    ("research", "environment"): _cmd_research,
    ("research", "checkpoint"): _cmd_research,
    ("ml", "nested-ridge"): _cmd_ml_nested_ridge,
    ("ml", "nested-logistic"): _cmd_ml_nested_ridge,
    ("ml", "calibrate-binary"): _cmd_ml_calibrate_binary,
    ("ml", "conformal-report"): _cmd_ml_conformal_report,
    ("ml", "conformal-classification"): _cmd_ml_conformal_report,
    ("ml", "train"): _cmd_ml_train,
    ("ml", "compare"): _cmd_ml_compare,
    ("ml", "check"): _cmd_ml_check,
    ("ml", "predict"): _cmd_ml_predict,
    ("ml", "card"): _cmd_ml_card,
    ("ml", "drift"): _cmd_ml_drift,
    ("ml", "calibrate"): _cmd_ml_calibrate,
    ("ml", "decide"): _cmd_ml_decide,
    ("ml", "subgroup"): _cmd_ml_subgroup,
    ("ml", "tune"): _cmd_ml_tune,
    ("ml", "ad"): _cmd_ml_ad,
    ("chem", "pic50"): _cmd_chem_pic50,
    ("chem", "descriptors"): _cmd_chem_descriptors,
    ("chem", "rism"): _cmd_chem_rism,
    ("chem", "compare"): _cmd_chem_compare,
    ("chem", "merge"): _cmd_chem_merge,
    ("pharma", "pk"): _cmd_pharma_pk,
    ("pharma", "dose"): _cmd_pharma_dose,
    ("pharma", "approvals"): _cmd_pharma_approvals,
    ("docking", "scan"): _cmd_docking_scan,
    ("docking", "check"): _cmd_docking_check,
    ("docking", "prep-ligands"): _cmd_docking_prep_ligands,
    ("docking", "prep-protein"): _cmd_docking_prep_protein,
    ("docking", "dpf"): _cmd_docking_dpf,
    ("docking", "collect"): _cmd_docking_collect,
    ("docking", "torsion"): _cmd_docking_torsion,
    ("docking", "gpf-scan"): _cmd_docking_gpf_scan,
    ("docking", "vina-scan"): _cmd_docking_vina_scan,
    ("docking", "rescore"): _cmd_docking_rescore,
    ("docking", "campaign"): _cmd_docking_campaign,
    ("docking", "campaign-status"): _cmd_docking_campaign_status,
    ("biology", "response-audit"): _cmd_biology_response_audit,
    ("biology", "top-biomarkers"): _cmd_biology_top_biomarkers,
    ("generative", "run"): _cmd_generative_run,
    ("generative", "corpus"): _cmd_generative_corpus,
}


class _NoConsoleCliError(logging.Filter):
    """Suppress the console echo of ``pharmaml.cli`` ERROR records.

    ``main()`` already prints one plain ``error: ...`` line to stderr for
    every failure; without this filter the ``pharmaml`` console handler
    echoes the same ``_LOG.error`` record a second time -- two copies of
    every CLI failure on stderr.  Only console handlers are filtered:
    ``--log-file`` handlers keep the record.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        return not (record.name == "pharmaml.cli" and record.levelno >= logging.ERROR)


def _attach_cli_error_filter() -> None:
    """Attach :class:`_NoConsoleCliError` to pharmaml console handlers.

    Idempotent: repeated ``main()`` calls in one process (tests, REPLs)
    never stack duplicate filters.  Console handlers are ``StreamHandler``
    instances that are not file-backed (``--log-file`` adds a rotating
    file handler, which must keep seeing the records).
    """
    for handler in logging.getLogger("pharmaml").handlers:
        is_console = isinstance(handler, logging.StreamHandler) and not isinstance(
            handler, logging.FileHandler
        )
        if is_console and not any(
            isinstance(flt, _NoConsoleCliError) for flt in handler.filters
        ):
            handler.addFilter(_NoConsoleCliError())


def main(argv: list[str] | None = None) -> int:
    """CLI entry point (returns a process exit code)."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    configure_logging(
        level=10 if args.verbose else 30,  # DEBUG / INFO
        log_file=args.log_file,
    )
    _attach_cli_error_filter()

    sub = getattr(args, f"{args.command}_command", None)
    handler = _HANDLERS.get((args.command, sub))
    if handler is None:  # pragma: no cover - argparse guards this
        parser.error("unknown command combination")
    try:
        return handler(args)
    except Exception as exc:
        _LOG.error("%s", exc)
        if args.verbose:
            raise
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
