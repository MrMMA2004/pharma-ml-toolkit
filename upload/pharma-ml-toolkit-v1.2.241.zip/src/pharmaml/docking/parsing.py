"""Parsers for AutoDock4 (DLG) and Vina outputs.

Upgrades ``readerwithdetails.py`` (cluster-table regex parser with
"most populated cluster" logic), ``reader.py``/``reader_at_same_folder.py``
(iterative summary), ``checker.py`` (completion audit),
``dlg_extracter.py``/``Prettier_extracted_dlgs.py`` and
``others/Vina/vina_reader.py`` (best-affinity scan of a results tree).

All parsers accept *text or paths* and return typed dataclasses or
DataFrames, so they are unit-testable without a docking engine.

Examples
--------
>>> from pathlib import Path
>>> from pharmaml.docking.parsing import (
...     check_docking_completion, parse_dlg_cluster_table, parse_dlg_summary,
...     parse_vina_output, scan_docking_directory, scan_vina_directory)
>>> dlg_text = (
...     "CLUSTERING HISTOGRAM\\n"
...     "______________________________________________________________________\\n"
...     "Cluster Rank | Lowest Energy | Run | Mean Energy | # in Cluster\\n"
...     "     1       |       -9.65    |   41 |      -9.58    |     6 |\\n"
...     "     2       |       -8.20    |   12 |      -7.90    |    15 |\\n"
...     "     3       |       -4.91    |   38 |      -4.74    |     8 |\\n"
...     "Successful Completion\\n"
... )
>>> clusters = parse_dlg_cluster_table(dlg_text)          # text or path accepted
>>> clusters[0]
DockingCluster(rank=1, lowest_energy=-9.65, mean_energy=-9.58, num_in_cluster=6)
>>> [(c.rank, c.lowest_energy, c.mean_energy, c.num_in_cluster) for c in clusters]
[(1, -9.65, -9.58, 6), (2, -8.2, -7.9, 15), (3, -4.91, -4.74, 8)]
>>> summary = parse_dlg_summary(dlg_text)
>>> (summary["n_clusters"], summary["top_lowest_energy"], summary["top_mean_energy"])
(3, -9.65, -9.58)
>>> (summary["best_rank"], summary["best_num_in_cluster"])   # most populated cluster
(2, 15)
>>> parse_dlg_cluster_table("AutoDock4 log...\\n... run interrupted before clustering")
Traceback (most recent call last):
...
pharmaml.exceptions.DockingParseError: no cluster table found in the provided DLG source
>>> parse_dlg_cluster_table(Path("/tmp/pharmaml_doctest_missing.dlg"))
Traceback (most recent call last):
...
pharmaml.exceptions.DockingParseError: file not found: /tmp/pharmaml_doctest_missing.dlg

>>> vina_log = (
...     "mode | affinity | dist from best mode\\n"
...     "     | (kcal/mol) | rmsd l.b. | rmsd u.b.\\n"
...     "-----+------------+----------+----------\\n"
...     "    1       -11.5          0          0\\n"
...     "    2       -10.3       1.825      2.941\\n"
... )
>>> poses = parse_vina_output(vina_log)
>>> [(p.mode, p.affinity, p.rmsd_lb, p.rmsd_ub) for p in poses]
[(1, -11.5, 0.0, 0.0), (2, -10.3, 1.825, 2.941)]
>>> pdbqt_text = (
...     "REMARK VINA RESULT:    -7.3      0.000      0.000\\n"
...     "REMARK VINA RESULT:    -6.1      1.923      2.941\\n"
...     "REMARK VINA RESULT:    truncated\\n"
... )
>>> [p.affinity for p in parse_vina_output(pdbqt_text)]   # truncated line: poses survive
[-7.3, -6.1]
>>> parse_vina_output("Vina crashed before scoring")
Traceback (most recent call last):
...
pharmaml.exceptions.DockingParseError: no Vina pose rows found in the provided source

>>> import shutil
>>> root = Path("/tmp/pharmaml_doctest_dlg_scan")
>>> shutil.rmtree(root, ignore_errors=True)               # deterministic start
>>> for folder in ("lig1", "lig2", "lig3"):
...     (root / folder).mkdir(parents=True)
>>> _ = (root / "lig1" / "r.dlg").write_text(dlg_text)     # a completed run
>>> _ = (root / "lig2" / "r.dlg").write_text("interrupted before clustering")
>>> audit = check_docking_completion(root)                # lig3 has no r.dlg at all
>>> (audit["folder"].tolist(), audit["status"].tolist())
(['lig1', 'lig2', 'lig3'], ['OK', 'INCOMPLETE', 'MISSING_LOG'])
>>> scan = scan_docking_directory(root)
>>> [status.split(":")[0] for status in scan["status"]]   # lig2's log has no table
['OK', 'PARSE_ERROR', 'MISSING_LOG']
>>> float(scan.loc[0, "top_lowest_energy"])               # lig1's best cluster energy
-9.65
>>> check_docking_completion("/tmp/pharmaml_doctest_nodir")
Traceback (most recent call last):
...
pharmaml.exceptions.DockingParseError: docking directory not found: /tmp/pharmaml_doctest_nodir
>>> shutil.rmtree(root)
>>> vroot = Path("/tmp/pharmaml_doctest_vina_scan")
>>> shutil.rmtree(vroot, ignore_errors=True)
>>> (vroot / "good").mkdir(parents=True)
>>> _ = (vroot / "good" / "good.log").write_text(vina_log)
>>> (vroot / "bad").mkdir(parents=True)
>>> _ = (vroot / "bad" / "bad.log").write_text("no table here")
>>> vscan = scan_vina_directory(vroot)                    # best affinity first, NaN last
>>> list(vscan.itertuples(index=False, name=None))
[('good', 'good/good.log', -11.5, 2), ('bad', 'bad/bad.log', nan, 0)]
>>> shutil.rmtree(vroot)
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from pharmaml.exceptions import DockingParseError
from pharmaml.logger import get_logger

_LOG = get_logger(__name__)

__all__ = [
    "DockingCluster",
    "VinaPose",
    "check_docking_completion",
    "parse_dlg_cluster_table",
    "parse_dlg_summary",
    "parse_vina_output",
    "scan_docking_directory",
    "scan_vina_directory",
]


@dataclass(frozen=True, slots=True)
class DockingCluster:
    """One row of the AutoDock4 cluster table.

    Attributes
    ----------
    rank:
        Cluster rank (1 = lowest-energy cluster).
    lowest_energy:
        Best binding energy in the cluster (kcal/mol).
    mean_energy:
        Mean binding energy of the cluster (kcal/mol).
    num_in_cluster:
        Poses assigned to the cluster.
    """

    rank: int
    lowest_energy: float
    mean_energy: float
    num_in_cluster: int


@dataclass(frozen=True, slots=True)
class VinaPose:
    """One pose from a Vina output PDBQT.

    Attributes
    ----------
    mode:
        Pose rank (1-based).
    affinity:
        Predicted binding affinity (kcal/mol).
    rmsd_ub / rmsd_lb:
        RMSD upper/lower bounds vs. the best mode (Å).
    """

    mode: int
    affinity: float
    rmsd_ub: float
    rmsd_lb: float


# Cluster table lines look like:
#   "   1 |     -11.5 |   2 |     -11.4 |  100 |"
_CLUSTER_ROW = re.compile(
    r"^\s*(\d+)\s+\|\s+([-+]?\d+\.?\d*)\s+\|\s+\d+\s+\|"
    r"\s+([-+]?\d+\.?\d*)\s+\|\s+(\d+)\s+\|"
)
# Vina table lines look like:
#   "   1        -11.5        0.000        0.000"
# Affinity/RMSD groups accept optional scientific notation (some
# post-processing pipelines normalise the tables that way).
_VINA_ROW = re.compile(
    r"^\s+(\d+)\s+([-+]?\d+\.?\d*(?:[eE][-+]?\d+)?)"
    r"\s+(\d+\.?\d*(?:[eE][-+]?\d+)?)\s+(\d+\.?\d*(?:[eE][-+]?\d+)?)\s*$"
)


def _read_text(source: str | Path) -> str:
    """Accept a path or raw text; return the text content."""
    if isinstance(source, Path):
        if not source.is_file():
            raise DockingParseError(f"file not found: {source}")
        return source.read_text(encoding="utf-8", errors="ignore")
    text = str(source)
    # A short single-line string is most likely a path; try to read it
    # and otherwise treat it as literal text.
    if "\n" not in text and len(text) < 260:
        candidate = Path(text)
        if candidate.is_file():
            return candidate.read_text(encoding="utf-8", errors="ignore")
    return text


def parse_dlg_cluster_table(source: str | Path) -> list[DockingCluster]:
    """Parse the ``CLUSTERING HISTOGRAM`` table of an AutoDock4 DLG.

    The DLG prints, after the docking runs, a table whose columns are
    ``rank | lowest-energy | run# | mean-energy | #in-cluster``.  This
    is exactly the regex the original ``readerwithdetails.py`` used,
    now with validation and typed results.

    Raises
    ------
    DockingParseError
        If the file/text contains no cluster table (e.g. a failed
        docking that stopped before clustering).
    """
    text = _read_text(source)
    clusters: list[DockingCluster] = []
    in_table = False
    for line in text.splitlines():
        if not in_table:
            # AutoDock writes the section title in varying case across
            # versions ("CLUSTERING HISTOGRAM" / "Clustering Histogram").
            lowered = line.lower()
            if "clus" in lowered and "histogram" in lowered:
                in_table = True
            continue
        match = _CLUSTER_ROW.match(line)
        if match:
            clusters.append(
                DockingCluster(
                    rank=int(match.group(1)),
                    lowest_energy=float(match.group(2)),
                    mean_energy=float(match.group(3)),
                    num_in_cluster=int(match.group(4)),
                )
            )
    if not clusters:
        raise DockingParseError("no cluster table found in the provided DLG source")
    return clusters


def parse_dlg_summary(source: str | Path) -> dict[str, float | int]:
    """Summarise one DLG: best cluster, most populated cluster, extremes.

    Mirrors the columns the original exported to Excel:

    * ``top_*``      -- the first table row (lowest energy overall),
    * ``best_*``     -- the most populated cluster (largest
      ``num_in_cluster``), which is often the more robust pick,
    * ``n_clusters`` -- number of clusters.
    """
    clusters = parse_dlg_cluster_table(source)
    top = clusters[0]
    best = max(clusters, key=lambda c: c.num_in_cluster)
    return {
        "n_clusters": len(clusters),
        "top_rank": top.rank,
        "top_lowest_energy": top.lowest_energy,
        "top_mean_energy": top.mean_energy,
        "top_num_in_cluster": top.num_in_cluster,
        "best_rank": best.rank,
        "best_lowest_energy": best.lowest_energy,
        "best_mean_energy": best.mean_energy,
        "best_num_in_cluster": best.num_in_cluster,
    }


def parse_vina_output(source: str | Path) -> list[VinaPose]:
    """Parse the mode table of a Vina output (stdout log or PDBQT REMARKs).

    Vina writes::

        mode | affinity | dist from best mode
            | (kcal/mol) | rmsd l.b. | rmsd u.b.
        -----+------------+----------+----------
           1       -11.5          0          0

    which the regex captures regardless of the table decoration.

    Raises
    ------
    DockingParseError
        If no pose rows are found.
    """
    text = _read_text(source)
    poses: list[VinaPose] = []
    for line in text.splitlines():
        if line.startswith(("REMARK VINA RESULT", "VINA RESULT")):
            parts = line.split(":")[-1].split()
            try:
                if len(parts) >= 3:
                    poses.append(
                        VinaPose(
                            mode=len(poses) + 1,
                            affinity=float(parts[0]),
                            rmsd_lb=float(parts[1]),
                            rmsd_ub=float(parts[2]),
                        )
                    )
                    continue
            except ValueError:
                pass
            # Truncated or corrupted REMARK (interrupted run, edited
            # file): keep the surviving poses but say so instead of
            # silently dropping the line.
            _LOG.warning(
                "Skipping malformed Vina RESULT line (expected "
                "'<affinity> <rmsd l.b.> <rmsd u.b.>'): %r",
                line.strip(),
            )
            continue
        match = _VINA_ROW.match(line)
        if match:
            poses.append(
                VinaPose(
                    mode=int(match.group(1)),
                    affinity=float(match.group(2)),
                    rmsd_lb=float(match.group(3)),
                    rmsd_ub=float(match.group(4)),
                )
            )
    if not poses:
        raise DockingParseError("no Vina pose rows found in the provided source")
    return sorted(poses, key=lambda p: p.mode)


def check_docking_completion(
    directory: str | Path, log_name: str = "r.dlg"
) -> pd.DataFrame:
    """Audit a docking tree for missing/failed runs (upgrades checker.py).

    Every sub-directory is checked for the expected log file *and* the
    ``Successful Completion`` sentinel that AutoDock4 writes at the end
    of a healthy run.

    Returns
    -------
    pandas.DataFrame
        One row per sub-directory with ``folder`` and ``status``
        columns (``OK`` / ``INCOMPLETE`` / ``MISSING_LOG``).

    Raises
    ------
    DockingParseError
        If ``directory`` does not exist or is not a directory (an
        empty audit table would otherwise look like "all runs passed").
    """
    base = Path(directory)
    if not base.is_dir():
        raise DockingParseError(f"docking directory not found: {base}")
    rows = []
    sub_directories = sorted(p for p in base.iterdir() if p.is_dir())
    for sub in sub_directories:
        log = sub / log_name
        if not log.is_file():
            status = "MISSING_LOG"
        else:
            content = log.read_text(encoding="utf-8", errors="ignore")
            status = "OK" if "Successful Completion" in content else "INCOMPLETE"
        rows.append({"folder": sub.name, "status": status})
    return pd.DataFrame(rows, columns=["folder", "status"])


def scan_docking_directory(
    directory: str | Path, log_name: str = "r.dlg"
) -> pd.DataFrame:
    """Build the docking summary table for every sub-directory.

    Combines the original ``reader.py`` + ``readerwithdetails.py``
    behaviour: one row per ligand folder with the top/best cluster
    columns; folders with missing or unparseable logs get explicit
    status columns instead of crashing the whole scan.
    """
    base = Path(directory)
    if not base.is_dir():
        raise DockingParseError(f"docking directory not found: {base}")

    rows: list[dict] = []
    for sub in sorted(p for p in base.iterdir() if p.is_dir()):
        log = sub / log_name
        record: dict = {"folder": sub.name}
        if not log.is_file():
            record.update({"status": "MISSING_LOG"})
        else:
            try:
                record.update(parse_dlg_summary(log))
                record.update({"status": "OK"})
            except DockingParseError as exc:
                record.update({"status": f"PARSE_ERROR: {exc}"})
        rows.append(record)
    return pd.DataFrame(rows)


def scan_vina_directory(directory: str | Path) -> pd.DataFrame:
    """Summarise every Vina ``.log`` under a results tree.

    Upgrades ``others/Vina/vina_reader.py``: each log found recursively
    is parsed with :func:`parse_vina_output`, the best (minimum)
    affinity and pose count are reported per ligand, and the table is
    sorted by best affinity ascending so the strongest binders are at
    the top.  Logs without a parseable mode table keep their row with
    a ``None`` affinity (the original crashed on those) -- NaN rows
    sort last.

    Returns
    -------
    pandas.DataFrame
        Columns ``ligand`` (log file stem), ``log`` (path relative to
        ``directory``), ``best_affinity`` (kcal/mol) and ``n_poses``.

    Raises
    ------
    DockingParseError
        If ``directory`` is not a directory.
    """
    base = Path(directory)
    if not base.is_dir():
        raise DockingParseError(f"directory not found: {base}")

    rows: list[dict] = []
    for log in sorted(base.rglob("*.log")):
        record: dict = {"ligand": log.stem, "log": str(log.relative_to(base))}
        try:
            poses = parse_vina_output(log)
        except DockingParseError as exc:
            _LOG.warning("Skipping pose table of %s: %s", log, exc)
            record.update({"best_affinity": None, "n_poses": 0})
        else:
            record.update(
                {
                    "best_affinity": min(pose.affinity for pose in poses),
                    "n_poses": len(poses),
                }
            )
        rows.append(record)
    frame = pd.DataFrame(rows, columns=["ligand", "log", "best_affinity", "n_poses"])
    return frame.sort_values(
        "best_affinity", ascending=True, na_position="last"
    ).reset_index(drop=True)
