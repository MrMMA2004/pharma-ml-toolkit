"""The loopback uvicorn runner with the structured startup handshake
(part10 Phase Seven §10.1 steps 5-8).

Startup contract (machine-readable, **separate from diagnostic logs**):

* the server owns a socket bound to ``127.0.0.1`` with port ``0`` —
  the OS assigns a free port atomically inside ``bind()`` (no
  hardcoded port, no check-then-bind race: the "controlled port-0
  binding" the spec asks for);
* the handshake line is written as soon as ``listen()`` returns —
  the port is real and accepting connections BEFORE uvicorn even
  starts — exactly ONE machine-readable line on stdout::

      PHARMAML-READY {"port": 43551, "token": "<session-token>",
                      "pid": 1234, "version": "1.2.218"}

  The WinUI host parses it, validates the handshake, then
  authenticates every REST/WS call with the token.  Diagnostics go
  to stderr only — stdout stays machine-clean.
* ``SIGTERM``/``SIGINT`` run FastAPI's shutdown handlers (the
  JobManager drains, the bus publishes ``shutdown``) and the
  process exits — the graceful path; forced termination stays the
  documented parent-side fallback only.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import signal
import socket
import sys
from typing import Any

import uvicorn

from . import create_app
from .events import EventType
from .persistence import default_data_dir
from .security import session_security

_logger = logging.getLogger(__name__)

HANDSHAKE_PREFIX = "PHARMAML-READY"


class StudioServer(uvicorn.Server):
    """Uvicorn lifecycle with part11 §13's graceful-shutdown push honoured.

    Stock uvicorn closes every live connection BEFORE the lifespan
    shutdown handlers run, so the app-level ``job_manager.shutdown()``
    publish of the ``shutdown`` envelope never reaches an open socket
    — the round-280 services E2E caught this on a real SIGTERM (the
    socket closed without the envelope; the client then reconnected
    into a dying backend). The override publishes the envelope the
    moment the exit begins and gives the WebSocket sender tasks one
    loop beat (~0.25 s) to flush before uvicorn's connection shutdown
    runs. The lifespan drain (no new jobs, cancel, persist) follows in
    its documented place afterwards.
    """

    async def shutdown(self, sockets=None) -> None:
        app = getattr(self.config, "app", None)
        bus = getattr(getattr(app, "state", None), "bus", None)
        if bus is not None:
            try:
                bus.publish(EventType.SHUTDOWN, {})
            except Exception:
                _logger.warning("shutdown envelope publish failed",
                                exc_info=True)
            # one loop beat: the per-connection sender tasks drain
            # their bounded queues onto the sockets before close
            await asyncio.sleep(0.25)
        await super().shutdown(sockets=sockets)


def handshake_line(port: int, token: str, pid: int,
                    version: str) -> str:
    """The single machine-readable startup line (stdout, once)."""
    payload: dict[str, Any] = {
        "port": port,
        "token": token,
        "pid": pid,
        "version": version,
    }
    return f"{HANDSHAKE_PREFIX} {json.dumps(payload)}"


def bind_loopback_socket(host: str = "127.0.0.1",
                         port: int = 0) -> socket.socket:
    """Bind + listen on a loopback socket (port 0 = OS-assigned)."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind((host, port))
    sock.listen(128)
    return sock


async def serve(
    token: str | None = None,
    host: str = "127.0.0.1",
    port: int = 0,
    stdout=None,
) -> int:
    """Bind loopback:0, emit the handshake, serve until signalled.

    The shipped host entry is **durable** (part11 Phase Eleven): it
    always passes the platform user-data directory, so the registry
    (datasets / models / priors / artifacts / job history /
    preferences) survives restarts in SQLite + the file vault.

    Returns the *actual* bound port (tests and the Tauri host both
    need it; the handshake line carries it too).
    """
    import os

    out = stdout or sys.stdout
    app = create_app(token=token, data_dir=default_data_dir())
    secure = session_security()

    sock = bind_loopback_socket(host, port)
    real_port = sock.getsockname()[1]
    # the socket is already listening: emit the handshake NOW —
    # nothing later on stdout is machine-readable
    line = handshake_line(real_port, secure.token, os.getpid(),
                          _version())
    out.write(line + "\n")
    out.flush()

    # r297: the socket is handed to uvicorn as a SOCKET OBJECT via
    # serve(sockets=[...]) -- uvicorn's fd= path is Unix-only by
    # construction (its startup does socket.fromfd(fd, AF_UNIX, ...) and
    # fromfd/AF_UNIX both do not exist on Windows, so the Windows runner
    # crashed the serve() task before uvicorn ever accepted, while the
    # bind-first handshake had already been emitted -- the production
    # host entry (the frozen sidecar's own lifeline) would hang exactly
    # like run 44509479447's two real-socket tests did.
    config = uvicorn.Config(
        app,
        log_level="warning",  # diagnostics on stderr only
        access_log=False,
        loop="asyncio",
    )
    server = StudioServer(config)
    # r297: the graceful-signal lanes, wired for real. The shipped entry
    # previously had NO handler at all -- the docstrings promised
    # SIGTERM-graceful shutdown while the process actually died on the
    # OS default path (the Windows runner's CTRL_BREAK verification
    # caught it: the frozen sidecar exited 1, abruptly, never running
    # StudioServer's envelope-first shutdown). A console child receives
    # CTRL_BREAK as SIGBREAK and Ctrl+C as SIGINT on Windows; SIGTERM is
    # the POSIX lane. The handler flips uvicorn's should_exit, which the
    # serve loop polls -- the shutdown envelope publishes BEFORE the
    # sockets close, then serve() returns and the process exits 0.
    previous: dict[int, Any] = {}

    def _graceful(signum: int, _frame: object) -> None:
        server.should_exit = True

    lanes: list[int] = [int(signal.SIGINT)]
    lanes.append(
        # SIGBREAK exists only on Windows; a direct constant access would
        # not even type-check on the POSIX dev host.
        int(getattr(signal, "SIGBREAK")) if os.name == "nt" else int(signal.SIGTERM)  # noqa: B009
    )
    for sig in lanes:
        with contextlib.suppress(ValueError, OSError):
            previous[sig] = signal.signal(sig, _graceful)
    try:
        await server.serve(sockets=[sock])
    finally:
        # restore the surrounding process's handlers (tests drive serve()
        # inside the pytest process; the sidecar exits before this anyway)
        for sig, old in previous.items():
            with contextlib.suppress(ValueError, OSError):
                signal.signal(sig, old)  # type: ignore[arg-type]
        sock.close()
    return real_port


def _version() -> str:
    import pharmaml

    return pharmaml.__version__


def main() -> None:  # pragma: no cover - the WinUI-hosted entry
    """Console entry: ``python -m pharmaml.api``."""
    asyncio.run(serve())


if __name__ == "__main__":  # pragma: no cover
    main()
