# Archive audit — not a release certification

Archive: `pharma-ml-toolkit-v1.2.183.zip`
Size: 9531726 bytes; SHA-256: `9c0272a93c9cf11e70983dc5609e2611ae6c146286f6c1228c775ec315d46d45`
Entries: 700; files: 644

## Checks

- path_and_bounds: **passed**
- crc: **passed**
- version_carriers: **passed**
- manifest: **passed**
- excluded_paths: **passed**
- engine_checksums: **passed**
- isolated_restore: **passed**
- archive_stability: **passed**

Example-data files: 45 recursive, 16 top-level. Documentation consistency not fully checked.

## Bundled engine checksum references

- `engines/autodock4.exe`: MD5 `052576a87455c30df8ef8bdd951d65ab`, reference match: True; not executed
- `engines/autogrid4.exe`: MD5 `9ef694a508215d5c46ab072fba59e035`, reference match: True; not executed
- `engines/vina.exe`: MD5 `51fd15a78c71da12958d55609c3720c7`, reference match: True; not executed

Test profiles: **not executed by this audit** (no --profile-results input).

See `report.json` for the sorted per-file manifest, checksums, recorded profile evidence and limitations.
