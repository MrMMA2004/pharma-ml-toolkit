"""PharmaML Playground -- the whole toolkit behind one window.

Run this file from the toolkit root (what you get when you unzip the
downloaded archive)::

    python playground.py

A tabbed graphical interface opens with every calculation domain of the
:mod:`pharmaml` package, no command-line knowledge required:

* **Chemistry**     -- IC50/Ki -> pIC50/pKi conversion, molar mass, the
  full RDKit descriptor table for any SMILES, Tanimoto similarity, the
  RISM-KH solvation card (ten 3D-RISM-KH-inspired descriptors per
  molecule -- solvation free energy split into Lennard-Jones and
  Coulomb parts, water-site distribution peaks, first-shell
  coordination numbers, excluded volume, dipole, charge asymmetry,
  over an embedded 3D geometry with the SPC / TIP3P site models),
  and the feature factory: the rar's own pipeline grown to an
  8-family, 10,000+-column descriptor + fingerprint matrix (the
  RISM-KH family included), ranked and cut to a top-K selection --
  plus (100x-119) the canonical-tautomer & 3D-structure card
  (canonicalize_tautomer + a multi-conformer 3D PDB writer with its
  ETKDG/UFF report), the 167-key MACCS fingerprint card, and the
  similarity scan's labelled heat-map figure.
* **PK / PD**       -- half-life <-> k(e), accumulation, IV bolus decay
  and Emax curves (plotted), oral Cmax/tmax, Cockcroft-Gault creatinine
  clearance with renal dose adjustment, loading/maintenance dosing,
  BSA/weight-based and pediatric dose rules -- plus (100x-119) the
  non-compartmental analysis card (paste a concentration-time series:
  AUC/AUMC/MRT/Cmax/Tmax + terminal t½ by the linear trapezoid, Vd and
  CL when a dose is given, the shaded profile figure, a CSV export),
  the IV infusion & distribution card (rate = CL·Css, steady state,
  Vd = CL/ke, absolute bioavailability F, the repeated-dosing
  approach-to-steady-state figure), the TDM trough adjustment card,
  and the PD model explorer (sigmoid Emax with a Hill slope, inhibitory
  Emax, linear effect -- table + curve + the reverse
  EC50-for-a-target-effect solver) -- and (100x-121) the dimension-
  aware unit converter (mass / volume / amount / concentration / time).
* **Cell Lines**    -- GDSC-style drug-response screens: load and audit
  a screen, pivot the sensitivity matrix, call sensitive vs resistant
  lines, convert ``LN_IC50`` <-> pIC50, and discover expression
  biomarkers for any compound (the EGFR / erlotinib story).
* **Docking**       -- molecular docking end to end: prepare a ligand
  library and a receptor into PDBQT files (with an auto-remove bad
  residues fallback for the broken-density PDBs Meeko's templates
  reject -- the library twin of ``--delete_bad_res``), compute the
  grid box and write the GPF/DPF configs (one ligand, or the whole
  campaign tree in one batch -- custom receptor types included for
  Ni-bearing receptors), parse DLG / Vina results, scan a whole
  campaign or a whole Vina results folder, launch batch AutoDock4 or
  single Vina runs -- and dock a whole pasted SMILES ARRAY in one
  call: every SMILES prepared into its own campaign folder, the Vina
  or AutoDock4 engine run SIMULTANEOUSLY across a worker pool, and
  the best affinities ranked into the results table.
* **Data & ML**     -- open any CSV (or one of the bundled example
  datasets), pick a target column, train a registry model with the
  toolkit's own preprocessing pipeline, inspect the metrics and the
  parity/confusion figure, cross-validate a model leaderboard, build
  VOTING and STACKING ensembles by hand (tick the base models, pick
  soft/hard voting or the stacking meta-learner, train), write the
  whole run as a report bundle -- ``report.html`` + figures +
  tables (+ the multi-page ``report.pdf`` when ticked), the CLI
  ``--plots``/``--pdf-report`` story, mouse edition -- edit the selected
  model's registry knobs by hand in the Manual hyperparameters card
  (blank keeps the estimator default, pinned keys are excluded from the
  grid search, values persist per model with the session, Apply best
  prefills the winner, the cv-folds spinner sets the fold count), watch
  every long job as a determinate progress bar with a live
  remaining-time estimate (a search's trials, a network's epochs, a
  leaderboard's models), run a
  keras-tuner-style hyperparameter search (``ml tune``'s RandomSearch
  over the ann / dnn / hsvr families, or Hyperband successive halving
  over the resource budget -- ann's ``max_iter``, dnn's ``epochs`` --
  with the rung ladder sized from the family's own declared grid via
  ``resource_bounds``, the epoch-economics budget line, the defaults
  baseline, the held-out verdict, an apply-best bridge to the Deep
  Learning tab and a trials CSV export) -- save the trained model as a
  provenance-carrying BUNDLE (joblib + metadata sidecar: feature
  order, hyperparameters, metrics, library versions, timestamp), load
  any bundle back, audit new data against its feature contract and
  predict (the ``ml save`` / ``ml check`` story, mouse edition) -- and
  audit any new CSV against the last
  trained model before predicting (the ``ml check`` story, mouse
  edition: every difference named).
* **Deep Learning** -- the toolkit's PyTorch estimators behind one card
  of inputs: pick the architecture (feed-forward or residual MLP), the
  hidden widths, dropout, activation, Adam's learning rate and weight
  decay, the early-stopping patience and validation fraction, toggle
  batch normalisation (``batchnorm=True``, 1.2.36 -- a BatchNorm1d
  between every hidden linear map and its activation), then watch the
  held-out metrics, the parity/confusion figure and the epoch-by-epoch
  loss curves (``plot_training_history`` -- the early-stopping verdict
  rides on the title, the per-epoch records export as CSV) -- and audit
  any new CSV against the last trained network before predicting (the
  ``ml check`` story, deep edition: every difference named, the
  training target dropped automatically).
* **Generative**    -- run the genetic algorithm OR the reinforcement
  learning optimiser on a SMILES corpus with any bundled objective (QED,
  LogP window, ..., or the three reference-driven ones: Tanimoto
  similarity to a reference molecule, structural novelty against the
  corpus, a hard SMARTS substructure constraint); adaptive GA runs
  render the operator-mix learning curve (``plot_operator_trajectory``),
  RL runs render the four-panel prior-drift introspection
  (``plot_rl_introspection``: score trajectory, agent-vs-prior
  log-probs, the anchored drift, the exploration entropy) plus a
  first→last history table; multi-objective runs fill the Pareto front
  card: the audit line, the non-dominated table (with the
  crowding-distance column and the deepest hidden trade-off rank), the
  objective-pair scatter, a CSV export of the front, and (100x-125) a
  colour-coded 2D structure grid of the front's molecules -- boundary
  corners accented teal, interior trade-offs muted, objective values
  under every panel, and (100x-126) a per-card "Save figure…" export
  of whatever the card currently shows (grid or scatter -- unlike
  Ctrl+S, which saves the last figure drawn anywhere); and the two
  molecule-surgery cards answer what-if questions WITHOUT a run --
  enumerate one molecule's one-step ring-size move set
  (``ring_topology_moves``) or breed two parents into hybrid children
  (``scaffold_hop_crossover``, the same operator the GA's crossover
  combobox selects).  (100x-127) every Generative figure card -- the
  evolution Results, both surgery cards, the front -- carries its own
  "Save figure…" button, so a grid or plot leaves the app from the
  card that shows it instead of racing the global Ctrl+S.  (100x-128)
  the pattern closes app-wide: EVERY remaining figure card -- the ML
  results / leaderboard / applicability-domain, the network results
  and training history, the PK profile / accumulation / NCA, the PD
  and pharmacology-family curves, the descriptor distributions, the
  similarity heat-map, the docking receptor and results, the
  utilities reconciliation -- carries the same per-card export
  button; a figure now leaves the app from the card that shows it,
  everywhere.
* **Utilities**     -- the original archive's own file & table
  operations, the coverage audit's closing move (100x-110): merge
  picked tables or a whole folder (``CSV_merger`` / ``filemerger``),
  split one big CSV into parts (``Split CSV file``), reconcile a
  ligand column across two tables or annotate names with SMILES
  (``common_between_two_excel`` / ``notcommon`` / ``smilesgetter``),
  filter approved drugs into a CSV or a Word report (``approved.py``
  + ``export_docx``), the campaign file tools -- collect, list,
  distribute, delete strays, cleanup with a keep-list, dry-run first
  (``extaacter`` / ``dlg_extracter`` / ``ligand_pdbqt_extracter`` /
  ``Nameextracter`` / ``adder`` / ``deleter`` / ``delete``) -- and the
  reindex-by-number table (``Prettier_extracted_dlgs``).  The
  Chemistry tab gained the structure & table converters (``Convert
  CSV to SDF``, ``Convert SMI to CSV``, the SDF-reading notebook,
  ``Convert IC50(nM) to pIC50`` as a batch column) and the library
  similarity scan (``Tanimoto calculator``'s matrix,
  ``Tanimoto-edited``'s threshold scan, top-k); the Docking tab
  gained the grid / torsion / completion audit (``gpfreader`` /
  ``checker`` / ``niggamatch`` / ``mismatch2``), the Vina config
  batch (``vinar_multiple``) and the single-ligand SMILES → PDBQT
  (``smilestopdbqt`` / ``smiqt``); the Data & ML tab gained the
  non-numeric column remover (``Non-numerical data remover``) -- every
  script of the original rar now has a GUI surface.

Design notes
------------
* The file needs nothing but the standard library to *start*: every
  heavy dependency is probed at launch and each feature explains the
  exact ``pip install`` line it wants when missing.
* ``pharmaml`` itself resolves two ways: a normal installed package, or
  the ``src/`` tree sitting next to this file -- so the playground
  works straight after unzipping, before any ``pip install -e .``.
* The playground version follows the toolkit's own version (read from
  ``pyproject.toml`` / ``VERSION`` at import), so the two can never
  silently drift apart.
* Long calculations (descriptor batches, model training, evolution,
  biomarker discovery, docking preparation runs, feature-factory
  selection) run in a worker thread; the window never freezes and shows
  a progress bar plus a live status line.
* Every input survives a restart: on close the window writes a session
  file (``~/.pharmaml/playground-session.json``) with all entries,
  toggles, pasted corpora, the active tab, the window geometry and the
  theme, and restores it on the next launch (``File ▸ Save session
  now`` / ``Clear saved session`` control it manually).
* Sessions are shareable: ``File ▸ Export session`` writes the exact
  same payload to any path (mail it to a colleague) and ``File ▸
  Import session`` applies such a file onto the live window --
  including the theme.  ``File ▸ Reset current tab to defaults``
  (Ctrl+Shift+R) restores just the active tab's inputs to their
  freshly-launched values, leaving every other tab untouched -- and
  every content tab ALSO carries its own quiet ``Reset this tab to
  defaults`` button pinned in a non-scrolling footer strip below the
  cards (Home, which owns no inputs, carries none), so the reset is
  always one click away without scrolling back up.  Next to it sits
  the footer's second affordance: ``Copy inputs as JSON`` puts the
  SAME tab's live inputs on the clipboard as a small JSON snippet --
  a share-lite for issue reports and quick hand-offs.
* ``View ▸ Follow system / Light / Dark`` recolours the whole window
  (two named palettes drive every shade); the choice is part of the
  saved session.  Embedded figures keep the toolkit's white
  published-figure background on purpose -- plot legibility first.
* Embedded figures reuse the toolkit's own plotting helpers, so the
  playground looks exactly like the package's published figures.
* A quiet keyboard-shortcut hint row sits above the status bar,
  listing every global accelerator (Ctrl+O open · Ctrl+S save figure ·
  Ctrl+Shift+S save session · Ctrl+Shift+R reset this tab ·
  Ctrl+F find a card ·
  Ctrl+PgDn/PgUp next/previous tab · Ctrl+Q quit -- all bound and
  pinned by tests).  ``View ▸ Shortcut hints`` or the row's own
  ``Hide`` button toggles it, and the preference rides the session
  file like any other input.
* UI polish (100x-119): every card title carries a 3px accent strip
  (recoloured with the theme), the home tab's hero offers quick-jump
  chips straight to every tab, the status bar names the finished job
  and how long it took, and Ctrl+PgDn / Ctrl+PgUp cycle the tabs.
* UI polish (100x-120): ``Ctrl+F`` (or ``View \u25b8 Find a card...``)
  opens a live card finder -- type any words from a card's title or
  subtitle, Enter jumps to its tab, scrolls it into view and flashes
  its border.  A 60-card window becomes navigable without hunting.
* Content review (100x-120): the GUI now surfaces the last library
  stragglers -- descriptor-distribution histograms on the feature
  factory, the learning-curve figure on the ML results card, the
  ligand-set reconciliation figure on the table-compare card, the
  parsed view of a picked Vina config, MAD-ranked variable genes on
  the cell-line expression card, ``effect_table`` behind the PD
  explorer's sigmoid table, and a single-folder AutoDock4 engine mode
  next to the campaign runner.
* Content review (100x-121): ``UnitConverter`` gained its card on the
  PK/PD tab (dimension-aware mass / volume / amount / concentration /
  time conversion with the honest cross-dimension error), and EVERY
  table save in the window now routes through ``export_table`` --
  pick ``.csv``, ``.tsv``, GitHub-ready ``.md``, records ``.json`` or
  a standalone styled ``.html``; the Deep Learning tab's training
  history card grew the size-vs-score learning curve (the deep twin of
  the ML results button), the single-folder AutoDock4 verdict line
  carries the parsed DLG cluster summary, and the Ctrl+F finder
  remembers its last query across dialog opens AND restarts (the
  session file's ``finder`` text key).
* Content review (100x-122): the objective combobox finally carries
  EVERY bundled objective -- the three reference-driven ones
  (``SimilarityObjective`` / ``NoveltyObjective`` /
  ``SubstructureObjective``) with their swapped-in reference /
  SMARTS row -- plus the two molecule-surgery cards
  (``ring_topology_moves`` and ``scaffold_hop_crossover``) for
  single-molecule what-ifs without a full run, each with its 2D
  structure grid (one RDKit panel per mutant / parent / child).  The
  UI gained its reporting layer: ``File ▸ Save session report
  (PDF)…`` composes ``save_pdf_report`` over every live figure on
  screen (one page per figure, a title page with the census, the
  on-screen figures stay alive via ``close=False``) AND every filled
  table (real text pages via the library's own ``tables=`` axis --
  searchable, truncation notes and all), and the session restore now
  re-syncs the swapped GA/RL and reference rows to the restored
  selections.  (100x-124) The reporting layer gained its portable
  twin: ``File ▸ Save session report (HTML)…`` drives
  ``pharmaml.viz.HTMLReport`` -- the library's self-contained HTML
  builder, its first caller anywhere -- over the exact same two axes
  (figures base64-embedded, tables as styled text, plus the builder's
  own metric cards carrying the session census), and the generative
  Results card draws its leaderboard's top molecules as a 2D
  structure grid with a score row per panel.  (100x-126) The HTML
  report gained a theme engine: it OPENS in the app's View ▸ theme
  setting (auto / light / dark baked as the initial ``data-theme``),
  and a small toggle button in every report's top-right corner cycles
  the palette per reader, remembered by the browser -- the CSS uses
  custom properties, so 'auto' keeps the original
  ``prefers-color-scheme`` behaviour byte-for-byte.  (100x-129) The
  PDF twin rides the same radios: saving ``File ▸ Save session
  report (PDF)…`` while the app is dark writes the library's new
  dark-ink variant (near-black pages, light ink and accent headings
  in the app's own palette, every figure on a white plate -- the
  bright-window look of the dark HTML report), while a light app
  writes the classic white paper, byte-identical to every prior
  release; ``auto`` resolves through ``_resolve_auto_theme`` at save
  time, because a PDF's ink is frozen at write time (no reading-time
  toggle like the HTML twin's).  Flip the View ▸ theme radio before
  saving to pick the other variant.  (100x-130) The Ctrl+F card
  finder gained a "Recently jumped" recency row: every jump the
  finder makes is remembered (most recent first, de-duplicated,
  capped at ``_FINDER_RECENT_MAX`` and persisted with the session as
  the ``finder_recent`` text key), and the dialog offers one-click
  chips back to those cards -- filtered to the cards that are live
  right now, so a vanished shell never leaves a dead button.  The
  web twin's Ctrl+Shift+F finder gained the same memory
  (localStorage-backed, only jumps that actually landed are
  remembered), and its Playground gained the Surgery sub-tab -- the
  web twin of the two molecule-surgery cards below.  (100x-131) Both
  finders' recency rows carry their own "Clear" affordance: one click
  forgets every remembered jump (the desktop empties the session
  key and collapses the row in place; the web twin clears its
  localStorage) -- the honest empty, no re-open needed.  The web
  session report gained per-section control (toggle chips for every
  group the session has content for -- skip the PK figures when only
  the ML run matters) AND the surgery feeds: a run on either surgery
  card persists to the session (the latest run wins, like
  ``mlResult``), and the report walks its metrics + SMILES table +
  structure grid through a new ``image`` section kind on the report
  bridge (decoded, PNG-magic-checked, re-composed full-bleed through
  the library's own ``add_figure`` contract).  (100x-132) Both report
  menus consult a pre-save picklist before the file dialog -- the
  desktop twin of the web report card's per-section control: every
  page the session walk found (one figure page per live render, one
  text page per filled table) is offered with a checkbox, all on by
  default, a live census footer recounts on every flip, and the Save
  button disables itself at zero pages.  The web twin's section chips
  became reorderable in the same round: drag (or the per-chip arrows)
  walks the groups into any order, persisted per browser, and the
  collector honours it -- the report reads the way the reader wants.

Command line helpers (useful for scripting and CI)::

    python playground.py --probe        # dependency report, then exit
    python playground.py --self-test    # build the UI headlessly, then exit
    python playground.py --version      # print versions, then exit
"""

from __future__ import annotations

import argparse
import contextlib
import csv
import inspect
import json
import math
import queue
import re
import shutil
import sys
import threading
import time
import traceback
from collections.abc import Callable, Iterable, Iterator
from pathlib import Path
from typing import Any

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    from tkinter import font as tkfont
except ImportError:  # pragma: no cover -- a Python built without tkinter
    tk = None  # type: ignore[assignment]
    filedialog = None  # type: ignore[assignment]
    messagebox = None  # type: ignore[assignment]
    ttk = None  # type: ignore[assignment]
    tkfont = None  # type: ignore[assignment]

TOOLKIT_ROOT = Path(__file__).resolve().parent
SRC_DIR = TOOLKIT_ROOT / "src"
EXAMPLES_DIR = TOOLKIT_ROOT / "examples" / "data"


def toolkit_version() -> str:
    """The toolkit's own version: pyproject ``[project]`` -> ``VERSION``.

    A deliberate line scan (no ``tomllib`` import) so the value is
    available on every Python that can start this file: the
    ``version = "x.y.z"`` entry of the ``[project]`` section wins, a
    bare ``VERSION`` file at the toolkit root is the fallback, and
    ``"0.0.0"`` covers a tree with neither (never happens in the
    shipped archive).
    """
    pyproject = TOOLKIT_ROOT / "pyproject.toml"
    if pyproject.is_file():
        in_project = False
        try:
            lines = pyproject.read_text(encoding="utf-8").splitlines()
        except OSError:  # pragma: no cover - unreadable pyproject
            lines = []
        for raw_line in lines:
            line = raw_line.strip()
            if line.startswith("[") and line.endswith("]"):
                in_project = line == "[project]"
                continue
            if not in_project or not line.startswith("version"):
                continue
            key, sep, value = line.partition("=")
            if not sep or key.strip() != "version":
                continue
            declared = value.split("#", 1)[0].strip().strip('"').strip("'")
            if declared:
                return declared
    version_file = TOOLKIT_ROOT / "VERSION"
    if version_file.is_file():
        try:
            text = version_file.read_text(encoding="utf-8").strip()
        except OSError:  # pragma: no cover - unreadable VERSION
            text = ""
        if text:
            return text
    return "0.0.0"


#: The playground is versioned WITH the toolkit (see ``toolkit_version``).
__version__ = toolkit_version()

# -- visual language (a calm pharma green, no framework required) ------------
#
# Two named palettes drive every colour in the window.  The module-level
# names below (``BG``, ``CARD``, ...) are *rebound in place* by
# :func:`apply_theme`, so all widget code keeps reading plain module
# globals while the View menu flips the whole window between light and
# dark.  Keys beyond the original ten exist only for the inline shades
# ``_build_style`` used to hardcode (tabs, headings, status bar, button
# faces) so the dark theme can recolour them too.
_LIGHT_PALETTE: dict[str, str] = {
    "BG": "#eef1ee",
    "CARD": "#ffffff",
    "BORDER": "#d9ded7",
    "INK": "#1c2321",
    "MUTED": "#5f6b64",
    "ACCENT": "#0e7c66",
    "ACCENT_DARK": "#0a5c4b",
    "ACCENT_SOFT": "#dceee8",
    "GOOD": "#157f3d",
    "BAD": "#b3261e",
    "TAB": "#dde3de",
    "HEADING": "#edf1ee",
    "STATUS": "#e3e7e2",
    "BUTTON_FACE": "#ffffff",
    "BUTTON_DISABLED": "#9fbcb4",
    "BUTTON_DISABLED_INK": "#e8f0ee",
}
_DARK_PALETTE: dict[str, str] = {
    "BG": "#151a18",
    "CARD": "#202724",
    "BORDER": "#39423e",
    "INK": "#e7ece9",
    "MUTED": "#9daba4",
    "ACCENT": "#16a98a",
    "ACCENT_DARK": "#0f8a70",
    "ACCENT_SOFT": "#2c4139",
    "GOOD": "#37c46f",
    "BAD": "#e5766b",
    "TAB": "#242c29",
    "HEADING": "#2b3531",
    "STATUS": "#111514",
    "BUTTON_FACE": "#2b3531",
    "BUTTON_DISABLED": "#3a4642",
    "BUTTON_DISABLED_INK": "#8d9b95",
}
_PALETTES: dict[str, dict[str, str]] = {"light": _LIGHT_PALETTE, "dark": _DARK_PALETTE}

#: The palette currently bound to the module-level colour names.
_ACTIVE_THEME = "light"

BG = _LIGHT_PALETTE["BG"]
CARD = _LIGHT_PALETTE["CARD"]
BORDER = _LIGHT_PALETTE["BORDER"]
INK = _LIGHT_PALETTE["INK"]
MUTED = _LIGHT_PALETTE["MUTED"]
ACCENT = _LIGHT_PALETTE["ACCENT"]
ACCENT_DARK = _LIGHT_PALETTE["ACCENT_DARK"]
ACCENT_SOFT = _LIGHT_PALETTE["ACCENT_SOFT"]
GOOD = _LIGHT_PALETTE["GOOD"]
BAD = _LIGHT_PALETTE["BAD"]
TAB = _LIGHT_PALETTE["TAB"]
HEADING = _LIGHT_PALETTE["HEADING"]
STATUS = _LIGHT_PALETTE["STATUS"]
BUTTON_FACE = _LIGHT_PALETTE["BUTTON_FACE"]
BUTTON_DISABLED = _LIGHT_PALETTE["BUTTON_DISABLED"]
BUTTON_DISABLED_INK = _LIGHT_PALETTE["BUTTON_DISABLED_INK"]


def apply_theme(name: str) -> str:
    """Rebind the module-level colour names to the named palette.

    ``"light"`` and ``"dark"`` are the two shipped palettes; anything
    else falls back to light.  Returns the palette actually applied (the
    caller resolves ``"auto"`` itself -- detecting the OS preference
    needs a live Tk interpreter, which this pure helper must not).

    Widget code reads ``BG`` / ``CARD`` / ... at call time, so a live
    window only needs :meth:`PlaygroundApp._build_style` re-run plus a
    walk over the plain ``tk`` widgets (see ``_retint_plain_widgets``)
    after calling this.
    """
    global _ACTIVE_THEME, BG, CARD, BORDER, INK, MUTED, ACCENT, ACCENT_DARK
    global ACCENT_SOFT, GOOD, BAD, TAB, HEADING, STATUS
    global BUTTON_FACE, BUTTON_DISABLED, BUTTON_DISABLED_INK
    _ACTIVE_THEME = name if name in _PALETTES else "light"
    palette = _PALETTES[_ACTIVE_THEME]
    BG = palette["BG"]
    CARD = palette["CARD"]
    BORDER = palette["BORDER"]
    INK = palette["INK"]
    MUTED = palette["MUTED"]
    ACCENT = palette["ACCENT"]
    ACCENT_DARK = palette["ACCENT_DARK"]
    ACCENT_SOFT = palette["ACCENT_SOFT"]
    GOOD = palette["GOOD"]
    BAD = palette["BAD"]
    TAB = palette["TAB"]
    HEADING = palette["HEADING"]
    STATUS = palette["STATUS"]
    BUTTON_FACE = palette["BUTTON_FACE"]
    BUTTON_DISABLED = palette["BUTTON_DISABLED"]
    BUTTON_DISABLED_INK = palette["BUTTON_DISABLED_INK"]
    return _ACTIVE_THEME


# -- session persistence (inputs survive restarts) --------------------------- #

#: Bumped whenever the on-disk session layout changes in a way old
#: playgrounds must not silently mis-read.
SESSION_FORMAT = 1

_THEMES = ("light", "dark", "auto")


def session_path() -> Path:
    """Where the playground keeps its session file (``~/.pharmaml``)."""
    return Path.home() / ".pharmaml" / "playground-session.json"


def parse_geometry(text: str) -> tuple[int, int, int, int] | None:
    """Split a Tk geometry string into ``(w, h, x, y)`` (or ``None``).

    Only the full ``WxH+X+Y`` form is accepted -- a bare size or a bare
    position is not enough to restore a window deterministically.
    """
    match = re.match(r"^(\d+)x(\d+)([+-]\d+)([+-]\d+)$", str(text).strip())
    if match is None:
        return None
    return int(match.group(1)), int(match.group(2)), int(match.group(3)), int(match.group(4))


def dump_session(
    *,
    theme: str,
    geometry: str,
    tab: int,
    variables: dict[str, Any],
    families: dict[str, bool],
    texts: dict[str, str],
) -> dict[str, Any]:
    """Assemble the JSON-serialisable session payload (pure normaliser).

    Values are coerced to their session types here so the file can never
    carry a half-typed payload, whatever the caller collected.
    """
    return {
        "format": SESSION_FORMAT,
        "theme": theme if theme in _THEMES else "light",
        "geometry": str(geometry),
        "tab": int(tab),
        "variables": {str(name): value for name, value in variables.items()},
        "families": {str(name): bool(checked) for name, checked in families.items()},
        "texts": {str(name): str(content) for name, content in texts.items()},
    }


def load_session(raw: Any) -> dict[str, Any] | None:
    """Validate a parsed session file into a trusted dict (or ``None``).

    Malformed files are rejected wholesale (``None``); structurally fine
    files get every field sanitised back to its session type, so the
    restore path never has to defend itself twice.
    """
    if not isinstance(raw, dict) or raw.get("format") != SESSION_FORMAT:
        return None
    theme = raw.get("theme")
    if theme not in _THEMES:
        theme = "light"
    geometry = raw.get("geometry")
    geometry = geometry if isinstance(geometry, str) else ""
    tab = raw.get("tab")
    if isinstance(tab, bool) or not isinstance(tab, int) or tab < 0:
        tab = 0
    variables = raw.get("variables")
    if not isinstance(variables, dict):
        variables = {}
    variables = {str(name): value for name, value in variables.items()}
    families = raw.get("families")
    if not isinstance(families, dict):
        families = {}
    families = {
        str(name): checked for name, checked in families.items() if isinstance(checked, bool)
    }
    texts = raw.get("texts")
    if not isinstance(texts, dict):
        texts = {}
    texts = {str(name): content for name, content in texts.items() if isinstance(content, str)}
    return {
        "format": SESSION_FORMAT,
        "theme": theme,
        "geometry": geometry,
        "tab": tab,
        "variables": variables,
        "families": families,
        "texts": texts,
    }


def export_session(payload: dict[str, Any], path: str | Path) -> bool:
    """Write a session payload to ``path`` as shareable JSON.

    The file uses the exact same format as the auto-saved session
    (``format`` marker included), so an exported session can be mailed
    to a colleague and imported on their machine.  ``False`` on any
    write failure (unwritable directory, non-serialisable payload) --
    never an exception.
    """
    try:
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2)
        return True
    except (OSError, TypeError, ValueError):
        return False


def read_json_file(path: str | Path) -> Any | None:
    """Read parsed JSON from ``path`` (``None`` on any failure)."""
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return None


#: (import name, display label, why it matters, pip hint)
_DEPENDENCIES: tuple[tuple[str, str, str, str], ...] = (
    ("numpy", "numpy", "array math behind every domain", "numpy"),
    ("pandas", "pandas", "descriptor / dataset / leaderboard tables", "pandas"),
    ("sklearn", "scikit-learn", "QSAR model training + evaluation", "scikit-learn"),
    ("scipy", "SciPy", "statistics behind biomarker discovery", "scipy"),
    ("matplotlib", "matplotlib", "embedded figures (parity, profiles, curves)", "matplotlib"),
    ("rdkit", "RDKit", "chemistry: descriptors, fingerprints, QED, the GA", "rdkit"),
    ("torch", "PyTorch", "deep-learning estimators + the RL optimiser", "torch"),
)

_OBJECTIVE_KINDS = (
    "QED drug-likeness",
    "LogP window",
    "Molecular weight window",
    "TPSA window",
    "QED + LogP blend",
    "Multi-objective (QED \u00d7 MW \u00d7 TPSA)",
    # (100x-122) the three reference-driven objectives the combobox
    # skipped until now: every ScoringObjective subclass the library
    # ships is finally selectable.
    "Similarity to reference SMILES",
    "Novelty vs corpus",
    "Contains substructure (SMARTS)",
)

#: Objectives whose extra reference row (a SMILES or SMARTS entry) is
#: shown in the Objective & evolution card; the label swaps per kind.
_OBJECTIVE_REFERENCE_KINDS = {
    "Similarity to reference SMILES": "reference",
    "Contains substructure (SMARTS)": "SMARTS",
}

#: Resolved once on first figure render: the TkAgg canvas class, or None when
#: the ``_tkagg`` acceleration cannot load on this Python build (e.g. a Tcl 9
#: build without the legacy ``Tcl_SetVar`` symbol).  None switches figure
#: embedding to an Agg-rendered PNG -- visually equivalent for results panes
#: and portable across every Tcl/Tk combination.
_FIGURE_CANVAS: Any = None
_FIGURE_CANVAS_PROBED = False

_PHARMAML_HINT = (
    "pharmaml could not be imported.\n\n"
    "Either run the playground from the toolkit root (the folder holding\n"
    "src/ and README.md), or install the package first:\n\n"
    "    pip install -e ."
)


# --------------------------------------------------------------------------- #
# environment probing
# --------------------------------------------------------------------------- #
def probe_dependencies() -> dict[str, bool]:
    """Report which optional heavy dependencies are importable.

    Uses :func:`importlib.util.find_spec` (no actual import, so probing
    is instant and side-effect free).
    """
    import importlib.util

    status: dict[str, bool] = {}
    for module, _label, _purpose, _pip in _DEPENDENCIES:
        try:
            status[module] = importlib.util.find_spec(module) is not None
        except (ImportError, ValueError):  # pragma: no cover - exotic setups
            status[module] = False
    return status


def fpdf_available() -> bool:
    """Report whether the PDF-report dependency is importable.

    Companion to :func:`probe_dependencies` for the one optional dep the
    heavy-packages table does not carry: ``fpdf`` (the ``fpdf2`` wheel,
    part of the ``reports`` extra) writes the multi-page ``report.pdf``
    behind the Data & ML tab's *include report.pdf* checkbox.
    """
    import importlib.util

    try:
        return importlib.util.find_spec("fpdf") is not None
    except (ImportError, ValueError):  # pragma: no cover - exotic setups
        return False


def load_pharmaml() -> Any:
    """Import :mod:`pharmaml`, falling back to the bundled ``src/`` tree.

    The playground ships inside the toolkit archive next to ``src/``, so
    it works straight after ``unzip`` with no installation -- and keeps
    working unchanged once the package is properly installed.
    """
    try:
        import pharmaml
    except ImportError:
        if not SRC_DIR.is_dir():
            raise
        sys.path.insert(0, str(SRC_DIR))
        import pharmaml
    return pharmaml


# --------------------------------------------------------------------------- #
# small pure helpers (unit-tested in tests/test_playground.py)
# --------------------------------------------------------------------------- #
def parse_float(
    raw: str,
    field: str,
    *,
    minimum: float | None = None,
    maximum: float | None = None,
) -> float:
    """Parse a widget string into a finite float with a friendly error.

    Raises
    ------
    ValueError
        When the text is not a number, is NaN/inf, or violates the
        optional ``minimum`` / ``maximum`` bounds.
    """
    text = str(raw).strip()
    try:
        value = float(text)
    except ValueError as exc:
        raise ValueError(f"{field}: {raw!r} is not a number") from exc
    if math.isnan(value) or math.isinf(value):
        raise ValueError(f"{field}: {raw!r} is not a finite number")
    if minimum is not None and value < minimum:
        raise ValueError(f"{field}: {value} is below the minimum {minimum}")
    if maximum is not None and value > maximum:
        raise ValueError(f"{field}: {value} is above the maximum {maximum}")
    return value


def parse_int(
    raw: str,
    field: str,
    *,
    minimum: int | None = None,
    maximum: int | None = None,
) -> int:
    """Parse a widget string into an int with a friendly error."""
    text = str(raw).strip()
    try:
        value = int(float(text))
    except ValueError as exc:
        raise ValueError(f"{field}: {raw!r} is not a whole number") from exc
    if minimum is not None and value < minimum:
        raise ValueError(f"{field}: {value} is below the minimum {minimum}")
    if maximum is not None and value > maximum:
        raise ValueError(f"{field}: {value} is above the maximum {maximum}")
    return value


def parse_typed_value(raw: str, default: Any) -> Any:
    """Parse one manual-hyperparameter field against its default's type.

    The manual-hyperparameter card (100x-106) edits registry grid knobs
    whose defaults come from the estimator itself, so the string in the
    entry box is converted by the *type of the default*: bool fields
    accept ``true/false/yes/no/1/0`` (case-insensitive), int and float
    fields go through :class:`int`/:class:`float` (``ValueError``
    propagates with the raw text in it), string fields pass through
    unchanged, tuple fields (a forest's ``hidden_layer_sizes``) parse
    ``"128, 64"`` / ``"(128, 64)``"`` into the tuple itself, and
    ``None`` defaults (e.g. ``max_depth``) accept ``none``/``null``
    verbatim or any literal int/float, falling back to the raw string.
    A blank raw value never reaches this helper — the caller keeps
    the default instead.
    """
    text = str(raw).strip()
    if not text:
        return default
    if isinstance(default, bool):  # before int: bool IS an int subclass
        lowered = text.lower()
        if lowered in ("true", "yes", "1"):
            return True
        if lowered in ("false", "no", "0"):
            return False
        raise ValueError(f"{text!r} is not a true/false value")
    if isinstance(default, int):
        return int(text)
    if isinstance(default, float):
        return float(text)
    if isinstance(default, tuple):
        cleaned = text.strip("()[] ")
        parts = [part for part in cleaned.replace(",", " ").split() if part]
        if not parts:
            raise ValueError(f"{text!r} is not a comma-separated width list")
        members = []
        for part in parts:
            try:
                members.append(int(part))
            except ValueError as exc:
                raise ValueError(f"{text!r} mixes non-integer widths ({part!r})") from exc
        return tuple(members)
    if default is None:
        lowered = text.lower()
        if lowered in ("none", "null"):
            return None
        # comma-separated integer lists parse as tuples -- the ensemble
        # ``weights`` knob (a None-default parameter) takes them
        if "," in text:
            cleaned = text.strip("()[] ")
            parts = [part for part in cleaned.split(",") if part.strip()]
            try:
                return tuple(int(part) for part in parts)
            except ValueError:
                pass  # not an integer list -- fall through to the casts
        for cast in (int, float):
            try:
                return cast(text)
            except ValueError:
                continue
        return text
    return text


def _fmt_duration(seconds: float) -> str:
    """Compact human duration for the progress bar's ETA readout.

    ``42 s`` → ``3 min 05 s`` → ``1 h 04 min``: one consistent format
    per magnitude, always from a clamped non-negative input (a fresh
    job's sub-second elapsed time must never render as ``-0 s``).
    """
    total = max(0, round(float(seconds)))
    if total < 60:
        return f"{total} s"
    minutes, seconds_left = divmod(total, 60)
    if minutes < 60:
        return f"{minutes} min {seconds_left:02d} s"
    hours, minutes_left = divmod(minutes, 60)
    return f"{hours} h {minutes_left:02d} min"


def _accepts_progress_argument(work: Callable[..., Any]) -> bool:
    """True when ``work`` wants the progress reporter injected.

    A zero-argument ``work`` (every historical job) is called as
    ``work()``; a one-argument ``work`` receives the reporter callable
    — the signature decides, so no call site has to change.
    """
    try:
        parameters = list(inspect.signature(work).parameters.values())
    except (TypeError, ValueError):  # builtins / C callables -- no report
        return False
    return any(
        parameter.kind
        in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.VAR_POSITIONAL,
        )
        for parameter in parameters
    )


def _call_work(work: Callable[..., Any], report: Callable[..., None]) -> Any:
    """Invoke ``work`` with the reporter only when it accepts one."""
    if _accepts_progress_argument(work):
        return work(report)
    return work()


def _split_triple(raw: str) -> list[str]:
    """Split an ``"x y z"`` / ``"x,y,z"`` widget string into three parts."""
    return str(raw).strip().replace(",", " ").split()


def parse_int_triple(
    raw: str,
    field: str,
    *,
    minimum: int | None = None,
    maximum: int | None = None,
) -> tuple[int, int, int]:
    """Parse an ``"n n n"`` grid-points string into a tuple of three ints.

    Accepts spaces or commas (``"60 60 60"`` and ``"60,60,60"`` are
    the same input); anything that is not exactly three whole numbers
    raises :class:`ValueError` with the field name in the message.
    """
    parts = _split_triple(raw)
    if len(parts) != 3:
        raise ValueError(f"{field}: {raw!r} must be three whole numbers, e.g. '60 60 60'")
    first, second, third = (
        parse_int(part, field, minimum=minimum, maximum=maximum) for part in parts
    )
    return (first, second, third)


def parse_float_triple(raw: str, field: str) -> tuple[float, float, float]:
    """Parse an ``"x y z"`` centre/size string into three finite floats."""
    parts = _split_triple(raw)
    if len(parts) != 3:
        raise ValueError(f"{field}: {raw!r} must be three numbers, e.g. '20 20 20'")
    first, second, third = (parse_float(part, field) for part in parts)
    return (first, second, third)


def _split_pair(raw: str) -> tuple[float, float]:
    """Parse a ``"dose / auc"`` pair entry (slash or whitespace separated).

    The IV-infusion card's bioavailability row types two numbers into one
    field; this splits them with a field-named error for anything else.
    """
    text = raw.replace("/", " ").strip()
    parts = text.split()
    if len(parts) != 2:
        raise ValueError(f"pair {raw!r} must be two numbers, e.g. '250 / 58.3'")
    return parse_float(parts[0], "pair value"), parse_float(parts[1], "pair value")


#: The Docking tab's campaign-runner engines (combobox values).
_DOCK_ENGINES = ("AutoDock4 campaign", "AutoDock4 single folder", "Vina single ligand")

#: The SMILES-array card's engines (dock_smiles_array tokens).
_SMILES_DOCK_ENGINES = ("vina", "autodock4")

#: Utilities tab -- the table merge & split card's modes (the rar's
#: CSV_merger / filemerger / Split CSV file trio, one combobox).
_UTIL_MERGE_MODES = (
    "merge picked files",
    "merge whole folder",
    "split into chunks",
)

#: Utilities tab -- the compare & annotate card's modes
#: (common_between_two_excel / notcommon vs smilesgetter).
_UTIL_COMPARE_MODES = (
    "compare a column (A vs B)",
    "annotate names with SMILES",
)

#: Utilities tab -- the campaign file tools card's modes (extaacter /
#: dlg_extracter / ligand_pdbqt_extracter / Nameextracter / adder /
#: deleter / delete, one combobox; destructive modes dry-run first).
_UTIL_TOOL_MODES = (
    "collect files (name/pattern)",
    "list file names",
    "distribute files into folders",
    "delete named files",
    "cleanup tree (keep list)",
)

#: Chemistry tab -- the structure & table converter card's modes (the
#: rar's Convert CSV to SDF / Convert SMI to CSV / Sdf reading notebook /
#: Convert IC50(nM) to pIC50 scripts, one combobox).
_CONVERTER_MODES = (
    "CSV table → 3D SDF",
    ".smi list → CSV",
    "SDF → table",
    "table → .smi list",
    "append pIC50 column",
)

#: Chemistry tab -- the library similarity scan card's modes (the rar's
#: Tanimoto calculator matrix / Tanimoto-edited threshold scan / top-k).
_SCAN_MODES = (
    "matrix: references × library",
    "scan: pairs ≥ threshold",
    "top-k: nearest of first reference",
)

#: Docking tab -- the audit card's modes (the rar's gpfreader /
#: checker.py / niggamatch.py + mismatch2.py scripts, one combobox).
_DOCK_AUDIT_MODES = (
    "GPF file → parameters",
    "folder: ligand_types per sub-dir",
    "folder: torsion consistency",
    "folder: completion check",
)

#: The similarity scan card's default reference / query molecules.
_SCAN_DEFAULT_REFS = (
    "CC(=O)Oc1ccccc1C(=O)O",  # aspirin
    "CC(=O)Nc1ccc(O)cc1",  # paracetamol
)

#: The similarity scan card's default pasted library (the trivial-name
#: drugs the example campaign ships, plus two decoys).
_SCAN_DEFAULT_LIB = (
    "CC(=O)Oc1ccccc1C(=O)O",  # aspirin
    "CN1C=NC2=C1C(=O)N(C)C(=O)N2C",  # caffeine
    "CC(=O)Nc1ccc(O)cc1",  # paracetamol
    "CC(C)Cc1ccc(cc1)C(C)C(=O)O",  # ibuprofen
    "COc1ccc2cc(ccc2c1)C(C)C(=O)O",  # naproxen
    "CCCCNC(=O)c1ccccc1",  # lidocaine-ish decoy
    "c1ccccc1",  # benzene decoy
)

#: The SMILES-array card's default pasted array: the trivial-name drugs
#: the example campaign ships (matched to folder names by the library's
#: own trivial-name table).
_DOCK_SMILES_DEFAULTS = (
    "CC(=O)Oc1ccccc1C(=O)O",  # aspirin
    "CN1C=NC2=C1C(=O)N(C)C(=O)N2C",  # caffeine
    "CC(=O)Nc1ccc(O)cc1",  # paracetamol
    "CC(C)Cc1ccc(cc1)C(C)C(=O)O",  # ibuprofen
    "COc1ccc2cc(ccc2c1)C(C)C(=O)O",  # naproxen
)

#: PK / PD tab -- the PD model explorer card's models (the pharma.pd
#: family beyond the plain-Emax card: the sigmoid Emax with its Hill
#: slope, the inhibitory Emax, and the pure linear effect).
_PD_FAMILY_MODES = (
    "sigmoid Emax (Hill slope)",
    "inhibitory Emax",
    "linear effect",
)

#: PK / PD tab -- a realistic default concentration-time series for the
#: NCA card: a one-compartment IV bolus, t½ ≈ 4 h, sampled to 24 h.
_NCA_DEFAULT_TIMES = "0, 0.5, 1, 2, 4, 6, 8, 12, 16, 24"
_NCA_DEFAULT_CONCS = "12.0, 10.2, 8.7, 6.4, 4.6, 3.3, 2.4, 1.2, 0.63, 0.17"

#: PK / PD tab -- the unit-converter card's dimensions and their units
#: (pharmaml.pharma.UnitConverter's own scale tables, mirrored for the
#: comboboxes; the entries stay editable so an unknown or cross-dimension
#: unit surfaces the library's honest UnitConversionError, which names
#: every supported unit by dimension).
_UNIT_DIMENSIONS = ("mass", "volume", "amount", "concentration", "time")
_UNIT_CHOICES: dict[str, tuple[str, ...]] = {
    "mass": ("kg", "g", "mg", "ug", "µg", "mcg", "ng", "pg"),
    "volume": ("L", "mL", "ml", "uL", "µL", "nL"),
    "amount": ("mol", "mmol", "umol", "µmol", "nmol"),
    "concentration": ("M", "mM", "uM", "µM", "nM", "pM"),
    "time": ("s", "min", "h", "hr", "d", "day"),
}

# Canonical evidence columns for the consensus rescore card, in
# preference order -- the names consensus_rescore's own examples and the
# §9 notebook demo use.  The prefill intersects these with the loaded
# table's columns; anything else is typed by hand.
_RESCORE_PREFERRED_COLUMNS = (
    "ligand_efficiency",
    "LE (kcal/mol/atom)",
    "best_lowest_energy",
    "lowest_energy",
    "affinity",
    "best_num_in_cluster",
    "num_in_cluster",
    "cluster_size",
)


def docking_engine_binaries(engine: str) -> tuple[str, ...]:
    """The external binaries an engine needs on ``PATH``.

    The AutoDock4 campaign runner (and the SMILES array's
    ``autodock4`` engine) drives ``autogrid4`` + ``autodock4`` over
    every ligand folder; the Vina engines need the single ``vina``
    binary.  Used to pre-empt the workflow module's own RuntimeError
    with a friendly install hint before any job is started.
    """
    if engine in ("AutoDock4 campaign", "AutoDock4 single folder", "autodock4"):
        return ("autogrid4", "autodock4")
    return ("vina",)


def parse_smiles_lines(text: str) -> list[str]:
    """Extract non-empty SMILES lines from a corpus text widget.

    Blank lines and ``#`` comments are dropped; order is preserved and
    duplicates are kept (the optimisers decide how to handle them).
    """
    lines: list[str] = []
    for raw in text.splitlines():
        line = raw.strip()
        if line and not line.startswith("#"):
            lines.append(line)
    return lines


# --------------------------------------------------------------------------- #
# the Chemistry tab's feature factory (the rar's 7-family ML pipeline)
# --------------------------------------------------------------------------- #
#: Feature-factory families in canonical (frame column) order:
#: ``(pharmaml family name, checkbox label)``.  The bit widths mirror
#: ``pharmaml.chem.features``; the descriptor family's width depends on
#: the installed RDKit and is resolved at build time instead.
_FEATURE_FAMILY_LABELS: tuple[tuple[str, str], ...] = (
    ("descriptors", "RDKit descriptors"),
    ("atompair_count", "Atom-pair counts (2048)"),
    ("ecfp", "ECFP bits (2048)"),
    ("avalon_count", "Avalon counts (512)"),
    ("rdkit_fingerprint", "RDKit fingerprint (2048)"),
    ("morgan_full", "Morgan full (2048)"),
    ("morgan_scaffold", "Morgan scaffold (2048)"),
    ("rism", "RISM-KH solvation (10)"),
)

#: Column count of each fingerprint family.
_FEATURE_FAMILY_BITS: dict[str, int] = {
    "atompair_count": 2048,
    "ecfp": 2048,
    "avalon_count": 512,
    "rdkit_fingerprint": 2048,
    "morgan_full": 2048,
    "morgan_scaffold": 2048,
    "rism": 10,
}

#: Descriptor-family width when RDKit cannot be probed (estimate only).
_FEATURE_DESCRIPTORS_FALLBACK = 50

#: Column names auto-detected for the SMILES column (case-insensitive;
#: mirrors the docking module's convention, the rar hard-coded "SMILES").
_SMILES_COLUMN_CANDIDATES = (
    "smiles",
    "smile",
    "canonical_smiles",
    "smiles_nostereo",
    "smiles_no_stereo",
    "smiles_string",
    "canonical",
)

#: Target-combobox entry meaning "no target -- rank by variance instead".
_FEAT_NO_TARGET = "(none — variance ranking)"

#: The ranker combobox values, in display order.
_FEAT_RANKERS = (
    "Auto (RandomForest or LightGBM)",
    "Random forest",
    "LightGBM (if installed)",
    "Variance (no target needed)",
)

#: Ranker combobox label -> ``rank_features`` ``method`` argument.
_FEAT_RANKER_METHODS: dict[str, str] = {
    "Auto (RandomForest or LightGBM)": "auto",
    "Random forest": "random_forest",
    "LightGBM (if installed)": "lightgbm",
    "Variance (no target needed)": "variance",
}

#: The task combobox values, in display order.
_FEAT_TASKS = ("Auto detect", "Classification", "Regression")

#: Task combobox label -> ``rank_features`` ``task`` argument.
_FEAT_TASK_METHODS: dict[str, str] = {
    "Auto detect": "auto",
    "Classification": "classification",
    "Regression": "regression",
}

#: The card's default pasted corpus: three well-known drugs.
_FEAT_DEFAULT_SMILES = (
    "CC(=O)Oc1ccccc1C(=O)O",  # aspirin
    "CN1C=NC2=C1C(=O)N(C)C(=O)N2C",  # caffeine
    "CC(=O)Nc1ccc(O)cc1",  # paracetamol
)

#: Plain-language meaning + unit of every RISM-KH descriptor column
#: (the Chemistry tab's RISM card renders them next to the numbers).
_RISM_MEANINGS: dict[str, tuple[str, str]] = {
    "RISM_Gsolv_kcalmol": ("total solvation free energy", "kcal/mol"),
    "RISM_Glj_kcalmol": ("Lennard-Jones (dispersion) part", "kcal/mol"),
    "RISM_Gcoul_kcalmol": ("Coulomb charging part", "kcal/mol"),
    "RISM_Ow_gmax": ("water-O distribution peak", "g(d) max"),
    "RISM_Hw_gmax": ("water-H distribution peak", "g(d) max"),
    "RISM_Ow_cn1": ("first-shell water-O coordination", "molecules"),
    "RISM_Hw_cn1": ("first-shell water-H coordination", "molecules"),
    "RISM_Ow_exclvol_A3": ("water-O excluded volume", "Å³"),
    "RISM_dipole_D": ("molecular dipole moment", "Debye"),
    "RISM_q_neg_frac": ("negative-charge fraction", "fraction"),
}

#: Tooltip on the K entry: the rar pipeline's own top-K presets.
_FEAT_K_PRESETS = "200 / 500 / 1000 / 1500 are the pipeline's presets"


def feature_factory_width(families: Iterable[str], descriptor_count: int) -> int:
    """Estimated column count of a feature-factory run, before it happens.

    Sums the fingerprint bit widths of the requested families plus
    ``descriptor_count`` for the descriptor family, so the Chemistry tab
    can preview the matrix width as the family checkboxes toggle.

    Raises
    ------
    ValueError
        When a name is not a feature-factory family.
    """
    total = 0
    for family in families:
        if family == "descriptors":
            total += descriptor_count
        elif family in _FEATURE_FAMILY_BITS:
            total += _FEATURE_FAMILY_BITS[family]
        else:
            raise ValueError(
                f"unknown feature family {family!r}; valid families are: "
                + ", ".join(name for name, _label in _FEATURE_FAMILY_LABELS)
            )
    return total


def detect_smiles_column(frame: Any) -> str | None:
    """Find the SMILES column of a loaded table, or None when absent.

    Name-based and case-insensitive over the same candidate list the
    docking module uses (``smiles``, ``smile``, ``canonical_smiles``,
    ...); any object with a ``.columns`` attribute works.
    """
    lowered = {str(column).strip().lower(): str(column) for column in frame.columns}
    for candidate in _SMILES_COLUMN_CANDIDATES:
        if candidate in lowered:
            return lowered[candidate]
    return None


def default_target_column(frame: Any) -> str | None:
    """Pick the most likely target column of a loaded dataset.

    Walks from the RIGHT, skipping the SMILES column and string columns
    whose every value is unique -- an ID column (``compound_id`` with
    420 distinct values), never a prediction target.  The bundled
    examples all cooperate: ``qsar_regression.csv`` ends in ``pIC50``
    and ``qsar_multiclass.csv`` in ``Target``, but
    ``qsar_classification.csv`` ends in ``compound_id`` with the real
    ``activity`` label one step left -- the naive last-column default
    trained a 420-class classifier on row IDs.
    """
    columns = [str(column) for column in frame.columns]
    if not columns:
        return None
    smiles = detect_smiles_column(frame)
    rows = len(frame)
    for column in reversed(columns):
        if smiles is not None and column == smiles:
            continue
        series = frame[column]
        if rows > 6 and str(series.dtype) == "object" and series.nunique() == rows:
            continue  # unique-per-row strings: an ID, not a label
        return column
    return columns[-1]


def numeric_feature_columns(frame: Any, target: str) -> tuple[list[str], list[str]]:
    """Split a dataset's non-target columns into ``(numeric, dropped)``.

    The train flows' shared rule (Data & ML, Deep Learning): numeric
    columns become features; everything else -- SMILES, IDs, free text
    -- is reported as dropped so the user sees WHY those columns never
    reached the model.
    """
    import pandas as pd

    numeric = [
        column
        for column in frame.columns
        if column != target and pd.api.types.is_numeric_dtype(frame[column])
    ]
    dropped = [
        str(column) for column in frame.columns if column != target and column not in numeric
    ]
    return numeric, dropped


def format_number(value: float, digits: int = 4) -> str:
    """Human-friendly number rendering for result labels and tables."""
    if isinstance(value, bool) or value is None:
        return str(value)
    if math.isnan(value):
        return "nan"
    if math.isinf(value):
        return "inf" if value > 0 else "-inf"
    magnitude = abs(value)
    if value != 0 and (magnitude >= 1e5 or magnitude < 1e-3):
        return f"{value:.3e}"
    return f"{value:,.{digits}f}"


def build_objective(
    kind: str,
    lo: float,
    hi: float,
    reference: str = "",
    corpus: list[str] | tuple[str, ...] | None = None,
) -> Any:
    """Instantiate a generative objective selected by its GUI label.

    (100x-122) ``reference`` carries the similarity seed / SMARTS pattern
    for the three reference-driven objectives; ``corpus`` is the Novelty
    objective's reference pool (the card's own corpus text).
    """
    from pharmaml.generative import (
        LogPBandObjective,
        MolecularWeightBandObjective,
        MultiObjective,
        NoveltyObjective,
        QedObjective,
        SimilarityObjective,
        SubstructureObjective,
        TpsaBandObjective,
    )

    if kind == "QED drug-likeness":
        return QedObjective()
    if kind == "LogP window":
        return LogPBandObjective(lo, hi)
    if kind == "Molecular weight window":
        return MolecularWeightBandObjective(lo, hi)
    if kind == "TPSA window":
        return TpsaBandObjective(lo, hi)
    if kind == "Similarity to reference SMILES":
        return SimilarityObjective(reference)
    if kind == "Novelty vs corpus":
        return NoveltyObjective(list(corpus) if corpus else None)
    if kind == "Contains substructure (SMARTS)":
        return SubstructureObjective(reference)
    if kind == "Multi-objective (QED \u00d7 MW \u00d7 TPSA)":
        # the CLI's 'druglike' recipe: equal-weight triple whose blended
        # leaderboard hides the trade-offs the Pareto front card surfaces.
        return MultiObjective(
            [
                QedObjective(),
                MolecularWeightBandObjective(150, 450),
                TpsaBandObjective(30, 90),
            ]
        )
    return MultiObjective([QedObjective(), LogPBandObjective(lo, hi)], weights=[0.7, 0.3])


#: Deep-learning tab (100x-61): architecture labels the combobox offers.
_DL_ARCHITECTURES: tuple[str, ...] = (
    "Deep MLP (feed-forward)",
    "Residual MLP (skip connections)",
)

#: Hidden-activation tokens -- mirrors ``pharmaml.ml.neural._ACTIVATIONS``
#: (the test suite pins the two together, so they cannot drift).
_DL_ACTIVATIONS: tuple[str, ...] = ("relu", "tanh", "gelu", "sigmoid")

#: The keyboard-shortcut hint row (100x-65): one quiet line above the
#: status bar listing every global accelerator.  The five entries mirror
#: the ``bind_all`` sequences in ``_build_menu`` (the test suite pins the
#: set together, so a new binding without a hint -- or vice versa --
#: fails loudly).
SHORTCUT_HINTS: tuple[tuple[str, str], ...] = (
    ("Ctrl+O", "open"),
    ("Ctrl+S", "save figure"),
    ("Ctrl+Shift+S", "save session"),
    ("Ctrl+Shift+R", "reset this tab"),
    ("Ctrl+F", "find a card"),
    ("Ctrl+PgDn/PgUp", "next/previous tab"),
    ("Ctrl+Q", "quit"),
)

#: (100x-130) the card finder's recency cap -- the "Recently jumped"
#: chip row keeps at most this many destinations, newest first.
_FINDER_RECENT_MAX = 6


def shortcut_hints_text() -> str:
    """Render the hint row's one-line label from :data:`SHORTCUT_HINTS`."""
    return " \u00b7 ".join(f"{keys} {what}" for keys, what in SHORTCUT_HINTS)


def parse_hidden_layers(raw: str) -> tuple[int, ...]:
    """Parse the hidden-layers entry (``"64, 32"``) into a width tuple.

    An empty entry is the empty tuple -- a single linear layer, the
    regularised multinomial/linear baseline the estimators themselves
    build for ``hidden_layers=()``.

    Raises
    ------
    ValueError
        When a token is not a number or a width below 1.
    """
    widths: list[int] = []
    for token in str(raw).split(","):
        token = token.strip()
        if not token:
            continue
        try:
            width = int(float(token))  # "64" and "64.0" both parse
        except ValueError as exc:
            raise ValueError(f"hidden layer widths must be numbers, got {token!r}") from exc
        if width < 1:
            raise ValueError(f"hidden layer widths must be >= 1, got {token!r}")
        widths.append(width)
    return tuple(widths)


def deep_estimator_name(architecture: str, task: str) -> str:
    """Map the GUI's architecture/task pair onto an estimator class name.

    Pure on purpose: the playground never imports ``pharmaml.ml.neural``
    at module scope -- the worker thread resolves the returned name at
    fit time, so the mapping stays testable (and typo-checkable) without
    pharmaml or torch installed.

    Raises
    ------
    ValueError
        On an unknown architecture label or task token.
    """
    if architecture not in _DL_ARCHITECTURES:
        raise ValueError(f"unknown architecture {architecture!r}")
    if task not in ("classification", "regression"):
        raise ValueError(f"unknown task {task!r}")
    family = "ResidualMLP" if architecture.startswith("Residual") else "DeepMLP"
    return family + ("Classifier" if task == "classification" else "Regressor")


#: Data & ML tab (100x-90): hypermodel families the Tune card offers --
#: the same tokens the CLI's ``ml tune --estimator`` accepts.
_TUNE_ESTIMATORS: tuple[str, ...] = ("ann", "hsvr", "dnn")

#: Ensemble-builder card: registry members offered as checkboxes --
#: ``(registry token, label)``.  Dual-task, dependency-free families
#: only, so every combination builds for both tasks.
_ENSEMBLE_MEMBER_LABELS: tuple[tuple[str, str], ...] = (
    ("random_forest", "Random forest"),
    ("extra_trees", "Extra trees"),
    ("svm", "SVM"),
    ("knn", "KNN"),
    ("decision_tree", "Decision tree"),
    ("logistic_regression", "Logistic (cls)"),
    ("ridge", "Ridge (reg)"),
    ("gradient_boosting", "Gradient boosting"),
    ("ann", "ANN (MLP)"),
    ("gaussian_process", "Gaussian process"),
)

#: The default ticked trio -- the rar's own Voting.py / Stacking.py
#: members (RF + SVM + KNN), matching the registry ensembles' defaults.
_ENSEMBLE_DEFAULT_MEMBERS: tuple[str, ...] = ("random_forest", "svm", "knn")

#: Searcher tokens for the Tune card -- the same two the CLI's
#: ``ml tune --searcher`` accepts (random | hyperband).
_TUNE_SEARCHERS: tuple[str, ...] = ("random", "hyperband")

#: The resource slot each Hyperband-able family halves over -- the
#: CLI's own rule (``max_iter`` for the sklearn ann, ``epochs`` for
#: the torch dnn); hsvr declares neither, so the card guards it.
_TUNE_RESOURCES: dict[str, str] = {"ann": "max_iter", "dnn": "epochs"}

#: Hypermodel builder names for the Tune card, keyed by
#: ``(estimator, task)`` -- resolved on the worker thread (the playground
#: never imports ``pharmaml`` at module scope), and pinned to the CLI's
#: own ``ml tune`` registry by the test suite so the two surfaces cannot
#: drift apart (the ``_DL_ACTIVATIONS`` pin pattern).
_TUNE_HYPERMODELS: dict[tuple[str, str], str] = {
    ("ann", "regression"): "build_ann_regressor",
    ("ann", "classification"): "build_ann_classifier",
    ("dnn", "regression"): "build_deep_regressor",
    ("dnn", "classification"): "build_deep_classifier",
    ("hsvr", "regression"): "build_hsvr",
}


def tune_config_text(params: dict[str, Any]) -> str:
    """Render one trial's hyperparameters as ``k=v`` tokens.

    Floats go through ``%g`` (``alpha=0.001``, not ``alpha=0.0010000``),
    booleans render as ``on`` / ``off`` and everything else as ``str``.
    Keys are sorted so the leaderboard's configuration column is stable
    across trials (and across runs -- determinism is the tuner's own
    contract).

    >>> tune_config_text({"units": 64, "alpha": 0.001, "batchnorm": True})
    'alpha=0.001 batchnorm=on units=64'
    >>> tune_config_text({"gamma": "scale"})
    'gamma=scale'
    """
    tokens: list[str] = []
    for key in sorted(params):
        value = params[key]
        if isinstance(value, bool):
            text = "on" if value else "off"
        elif isinstance(value, float):
            text = f"{value:g}"
        else:
            text = str(value)
        tokens.append(f"{key}={text}")
    return " ".join(tokens)


def _cell_text(value: Any, limit: int = 26) -> str:
    """Render one table cell for the preview/leaderboard trees."""
    if value is None:
        return ""
    if isinstance(value, float):
        return format_number(value)
    text = str(value)
    return text if len(text) <= limit else text[: limit - 1] + "…"


# --------------------------------------------------------------------------- #
# widgets
# --------------------------------------------------------------------------- #
class Tooltip:
    """A small delayed hover tooltip attached to any widget."""

    def __init__(self, widget: Any, text: str) -> None:
        self._widget = widget
        self._text = text
        self._after_id: Any = None
        self._tip: Any = None
        widget.bind("<Enter>", self._schedule)
        widget.bind("<Leave>", self._hide)

    def _schedule(self, _event: Any = None) -> None:
        self._cancel()
        self._after_id = self._widget.after(550, self._show)

    def _cancel(self) -> None:
        if self._after_id is not None:
            try:
                self._widget.after_cancel(self._after_id)
            except tk.TclError:  # pragma: no cover - widget already gone
                pass
            self._after_id = None

    def _show(self) -> None:
        if self._tip is not None or not self._text:
            return
        x = self._widget.winfo_rootx() + 16
        y = self._widget.winfo_rooty() + self._widget.winfo_height() + 6
        self._tip = tk.Toplevel(self._widget)
        self._tip.wm_overrideredirect(True)
        self._tip.wm_geometry(f"+{x}+{y}")
        tk.Label(
            self._tip,
            text=self._text,
            justify="left",
            wraplength=340,
            background="#111827",
            foreground="#f9fafb",
            padx=9,
            pady=5,
        ).pack()

    def _hide(self, _event: Any = None) -> None:
        self._cancel()
        if self._tip is not None:
            self._tip.destroy()
            self._tip = None


class ScrollFrame(ttk.Frame):  # type: ignore[misc] # ttk is None headless
    """A vertically scrollable tab page with mouse-wheel support.

    Cards live on ``self.body``; the inner frame always stays as wide as
    the viewport so cards stretch with the window.  ``self.footer`` is a
    NON-scrolling strip pinned below the canvas (packed first, so the
    scroll area shrinks around it) -- tab-level affordances that must
    stay visible live there (the per-tab reset button, 100x-55).
    """

    def __init__(self, master: Any) -> None:
        super().__init__(master, style="Tab.TFrame")
        self.footer = ttk.Frame(self, style="Tab.TFrame")
        self.footer.pack(side="bottom", fill="x")
        self._canvas = tk.Canvas(self, background=BG, highlightthickness=0, bd=0)
        self._bar = ttk.Scrollbar(self, orient="vertical", command=self._canvas.yview)
        self.body = ttk.Frame(self._canvas, style="Tab.TFrame")
        self._window = self._canvas.create_window((0, 0), window=self.body, anchor="nw")
        self.body.bind(
            "<Configure>",
            lambda _event: self._canvas.configure(scrollregion=self._canvas.bbox("all")),
        )
        self._canvas.configure(yscrollcommand=self._bar.set)
        self._canvas.bind(
            "<Configure>",
            lambda _event: self._canvas.itemconfigure(
                self._window, width=self._canvas.winfo_width()
            ),
        )
        self._bar.pack(side="right", fill="y")
        self._canvas.pack(side="left", fill="both", expand=True)
        for host in (self, self._canvas, self.body):
            host.bind("<Enter>", lambda _event: self._bind_wheel())
            host.bind("<Leave>", lambda _event: self._unbind_wheel())

    def _bind_wheel(self) -> None:
        if self.tk.call("tk", "windowingsystem") == "x11":
            self.bind_all("<Button-4>", self._on_wheel)
            self.bind_all("<Button-5>", self._on_wheel)
        else:
            self.bind_all("<MouseWheel>", self._on_wheel)

    def _unbind_wheel(self) -> None:
        if self.tk.call("tk", "windowingsystem") == "x11":
            self.unbind_all("<Button-4>")
            self.unbind_all("<Button-5>")
        else:
            self.unbind_all("<MouseWheel>")

    def _on_wheel(self, event: Any) -> None:
        if getattr(event, "num", 0) == 4 or getattr(event, "delta", 0) > 0:
            self._canvas.yview_scroll(-3, "units")
        elif getattr(event, "num", 0) == 5 or getattr(event, "delta", 0) < 0:
            self._canvas.yview_scroll(3, "units")


#: The card finder's directory (100x-120): every card shell ``make_card``
#: appends ``(title, subtitle, shell)`` here, and ``Ctrl+F`` filters it
#: live.  Module-level because ``make_card`` is a plain function; the
#: shells are weak references in practice (a destroyed app leaves
#: dead paths -- the finder re-resolves tabs through the LIVE notebook,
#: so stale entries simply never match).
_CARD_INDEX: list[tuple[str, str, Any]] = []


def make_card(
    parent: Any,
    title: str,
    subtitle: str = "",
    *,
    row: int = 0,
    column: int = 0,
    span: int = 1,
) -> Any:
    """Create a white card with a heading on a tab's card grid.

    Returns the content frame callers grid their controls into (the
    content frame is itself grid-managed with two weighted columns).

    The header carries a 3px accent strip to the title's left (the
    100x-119 UI pass): a quiet visual anchor that groups each card's
    controls at a glance.  The strip is a plain ``tk.Frame`` painted
    ``ACCENT``; ``_retint_plain_widgets`` recolours it on theme flips.

    Every shell is also appended to :data:`_CARD_INDEX` (title,
    subtitle, shell) -- the Ctrl+F card finder's directory (100x-120).
    """
    shell = tk.Frame(parent, background=CARD, highlightbackground=BORDER, highlightthickness=1)
    _CARD_INDEX.append((title, subtitle, shell))
    shell.grid(row=row, column=column, columnspan=span, sticky="nsew", padx=6, pady=6)
    header = ttk.Frame(shell, style="Card.TFrame", padding=(14, 10, 14, 0))
    header.pack(fill="x")
    title_row = ttk.Frame(header, style="Card.TFrame")
    title_row.pack(fill="x")
    strip = tk.Frame(title_row, width=3, background=ACCENT)
    strip.pack(side="left", fill="y", padx=(0, 8))
    ttk.Label(title_row, text=title, style="CardTitle.TLabel").pack(side="left", anchor="w")
    if subtitle:
        ttk.Label(
            header, text=subtitle, style="CardMuted.TLabel", wraplength=620, justify="left"
        ).pack(anchor="w", pady=(2, 0))
    content = ttk.Frame(shell, style="Card.TFrame", padding=(14, 8, 14, 12))
    content.pack(fill="both", expand=True)
    content.columnconfigure(1, weight=1)
    return content


def form_row(parent: Any, label: str, widget: Any) -> None:
    """Append a ``label | widget`` row onto a card's content grid."""
    row = parent.grid_size()[1]
    ttk.Label(parent, text=label, style="Field.TLabel").grid(
        row=row, column=0, sticky="w", padx=(0, 10), pady=3
    )
    widget.grid(row=row, column=1, sticky="ew", pady=3)


def grid_append(
    parent: Any,
    widget: Any,
    *,
    columnspan: int = 2,
    sticky: str = "w",
    pady: tuple[int, int] = (0, 0),
    weight: bool = False,
) -> int:
    """Append ``widget`` on the next free row of a card's content grid.

    Card content frames are grid-managed (``form_row`` siblings), so
    every child must use grid -- never pack -- inside them.
    """
    row = parent.grid_size()[1]
    widget.grid(row=row, column=0, columnspan=columnspan, sticky=sticky, pady=pady)
    if weight:
        parent.rowconfigure(row, weight=1)
    return row


def bind_enter(widget: Any, button: Any) -> None:
    """Let pressing Return in ``widget`` invoke ``button``."""
    widget.bind("<Return>", lambda _event: button.invoke())


def _grid_text(parent: Any, height: int = 6, mono: Any = None) -> Any:
    """A flat white multi-line text box (corpus editing, stats dumps)."""
    box = tk.Text(
        parent,
        height=height,
        background=CARD,
        foreground=INK,
        relief="solid",
        borderwidth=1,
        highlightthickness=0,
        padx=8,
        pady=6,
        font=mono or ("TkFixedFont", 10),
        wrap="none",
    )
    return box


def _truncate_caption_text(text: str, width: int = 34) -> str:
    """Shorten a caption line to ``width`` characters with an ellipsis."""
    return text if len(text) <= width else text[: width - 1] + "\u2026"


def molecule_grid_figure(
    entries: list[tuple[str, str]],
    title: str,
    scores: list[str] | None = None,
    colors: list[str] | None = None,
) -> Any:
    """One matplotlib figure of captioned 2D structure panels (100x-123).

    ``entries`` pairs a short caption with a SMILES string: every
    parseable molecule becomes one panel (an RDKit 2D drawing raster,
    :func:`rdkit.Chem.Draw.MolToImage`), an unparseable entry keeps its
    slot with an honest note instead of silently vanishing, and an empty
    list draws the honest ``nothing to draw`` line.  Callers pass the
    caption pre-built (label + truncated SMILES) so the grid stays
    self-describing when copy-pasted into the session report.

    (100x-124) ``scores`` adds one score line per entry -- rendered as
    the panel's ``xlabel``, a distinct row under every structure, so a
    ranked leaderboard reads at a glance.  A shorter list pads with
    blanks and a longer one is truncated (a caller's off-by-one can
    never shift the grid); ``None`` keeps the classic bare panels.

    (100x-125) ``colors`` adds one accent colour per entry: the caption
    AND the panel border take it (a colour-blind-safe encoding of a
    split the score row cannot carry -- the Pareto front's boundary
    corners vs its interior trade-offs).  The same pad/truncate contract
    as ``scores``; ``None`` keeps the uniform classic look.
    """
    import matplotlib.pyplot as plt
    import numpy as np
    from rdkit import Chem
    from rdkit.Chem import Draw

    count = max(len(entries), 1)
    # 3 columns fit the card width up to a 2-row litter (parents +
    # children); wider grids only for the biggest draws.
    columns = 3 if count <= 6 else 4
    rows = max(1, -(-count // columns))  # ceil division
    figure, axes = plt.subplots(
        rows, columns, figsize=(3.1 * columns, 3.0 * rows + 0.5), squeeze=False
    )
    panels = [panel for row_axes in axes for panel in row_axes]
    score_lines: list[str | None] = [None] * len(entries)
    if scores is not None:
        for index in range(min(len(scores), len(entries))):
            score_lines[index] = scores[index] or None
    color_values: list[str | None] = [None] * len(entries)
    if colors is not None:
        for index in range(min(len(colors), len(entries))):
            color_values[index] = colors[index] or None
    for panel in panels:
        # NB: axis("off") would hide the xlabel machinery too (axison
        # skips the whole xaxis at draw time), so the scores row would
        # vanish -- hide the frame and the ticks instead, keeping the
        # label machinery alive.  Same look, one more capability.
        for spine in panel.spines.values():
            spine.set_visible(False)
        panel.set_xticks([])
        panel.set_yticks([])
    if not entries:
        panels[0].text(0.5, 0.5, "nothing to draw", ha="center", va="center", fontsize=11)
    for panel, (caption, smiles), score_line, accent in zip(
        panels, entries, score_lines, color_values
    ):
        mol = Chem.MolFromSmiles(smiles) if smiles else None
        if mol is None:
            panel.text(
                0.5,
                0.5,
                f"{caption}\n(unparseable SMILES)",
                ha="center",
                va="center",
                fontsize=9,
                color=accent or "black",
            )
            continue
        raster = np.asarray(Draw.MolToImage(mol, size=(300, 300)))
        panel.imshow(raster)
        if accent is not None:
            # the accent speaks twice -- caption text + a visible border
            # -- so the split survives grayscale printing and colour
            # vision differences alike.
            panel.set_title(caption, fontsize=8, pad=6, color=accent)
            for spine in panel.spines.values():
                spine.set_visible(True)
                spine.set_color(accent)
                spine.set_linewidth(1.6)
        else:
            panel.set_title(caption, fontsize=8, pad=6)
        if score_line is not None:
            panel.set_xlabel(score_line, fontsize=8.5, labelpad=2)
    figure.suptitle(title, fontsize=10)
    figure.tight_layout(rect=(0, 0, 1, 0.96))
    return figure


# --------------------------------------------------------------------------- #
# the application
# --------------------------------------------------------------------------- #
if tk is not None:
    _TkBase: Any = tk.Tk
else:  # allow `import playground` on tkinter-less builds (probe path)

    class _TkBase:  # type: ignore[no-redef]
        """Placeholder superclass when tkinter is unavailable."""


class PlaygroundApp(_TkBase):  # type: ignore[misc]
    """The playground window: one notebook, eight tabs, one worker."""

    def __init__(
        self, dependencies: dict[str, bool] | None = None, persist_session: bool = True
    ) -> None:
        """Build the window.

        ``persist_session`` switches the whole session machinery on or
        off: the real app reads ``~/.pharmaml/playground-session.json``
        at startup (restoring inputs, geometry, active tab and theme)
        and writes it back on close, while ``--self-test`` passes
        ``False`` so CI-style runs stay deterministic and never touch
        (let alone overwrite) a developer's saved session.
        """
        if tk is None:  # pragma: no cover - guarded by main()
            raise RuntimeError(
                "tkinter is not available in this Python build -- install the "
                "python3-tk system package (or use an official python.org build)"
            )
        super().__init__()
        self.deps = dependencies if dependencies is not None else probe_dependencies()
        self.pharmaml: Any = None
        self.pharmaml_error = ""
        try:
            self.pharmaml = load_pharmaml()
        except Exception as exc:  # noqa: BLE001 - degrade gracefully, never crash
            self.pharmaml_error = f"{type(exc).__name__}: {exc}"

        self._jobs: queue.Queue[tuple[str, Any, Any]] = queue.Queue()
        self._busy = False
        self._on_done: Callable[[Any], None] | None = None
        # -- progress + ETA plumbing (100x-106) ----------------------- #
        # Worker threads push (done, total, note) tuples here; the
        # ``_poll_progress`` after-loop drains them onto the status bar
        # (determinate progressbar + "~ 42 s left" in the job label).
        # Updates arriving while no job runs are dropped.
        self._progress_updates: queue.Queue[tuple[int, int | None, str]] = queue.Queue()
        self._job_started = 0.0
        self._job_label_base = ""
        self._action_buttons: list[Any] = []
        self._last_figure: Any = None
        # (100x-127) monotonically increasing render counter -- every
        # _render_figure stamps it on the host as ``_pg_figure_seq`` so a
        # card holding MORE than one figure host can export the figure
        # that drew LAST on that card (the Results card carries both the
        # leaderboard structure grid and the evolution history).
        self._figure_seq: int = 0
        # -- session figure registry (100x-122): one live entry per figure
        # host -- [host, title, figure].  _render_figure updates entries in
        # place (a re-rendered card replaces its figure; the old one is
        # closed), and File ▸ Save session report (PDF) walks it to compose
        # pharmaml.viz.save_pdf_report over everything on screen.
        self._session_figures: list[list] = []
        self._ml_frame: Any = None
        self._ml_path: Path | None = None
        # -- Data & ML report state (100x-76, extended 100x-79/118) -- #
        # (trained, report, task, X_train, y_train, X_test, y_test,
        # train_target) of the last successful train -- the Save-report
        # button rebuilds the CLI's bundle from it; the Check-CSV button
        # audits new data against it (the training target rides along as
        # the automatic --target drop); the applicability-domain card
        # reuses its split (X_train for the domain, X_test as the query
        # set -- 100x-118, the upload's workflow on the live run).
        self._ml_last_run: tuple[Any, Any, str, Any, Any, Any, Any, str] | None = None
        # -- Hyperparameter-search card state (100x-90) ------------- #
        # (TunerResults, estimator token, task, target column) of the
        # last search -- the Apply-best and Save-trials payloads.
        self._tune_last: tuple[Any, str, str, str] | None = None
        self._desc_frame: Any = None
        self._desc_rows: list[tuple[str, str, str]] = []
        self._ga_result: Any = None
        # -- Generative Pareto card state (100x-58) ------------------ #
        self._pareto_front: Any = None  # ParetoFront of the last run
        self._pareto_result: Any = None  # the GenerationResult it came from
        # -- Cell Lines tab state ----------------------------------- #
        self._bio_screen: Any = None  # ResponseScreen (maybe collapsed)
        self._bio_screen_path: Path | None = None
        self._bio_collapsed = False
        self._bio_matrix: Any = None  # cell line x compound DataFrame
        self._bio_matrix_metric: str | None = None
        self._bio_expr: Any = None  # raw expression frame
        self._bio_expr_norm: Any = None  # normalize + impute cache
        # -- Docking tab state --------------------------------------- #
        self._dock_library: Any = None  # LigandLibrary from the CSV
        self._dock_lib_path: Path | None = None
        self._dock_out_dir: Path | None = None  # ligand campaign output root
        self._dock_report: Any = None  # LigandPreparationReport
        self._dock_receptor_source: Path | None = None  # PDB / CIF / PDBQT in
        self._dock_protein_report: Any = None  # ProteinReport
        self._dock_receptor_path: Path | None = None  # prepared receptor out
        self._dock_ligand_path: Path | None = None  # reference ligand PDBQT
        self._dock_box: Any = None  # GridBox
        self._dock_results_frame: Any = None  # current results table
        self._dock_rescore_last: (
            tuple[Any, list[str], list[float] | None, dict[str, bool], str] | None
        ) = None
        # (rescored frame, evidence columns, weights, higher overrides,
        #  source label) — the Save report… payload
        self._dock_results_source: str | None = None  # campaign / dlg / vina / smiles
        self._dock_campaign_root: Path | None = None  # AutoDock4 batch root
        self._dock_vina_receptor: Path | None = None
        self._dock_vina_ligand: Path | None = None
        # -- SMILES array docking state (the one-call batch card) ---- #
        self._dock_smiles_receptor: Path | None = None  # picked receptor PDBQT
        self._dock_smiles_out: Path | None = None  # campaign output root
        self._dock_smiles_last: Any = None  # ranked DataFrame
        # -- Feature factory state (Chemistry tab) ------------------- #
        self._feat_frame: Any = None  # full computed feature frame
        self._feat_report: Any = None  # FeatureReport of the last run
        self._feat_selection: Any = None  # FeatureSelection of the last run
        self._feat_smiles: list[str] = []  # valid SMILES, frame row order
        self._feat_target_series: list[float] | None = None  # aligned target
        self._feat_target_name: str | None = None  # target column name (or None)
        self._feat_k: int = 0  # K requested by the last run
        self._feat_csv_frame: Any = None  # the loaded source CSV frame
        self._feat_csv_path: Path | None = None
        self._feat_smiles_column: str | None = None
        self._feat_descriptor_count: int = _FEATURE_DESCRIPTORS_FALLBACK
        # -- RISM-KH solvation card state ----------------------------- #
        self._rism_frame: Any = None  # last computed descriptor frame
        # -- Ensemble-builder + model-persistence state (ML tab) ------ #
        self._ml_bundle: tuple[Any, dict[str, Any], Path] | None = None
        self._ml_predictions: Any = None  # last bundle prediction frame
        # -- Applicability-domain card state (100x-118: the upload) --- #
        self._ml_ad_result: Any = None  # ApplicabilityDomainResult
        self._ml_ad_frame: Any = None  # its reliability table
        self._ml_ad_train_path: Path | None = None  # bundle-mode train CSV
        self._ml_ad_test_path: Path | None = None  # bundle-mode test CSV

        # -- session + theme state ------------------------------------- #
        self._persist_session = persist_session
        self._session: dict[str, Any] | None = None
        if persist_session:
            self._session = load_session(self._read_session_file())
        self._theme = self._session["theme"] if self._session else "light"
        self._theme_var: Any = None  # built by _build_menu (View menu)
        self._menu_tints: list[Any] = []  # menus to recolour on theme flip
        apply_theme(self._resolve_auto_theme() if self._theme == "auto" else self._theme)

        self.title("PharmaML Playground")
        self.configure(background=BG)
        self._setup_dpi()
        width, height = self._window_size(1180, 780)
        self.geometry(f"{width}x{height}")
        self.minsize(960, 620)

        self._setup_fonts()
        self._build_style()
        self._build_menu()
        self._build_statusbar()
        self._build_hintbar()
        self._build_tabs()
        # Per-tab reset support (100x-54): snapshot the freshly built
        # (default) inputs and which tab owns which input BEFORE the
        # session restore overwrites either of them.
        self._tab_input_owners = self._tab_input_names()
        self._session_defaults = self._collect_session()
        restored_geometry = self._restore_session()
        if not restored_geometry:
            self._center_on_screen(width, height)
        self.lift()
        self.attributes("-topmost", True)
        self.after(250, lambda: self.attributes("-topmost", False))
        self.after(80, self._poll_jobs)
        self.after(150, self._poll_progress)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # -- plumbing -------------------------------------------------------- #
    def _setup_dpi(self) -> None:
        """Ask Windows for crisp text on high-DPI screens."""
        if sys.platform == "win32":
            import ctypes

            with contextlib.suppress(Exception):
                ctypes.windll.shcore.SetProcessDpiAwareness(1)

    def _window_size(self, width: int, height: int) -> tuple[int, int]:
        screen_w = self.winfo_screenwidth()
        screen_h = self.winfo_screenheight()
        return min(width, screen_w - 40), min(height, screen_h - 90)

    def _center_on_screen(self, width: int, height: int) -> None:
        x = max(0, (self.winfo_screenwidth() - width) // 2)
        y = max(0, (self.winfo_screenheight() - height) // 3)
        self.geometry(f"+{x}+{y}")

    def _setup_fonts(self) -> None:
        fixed = tkfont.nametofont("TkFixedFont")
        fixed.configure(size=10)
        self._mono = fixed
        result_font = fixed.copy()
        result_font.configure(size=12, weight="bold")
        self._mono_result = result_font

    def _build_style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:  # pragma: no cover - exotic Tk builds
            pass
        style.configure(".", background=BG, foreground=INK)
        style.configure("TFrame", background=BG)
        style.configure("Tab.TFrame", background=BG)
        style.configure("Card.TFrame", background=CARD)
        style.configure(
            "CardTitle.TLabel", background=CARD, foreground=INK, font=("TkDefaultFont", 11, "bold")
        )
        style.configure(
            "CardMuted.TLabel", background=CARD, foreground=MUTED, font=("TkDefaultFont", 9)
        )
        style.configure("Field.TLabel", background=CARD, foreground=INK)
        style.configure("Result.TLabel", background=CARD, foreground=ACCENT_DARK)
        style.configure(
            "Title.TLabel", background=CARD, foreground=INK, font=("TkDefaultFont", 15, "bold")
        )
        style.configure(
            "Primary.TButton",
            background=ACCENT,
            foreground="#ffffff",
            borderwidth=0,
            focusthickness=1,
            focuscolor="#ffffff",
            padding=(16, 7),
            font=("TkDefaultFont", 10, "bold"),
        )
        style.map(
            "Primary.TButton",
            background=[("active", ACCENT_DARK), ("disabled", BUTTON_DISABLED)],
            foreground=[("disabled", BUTTON_DISABLED_INK)],
        )
        style.configure("TButton", padding=(10, 5), background=BUTTON_FACE, foreground=INK)
        style.map(
            "TButton",
            background=[("active", ACCENT_SOFT), ("disabled", BG)],
            foreground=[("disabled", MUTED)],
        )
        # the quiet tab-footer reset button (100x-55): flat on the page
        # background, muted until hovered -- an affordance, not an action
        style.configure(
            "Ghost.TButton",
            background=BG,
            foreground=MUTED,
            borderwidth=0,
            lightcolor=BG,
            darkcolor=BG,
            focusthickness=1,
            focuscolor=MUTED,
            padding=(8, 2),
            font=("TkDefaultFont", 9),
        )
        style.map(
            "Ghost.TButton",
            background=[("active", BG), ("disabled", BG)],
            foreground=[("active", ACCENT), ("disabled", BORDER)],
            lightcolor=[("pressed", BG)],
            darkcolor=[("pressed", BG)],
        )
        # the home tab's quick-jump chips (100x-119): flat pills that lift
        # to the accent on hover -- navigation, not actions
        style.configure(
            "Chip.TButton",
            background=TAB,
            foreground=INK,
            borderwidth=0,
            lightcolor=TAB,
            darkcolor=TAB,
            focusthickness=1,
            focuscolor=ACCENT,
            padding=(12, 4),
            font=("TkDefaultFont", 9, "bold"),
        )
        style.map(
            "Chip.TButton",
            background=[("active", ACCENT_SOFT), ("disabled", TAB)],
            foreground=[("active", ACCENT_DARK), ("disabled", MUTED)],
            lightcolor=[("pressed", BORDER)],
            darkcolor=[("pressed", BORDER)],
        )
        style.configure("TNotebook", background=BG, borderwidth=0, tabmargins=(10, 6, 12, 0))
        style.configure(
            "TNotebook.Tab",
            background=TAB,
            foreground=MUTED,
            padding=(16, 8),
            font=("TkDefaultFont", 10, "bold"),
        )
        style.map(
            "TNotebook.Tab", background=[("selected", CARD)], foreground=[("selected", ACCENT)]
        )
        style.configure(
            "Treeview",
            background=CARD,
            fieldbackground=CARD,
            foreground=INK,
            rowheight=26,
            borderwidth=0,
        )
        style.map(
            "Treeview", background=[("selected", ACCENT_SOFT)], foreground=[("selected", INK)]
        )
        style.configure(
            "Treeview.Heading",
            background=HEADING,
            foreground=INK,
            font=("TkDefaultFont", 9, "bold"),
            relief="flat",
        )
        style.configure(
            "TEntry",
            fieldbackground=CARD,
            bordercolor=BORDER,
            lightcolor=BORDER,
            darkcolor=BORDER,
            padding=4,
        )
        style.configure(
            "TCombobox",
            fieldbackground=CARD,
            background=CARD,
            arrowcolor=ACCENT,
            bordercolor=BORDER,
            padding=3,
        )
        style.configure(
            "TSpinbox", fieldbackground=CARD, bordercolor=BORDER, arrowcolor=ACCENT, padding=3
        )
        style.configure("TCheckbutton", background=CARD, foreground=INK, focuscolor=ACCENT)
        style.map("TCheckbutton", background=[("active", CARD)])
        style.configure(
            "Horizontal.TProgressbar",
            background=ACCENT,
            troughcolor=TAB,
            borderwidth=0,
            thickness=8,
        )
        style.configure("TProgressbar", background=ACCENT, troughcolor=TAB)
        style.configure("Status.TFrame", background=STATUS)
        style.configure(
            "Status.TLabel", background=STATUS, foreground=MUTED, font=("TkDefaultFont", 9)
        )
        # clam's state maps and trough colours ship full of light defaults
        # (readonly combobox fields, focus borders, pressed buttons,
        # scrollbar troughs).  ``style.map`` REPLACES the whole map for
        # each option, so this block pins every reachable state to the
        # active palette -- without it dark mode keeps bright stragglers.
        style.configure(
            "TScrollbar",
            troughcolor=TAB,
            background=BUTTON_FACE,
            arrowcolor=MUTED,
            lightcolor=BORDER,
            darkcolor=BORDER,
            bordercolor=BORDER,
        )
        style.map("TScrollbar", background=[("active", ACCENT_SOFT), ("pressed", ACCENT_SOFT)])
        style.configure("TEntry", insertcolor=INK)
        style.map(
            "TEntry",
            background=[("readonly", BG)],
            fieldbackground=[("readonly", CARD)],
            bordercolor=[("focus", ACCENT)],
        )
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", CARD)],
            foreground=[("readonly", INK)],
            bordercolor=[("focus", ACCENT)],
        )
        style.map(
            "TSpinbox",
            background=[("readonly", BG)],
            fieldbackground=[("readonly", CARD)],
            bordercolor=[("focus", ACCENT)],
        )
        style.map("TButton", darkcolor=[("pressed", BORDER)], lightcolor=[("pressed", BORDER)])
        style.map("Treeview", bordercolor=[("focus", BORDER)])
        for name in ("TEntry", "TCombobox", "TSpinbox"):
            style.configure(name, selectbackground=ACCENT_SOFT, selectforeground=INK)
        for key, value in (
            ("*TCombobox*Listbox.background", CARD),
            ("*TCombobox*Listbox.foreground", INK),
            ("*TCombobox*Listbox.selectBackground", ACCENT_SOFT),
            ("*TCombobox*Listbox.selectForeground", INK),
        ):
            self.option_add(key, value)

    def _build_menu(self) -> None:
        bar = tk.Menu(self)
        file_menu = tk.Menu(bar, tearoff=0)
        file_menu.add_command(label="Open CSV…", accelerator="Ctrl+O", command=self._menu_open_csv)
        file_menu.add_command(
            label="Save last figure…", accelerator="Ctrl+S", command=self._menu_save_figure
        )
        file_menu.add_command(
            label="Save session report (PDF)…", command=self._menu_save_session_report
        )
        # (100x-124) the portable twin -- pharmaml.viz.HTMLReport's first
        # caller anywhere: same two axes, metric cards, no fpdf needed.
        file_menu.add_command(
            label="Save session report (HTML)…", command=self._menu_save_session_report_html
        )
        file_menu.add_separator()
        file_menu.add_command(
            label="Save session now", accelerator="Ctrl+Shift+S", command=self._save_session_now
        )
        file_menu.add_command(label="Clear saved session…", command=self._clear_saved_session)
        file_menu.add_command(label="Export session…", command=self._export_session)
        file_menu.add_command(label="Import session…", command=self._import_session)
        file_menu.add_command(
            label="Reset current tab to defaults",
            accelerator="Ctrl+Shift+R",
            command=self._reset_current_tab,
        )
        file_menu.add_separator()
        file_menu.add_command(label="Exit", accelerator="Ctrl+Q", command=self._on_close)
        bar.add_cascade(label="File", menu=file_menu)

        view_menu = tk.Menu(bar, tearoff=0)
        # the card finder (100x-120): Ctrl+F, also bound below
        view_menu.add_command(
            label="Find a card…", accelerator="Ctrl+F", command=self._find_card_dialog
        )
        view_menu.add_separator()
        self._theme_var = tk.StringVar(value=self._theme)
        for label, value in (("Follow system", "auto"), ("Light", "light"), ("Dark", "dark")):
            view_menu.add_radiobutton(
                label=label, value=value, variable=self._theme_var, command=self._on_theme_change
            )
        # (100x-129) the radios pick more than the window's palette:
        # both session reports ride them (the HTML's initial data-theme
        # and the PDF's ink variant), so say so right under them -- a
        # disabled caption is the menu's own quiet affordance.
        view_menu.add_command(
            label="(both session reports save in this theme)",
            state="disabled",
        )
        # Shortcut-hint row visibility (100x-65): a plain tk.Variable, so
        # the generic session machinery persists it for free.
        self._hints_var = tk.BooleanVar(value=True)
        view_menu.add_checkbutton(
            label="Shortcut hints", variable=self._hints_var, command=self._apply_hint_visibility
        )
        bar.add_cascade(label="View", menu=view_menu)

        help_menu = tk.Menu(bar, tearoff=0)
        help_menu.add_command(label="About PharmaML Playground", command=self._show_about)
        help_menu.add_command(label="Dependency report", command=self._show_dependency_report)
        bar.add_cascade(label="Help", menu=help_menu)
        self.configure(menu=bar)
        self._menu_tints = [bar, file_menu, view_menu, help_menu]
        self._tint_menus()
        self.bind_all("<Control-o>", lambda _e: self._menu_open_csv())
        self.bind_all("<Control-s>", lambda _e: self._menu_save_figure())
        self.bind_all("<Control-Shift-S>", lambda _e: self._save_session_now())
        # 100x-65: the menu (and the docstring) had advertised Ctrl+Shift+R
        # since 100x-54, but no binding ever existed -- pressing it did
        # nothing.  Bound now, and the test suite pins the whole set.
        self.bind_all("<Control-Shift-R>", lambda _e: self._reset_current_tab())
        # 100x-120: the card finder -- bound and advertised in the hint
        # row together with the rest of the accelerators.
        self.bind_all("<Control-f>", lambda _e: self._find_card_dialog())
        self.bind_all("<Control-q>", lambda _e: self._on_close())

    def _build_statusbar(self) -> None:
        bar = ttk.Frame(self, style="Status.TFrame", padding=(12, 5))
        bar.pack(side="bottom", fill="x")
        self._status_bar = bar  # pinned so tests can order hint row vs bar
        if self.pharmaml is not None:
            left = f"pharmaml {self.pharmaml.__version__} · toolkit v{__version__}"
        else:
            left = (
                "pharmaml not loaded -- run from the toolkit root or "
                f"pip install -e . · toolkit v{__version__}"
            )
        ttk.Label(bar, text=left, style="Status.TLabel").pack(side="left")
        self._job_label = ttk.Label(bar, text="idle", style="Status.TLabel")
        self._job_label.pack(side="right", padx=(12, 0))
        self._progress = ttk.Progressbar(bar, mode="indeterminate", length=130)
        self._progress.pack(side="right")

    def _build_hintbar(self) -> None:
        """The keyboard-shortcut hint row (100x-65), above the status bar.

        One quiet line listing every global accelerator, so the bindings
        are discoverable without opening a menu.  ``View \u25b8 Shortcut
        hints`` (or the row's own ``Hide`` button) toggles it; the
        preference is a plain ``tk.Variable`` on ``self``, so the session
        machinery saves and restores it like any other input.  Packed
        ``side="bottom"`` AFTER the status bar claimed the bottom edge,
        which pins it directly above the status line.
        """
        bar = ttk.Frame(self, style="Status.TFrame", padding=(12, 2))
        label = ttk.Label(bar, text=shortcut_hints_text(), style="Status.TLabel")
        label.pack(side="left")
        Tooltip(
            label,
            "The global keyboard shortcuts, also listed in the File "
            "menu.  View \u25b8 Shortcut hints re-enables this row "
            "after hiding it (the preference is saved with the "
            "session).",
        )
        hide = ttk.Button(bar, text="Hide", style="Ghost.TButton", command=self._hide_hints)
        hide.pack(side="right", padx=(12, 0))
        Tooltip(hide, "Hide the shortcut hint row (View \u25b8 Shortcut hints brings it back).")
        self._hint_bar = bar
        bar.pack(side="bottom", fill="x")
        self._apply_hint_visibility()

    def _apply_hint_visibility(self) -> None:
        """Show/hide the hint row to match :attr:`_hints_var`."""
        bar = getattr(self, "_hint_bar", None)
        if bar is None:
            return
        if self._hints_var.get():
            bar.pack(side="bottom", fill="x")
        else:
            bar.pack_forget()

    def _hide_hints(self) -> None:
        """The hint row's own Hide button -- flip the preference off."""
        self._hints_var.set(False)
        self._apply_hint_visibility()

    def _build_tabs(self) -> None:
        self._book = ttk.Notebook(self)
        self._book.pack(fill="both", expand=True, padx=10, pady=(10, 4))
        self._build_home_tab()
        self._build_chemistry_tab()
        self._build_pk_tab()
        self._build_cellline_tab()
        self._build_docking_tab()
        self._build_ml_tab()
        self._build_dl_tab()
        self._build_generative_tab()
        self._build_utilities_tab()
        # keyboard tab cycling (100x-119): Ctrl+PgDn / Ctrl+PgUp walk the
        # notebook without reaching for the mouse
        self.bind("<Control-Next>", self._cycle_tab)
        self.bind("<Control-Prior>", self._cycle_tab)

    def _cycle_tab(self, event: Any) -> str:
        """Ctrl+PgDn / Ctrl+PgUp -- select the next / previous tab."""
        try:
            count = self._book.index("end")
            current = self._book.index(self._book.select())
        except tk.TclError:  # pragma: no cover - no tab selected yet
            return "break"
        step = 1 if str(event.keysym) == "Next" else -1
        self._book.select((current + step) % count)
        return "break"

    def _jump_to_tab(self, index: int) -> None:
        """Select a tab by index (the home tab's quick-jump chips)."""
        try:
            if 0 <= index < self._book.index("end"):
                self._book.select(index)
        except tk.TclError:  # pragma: no cover - no tab selected yet
            pass

    # -- the Ctrl+F card finder (100x-120) ----------------------------- #
    def _card_tab_index(self, shell: Any, pages: list[Any]) -> int | None:
        """Resolve which tab page a card shell descends from."""
        node: Any = shell
        while node is not None:
            for index, page in enumerate(pages):
                if node is page:
                    return index
            try:
                node = node.master
            except tk.TclError:  # a destroyed ancestor
                return None
        return None

    def _live_cards(self) -> list[tuple[str, str, Any, int]]:
        """The card index filtered to shells of THIS app's live tabs."""
        try:
            pages = [self._book.nametowidget(tab) for tab in self._book.tabs()]
        except tk.TclError:  # pragma: no cover - no notebook yet
            return []
        live: list[tuple[str, str, Any, int]] = []
        for title, subtitle, shell in _CARD_INDEX:
            try:
                if not bool(shell.winfo_exists()):
                    continue
            except tk.TclError:
                continue
            index = self._card_tab_index(shell, pages)
            if index is not None:
                live.append((title, subtitle, shell, index))
        return live

    def _finder_remember(self, title: str) -> None:
        """Record a card jump for the finder's recency row (100x-130).

        Most-recent-first, de-duplicated, capped at
        ``_FINDER_RECENT_MAX`` entries -- the same honest memory the
        web twin's finder gained this round, persisted with the session
        (``finder_recent`` text key, JSON-encoded).
        """
        recent = [t for t in getattr(self, "_finder_recent", []) if t != title]
        recent.insert(0, title)
        self._finder_recent = recent[:_FINDER_RECENT_MAX]

    def _find_card_dialog(self) -> None:
        """Ctrl+F -- a live card finder over every tab (100x-120).

        Typing filters the card index on title + subtitle; Enter (or a
        double-click) selects the card's tab, scrolls the card into
        view and flashes its border -- a 60-card window becomes
        navigable without hunting through tabs.

        (100x-130) A "Recently jumped" chip row rides under the query:
        one click returns to the cards you keep visiting, without
        retyping (the memory is de-duplicated, capped and persisted
        with the session -- restarting the app keeps it).

        (100x-131) The row carries its own "Clear" ghost button: one
        click forgets every remembered jump (the session-persisted
        ``finder_recent`` key too) and the row collapses in place --
        the honest empty, no re-open needed.  The web twin's finder
        row gained the same affordance (localStorage-backed).
        """
        if tk is None:  # pragma: no cover - headless import
            return
        win = tk.Toplevel(self)
        win.title("Find a card")
        win.configure(background=BG)
        win.transient(self)
        try:
            win.geometry(f"+{self.winfo_rootx() + 140}+{self.winfo_rooty() + 110}")
        except tk.TclError:  # pragma: no cover - unmapped parent
            pass
        ttk.Label(
            win,
            text="Type words from a card's title or subtitle — Enter jumps to it.",
            style="CardMuted.TLabel",
        ).pack(anchor="w", padx=14, pady=(12, 4))
        entry = ttk.Entry(win, width=54)
        # 100x-121: the finder remembers its last query -- prefilled here,
        # persisted with the session ("finder" text key).
        last_query = getattr(self, "_finder_last_query", "")
        if last_query:
            entry.insert(0, last_query)
        entry.pack(fill="x", padx=14, pady=(0, 8))

        def jump_title(title: str) -> None:
            """Chip shortcut: jump straight to a remembered card."""
            for card_title, _subtitle, _shell, index in self._live_cards():
                if card_title == title:
                    self._jump_to_card(index, title)
                    win.destroy()
                    return

        # (100x-130) the recency row -- one chip per recently jumped
        # card, filtered to the cards that are live RIGHT NOW (a
        # remembered title whose shell vanished is honestly omitted,
        # never a dead button).  (100x-131) the row carries its own
        # "Clear" ghost button: one click empties the memory (the
        # session-persisted ``finder_recent`` key too) and the row
        # collapses in place -- the honest empty, no re-open needed.
        recent_titles = [
            title
            for title in getattr(self, "_finder_recent", [])
            if any(card_title == title for card_title, _s, _sh, _i in self._live_cards())
        ]
        if recent_titles:
            recent_row = ttk.Frame(win, style="Card.TFrame")
            recent_row.pack(fill="x", padx=14, pady=(0, 6))
            ttk.Label(
                recent_row, text="Recently jumped:", style="CardMuted.TLabel"
            ).pack(side="left")
            chips = ttk.Frame(recent_row, style="Card.TFrame")
            chips.pack(side="left", padx=(8, 0))
            for title in recent_titles:
                chip = ttk.Button(
                    chips,
                    text=_truncate_caption_text(title, 24),
                    style="Ghost.TButton",
                    command=lambda remembered=title: jump_title(remembered),
                )
                chip.pack(side="left", padx=(4, 0))
                Tooltip(
                    chip,
                    f"Jump back to {title} -- one of your most recent "
                    "finder jumps (the row remembers up to "
                    f"{_FINDER_RECENT_MAX}, newest first).",
                )

            def clear_recent() -> None:
                """Forget every remembered jump (the row's Clear button)."""
                self._finder_recent = []
                recent_row.destroy()

            clear_button = ttk.Button(
                recent_row,
                text="Clear",
                style="Ghost.TButton",
                command=clear_recent,
            )
            clear_button.pack(side="right", padx=(8, 0))
            Tooltip(
                clear_button,
                "Forget every remembered jump -- the row disappears "
                "until you land on cards again (also clears the "
                "session-persisted memory).",
            )

        tree = ttk.Treeview(win, columns=("card", "tab"), show="headings", height=12)
        tree.heading("card", text="card")
        tree.heading("tab", text="tab")
        tree.column("card", width=360)
        tree.column("tab", width=130)
        tree.pack(fill="both", expand=True, padx=14, pady=(0, 4))
        ttk.Label(
            win, text="Enter jump · double-click jump · Esc close", style="CardMuted.TLabel"
        ).pack(anchor="w", padx=14, pady=(0, 10))

        def refresh() -> None:
            query = entry.get().strip().lower()
            self._finder_last_query = entry.get().strip()
            tree.delete(*tree.get_children())
            for title, subtitle, _shell, index in self._live_cards():
                haystack = f"{title} {subtitle}".lower()
                if query and not all(word in haystack for word in query.split()):
                    continue
                try:
                    tab_name = str(self._book.tab(index, "text")).strip()
                except tk.TclError:  # pragma: no cover - tab vanished
                    continue
                tree.insert("", "end", values=(title, tab_name), iid=f"{index}:{title}")

        def jump(item: str | None = None) -> None:
            picked = item or (tree.selection() or [None])[0]
            if not picked:
                return
            index = int(str(picked).split(":", 1)[0])
            title = str(picked).split(":", 1)[1]
            self._jump_to_card(index, title)
            win.destroy()

        entry.bind("<KeyRelease>", lambda _e: refresh())
        entry.bind("<Return>", lambda _e: jump())
        tree.bind("<Double-1>", lambda e: jump(tree.identify_row(e.y)))
        win.bind("<Escape>", lambda _e: win.destroy())
        refresh()
        entry.focus_set()

    def _jump_to_card(self, tab_index: int, title: str) -> None:
        """Select the tab, scroll the card into view and flash it.

        (100x-130) Every jump is remembered for the finder's recency
        row -- the desktop twin of the web finder's own memory, so the
        cards you keep visiting stay one click away.
        """
        self._jump_to_tab(tab_index)
        self._finder_remember(title)
        self.update_idletasks()
        for entry_title, _subtitle, shell in _CARD_INDEX:
            if entry_title != title:
                continue
            try:
                if not bool(shell.winfo_exists()):
                    continue
            except tk.TclError:
                continue
            if (
                self._card_tab_index(
                    shell, [self._book.nametowidget(tab) for tab in self._book.tabs()]
                )
                != tab_index
            ):
                continue
            page = self._book.nametowidget(self._book.tabs()[tab_index])
            canvas = getattr(page, "_canvas", None)
            if canvas is not None:
                body_height = int(page.body.winfo_reqheight() or 1)
                fraction = max(0.0, min(0.99, (shell.winfo_y() - 12) / max(1, body_height)))
                canvas.yview_moveto(fraction)
            shell.configure(highlightbackground=ACCENT, highlightthickness=3)
            self.after(1200, lambda s=shell: self._unflash_card(s))
            break

    def _unflash_card(self, shell: Any) -> None:
        """Restore a flashed card's border (the finder's highlight)."""
        with contextlib.suppress(tk.TclError):
            if bool(shell.winfo_exists()):
                shell.configure(highlightbackground=BORDER, highlightthickness=1)

    def _new_page(self, title: str, reset: bool = True) -> Any:
        page = ScrollFrame(self._book)
        grid = ttk.Frame(page.body, style="Tab.TFrame")
        grid.pack(fill="both", expand=True)
        grid.columnconfigure(0, weight=1, uniform="cards")
        grid.columnconfigure(1, weight=1, uniform="cards")
        page.grid = grid  # type: ignore[attr-defined]
        self._book.add(page, text=f"  {title}  ")
        if reset:
            # per-tab reset button (100x-55): the ownership map is keyed
            # by tab index, and add() just appended this page -- its index
            # is the last one.  Pinned in the non-scrolling footer so it
            # stays reachable without scrolling back up.
            index = len(self._book.tabs()) - 1
            button = ttk.Button(
                page.footer,
                text="Reset this tab to defaults",
                style="Ghost.TButton",
                command=lambda idx=index: self._reset_tab(idx),
            )
            button.pack(side="right", padx=(0, 14), pady=(4, 5))
            Tooltip(
                button,
                "Restore only THIS tab's inputs to their launch "
                "defaults -- every other tab keeps its live "
                "values (same as File \u25b8 Reset current tab).",
            )
            # per-tab copy button (100x-60): the same ownership map, read
            # LIVE -- a share-lite JSON snippet of this tab's inputs on
            # the clipboard (paste into an issue, a script, or a message).
            copy_button = ttk.Button(
                page.footer,
                text="Copy inputs as JSON",
                style="Ghost.TButton",
                command=lambda idx=index: self._copy_tab_inputs(idx),
            )
            copy_button.pack(side="right", padx=(0, 6), pady=(4, 5))
            Tooltip(
                copy_button,
                "Copy THIS tab's live inputs as a JSON snippet -- the "
                "same fields the session file stores, for one tab. "
                "Paste it into an issue report or a colleague's "
                "import (File \u25b8 Import session takes full files).",
            )
        return page

    def _action_button(
        self,
        parent: Any,
        text: str,
        command: Callable[[], None],
        tooltip: str = "",
        primary: bool = False,
    ) -> Any:
        button = ttk.Button(
            parent, text=text, command=command, style="Primary.TButton" if primary else "TButton"
        )
        if tooltip:
            Tooltip(button, tooltip)
        self._action_buttons.append(button)
        return button

    def _show_error(self, title: str, exc: BaseException) -> None:
        detail = f"{type(exc).__name__}: {exc}"
        print(detail, file=sys.stderr)
        messagebox.showerror(title, detail)

    def _require(self, module: str, feature: str) -> bool:
        """Gate a feature on a probed dependency with an install hint."""
        if self.deps.get(module):
            return True
        pip_hint = next(hint for name, _l, _p, hint in _DEPENDENCIES if name == module)
        messagebox.showwarning(
            f"{feature} needs {module}",
            f"{feature} needs the {module} package, which is not installed.\n\n"
            f"    pip install {pip_hint}\n\n"
            "Install it, then restart the playground.",
        )
        return False

    def _require_pharmaml(self) -> bool:
        if self.pharmaml is not None:
            return True
        messagebox.showerror("pharmaml not loaded", _PHARMAML_HINT)
        return False

    def _start_job(
        self, label: str, work: Callable[..., Any], on_done: Callable[[Any], None] | None = None
    ) -> None:
        """Run ``work`` in a worker thread; render via ``on_done``.

        Progress (100x-106): a ``work`` that *accepts an argument*
        receives a reporter callable to push ``(done, total, note)``
        updates -- the status bar then switches from the marquee to a
        determinate bar carrying the fraction and a live "~ x left"
        ETA (see :meth:`_poll_progress`).  Zero-argument ``work``
        functions keep the historical indeterminate marquee.
        """
        if self._busy:
            messagebox.showinfo(
                "Busy",
                "Another calculation is still running -- please wait for it.",
            )
            return
        self._busy = True
        self._on_done = on_done
        for button in self._action_buttons:
            if button.winfo_exists():
                button.state(["disabled"])
        self._job_label_base = label
        self._job_started = time.monotonic()
        with contextlib.suppress(queue.Empty):
            while True:  # stale updates from a previous job never leak
                self._progress_updates.get_nowait()
        self._progress.start(12)
        self._job_label.configure(text=label)

        def runner() -> None:
            try:
                self._jobs.put((_call_work(work, self._report_progress), None))
            except BaseException as exc:  # noqa: BLE001 - surfaced in the UI
                self._jobs.put((None, exc))

        threading.Thread(target=runner, name="playground-job", daemon=True).start()

    def _report_progress(self, done: int, total: int | None = None, note: str = "") -> None:
        """Worker-thread progress feed (thread-safe: queue → poller).

        Called from inside ``work`` for every completed unit -- a tuner
        trial, a training epoch, a leaderboard model -- with the unit
        count, the total (``None`` for open-ended work) and an optional
        note rendered after the fraction.  Only the latest update is
        shown; the poller coalesces bursts.
        """
        self._progress_updates.put((int(done), total, note))

    def _poll_progress(self) -> None:
        """Drain progress updates into the status bar (bar + ETA).

        Coalesces everything queued into the newest update, then
        renders it: a determinate bar at ``done / total`` and a job
        label like ``tuning ann (regression) — 3/8 · ~45 s left · best
        0.712``.  The ETA extrapolates the elapsed/fraction ratio;
        total-less updates degrade to a plain counter.  Updates that
        arrive while no job is running (late stragglers) are dropped.
        """
        latest: tuple[int, int | None, str] | None = None
        with contextlib.suppress(queue.Empty):
            while True:
                latest = self._progress_updates.get_nowait()
        if latest is not None and self._busy:
            done, total, note = latest
            elapsed = max(time.monotonic() - self._job_started, 1e-9)
            text = self._job_label_base
            if total is not None and total > 0:
                fraction = min(done / total, 1.0)
                with contextlib.suppress(tk.TclError):
                    self._progress.stop()
                    self._progress.configure(mode="determinate", maximum=total)
                    self._progress["value"] = done
                text += f" — {done}/{total}"
                if fraction > 0.0:
                    remaining = elapsed * (1.0 - fraction) / fraction
                    text += f" · ~{_fmt_duration(remaining)} left"
            else:
                text += f" — {done}"
            if note:
                text += f" · {note}"
            with contextlib.suppress(tk.TclError):
                self._job_label.configure(text=text)
        self.after(150, self._poll_progress)

    def _poll_jobs(self) -> None:
        try:
            result, error = self._jobs.get_nowait()
        except queue.Empty:
            self.after(80, self._poll_jobs)
            return
        self._busy = False
        self._progress.stop()
        with contextlib.suppress(tk.TclError):
            # back to the launch-time marquee for the next job: the
            # determinate mode a progress-reporting job switched to is
            # per-job state, never a permanent UI change.
            self._progress.configure(mode="indeterminate")
            self._progress["value"] = 0
        with contextlib.suppress(queue.Empty):
            while True:  # late progress stragglers never leak either
                self._progress_updates.get_nowait()
        # the 100x-119 UI pass: a finished job reports what it was and
        # how long it took (the label reverts to "idle" only when the
        # next job starts)
        elapsed = time.monotonic() - self._job_started
        label = getattr(self, "_job_label_base", "") or "job"
        if error is not None:
            self._job_label.configure(text=f"{label} FAILED after {_fmt_duration(elapsed)}")
        else:
            self._job_label.configure(text=f"{label} — done in {_fmt_duration(elapsed)}")
        for button in self._action_buttons:
            if button.winfo_exists():
                button.state(["!disabled"])
        if error is not None:
            traceback.print_exception(type(error), error, error.__traceback__)
            messagebox.showerror("Calculation failed", f"{type(error).__name__}: {error}")
        elif self._on_done is not None:
            try:
                self._on_done(result)
            except Exception as exc:  # noqa: BLE001 - render errors are ours
                self._show_error("Could not display the result", exc)
        self._on_done = None
        self.after(80, self._poll_jobs)

    def report_callback_exception(self, exc: Any, val: Any, tb: Any) -> None:
        """Route Tk callback crashes to the console and a dialog."""
        traceback.print_exception(exc, val, tb)
        messagebox.showerror("Unexpected error", f"{type(val).__name__}: {val}")

    def _copy(self, text: str) -> None:
        self.clipboard_clear()
        self.clipboard_append(text)
        self._job_label.configure(text="copied to clipboard")
        self.after(1400, lambda: self._job_label.configure(text="busy…" if self._busy else "idle"))

    def _close_embedded(self, host: Any) -> None:
        figure = getattr(host, "_pg_figure", None)
        if figure is None:
            return
        with contextlib.suppress(Exception):
            from pharmaml.viz import close_figure

            close_figure(figure)
        host._pg_figure = None

    def _figure_canvas_class(self) -> Any:
        """Return ``FigureCanvasTkAgg`` once, or None when it cannot load."""
        global _FIGURE_CANVAS, _FIGURE_CANVAS_PROBED
        if not _FIGURE_CANVAS_PROBED:
            _FIGURE_CANVAS_PROBED = True
            try:
                from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

                _FIGURE_CANVAS = FigureCanvasTkAgg
            except ImportError:
                print(
                    "note: the TkAgg acceleration could not load on this Python "
                    "build -- figures render as PNG instead (fully functional)."
                )
                _FIGURE_CANVAS = None
        return _FIGURE_CANVAS

    def _render_figure(self, host: Any, figure: Any) -> None:
        """Embed a matplotlib figure into ``host`` (replacing any prior one).

        Prefers the live TkAgg canvas; when the TkAgg acceleration cannot
        load (some Tcl 9 builds), falls back to rendering the figure with
        the Agg backend and displaying the PNG directly -- same figures,
        every machine.  (100x-122) every render also feeds the session
        figure registry the File ▸ Save session report walks.
        """
        self._register_session_figure(host, figure)
        self._close_embedded(host)
        for child in host.winfo_children():
            child.destroy()
        canvas_cls = self._figure_canvas_class()
        if canvas_cls is not None:
            canvas = canvas_cls(figure, master=host)
            canvas.draw()
            widget = canvas.get_tk_widget()
            widget.configure(background=CARD, highlightthickness=0)
            widget.pack(fill="both", expand=True)
            self._figure_seq += 1
            host._pg_figure_seq = self._figure_seq
            host._pg_figure = figure
            self._last_figure = figure
            return
        import io

        buffer = io.BytesIO()
        figure.savefig(buffer, format="png", dpi=110, facecolor=CARD)
        data = buffer.getvalue()
        photo = tk.PhotoImage(data=data)
        # (100x-123) the PNG fallback cannot REDRAW like the TkAgg canvas
        # does, so an oversize raster used to show only its middle band
        # (the round-123 surgery grids were 385-682 px tall in 260 px
        # hosts -- the VLM screenshot review caught the clipping).  Fit
        # the whole figure instead: resample to the host's real box with
        # PIL (aspect kept, LANCZOS); without PIL the old behaviour
        # stands (matplotlib always depends on Pillow, so in practice
        # the resample always runs).
        try:
            from PIL import Image

            host.update_idletasks()
            box_w = max(int(host.winfo_width()), 100)
            box_h = max(int(host.winfo_height()), 100)
            with Image.open(io.BytesIO(data)) as raster:
                if raster.width > box_w or raster.height > box_h:
                    scale = min(box_w / raster.width, box_h / raster.height)
                    resample = getattr(Image, "Resampling", Image).LANCZOS
                    resized = raster.resize(
                        (
                            max(1, int(raster.width * scale)),
                            max(1, int(raster.height * scale)),
                        ),
                        resample,
                    )
                    out = io.BytesIO()
                    resized.save(out, format="PNG")
                    photo = tk.PhotoImage(data=out.getvalue())
        except Exception:  # noqa: BLE001 - keep the unscaled raster
            photo = tk.PhotoImage(data=data)
        label = tk.Label(host, image=photo, background=CARD)
        label.pack(fill="both", expand=True)
        label._pg_photo = photo  # keep a reference -- Tk frees unreferenced images
        self._figure_seq += 1
        host._pg_figure_seq = self._figure_seq
        host._pg_figure = figure
        self._last_figure = figure

    def _figure_host(self, parent: Any, height: int = 330) -> Any:
        """A reserved white area (grid-managed) that figures embed into."""
        host = tk.Frame(parent, background=CARD, height=height)
        grid_append(parent, host, sticky="nsew", pady=(6, 0), weight=True)
        host.pack_propagate(False)
        return host

    def _register_session_figure(self, host: Any, figure: Any) -> None:
        """Track one live ``(title, figure)`` per host for the session report.

        Called from :meth:`_render_figure` BEFORE the prior figure is
        closed: an existing host entry is replaced in place (order kept --
        the report reads top-of-session first), a new host appends.  The
        title is the running job's label, the honest provenance of what
        drew the figure.
        """
        title = self._job_label_base or "figure"
        for entry in self._session_figures:
            if entry[0] is host:
                entry[1] = title
                entry[2] = figure
                return
        self._session_figures.append([host, title, figure])

    def _live_session_figures(self) -> list[list]:
        """Registry entries whose host AND figure are both still alive."""
        live: list[list] = []
        for entry in self._session_figures:
            host, _title, figure = entry
            if not host.winfo_exists():
                continue  # the card's tab was rebuilt (defensive)
            if getattr(host, "_pg_figure", None) is not figure:
                continue  # superseded inside the host (defensive)
            live.append(entry)
        return live

    def _card_title_for_widget(self, widget: Any) -> str | None:
        """The card title of the nearest registered shell above ``widget``.

        (100x-123) Walks the parent chain until a :data:`_CARD_INDEX`
        shell matches; widgets that live outside every card (the finder
        dialog's tree, the root itself) return ``None`` and are skipped
        by the table walk.
        """
        node = widget
        while node is not None:
            for title, _subtitle, shell in _CARD_INDEX:
                if shell is node:
                    return title
            node = getattr(node, "master", None)
        return None

    def _live_session_tables(self) -> list[tuple[str, list[str], list[list[str]]]]:
        """Every filled table on screen: ``(title, headings, rows)``.

        (100x-123) The report's table axis -- the figure registry's twin.
        Instead of registering at fill time (15+ scattered sites), the
        walk discovers every live :class:`ttk.Treeview` with rows and
        derives its provenance from the card index.  Trees outside any
        card (the finder dialog) are skipped; empty trees are skipped
        (an unfilled card has nothing to report).  Hierarchical trees
        (``show`` includes ``tree``) contribute their ``#0`` label as
        the first column, the same way the user reads them.
        """
        collected: list[tuple[str, list[str], list[list[str]]]] = []

        def visit(widget: Any) -> None:
            try:
                children = widget.winfo_children()
            except tk.TclError:
                return  # a destroyed intermediate (defensive)
            for child in children:
                if isinstance(child, ttk.Treeview):
                    rows = list(child.get_children())
                    if rows:
                        title = self._card_title_for_widget(child)
                        if title:
                            shows = [str(token) for token in child.cget("show")]
                            hierarchical = "tree" in shows
                            headings: list[str] = []
                            if hierarchical:
                                headings.append(str(child.heading("#0", "text") or "item"))
                            headings.extend(
                                str(child.heading(column, "text") or str(column))
                                for column in child["columns"]
                            )
                            data: list[list[str]] = []
                            for iid in rows:
                                values = [str(value) for value in child.item(iid, "values")]
                                if hierarchical:
                                    values.insert(0, str(child.item(iid, "text")))
                                data.append(values)
                            collected.append((title, headings, data))
                visit(child)

        visit(self)
        return collected

    # -- session + theme ------------------------------------------------- #
    def _read_session_file(self) -> Any:
        """Parse the session file, or ``None`` when absent/corrupt."""
        try:
            with session_path().open("r", encoding="utf-8") as handle:
                return json.load(handle)
        except FileNotFoundError:
            return None
        except (OSError, ValueError):
            return None

    def _resolve_auto_theme(self) -> str:
        """Map ``"auto"`` onto light/dark using the OS preference (Tk 8.6.13+).

        Anything the interpreter cannot answer (older Tk, Linux) falls
        back to light -- the palette the window was designed around.
        """
        with contextlib.suppress(Exception):
            if bool(self.tk.call("tk", "dark")):
                return "dark"
        return "light"

    def _on_theme_change(self) -> None:
        """View-menu callback: flip the palette across the live window."""
        choice = self._theme_var.get()
        self._theme = choice if choice in _THEMES else "light"
        self._set_theme(self._resolve_auto_theme() if self._theme == "auto" else self._theme)

    def _set_theme(self, resolved: str) -> None:
        """Apply a resolved palette and recolour every live widget."""
        previous = _PALETTES[_ACTIVE_THEME]
        apply_theme(resolved)
        self.configure(background=BG)
        self._build_style()
        self._tint_menus()
        self._retint_plain_widgets(previous)

    def _tint_menus(self) -> None:
        """Recolour the menu bar for the active palette."""
        for menu in self._menu_tints:
            with contextlib.suppress(tk.TclError):
                menu.configure(
                    background=HEADING if _ACTIVE_THEME == "dark" else CARD,
                    foreground=INK,
                    activebackground=ACCENT_SOFT,
                    activeforeground=INK,
                )

    def _retint_plain_widgets(self, previous: dict[str, str]) -> None:
        """Walk the widget tree recolouring plain ``tk`` widgets.

        Only widgets still carrying a colour from the *previous* palette
        are touched, which is what keeps matplotlib's white figure
        canvases (also ``Canvas``/white in light mode) safely alone: the
        scroll canvases use ``BG``, never ``CARD``.
        """

        def walk(widget: Any) -> None:
            for child in widget.winfo_children():
                klass = child.winfo_class()
                try:
                    if klass == "Frame":
                        if str(child.cget("background")) == previous["CARD"]:
                            child.configure(background=CARD)
                        if str(child.cget("background")) == previous["ACCENT"]:
                            # the card headers' 3px accent strips (100x-119)
                            child.configure(background=ACCENT)
                        if str(child.cget("highlightbackground")) == previous["BORDER"]:
                            child.configure(highlightbackground=BORDER)
                    elif klass == "Canvas":
                        if str(child.cget("background")) == previous["BG"]:
                            child.configure(background=BG)
                    elif klass == "Text":
                        if str(child.cget("background")) == previous["CARD"]:
                            child.configure(background=CARD, foreground=INK)
                except tk.TclError:  # pragma: no cover - exotic widgets
                    pass
                walk(child)

        walk(self)

    def _collect_session(self) -> dict[str, Any]:
        """Snapshot every input on every tab into a session payload."""
        variables: dict[str, Any] = {}
        for name, value in sorted(vars(self).items()):
            if name.startswith("_book") or name == "_theme_var":
                continue  # transient bookkeeping, not user input
            if isinstance(value, tk.Variable):
                with contextlib.suppress(tk.TclError):
                    variables[name] = value.get()
            elif isinstance(value, ttk.Entry):  # covers Spinbox/Combobox
                variables[name] = value.get()
        families = {family: bool(var.get()) for family, var in self._feat_family_vars.items()}
        texts = {
            "pasted": self._feat_pasted_text.get("1.0", "end-1c"),
            "corpus": self._corpus_text.get("1.0", "end-1c"),
            "smiles": self._dock_smiles_text.get("1.0", "end-1c"),
            "rism": self._rism_text.get("1.0", "end-1c"),
            "maccs": self._maccs_text.get("1.0", "end-1c"),
            "scan_refs": self._scan_ref_text.get("1.0", "end-1c"),
            "scan_lib": self._scan_lib_text.get("1.0", "end-1c"),
            # 100x-121: the Ctrl+F card finder's last query -- a plain
            # string (restored into the attribute, not a Text widget).
            "finder": getattr(self, "_finder_last_query", ""),
            # 100x-130: the finder's recency row -- a JSON-encoded list
            # of card titles (texts values are coerced to str, so the
            # list rides as JSON; the restore path parses tolerantly).
            "finder_recent": json.dumps(getattr(self, "_finder_recent", [])),
        }
        try:
            tab = self._book.index(self._book.select())
        except tk.TclError:  # pragma: no cover - no tab selected yet
            tab = 0
        return dump_session(
            theme=self._theme,
            geometry=self.geometry(),
            tab=tab,
            variables=variables,
            families=families,
            texts=texts,
        )

    def _write_session_file(self) -> bool:
        """Persist the current session; ``True`` when the file landed."""
        try:
            path = session_path()
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("w", encoding="utf-8") as handle:
                json.dump(self._collect_session(), handle, indent=2)
            return True
        except (OSError, TypeError, ValueError):
            return False

    def _save_session_now(self) -> None:
        """File ▸ Save session now -- write immediately and report."""
        if not self._persist_session:
            return
        if self._write_session_file():
            self._job_label.configure(text=f"session saved · {session_path()}")
        else:
            self._job_label.configure(text="session NOT saved (path unwritable)")

    def _clear_saved_session(self) -> None:
        """File ▸ Clear saved session -- forget the stored inputs."""
        if not self._persist_session:
            return
        removed = False
        with contextlib.suppress(OSError):
            session_path().unlink()
            removed = True
        self._session = None
        if messagebox is not None:
            messagebox.showinfo(
                "Session cleared",
                "The saved session was removed.\nFresh defaults return on the next launch."
                if removed
                else "No saved session file existed.",
            )

    def _export_session(self) -> None:
        """File ▸ Export session -- write a shareable session file."""
        if filedialog is None:
            return
        target = filedialog.asksaveasfilename(
            defaultextension=".json",
            initialfile="pharmaml-playground-session.json",
            filetypes=[("Playground session", "*.json"), ("All files", "*.*")],
            title="Export playground session",
        )
        if not target:
            return
        if export_session(self._collect_session(), target):
            self._job_label.configure(text=f"session exported · {target}")
        else:
            self._job_label.configure(text="session NOT exported (path unwritable)")

    def _import_session(self) -> None:
        """File ▸ Import session -- apply a shareable session file."""
        if filedialog is None:
            return
        source = filedialog.askopenfilename(
            filetypes=[("Playground session", "*.json"), ("All files", "*.*")],
            title="Import playground session",
        )
        if not source:
            return
        session = load_session(read_json_file(source))
        if session is None:
            if messagebox is not None:
                messagebox.showerror(
                    "Invalid session file",
                    "That file is not a playground session (format marker missing or unreadable).",
                )
            return
        self._session = session
        self._restore_session()
        if session["theme"] in _THEMES and session["theme"] != self._theme:
            self._theme = session["theme"]
            if self._theme_var is not None:
                with contextlib.suppress(tk.TclError):
                    self._theme_var.set(self._theme)
            self._set_theme(self._resolve_auto_theme() if self._theme == "auto" else self._theme)
        self._job_label.configure(text=f"session imported · {source}")

    def _reset_current_tab(self) -> None:
        """File ▸ Reset current tab to defaults (Ctrl+Shift+R, 100x-54)."""
        try:
            index = self._book.index(self._book.select())
        except tk.TclError:  # pragma: no cover - no tab selected
            return
        self._reset_tab(index)

    def _reset_tab(self, index: int) -> None:
        """Reset ONE tab's inputs to launch defaults (per-tab footer
        button, 100x-55; the File-menu command delegates here).

        Only the named tab's inputs are reset -- every other tab keeps
        its live values -- using the defaults snapshot taken right after
        the tabs were built (before any session restore).
        """
        names = self._tab_input_owners.get(index, set())
        defaults = self._session_defaults
        text_widgets = {
            "pasted": self._feat_pasted_text,
            "corpus": self._corpus_text,
            "smiles": getattr(self, "_dock_smiles_text", None),
            "rism": getattr(self, "_rism_text", None),
            "maccs": getattr(self, "_maccs_text", None),
        }
        applied = 0
        for name in sorted(names):
            if name.startswith("family:"):
                family = name[len("family:") :]
                var = self._feat_family_vars.get(family)
                if family in defaults["families"] and var is not None:
                    with contextlib.suppress(tk.TclError):
                        var.set(bool(defaults["families"][family]))
                        applied += 1
                continue
            if name.startswith("text:"):
                key = name[len("text:") :]
                widget = text_widgets.get(key)
                if key in defaults["texts"] and widget is not None:
                    widget.delete("1.0", "end")
                    content = str(defaults["texts"][key])
                    if content:
                        widget.insert("1.0", content)
                    applied += 1
                continue
            if name not in defaults["variables"]:
                continue
            widget = getattr(self, name, None)
            value = defaults["variables"][name]
            if isinstance(widget, tk.Variable):
                with contextlib.suppress(tk.TclError):
                    widget.set(value)
                    applied += 1
            elif isinstance(widget, ttk.Entry):
                setter = getattr(widget, "set", None)
                if callable(setter):  # Spinbox / Combobox
                    setter(str(value))
                else:
                    widget.delete(0, "end")
                    if str(value):
                        widget.insert(0, str(value))
                applied += 1
        label = self._book.tab(index, "text")
        # the ML tab owns one DYNAMIC input -- the manual-hyperparameter
        # card.  Its JSON variable was reset with the others above; the
        # panel itself must be rebuilt to show it (100x-106).
        if label.strip() == "Data & ML":
            self._ml_params_var.set("{}")
            with contextlib.suppress(Exception):  # best effort
                self._ml_refresh_hyperparam_panel()
        self._job_label.configure(
            text=f"{label.lower()} tab reset · {applied} inputs back to defaults"
        )

    def _copy_tab_inputs(self, index: int) -> None:
        """Copy ONE tab's live inputs as a share-lite JSON snippet.

        The same ownership map the per-tab reset uses decides what
        belongs to the tab; values are read LIVE (not the launch
        defaults) and coerced the session's way, so the snippet is a
        plain ``{tab, variables, families, texts}`` dict -- paste it
        into an issue report, a script, or a message.
        """
        names = self._tab_input_owners.get(index, set())
        text_widgets = {
            "pasted": self._feat_pasted_text,
            "corpus": self._corpus_text,
            "smiles": getattr(self, "_dock_smiles_text", None),
            "rism": getattr(self, "_rism_text", None),
            "scan_refs": getattr(self, "_scan_ref_text", None),
            "scan_lib": getattr(self, "_scan_lib_text", None),
        }
        variables: dict[str, Any] = {}
        families: dict[str, bool] = {}
        texts: dict[str, str] = {}
        for name in sorted(names):
            if name.startswith("family:"):
                family = name[len("family:") :]
                var = self._feat_family_vars.get(family)
                if var is not None:
                    with contextlib.suppress(tk.TclError):
                        families[family] = bool(var.get())
                continue
            if name.startswith("text:"):
                key = name[len("text:") :]
                widget = text_widgets.get(key)
                if widget is not None:
                    texts[key] = widget.get("1.0", "end-1c")
                continue
            widget = getattr(self, name, None)
            if isinstance(widget, tk.Variable):
                with contextlib.suppress(tk.TclError):
                    variables[name] = widget.get()
            elif isinstance(widget, ttk.Entry):
                variables[name] = widget.get()
        label = self._book.tab(index, "text").strip()
        payload = {
            "tab": label,
            "variables": variables,
            "families": families,
            "texts": texts,
        }
        items = len(variables) + len(families) + len(texts)
        self._copy(json.dumps(payload, indent=2, sort_keys=True))
        self._job_label.configure(text=f"{label.lower()} inputs copied as JSON · {items} items")

    def _walk_widgets(self, widget: Any) -> Iterator[Any]:
        """Yield ``widget`` and every descendant (the GUI-tree walk)."""
        yield widget
        for child in widget.winfo_children():
            yield from self._walk_widgets(child)

    def _tab_input_names(self) -> dict[int, set[str]]:
        """Map each notebook tab to the session-input names it owns.

        Ownership is decided by the widget tree: every entry / spinbox /
        combobox / checkbutton / radiobutton living inside a tab's frame
        contributes its linked variable (Tcl name -> app attribute), an
        entry stored directly as an attribute contributes that name, the
        feature-family checkboxes contribute ``family:<name>`` keys and
        the two pasted corpora contribute ``text:<key>`` keys.  The theme
        radio and notebook bookkeeping are excluded (not user inputs).
        """
        var_by_tcl_name: dict[str, str] = {}
        entry_by_id: dict[int, str] = {}
        for name, value in vars(self).items():
            if name.startswith("_book") or name == "_theme_var":
                continue
            if isinstance(value, tk.Variable):
                var_by_tcl_name[str(value)] = name
            elif isinstance(value, ttk.Entry):
                entry_by_id[id(value)] = name
        family_by_tcl_name = {
            str(var): f"family:{family}" for family, var in self._feat_family_vars.items()
        }
        text_by_id = {
            id(self._feat_pasted_text): "text:pasted",
            id(self._corpus_text): "text:corpus",
            id(getattr(self, "_dock_smiles_text", None)): "text:smiles",
            id(getattr(self, "_rism_text", None)): "text:rism",
        }
        owners: dict[int, set[str]] = {}
        with contextlib.suppress(tk.TclError):
            for index, tab_id in enumerate(self._book.tabs()):
                names: set[str] = set()
                for widget in self._walk_widgets(self._book.nametowidget(tab_id)):
                    if id(widget) in text_by_id:
                        names.add(text_by_id[id(widget)])
                        continue
                    if isinstance(widget, ttk.Entry):
                        linked = str(widget.cget("textvariable"))
                        if linked and linked in var_by_tcl_name:
                            names.add(var_by_tcl_name[linked])
                        elif id(widget) in entry_by_id:
                            names.add(entry_by_id[id(widget)])
                    elif isinstance(
                        widget, (ttk.Checkbutton, ttk.Radiobutton, tk.Checkbutton, tk.Radiobutton)
                    ):
                        linked = str(widget.cget("variable"))
                        if linked in var_by_tcl_name:
                            names.add(var_by_tcl_name[linked])
                        elif linked in family_by_tcl_name:
                            names.add(family_by_tcl_name[linked])
                owners[index] = names
        return owners

    def _restore_session(self) -> bool:
        """Re-apply the saved session onto the freshly built tabs.

        Returns ``True`` when a geometry was restored (so ``__init__``
        can skip re-centering the window).  Restore never raises: a
        payload naming a widget that no longer exists (older session,
        renamed attribute) is simply skipped.
        """
        if not self._session:
            return False
        session = self._session
        for name, value in session["variables"].items():
            widget = getattr(self, name, None)
            if isinstance(widget, tk.Variable):
                with contextlib.suppress(tk.TclError):
                    widget.set(value)
            elif isinstance(widget, ttk.Entry):
                setter = getattr(widget, "set", None)
                if callable(setter):  # Spinbox / Combobox
                    setter(str(value))
                else:
                    widget.delete(0, "end")
                    widget.insert(0, str(value))
        for family, checked in session["families"].items():
            var = self._feat_family_vars.get(family)
            if var is not None:
                with contextlib.suppress(tk.TclError):
                    var.set(bool(checked))
        # the hint row's visibility rides a tk.Variable, so a restored
        # session may have flipped it -- re-apply after the variables.
        self._apply_hint_visibility()
        text_widgets = {
            "pasted": self._feat_pasted_text,
            "corpus": self._corpus_text,
            "smiles": getattr(self, "_dock_smiles_text", None),
            "rism": getattr(self, "_rism_text", None),
            "maccs": getattr(self, "_maccs_text", None),
            "scan_refs": getattr(self, "_scan_ref_text", None),
            "scan_lib": getattr(self, "_scan_lib_text", None),
        }
        for key, content in session["texts"].items():
            if key == "finder":
                # 100x-121: the finder's last query -- an attribute, not a
                # Text widget; older sessions simply lack the key.
                self._finder_last_query = str(content)
                continue
            if key == "finder_recent":
                # 100x-130: the recency row's memory -- a JSON list of
                # card titles, parsed tolerantly (a corrupt or foreign
                # value resets the memory, never the restore).
                try:
                    remembered = json.loads(content)
                except (TypeError, ValueError):
                    remembered = []
                if isinstance(remembered, list) and all(
                    isinstance(title, str) for title in remembered
                ):
                    self._finder_recent = remembered[:_FINDER_RECENT_MAX]
                continue
            widget = text_widgets.get(key)
            if widget is not None:
                widget.delete("1.0", "end")
                widget.insert("1.0", content)
        tab = session["tab"]
        if 0 <= tab < self._book.index("end"):
            self._book.select(tab)
        restored_geometry = False
        parsed = parse_geometry(session["geometry"])
        if parsed is not None:
            width, height, x, y = parsed
            width = min(width, self.winfo_screenwidth())
            height = min(height, self.winfo_screenheight())
            on_screen = 0 <= x < self.winfo_screenwidth() and 0 <= y < self.winfo_screenheight()
            spec = f"{width}x{height}" + (f"+{x}+{y}" if on_screen else "")
            with contextlib.suppress(tk.TclError):
                self.geometry(spec)
                restored_geometry = True
        if session["variables"] or session["texts"]:
            self._job_label.configure(text="session restored · File ▸ Clear saved session resets")
        # the ML tab's manual-hyperparameter card is DYNAMIC (rebuilt
        # per model selection, values carried by the JSON variable the
        # loop above already restored) -- rebuild it once, after the
        # comboboxes hold their restored selections (100x-106).
        with contextlib.suppress(Exception):  # never block restore
            self._ml_refresh_hyperparam_panel()
        # (100x-122) same discipline for the swapped rows: a restored RL
        # method or reference-driven objective must re-sync its frames
        # (fixes the latent restore bug where the GA block stayed visible
        # under an RL selection, and hides/shows the reference row).
        with contextlib.suppress(Exception):  # never block restore
            self._on_method_change()
            self._objective_hint()
        return restored_geometry

    def _on_close(self) -> None:
        """Window close: save the session (unless disabled), then exit."""
        if self._persist_session:
            self._write_session_file()
        self.destroy()

    # -- menu actions ---------------------------------------------------- #
    def _menu_open_csv(self) -> None:
        self._book.select(self._ml_page)
        self._ml_open_csv()

    def _menu_save_figure(self) -> None:
        if self._last_figure is None:
            messagebox.showinfo("No figure yet", "Run a calculation that draws one first.")
            return
        if not self._require_pharmaml():
            return
        path = filedialog.asksaveasfilename(
            title="Save figure",
            defaultextension=".png",
            filetypes=[
                ("PNG figure", "*.png"),
                ("SVG figure", "*.svg"),
                ("PDF figure", "*.pdf"),
            ],
        )
        if not path:
            return
        try:
            from pharmaml.viz import save_figure

            saved = save_figure(self._last_figure, path)
            messagebox.showinfo("Figure saved", f"Written to\n{saved}")
        except Exception as exc:  # noqa: BLE001
            self._show_error("Could not save the figure", exc)

    def _session_report_picklist(
        self, live: list[list], tables: list[tuple[str, list[str], list[list[str]]]]
    ) -> tuple[list[list], list[tuple[str, list[str], list[list[str]]]]] | None:
        """The pre-save checklist both session-report menus consult.

        (100x-132) The web twin's report card gained its per-section
        control in 100x-131 (toggle chips, localStorage-persisted); the
        desktop's groups differ -- it walks LIVE pages, one figure page
        per card render plus one text page per filled table -- so the
        desktop twin is a pre-save dialog: every page the walk found is
        listed with a checkbox, all on by default, and the caller ships
        only the kept pages.  Returns ``(kept_live, kept_tables)`` or
        ``None`` when the user cancelled (no save started at all).

        The dialog carries a LIVE census footer ("N of M pages will
        ship") that recounts on every checkbox flip, and the Save
        button disables itself at zero pages -- the honest empty, the
        same contract as the web twin's "Nothing would ship" line.
        """
        if tk is None:  # pragma: no cover - headless import
            return live, tables
        win = tk.Toplevel(self)
        win.title("Session report contents")
        win.configure(background=BG)
        win.transient(self)
        try:
            win.geometry(f"+{self.winfo_rootx() + 120}+{self.winfo_rooty() + 90}")
        except tk.TclError:  # pragma: no cover - unmapped parent
            pass
        win.bind("<Escape>", lambda _e: win.destroy())

        ttk.Label(
            win,
            text="Choose the pages the report ships — every page is on by default.",
            style="CardMuted.TLabel",
        ).pack(anchor="w", padx=16, pady=(14, 6))

        body = ttk.Frame(win, style="Card.TFrame")
        body.pack(fill="both", expand=True, padx=16)
        figure_vars: list[list[Any]] = []  # [BooleanVar, entry] pairs
        table_vars: list[list[Any]] = []

        def add_group(parent: Any, heading: str, count: int) -> None:
            row = ttk.Frame(parent, style="Card.TFrame")
            row.pack(fill="x", pady=(0, 4))
            ttk.Label(
                row,
                text=f"{heading} — {count} page{'s' if count != 1 else ''}",
                style="Field.TLabel",
            ).pack(side="left")

        def add_items(
            parent: Any,
            entries: list[Any],
            labels: list[str],
            var_bucket: list[list[Any]],
            prefix: str,
        ) -> None:
            for position, (label, entry) in enumerate(zip(labels, entries)):
                var = tk.BooleanVar(value=True)
                row = ttk.Frame(parent, style="Card.TFrame")
                row.pack(fill="x", padx=(10, 0), pady=(0, 2))
                check = ttk.Checkbutton(
                    row,
                    text=f"{prefix}{position + 1} · {_truncate_caption_text(label, 56)}",
                    variable=var,
                    command=refresh_census,
                )
                check.pack(anchor="w")
                var_bucket.append([var, entry])

        def refresh_census() -> None:
            kept = sum(1 for var, _entry in figure_vars + table_vars if var.get())
            total = len(figure_vars) + len(table_vars)
            census_label.configure(
                text=(
                    f"{kept} of {total} page{'s' if total != 1 else ''} will ship"
                    if kept
                    else "Nothing would ship — tick at least one page."
                )
            )
            if kept:
                save_button.state(["!disabled"])
            else:
                save_button.state(["disabled"])

        if live:
            add_group(body, "Figures (one page each)", len(live))
            add_items(
                body,
                entries=[entry for entry in live],
                labels=[str(entry[1]) for entry in live],
                var_bucket=figure_vars,
                prefix="figure ",
            )
        if tables:
            add_group(body, "Tables (one page each)", len(tables))
            add_items(
                body,
                entries=[entry for entry in tables],
                labels=[title for title, _headings, _rows in tables],
                var_bucket=table_vars,
                prefix="table ",
            )

        census_label = ttk.Label(win, style="CardMuted.TLabel")
        census_label.pack(anchor="w", padx=16, pady=(10, 4))
        buttons = ttk.Frame(win, style="Card.TFrame")
        buttons.pack(fill="x", padx=16, pady=(0, 14))
        outcome: dict[str, Any] = {"saved": False}

        def confirm() -> None:
            # zero pages never saves -- the button is disabled at zero,
            # but a keyboard/programmatic activation gets the same guard
            if not any(var.get() for var, _entry in figure_vars + table_vars):
                return
            outcome["saved"] = True
            win.destroy()

        save_button = ttk.Button(buttons, text="Save report…", command=confirm)
        save_button.pack(side="right")
        ttk.Button(buttons, text="Cancel", command=win.destroy).pack(
            side="right", padx=(0, 8)
        )
        refresh_census()
        win.protocol("WM_DELETE_WINDOW", win.destroy)
        win.grab_set()
        win.wait_window()
        if not outcome["saved"]:
            return None
        kept_live = [entry for var, entry in figure_vars if var.get()]
        kept_tables = [entry for var, entry in table_vars if var.get()]
        return kept_live, kept_tables

    def _menu_save_session_report(self) -> None:
        """File ▸ Save session report -- one PDF of the session on screen.

        (100x-122) Composes :func:`pharmaml.viz.save_pdf_report` over the
        session figure registry: a title page with the census and stamp,
        then one page per live figure (a figure replaced on its card is
        gone -- the host now shows the newer render, and the report says
        so honestly).  ``close=False``: the on-screen figures stay alive.

        (100x-123) The report gained its TABLE axis: every filled table
        on screen (leaderboards, prediction sheets, descriptor panels,
        docking results -- any card's table with rows) is walked the
        same way the registry walks hosts and shipped through
        ``save_pdf_report(tables=...)`` as REAL text pages -- searchable,
        selectable, the library's own truncation note and all -- so the
        PDF is the session's whole record, pictures AND numbers.

        (100x-129) The report gained its INK VARIANT, riding the View ▸
        theme radios the same way the HTML report's palette does: save
        while the app is dark and the PDF comes out in the dark-ink
        variant -- near-black pages, light ink, the app's own palette,
        figures on white plates (the bright-window look of the dark
        HTML report); save while light and it stays the classic white
        paper.  ``auto`` is resolved through ``_resolve_auto_theme``
        first -- a PDF's ink is frozen at write time, so there is no
        reading-time toggle to defer to.  Flip the View ▸ theme radio
        before saving to pick the other variant.

        (100x-132) Both report menus now consult the pre-save picklist
        (:meth:`_session_report_picklist`) -- the desktop twin of the
        web report card's per-section control: every page the walk
        found is offered with a checkbox (all on by default) and only
        the kept pages ship.  Cancel leaves the session untouched.
        """
        live = self._live_session_figures()
        tables = self._live_session_tables()
        if not live and not tables:
            messagebox.showinfo(
                "Nothing to report yet",
                "Run a calculation first -- the report collects every "
                "figure currently on screen (one page each) plus every "
                "filled table (real text pages, one each).",
            )
            return
        if not self._require_pharmaml() or not fpdf_available():
            if self.pharmaml is not None:
                messagebox.showwarning(
                    "Session report needs fpdf",
                    "The multi-page PDF report needs the fpdf package "
                    "(the fpdf2 wheel, extras: reports).\n\n"
                    "    pip install fpdf2\n\n"
                    "Install it, then restart the playground.",
                )
            return
        picked = self._session_report_picklist(live, tables)
        if picked is None:
            return  # the user cancelled the checklist -- no save at all
        live, tables = picked
        path = filedialog.asksaveasfilename(
            title="Save session report",
            defaultextension=".pdf",
            filetypes=[("PDF report", "*.pdf")],
        )
        if not path:
            return

        def unique_name(base: str, *registries: dict[str, Any]) -> str:
            # NB: save_pdf_report validates page names as plain file
            # names -- no directories, no '/' separators.
            name = base
            suffix = 2
            while any(name in registry for registry in registries):
                name = f"{base} ({suffix})"
                suffix += 1
            return name

        figures: dict[str, Any] = {}
        for _host, title, figure in live:
            figures[unique_name(title, figures)] = figure
        import pandas as pd

        table_pages: dict[str, Any] = {}
        for title, headings, rows in tables:
            frame = pd.DataFrame(rows, columns=headings)
            table_pages[unique_name(f"{title} table", table_pages, figures)] = frame
        stamp = time.strftime("%Y-%m-%d %H:%M")
        # (100x-129) the ink variant rides the theme radios -- captured
        # on the MAIN thread (Tk variables are not safe to read from the
        # worker), auto resolved NOW because a PDF's ink is frozen at
        # write time (no reading-time toggle like the HTML twin's).
        variant = self._theme_var.get()
        if variant == "auto":
            variant = self._resolve_auto_theme()
        # the library's own public contract pins the valid variants
        # (pharmaml.viz.PDF_THEMES) -- guarding here keeps the Tk radios
        # honest even if they ever drift from the library's accepted
        # values, instead of letting save_pdf_report raise mid-job.
        try:
            from pharmaml.viz import PDF_THEMES

            if variant not in PDF_THEMES:
                variant = "light"
        except ImportError:
            if variant not in ("light", "dark"):
                variant = "light"
        variant_label = (
            "dark ink variant (the View ▸ theme radios picked it)"
            if variant == "dark"
            else "classic light paper"
        )

        def work() -> Any:
            from pharmaml.viz import save_pdf_report

            return save_pdf_report(
                figures,
                tables=table_pages or None,
                out_path=path,
                title="PharmaML Playground session",
                subtitle=(
                    f"{len(figures)} figure page(s) · {len(table_pages)} table "
                    f"page(s) · generated {stamp} · playground {__version__} "
                    f"· {variant_label.split(' (')[0]}"
                ),
                close=False,
                theme=variant,
            )

        def render(saved: Any) -> None:
            messagebox.showinfo(
                "Session report saved",
                f"{len(figures)} figure page(s) + {len(table_pages)} table "
                f"page(s) written to\n{saved}\n\nSaved in the {variant_label}. "
                "Flip the View ▸ theme radio before saving to get the "
                "other one.",
            )

        self._start_job("session report", work, render)

    def _menu_save_session_report_html(self) -> None:
        """File ▸ Save session report (HTML)… -- the portable twin.

        (100x-124) :class:`pharmaml.viz.HTMLReport` is the library's
        self-contained HTML report builder -- figures base64-embedded,
        zero external resources, so the file renders identically
        offline and survives being moved or e-mailed -- and until this
        round it had NO caller anywhere.  This is its surface: the
        exact same two axes the PDF report walks (every live session
        figure + every filled table), plus the builder's own metric
        cards (``add_metrics`` -- the session census, which not even
        the library exercised) and an ``add_text`` provenance block.
        No fpdf dependency: one .html file, any browser.

        (100x-126) The report OPENS in the app's own theme -- the View
        ▸ theme radios (auto / light / dark) now do double duty: they
        tint the playground AND bake the report's initial
        ``data-theme``.  A small toggle button rides the top-right of
        every report: one click cycles auto → light → dark at reading
        time, remembered per browser (localStorage) -- the sender pins
        a starting palette, the reader overrides it for themselves,
        and neither touches the other's preference.

        (100x-132) Same picklist as the PDF twin: the pre-save
        checklist runs after the guards, and only the kept pages walk
        into the HTML.  Cancel leaves the session untouched.
        """
        live = self._live_session_figures()
        tables = self._live_session_tables()
        if not live and not tables:
            messagebox.showinfo(
                "Nothing to report yet",
                "Run a calculation first -- the report collects every "
                "figure currently on screen plus every filled table, as "
                "one self-contained HTML file (figures embedded, no "
                "external resources).",
            )
            return
        if not self._require_pharmaml():
            return
        picked = self._session_report_picklist(live, tables)
        if picked is None:
            return  # the user cancelled the checklist -- no save at all
        live, tables = picked
        path = filedialog.asksaveasfilename(
            title="Save session report (HTML)",
            defaultextension=".html",
            filetypes=[("HTML report", "*.html"), ("All files", "*.*")],
        )
        if not path:
            return
        stamp = time.strftime("%Y-%m-%d %H:%M")
        # captured on the MAIN thread (Tk variables are not safe to read
        # from the worker); the app's theme radios pin the report's
        # initial palette -- auto follows the READER's OS, not ours.
        theme = self._theme_var.get()
        # (100x-127) the library's own public contract pins the valid
        # themes (pharmaml.viz.REPORT_THEMES) -- guarding here keeps the
        # Tk radios honest even if they ever drift from the library's
        # accepted values, instead of letting HTMLReport raise mid-job.
        try:
            from pharmaml.viz import REPORT_THEMES

            if theme not in REPORT_THEMES:
                theme = "auto"
        except ImportError:
            pass  # the worker's HTMLReport import reports this honestly
        try:
            cards = len(self._live_cards())
        except Exception:  # noqa: BLE001 - the census is cosmetic
            cards = 0
        figure_count = len(live)
        table_count = len(tables)
        # caption dedupe: two cards can carry the same job label, and
        # identical captions would read as a missing figure -- number
        # the repeats the way the PDF's page names do.
        seen_captions: dict[str, int] = {}

        def unique_caption(base: str) -> str:
            seen = seen_captions.get(base, 0)
            seen_captions[base] = seen + 1
            return base if seen == 0 else f"{base} ({seen + 1})"

        captioned = [(unique_caption(title), figure) for _host, title, figure in live]

        def work() -> Any:
            import pandas as pd

            from pharmaml.viz import HTMLReport

            report = HTMLReport(
                "PharmaML Playground session",
                subtitle=(
                    f"{figure_count} figure(s) · {table_count} table(s) · "
                    f"generated {stamp} · playground {__version__}"
                ),
                theme=theme,
            )
            report.add_metrics(
                {
                    "figures": str(figure_count),
                    "tables": str(table_count),
                    "cards on screen": str(cards),
                    "pharmaml": str(self.pharmaml.__version__),
                }
            )
            report.add_text(
                "Every figure and every filled table currently on screen, "
                "collected in one pass.  A figure replaced on its card is "
                "gone -- the report shows the newest render, the honest "
                "provenance of the session.  The figures are embedded as "
                "base64, so this file needs no network and no companion "
                "assets: move it, mail it, archive it.",
                heading="What this file contains",
            )
            for title, headings, rows in tables:
                report.add_table(
                    pd.DataFrame(rows, columns=headings), heading=f"{title} table"
                )
            for caption, figure in captioned:
                report.add_figure(figure, caption=caption)
            return report.save(path)

        def render(saved: Any) -> None:
            messagebox.showinfo(
                "Session report saved",
                f"{figure_count} figure(s) + {table_count} table(s) written to\n"
                f"{saved}\n\nSelf-contained HTML -- the figures are embedded, "
                "so the file renders identically offline and survives "
                "being moved or e-mailed.\n\n"
                f"Theme: opens {theme} (the app's setting); the button in "
                "the report's top-right corner cycles it per reader.",
            )

        self._start_job("session report (HTML)", work, render)

    def _show_about(self) -> None:
        pharmaml_line = (
            f"pharmaml {self.pharmaml.__version__}"
            if self.pharmaml is not None
            else "pharmaml: NOT LOADED (run from the toolkit root)"
        )
        messagebox.showinfo(
            "About PharmaML Playground",
            f"PharmaML Playground {__version__}\n{pharmaml_line}\n\n"
            "A single-file graphical front end for the pharmaml toolkit:\n"
            "chemistry · PK/PD · cell lines · docking · QSAR machine learning · "
            "deep learning · generative design.\n\n"
            "Calculations run in pharmaml itself -- the playground only\n"
            "collects your inputs and renders the results.",
        )

    def _show_dependency_report(self) -> None:
        lines = [f"{'module':<14} status", "-" * 28]
        for module, label, _purpose, _pip in _DEPENDENCIES:
            lines.append(f"{label:<14} {'installed' if self.deps.get(module) else 'missing'}")
        lines.append(f"{'tkinter':<14} {'installed' if tk is not None else 'missing'}")
        report = "\n".join(lines)
        print(report)
        messagebox.showinfo("Dependency report", report)

    # ------------------------------------------------------------------ #
    # Home tab
    # ------------------------------------------------------------------ #
    def _build_home_tab(self) -> None:
        page = self._new_page("Home", reset=False)  # no inputs to reset
        hero = make_card(
            page.grid,
            "PharmaML Playground",
            span=2,
            row=0,
            column=0,
            subtitle="One window for the whole toolkit -- chemistry, PK/PD dosing, "
            "cell-line biology, molecular docking, QSAR modelling, "
            "deep learning and the generative GA, without touching "
            "a terminal.",
        )
        version_line = (
            f"playground {__version__} · pharmaml {self.pharmaml.__version__}"
            if self.pharmaml is not None
            else f"playground {__version__} · pharmaml NOT LOADED"
        )
        ttk.Label(hero, text=version_line, style="CardMuted.TLabel").grid(
            row=0, column=0, sticky="w"
        )
        # quick-jump row (the 100x-119 UI pass): one chip per tab -- the
        # fastest route from "where do I start" to the card you want.
        jump_row = ttk.Frame(hero, style="Card.TFrame")
        jump_row.grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Label(jump_row, text="jump to:", style="CardMuted.TLabel").pack(
            side="left", padx=(0, 8)
        )
        for index, name in enumerate(
            (
                "Chemistry",
                "PK / PD",
                "Cell Lines",
                "Docking",
                "Data & ML",
                "Deep Learning",
                "Generative",
                "Utilities",
            )
        ):
            chip = ttk.Button(
                jump_row,
                text=name,
                style="Chip.TButton",
                command=lambda idx=index + 1: self._jump_to_tab(idx),
            )
            chip.pack(side="left", padx=(0, 6))
            Tooltip(chip, f"Switch straight to the {name} tab.")

        status = make_card(
            page.grid,
            "Dependency status",
            span=2,
            row=1,
            column=0,
            subtitle="Each tab degrades politely and tells you the pip line it wants.",
        )
        grid = ttk.Frame(status, style="Card.TFrame")
        grid_append(status, grid, sticky="ew")
        grid.columnconfigure(2, weight=1)
        rows = [(label, module, purpose, pip) for module, label, purpose, pip in _DEPENDENCIES]
        rows.append(("tkinter", "tkinter", "the GUI itself (stdlib)", "python3-tk"))
        for label, module, purpose, pip in rows:
            row = grid.grid_size()[1]
            ok = self.deps.get(module, tk is not None)
            dot = tk.Label(
                grid,
                text="●",
                background=CARD,
                foreground=GOOD if ok else BAD,
                font=("TkDefaultFont", 12),
            )
            dot.grid(row=row, column=0, sticky="w", padx=(0, 8))
            ttk.Label(grid, text=label, style="Field.TLabel").grid(
                row=row, column=1, sticky="w", padx=(0, 10)
            )
            ttk.Label(grid, text=purpose, style="CardMuted.TLabel").grid(
                row=row, column=2, sticky="w"
            )
            state = "installed" if ok else f"missing → pip install {pip}"
            ttk.Label(grid, text=state, style="CardMuted.TLabel").grid(
                row=row, column=3, sticky="e"
            )
        missing = [pip for module, _l, _p, pip in _DEPENDENCIES if not self.deps.get(module)]
        if self.pharmaml is None:
            missing.append("-e .")
        if missing:
            grid_append(
                status,
                ttk.Label(
                    status,
                    style="CardMuted.TLabel",
                    justify="left",
                    text=(
                        "To light up every tab, from the toolkit root:\n"
                        "    pip install -e . numpy pandas scikit-learn scipy matplotlib rdkit"
                    ),
                ),
                pady=(8, 0),
            )
        else:
            grid_append(
                status,
                ttk.Label(
                    status,
                    style="CardMuted.TLabel",
                    text="Everything is available -- every tab is fully armed.",
                ),
                pady=(8, 0),
            )

        guide = make_card(page.grid, "What lives where", span=2, row=2, column=0)
        entries = [
            (
                "Chemistry",
                (
                    "IC50/Ki → pIC50/pKi, molar mass, the 200+ descriptor table for "
                    "any SMILES, Tanimoto similarity, the RISM-KH solvation "
                    "card (ten solvation-theory descriptors), the feature "
                    "factory: 10,000+ descriptor/fingerprint columns ranked to "
                    "a top-K (with the distribution-histogram grid), the "
                    "structure & table converters (CSV → 3D SDF, "
                    "SMI ↔ CSV, SDF → table, batch pIC50), the library "
                    "similarity scan (matrix / threshold / top-k, now with the "
                    "labelled heat-map figure), the canonical-tautomer & "
                    "3D-PDB writer and the 167-key MACCS fingerprint."
                ),
                "RDKit + pandas",
            ),
            (
                "PK / PD",
                (
                    "Half-life, accumulation, IV bolus decay and Emax curves, "
                    "Cockcroft–Gault, loading/maintenance and pediatric dosing — "
                    "plus non-compartmental analysis over any pasted "
                    "concentration-time series (AUC/AUMC/MRT/Cmax/t½ with the "
                    "profile figure), IV infusion & steady state, Vd and "
                    "bioavailability, the TDM trough dose adjustment, the "
                    "full PD model family (sigmoid Emax / inhibitory Emax / "
                    "linear) with the reverse EC50-for-target-effect solver, "
                    "and the dimension-aware unit converter."
                ),
                "numpy",
            ),
            (
                "Cell Lines",
                (
                    "Drug-response screens: audit (plus the replicate-variability "
                    "and per-compound summary readouts), the sensitivity "
                    "matrix, sensitive vs resistant calls, MAD-ranked variable "
                    "genes on the expression table, and biomarker discovery."
                ),
                "pandas + scipy",
            ),
            (
                "Docking",
                (
                    "Ligand library and receptor preparation into PDBQT (bad "
                    "residues auto-removed, atom-type census figure included), "
                    "the grid box with GPF/DPF "
                    "configs — one ligand or the whole campaign at once, "
                    "custom receptor types included — DLG / Vina result "
                    "parsing (single logs or a full Vina results folder, "
                    "top-ligand bars included), "
                    "batch campaign runs and the single-folder AutoDock4 "
                    "engine (with skip-completed resume), the SMILES array "
                    "card: paste a "
                    "list, dock every molecule simultaneously with Vina or "
                    "AutoDock4 -- plus the audit card (GPF parameters, "
                    "ligand_types, torsion consistency, completion), the "
                    "Vina config batch (parsed keys shown, box copied into "
                    "the single-run form) and one-ligand SMILES → PDBQT."
                ),
                "RDKit + pandas",
            ),
            (
                "Data & ML",
                (
                    "Open a CSV (or a bundled example), drop the non-numeric "
                    "columns, train a model, read the metrics (classification "
                    "runs gain the calibration reliability diagram; both "
                    "tasks gain the learning-curve figure — should you assay "
                    "more compounds?), browse the "
                    "cross-validation leaderboard (with the bar figure), build "
                    "voting / stacking ensembles by hand, and save the trained "
                    "model as a bundle you can load back and predict with (PDF "
                    "report included)."
                ),
                "pandas + sklearn",
            ),
            (
                "Deep Learning",
                (
                    "The PyTorch estimators behind one card: pick the "
                    "architecture (feed-forward or residual MLP), the hidden "
                    "widths, dropout, Adam's learning rate / weight decay and "
                    "the early-stopping patience, then watch the held-out "
                    "metrics, the parity / confusion figure and the "
                    "epoch-by-epoch loss curves — with the size-vs-score "
                    "learning curve (are more rows still buying accuracy?) "
                    "and the ml check CSV audit beside them."
                ),
                "torch",
            ),
            (
                "Generative",
                (
                    "Evolve molecules against QED / LogP / similarity / novelty / "
                    "SMARTS objectives with the GA or reinforcement learning; "
                    "adaptive runs show the operator-mix learning curve, RL runs "
                    "the prior-drift introspection, the leaderboard's top "
                    "molecules draw as a scored 2D structure grid, the Pareto "
                    "front's members draw colour-coded (boundary corners "
                    "accented, interior trade-offs muted) with a per-card "
                    "figure export, and the surgery cards enumerate one "
                    "molecule's ring moves or breed two parents -- then draw "
                    "every mutant or child the same way.  Every figure card "
                    "in the whole app carries its own Save figure… button -- "
                    "the ML parity / calibration / learning curves, the "
                    "network results and training history, the PK, PD and "
                    "NCA profiles, the descriptor distributions, the "
                    "similarity heat-map, the docking pictures and these "
                    "grids: a figure leaves the app from the card that "
                    "shows it, not the global Ctrl+S."
                ),
                "RDKit (+ torch for RL)",
            ),
            (
                "Utilities",
                (
                    "The archive's own file & table operations: merge or split "
                    "tables, compare / annotate ligand columns (with the "
                    "three-way reconciliation figure), filter "
                    "approved drugs into a CSV or Word report, the campaign "
                    "file tools (collect / list / distribute / delete / "
                    "cleanup, dry-run first) and the reindex-by-number table."
                ),
                "pandas",
            ),
        ]
        for name, blurb, needs in entries:
            row = ttk.Frame(guide, style="Card.TFrame")
            grid_append(guide, row, sticky="ew", pady=2)
            ttk.Label(
                row, text=name, style="Field.TLabel", font=("TkDefaultFont", 10, "bold")
            ).pack(side="left")
            ttk.Label(
                row, text=f" — {blurb}", style="CardMuted.TLabel", wraplength=560, justify="left"
            ).pack(side="left", padx=(8, 0))
            ttk.Label(row, text=f"[{needs}]", style="CardMuted.TLabel").pack(side="right")

        if self.pharmaml is None:
            broken = make_card(page.grid, "pharmaml could not be imported", span=2, row=3, column=0)
            grid_append(
                broken,
                ttk.Label(
                    broken, text=self.pharmaml_error, style="CardMuted.TLabel", wraplength=620
                ),
            )
            grid_append(
                broken,
                ttk.Label(broken, text=_PHARMAML_HINT, style="CardMuted.TLabel", justify="left"),
                pady=(6, 0),
            )

    # ------------------------------------------------------------------ #
    # Chemistry tab
    # ------------------------------------------------------------------ #
    def _build_chemistry_tab(self) -> None:
        page = self._new_page("Chemistry")

        conv = make_card(
            page.grid,
            "Affinity conversion",
            row=0,
            column=0,
            subtitle="IC50/Ki → pIC50/pKi. Censored entries like '<100' are handled.",
        )
        self._aff_mode = ttk.Combobox(
            conv, state="readonly", width=22, values=("IC50 → pIC50", "Ki → pKi")
        )
        self._aff_mode.set("IC50 → pIC50")
        form_row(conv, "Endpoint", self._aff_mode)
        self._aff_value = ttk.Entry(conv, width=22)
        self._aff_value.insert(0, "100")
        form_row(conv, "Value", self._aff_value)
        self._aff_unit = ttk.Combobox(
            conv, state="readonly", width=22, values=("nM", "uM", "µM", "mM", "M", "pM")
        )
        self._aff_unit.set("nM")
        form_row(conv, "Unit", self._aff_unit)
        button = self._action_button(
            conv,
            "Convert",
            self._convert_affinity,
            tooltip="-log10 of the value converted to molar units.",
        )
        button.grid(row=conv.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._aff_result = ttk.Label(conv, text="—", style="Result.TLabel", font=self._mono_result)
        self._aff_result.grid(row=button.grid_info()["row"], column=1, sticky="w", padx=(10, 0))
        bind_enter(self._aff_value, button)
        copy_btn = self._action_button(
            conv, "Copy", lambda: self._copy(self._aff_result.cget("text"))
        )
        copy_btn.grid(row=conv.grid_size()[1], column=0, sticky="w")

        mass = make_card(
            page.grid,
            "Molar mass",
            row=0,
            column=1,
            subtitle="Formula → g/mol (works with no heavy dependencies installed).",
        )
        self._formula = ttk.Entry(mass, width=22)
        self._formula.insert(0, "C8H10N4O2")
        form_row(mass, "Formula", self._formula)
        button = self._action_button(
            mass,
            "Weigh",
            self._molar_mass,
            tooltip="Supports hydrates (MgSO4.7H2O) and groups like Ca(OH)2.",
        )
        button.grid(row=mass.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._mass_result = ttk.Label(mass, text="—", style="Result.TLabel", font=self._mono_result)
        self._mass_result.grid(row=button.grid_info()["row"], column=1, sticky="w", padx=(10, 0))
        bind_enter(self._formula, button)

        desc = make_card(
            page.grid,
            "SMILES inspector",
            row=1,
            column=0,
            subtitle="Every RDKit 2D descriptor for one molecule (type to filter).",
        )
        self._smiles_entry = ttk.Entry(desc, width=34)
        self._smiles_entry.insert(0, "CC(=O)Oc1ccccc1C(=O)O")
        form_row(desc, "SMILES", self._smiles_entry)
        button = self._action_button(
            desc,
            "Analyse",
            self._analyse_smiles,
            primary=True,
            tooltip="Computes the ~200 RDKit descriptors in a worker thread.",
        )
        button.grid(row=desc.grid_size()[1], column=0, sticky="w", pady=(4, 0))
        self._smiles_summary = ttk.Label(
            desc, text="—", style="CardMuted.TLabel", wraplength=420, justify="left"
        )
        self._smiles_summary.grid(row=button.grid_info()["row"], column=1, sticky="w", padx=(10, 0))
        bind_enter(self._smiles_entry, button)
        self._desc_search = ttk.Entry(desc, width=24)
        self._desc_search.insert(0, "")
        self._desc_search.bind("<KeyRelease>", self._filter_descriptors)
        form_row(desc, "Filter", self._desc_search)
        tree_frame = ttk.Frame(desc, style="Card.TFrame")
        tree_frame.grid(row=desc.grid_size()[1], column=0, columnspan=2, sticky="nsew", pady=(4, 0))
        desc.rowconfigure(tree_frame.grid_info()["row"], weight=1)
        self._desc_tree = ttk.Treeview(
            tree_frame, columns=("descriptor", "value"), show="headings", height=9
        )
        self._desc_tree.heading("descriptor", text="descriptor")
        self._desc_tree.heading("value", text="value")
        self._desc_tree.column("descriptor", width=200, stretch=True)
        self._desc_tree.column("value", width=130, stretch=False)
        desc_bar = ttk.Scrollbar(tree_frame, orient="vertical", command=self._desc_tree.yview)
        self._desc_tree.configure(yscrollcommand=desc_bar.set)
        self._desc_tree.pack(side="left", fill="both", expand=True)
        desc_bar.pack(side="right", fill="y")
        save_btn = self._action_button(desc, "Save descriptors as CSV…", self._save_descriptors)
        save_btn.grid(row=desc.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(6, 0))

        tani = make_card(
            page.grid,
            "Tanimoto similarity",
            row=1,
            column=1,
            subtitle="Morgan fingerprint overlap between two molecules.",
        )
        self._tani_a = ttk.Entry(tani, width=34)
        self._tani_a.insert(0, "CC(=O)Oc1ccccc1C(=O)O")
        form_row(tani, "SMILES A", self._tani_a)
        self._tani_b = ttk.Entry(tani, width=34)
        self._tani_b.insert(0, "CC(=O)Nc1ccc(O)cc1")
        form_row(tani, "SMILES B", self._tani_b)
        button = self._action_button(
            tani,
            "Compare",
            self._compare_similarity,
            tooltip="1.0 = identical fingerprint, 0.0 = nothing shared.",
        )
        button.grid(row=tani.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._tani_result = ttk.Label(tani, text="—", style="Result.TLabel", font=self._mono_result)
        self._tani_result.grid(row=button.grid_info()["row"], column=1, sticky="w", padx=(10, 0))
        self._tani_verdict = ttk.Label(
            tani, text="", style="CardMuted.TLabel", wraplength=300, justify="left"
        )
        self._tani_verdict.grid(
            row=tani.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(6, 0)
        )
        bind_enter(self._tani_b, button)

        # -- feature factory: the rar's own ML pipeline ------------------ #
        factory = make_card(
            page.grid,
            "Feature factory",
            row=2,
            column=0,
            span=2,
            subtitle="The rar's own ML pipeline as a card: 8 descriptor / "
            "fingerprint families (~10,810 columns per molecule), "
            "ranked and cut to the top K you keep -- now including "
            "the RISM-KH solvation family.",
        )
        source_row = ttk.Frame(factory, style="Card.TFrame")
        grid_append(factory, source_row, sticky="w")
        ttk.Label(source_row, text="Source", style="Field.TLabel").pack(side="left")
        self._feat_source_var = tk.StringVar(value="Pasted SMILES")
        csv_radio = ttk.Radiobutton(
            source_row,
            text="CSV file",
            value="CSV file",
            variable=self._feat_source_var,
            command=self._feat_refresh_source,
        )
        csv_radio.pack(side="left", padx=(12, 0))
        pasted_radio = ttk.Radiobutton(
            source_row,
            text="Pasted SMILES",
            value="Pasted SMILES",
            variable=self._feat_source_var,
            command=self._feat_refresh_source,
        )
        pasted_radio.pack(side="left", padx=(8, 0))

        self._feat_csv_box = ttk.Frame(factory, style="Card.TFrame")
        grid_append(factory, self._feat_csv_box, sticky="ew", pady=(6, 0))
        csv_buttons = ttk.Frame(self._feat_csv_box, style="Card.TFrame")
        csv_buttons.grid(row=0, column=0, columnspan=2, sticky="w")
        csv_open_btn = self._action_button(csv_buttons, "Open CSV…", self._feat_open_csv)
        csv_open_btn.pack(side="left")
        csv_example_btn = self._action_button(
            csv_buttons,
            "Load example",
            self._feat_load_example,
            tooltip="examples/data/library_with_descriptors.csv -- 77 drugs "
            "with SMILES, 8 numeric descriptor columns and an activity "
            "label.",
        )
        csv_example_btn.pack(side="left", padx=(10, 0))
        self._feat_source_info = ttk.Label(
            self._feat_csv_box,
            text="no CSV loaded",
            style="CardMuted.TLabel",
            wraplength=520,
            justify="left",
        )
        self._feat_source_info.grid(row=1, column=0, columnspan=2, sticky="w", pady=(4, 0))
        self._feat_target_combo = ttk.Combobox(
            self._feat_csv_box,
            state="readonly",
            width=30,
            values=(_FEAT_NO_TARGET,),
        )
        self._feat_target_combo.set(_FEAT_NO_TARGET)
        form_row(self._feat_csv_box, "Target column", self._feat_target_combo)

        self._feat_pasted_box = ttk.Frame(factory, style="Card.TFrame")
        grid_append(factory, self._feat_pasted_box, sticky="ew", pady=(6, 0))
        self._feat_pasted_text = _grid_text(self._feat_pasted_box, height=4, mono=self._mono)
        self._feat_pasted_text.insert("1.0", "\n".join(_FEAT_DEFAULT_SMILES))
        grid_append(self._feat_pasted_box, self._feat_pasted_text, sticky="ew")
        grid_append(
            self._feat_pasted_box,
            ttk.Label(
                self._feat_pasted_box,
                style="CardMuted.TLabel",
                text="one SMILES per line; comments with # are ignored",
            ),
            pady=(2, 0),
        )

        families_box = ttk.Frame(factory, style="Card.TFrame")
        grid_append(factory, families_box, sticky="ew", pady=(6, 0))
        self._feat_family_vars: dict[str, Any] = {}
        for index, (family, label) in enumerate(_FEATURE_FAMILY_LABELS):
            family_var = tk.BooleanVar(value=True)
            self._feat_family_vars[family] = family_var
            family_check = ttk.Checkbutton(
                families_box,
                text=label,
                variable=family_var,
                command=self._feat_update_width,
            )
            family_check.grid(row=index // 2, column=index % 2, sticky="w", padx=(0, 24), pady=2)

        self._feat_k_entry = ttk.Entry(factory, width=10)
        self._feat_k_entry.insert(0, "1000")  # the rar pipeline's own default
        Tooltip(self._feat_k_entry, _FEAT_K_PRESETS)
        form_row(factory, "Features to keep (K)", self._feat_k_entry)
        self._feat_ranker_combo = ttk.Combobox(
            factory, state="readonly", width=28, values=_FEAT_RANKERS
        )
        self._feat_ranker_combo.set(_FEAT_RANKERS[0])
        form_row(factory, "Ranker", self._feat_ranker_combo)
        self._feat_task_combo = ttk.Combobox(
            factory, state="readonly", width=28, values=_FEAT_TASKS
        )
        self._feat_task_combo.set(_FEAT_TASKS[0])
        form_row(factory, "Task", self._feat_task_combo)
        self._feat_descriptor_count = _FEATURE_DESCRIPTORS_FALLBACK
        try:
            from rdkit.Chem import rdMolDescriptors

            self._feat_descriptor_count = len(rdMolDescriptors.Properties.GetAvailableProperties())
        except Exception:  # noqa: BLE001 - estimate only; the run gates RDKit
            self._feat_descriptor_count = _FEATURE_DESCRIPTORS_FALLBACK
        self._feat_width_label = ttk.Label(factory, text="", style="CardMuted.TLabel")
        grid_append(factory, self._feat_width_label, sticky="w")

        feat_btn = self._action_button(
            factory,
            "Compute & select features",
            self._feat_compute,
            primary=True,
            tooltip="Computes the ticked families in a worker thread, ranks "
            "every column, keeps the per-family median survivors, "
            "then the top K.",
        )
        feat_btn.grid(row=factory.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._feat_summary = ttk.Label(
            factory,
            text="—",
            style="CardMuted.TLabel",
            wraplength=560,
            justify="left",
        )
        self._feat_summary.grid(row=feat_btn.grid_info()["row"], column=1, sticky="w", padx=(10, 0))
        self._feat_family_label = ttk.Label(
            factory, text="", style="CardMuted.TLabel", wraplength=620, justify="left"
        )
        grid_append(factory, self._feat_family_label, sticky="w")
        feat_tree_frame = ttk.Frame(factory, style="Card.TFrame")
        grid_append(factory, feat_tree_frame, sticky="nsew", pady=(6, 0), weight=True)
        self._feat_tree = ttk.Treeview(
            feat_tree_frame,
            columns=("rank", "feature", "family", "importance"),
            show="headings",
            height=10,
        )
        for column, width in (
            ("rank", 56),
            ("feature", 210),
            ("family", 140),
            ("importance", 120),
        ):
            self._feat_tree.heading(column, text=column)
            self._feat_tree.column(column, width=width, minwidth=48, stretch=(column == "feature"))
        feat_bar = ttk.Scrollbar(feat_tree_frame, orient="vertical", command=self._feat_tree.yview)
        self._feat_tree.configure(yscrollcommand=feat_bar.set)
        self._feat_tree.pack(side="left", fill="both", expand=True)
        feat_bar.pack(side="right", fill="y")
        self._feat_more_label = ttk.Label(factory, text="", style="CardMuted.TLabel")
        grid_append(factory, self._feat_more_label, sticky="w")
        feat_export_buttons = ttk.Frame(factory, style="Card.TFrame")
        grid_append(factory, feat_export_buttons, sticky="w", pady=(2, 0))
        feat_csv_btn = self._action_button(
            feat_export_buttons,
            "Save selected features CSV…",
            self._feat_save_csv,
            tooltip="The rar-style output: SMILES, the target column (if any) "
            "and the K selected features in rank order.",
        )
        feat_csv_btn.pack(side="left")
        feat_json_btn = self._action_button(
            feat_export_buttons,
            "Save metadata JSON…",
            self._feat_save_json,
            tooltip="selection_metadata: selected features, family counts, "
            "fingerprint sizes, K and method.",
        )
        feat_json_btn.pack(side="left", padx=(10, 0))
        # 100x-120: the descriptor-distribution figure (the last viz
        # straggler) -- a histogram grid over the computed frame.
        feat_dist_btn = self._action_button(
            feat_export_buttons,
            "Plot distributions",
            self._feat_plot_distributions,
            tooltip="A histogram grid over the numeric columns of the "
            "computed frame (plot_descriptor_distributions) -- the "
            "honest first look at skew, bimodality and outliers "
            "before any model sees the numbers.",
        )
        feat_dist_btn.pack(side="left", padx=(10, 0))
        # 100x-128: the per-card export rides on EVERY figure card now.
        save_feat_figure_btn = self._action_button(
            feat_export_buttons,
            "Save figure…",
            self._save_feat_figure,
            tooltip="Save the figure this card is currently showing -- the "
            "descriptor histogram grid -- as PNG, SVG or PDF (unlike "
            "Ctrl+S, which saves the last figure drawn anywhere).",
        )
        save_feat_figure_btn.pack(side="left", padx=(10, 0))
        self._feat_host = self._figure_host(factory, height=300)
        self._feat_update_width()
        self._feat_refresh_source()

        # -- RISM-KH solvation descriptors (the 3D surrogate card) ------ #
        rism = make_card(
            page.grid,
            "RISM-KH solvation",
            row=3,
            column=0,
            span=2,
            subtitle="Ten 3D-RISM-KH-inspired solvation descriptors per "
            "molecule (KH-closure pair distributions over an "
            "embedded 3D geometry): solvation free energy split "
            "into Lennard-Jones and Coulomb parts, water-site "
            "distribution peaks, first-shell coordination numbers, "
            "excluded volume, dipole and charge asymmetry.",
        )
        rism_left = ttk.Frame(rism, style="Card.TFrame")
        rism_left.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        self._rism_text = _grid_text(rism_left, height=5, mono=self._mono)
        self._rism_text.insert("1.0", "\n".join(_FEAT_DEFAULT_SMILES))
        self._rism_text.pack(fill="both", expand=True)
        rism_run_row = ttk.Frame(rism_left, style="Card.TFrame")
        rism_run_row.pack(fill="x", pady=(6, 0))
        rism_btn = self._action_button(
            rism_run_row,
            "Compute RISM-KH",
            self._rism_run,
            primary=True,
            tooltip="Embeds every SMILES in 3D (ETKDGv3 + MMFF/UFF, fixed "
            "seed), applies the KH closure pair distributions "
            "against the chosen water model and integrates the "
            "same quantities a full 3D-RISM-KH solve reports -- "
            "milliseconds per molecule instead of grid hours.",
        )
        rism_btn.pack(side="left")
        self._rism_summary = ttk.Label(
            rism_run_row, text="—", style="CardMuted.TLabel", wraplength=430, justify="left"
        )
        self._rism_summary.pack(side="left", padx=(10, 0))

        rism_right = ttk.Frame(rism, style="Card.TFrame")
        rism_right.grid(row=0, column=1, sticky="n")
        rism_right.columnconfigure(1, weight=1)
        self._rism_solvent_combo = ttk.Combobox(
            rism_right, state="readonly", width=16, values=("spc", "tip3p")
        )
        self._rism_solvent_combo.set("spc")
        Tooltip(
            self._rism_solvent_combo,
            "The water model's site charges / LJ parameters: SPC or "
            "TIP3P (both keep the surrogate solvent charge-neutral).",
        )
        form_row(rism_right, "water model", self._rism_solvent_combo)
        self._rism_temp_entry = ttk.Entry(rism_right, width=16)
        self._rism_temp_entry.insert(0, "298.15")
        form_row(rism_right, "temperature (K)", self._rism_temp_entry)
        rism_save_btn = self._action_button(
            rism_right,
            "Save descriptors CSV…",
            self._rism_save,
            tooltip="SMILES + the ten RISM-KH descriptor columns, ready "
            "for the feature factory or a QSAR table.",
        )
        rism_save_btn.grid(
            row=rism_right.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(6, 0)
        )
        rism_tree_frame = ttk.Frame(rism, style="Card.TFrame")
        grid_append(rism, rism_tree_frame, sticky="nsew", pady=(6, 0), weight=True)
        self._rism_tree = ttk.Treeview(
            rism_tree_frame,
            columns=("molecule", "descriptor", "value", "meaning"),
            show="headings",
            height=9,
        )
        for column, width in (
            ("molecule", 150),
            ("descriptor", 170),
            ("value", 90),
            ("meaning", 230),
        ):
            self._rism_tree.heading(column, text=column)
            self._rism_tree.column(column, width=width, minwidth=56, stretch=(column == "meaning"))
        rism_bar = ttk.Scrollbar(rism_tree_frame, orient="vertical", command=self._rism_tree.yview)
        self._rism_tree.configure(yscrollcommand=rism_bar.set)
        self._rism_tree.pack(side="left", fill="both", expand=True)
        rism_bar.pack(side="right", fill="y")

        # -- structure & table converters (100x-110) --------------------- #
        # The rar's Convert CSV to SDF / Convert SMI to CSV / Sdf reading
        # notebook / Convert IC50(nM) to pIC50 -- one card, five modes.
        convert = make_card(
            page.grid,
            "Structure & table converters",
            row=4,
            column=0,
            span=2,
            subtitle="The rar's converter scripts, one card: a SMILES "
            "table becomes a 3D SDF (AddHs → ETKDG → UFF, every "
            "column an SD tag), a .smi list becomes CSV, an SDF "
            "becomes a table back, a table becomes .smi, or a "
            "measurement column gains pIC50 (censored '<100' "
            "entries handled, never fabricated).",
        )
        self._conv_mode = ttk.Combobox(convert, state="readonly", width=30, values=_CONVERTER_MODES)
        self._conv_mode.set(_CONVERTER_MODES[0])
        form_row(convert, "mode", self._conv_mode)
        conv_pick = ttk.Frame(convert, style="Card.TFrame")
        grid_append(convert, conv_pick, sticky="w")
        for label, command in (
            ("Input…", self._conv_pick_input),
            ("Output…", self._conv_pick_output),
        ):
            button = self._action_button(conv_pick, label, command)
            button.pack(side="left")
        self._conv_input: Path | None = None
        self._conv_output: Path | None = None
        self._conv_info = ttk.Label(
            convert,
            text="pick an input (and an output for the file modes)",
            style="CardMuted.TLabel",
            wraplength=620,
            justify="left",
        )
        grid_append(convert, self._conv_info, sticky="w", pady=(4, 0))
        conv_opts = ttk.Frame(convert, style="Card.TFrame")
        grid_append(convert, conv_opts, sticky="w")
        conv_opts.columnconfigure(1, weight=1)
        self._conv_smiles_col = ttk.Entry(conv_opts, width=18)
        self._conv_smiles_col.insert(0, "SMILES")
        form_row(conv_opts, "SMILES column", self._conv_smiles_col)
        self._conv_name_col = ttk.Entry(conv_opts, width=18)
        self._conv_name_col.insert(0, "")
        Tooltip(
            self._conv_name_col,
            "Optional name/title column (SDF titles and .smi names); "
            "blank uses the SMILES or the row index.",
        )
        form_row(conv_opts, "name column", self._conv_name_col)
        self._conv_source_col = ttk.Entry(conv_opts, width=18)
        self._conv_source_col.insert(0, "IC50 (nM)")
        Tooltip(
            self._conv_source_col,
            "pIC50 mode: the measurement column to convert "
            "(qualifiers like '<' / '>' are respected).",
        )
        form_row(conv_opts, "measure column (pIC50)", self._conv_source_col)
        self._conv_unit = ttk.Combobox(
            conv_opts, state="readonly", width=8, values=("nM", "uM", "µM", "mM", "M", "pM")
        )
        self._conv_unit.set("nM")
        form_row(conv_opts, "unit (pIC50)", self._conv_unit)
        self._conv_embed_var = tk.BooleanVar(value=True)
        embed_check = ttk.Checkbutton(
            conv_opts, text="embed 3D + UFF (SDF)", variable=self._conv_embed_var
        )
        form_row(conv_opts, "geometry", embed_check)
        conv_run_row = ttk.Frame(convert, style="Card.TFrame")
        grid_append(convert, conv_run_row, sticky="w", pady=(6, 0))
        conv_run_btn = self._action_button(
            conv_run_row,
            "Convert",
            self._conv_run,
            primary=True,
            tooltip="Runs in a worker thread; invalid SMILES are counted "
            "(never abort the batch) and the report names every "
            "non-fatal note.",
        )
        conv_run_btn.pack(side="left")
        self._conv_summary = ttk.Label(
            conv_run_row, text="—", style="CardMuted.TLabel", wraplength=520, justify="left"
        )
        self._conv_summary.pack(side="left", padx=(10, 0))
        conv_save_btn = self._action_button(
            conv_run_row,
            "Save table CSV…",
            self._conv_save_table,
            tooltip="Writes the last table-shaped result (SDF→table or pIC50) as CSV.",
        )
        conv_save_btn.pack(side="left", padx=(10, 0))
        conv_tree_frame = ttk.Frame(convert, style="Card.TFrame")
        grid_append(convert, conv_tree_frame, sticky="nsew", pady=(6, 0), weight=True)
        self._conv_tree = ttk.Treeview(conv_tree_frame, show="headings", height=6)
        conv_bar = ttk.Scrollbar(conv_tree_frame, orient="vertical", command=self._conv_tree.yview)
        conv_bar_x = ttk.Scrollbar(
            conv_tree_frame, orient="horizontal", command=self._conv_tree.xview
        )
        self._conv_tree.configure(yscrollcommand=conv_bar.set, xscrollcommand=conv_bar_x.set)
        self._conv_tree.pack(side="left", fill="both", expand=True)
        conv_bar.pack(side="right", fill="y")
        conv_bar_x.pack(side="bottom", fill="x")
        self._conv_frame: Any = None

        # -- library similarity scan (100x-110) -------------------------- #
        # The rar's Tanimoto calculator / Tanimoto-edited pair: the
        # reference × library matrix, the threshold scan and top-k.
        scan = make_card(
            page.grid,
            "Library similarity scan",
            row=5,
            column=0,
            span=2,
            subtitle="The rar's Tanimoto calculator & Tanimoto-edited: "
            "paste references on the left and a library on the "
            "right (or load one from a CSV) -- the all-vs-all "
            "Tanimoto matrix, the pairs-above-threshold scan, "
            "or the top-k nearest neighbours of one query.",
        )
        scan.columnconfigure(0, weight=1)
        scan.columnconfigure(1, weight=1)
        scan_left = ttk.Frame(scan, style="Card.TFrame")
        scan_left.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        ttk.Label(
            scan_left, text="references / query (one SMILES per line)", style="CardMuted.TLabel"
        ).pack(anchor="w")
        self._scan_ref_text = _grid_text(scan_left, height=5, mono=self._mono)
        self._scan_ref_text.insert("1.0", "\n".join(_SCAN_DEFAULT_REFS))
        self._scan_ref_text.pack(fill="both", expand=True, pady=(4, 0))
        scan_right = ttk.Frame(scan, style="Card.TFrame")
        scan_right.grid(row=0, column=1, sticky="nsew")
        ttk.Label(
            scan_right, text="library (SMILES per line, or pick a CSV)", style="CardMuted.TLabel"
        ).pack(anchor="w")
        self._scan_lib_text = _grid_text(scan_right, height=5, mono=self._mono)
        self._scan_lib_text.insert("1.0", "\n".join(_SCAN_DEFAULT_LIB))
        self._scan_lib_text.pack(fill="both", expand=True, pady=(4, 0))
        scan_lib_pick = self._action_button(
            scan_right,
            "Load library CSV…",
            self._scan_pick_library,
            tooltip="A CSV with a SMILES column (auto-detected); it replaces the pasted library.",
        )
        scan_lib_pick.pack(anchor="w", pady=(6, 0))
        self._scan_lib_info = ttk.Label(
            scan_right, text="", style="CardMuted.TLabel", wraplength=300, justify="left"
        )
        self._scan_lib_info.pack(anchor="w")
        scan_controls = ttk.Frame(scan, style="Card.TFrame")
        grid_append(scan, scan_controls, sticky="ew", pady=(8, 0))
        scan_controls.columnconfigure(1, weight=1)
        self._scan_mode = ttk.Combobox(
            scan_controls, state="readonly", width=28, values=_SCAN_MODES
        )
        self._scan_mode.set(_SCAN_MODES[0])
        Tooltip(
            self._scan_mode,
            "matrix: every reference × every library (the Tanimoto "
            "calculator table); scan: the pairs at or above the "
            "threshold (Tanimoto-edited); top-k: the nearest library "
            "entries of the FIRST reference.",
        )
        form_row(scan_controls, "mode", self._scan_mode)
        self._scan_threshold = ttk.Entry(scan_controls, width=10)
        self._scan_threshold.insert(0, "0.9")
        form_row(scan_controls, "threshold (scan)", self._scan_threshold)
        self._scan_k = ttk.Entry(scan_controls, width=10)
        self._scan_k.insert(0, "10")
        form_row(scan_controls, "k (top matches)", self._scan_k)
        self._scan_kind = ttk.Combobox(
            scan_controls,
            state="readonly",
            width=16,
            values=("rdkit", "morgan", "atom_pair", "avalon"),
        )
        self._scan_kind.set("rdkit")
        form_row(scan_controls, "fingerprint", self._scan_kind)
        self._scan_bits = ttk.Entry(scan_controls, width=10)
        self._scan_bits.insert(0, "2048")
        form_row(scan_controls, "bits", self._scan_bits)
        self._scan_radius = ttk.Entry(scan_controls, width=10)
        self._scan_radius.insert(0, "2")
        form_row(scan_controls, "radius (morgan)", self._scan_radius)
        scan_run_row = ttk.Frame(scan, style="Card.TFrame")
        grid_append(scan, scan_run_row, sticky="w", pady=(6, 0))
        scan_run_btn = self._action_button(
            scan_run_row,
            "Scan",
            self._scan_run,
            primary=True,
            tooltip="Fingerprints both sides with the chosen kind and "
            "computes the Tanimoto relation in a worker thread.",
        )
        scan_run_btn.pack(side="left")
        self._scan_summary = ttk.Label(
            scan_run_row, text="—", style="CardMuted.TLabel", wraplength=520, justify="left"
        )
        self._scan_summary.pack(side="left", padx=(10, 0))
        scan_save_btn = self._action_button(
            scan_run_row,
            "Save result CSV…",
            self._scan_save,
            tooltip="The last scan/matrix/top-k table.",
        )
        scan_save_btn.pack(side="left", padx=(10, 0))
        scan_heat_btn = self._action_button(
            scan_run_row,
            "Plot heatmap",
            self._scan_plot_heatmap,
            tooltip="The matrix mode's labelled heat-map figure "
            "(plot_similarity_heatmap) — run a matrix scan first.",
        )
        scan_heat_btn.pack(side="left", padx=(10, 0))
        save_scan_figure_btn = self._action_button(
            scan_run_row,
            "Save figure…",
            self._save_scan_figure,
            tooltip="Save the figure this card is currently showing -- the "
            "similarity heat-map -- as PNG, SVG or PDF (unlike Ctrl+S, "
            "which saves the last figure drawn anywhere).",
        )
        save_scan_figure_btn.pack(side="left", padx=(10, 0))
        scan_tree_frame = ttk.Frame(scan, style="Card.TFrame")
        grid_append(scan, scan_tree_frame, sticky="nsew", pady=(6, 0), weight=True)
        self._scan_tree = ttk.Treeview(scan_tree_frame, show="headings", height=7)
        scan_bar = ttk.Scrollbar(scan_tree_frame, orient="vertical", command=self._scan_tree.yview)
        scan_bar_x = ttk.Scrollbar(
            scan_tree_frame, orient="horizontal", command=self._scan_tree.xview
        )
        self._scan_tree.configure(yscrollcommand=scan_bar.set, xscrollcommand=scan_bar_x.set)
        self._scan_tree.pack(side="left", fill="both", expand=True)
        scan_bar.pack(side="right", fill="y")
        scan_bar_x.pack(side="bottom", fill="x")
        self._scan_host = self._figure_host(scan, height=280)
        self._scan_frame: Any = None
        self._scan_matrix: Any = None  # (matrix, refs, libs) — heatmap fuel

        # -- tautomer & 3D structure (the library's canonicalize_tautomer
        #    + smiles_to_pdb — the 100x-119 completeness review) --------- #
        taut = make_card(
            page.grid,
            "Tautomer & 3D structure",
            row=6,
            column=0,
            subtitle="Canonical tautomer form (RDKit's tautomer "
            "canonicalization) and a multi-conformer 3D PDB "
            "written to disk (ETKDG embedding + UFF relaxation).",
        )
        self._taut_smiles = ttk.Entry(taut, width=26)
        self._taut_smiles.insert(0, "CC(=O)Oc1ccccc1C(=O)O")
        form_row(taut, "SMILES", self._taut_smiles)
        self._taut_confs = ttk.Entry(taut, width=10)
        self._taut_confs.insert(0, "50")
        form_row(taut, "conformers", self._taut_confs)
        taut_buttons = ttk.Frame(taut, style="Card.TFrame")
        grid_append(taut, taut_buttons, sticky="w", pady=(6, 0))
        taut_btn = self._action_button(
            taut_buttons,
            "Canonical tautomer",
            self._tautomer_run,
            tooltip="The canonical tautomer form of the SMILES — the form "
            "the descriptor calculations should agree on.",
        )
        taut_btn.pack(side="left")
        taut_pdb_btn = self._action_button(
            taut_buttons,
            "Write 3D PDB…",
            self._smiles_3d_run,
            primary=True,
            tooltip="Embeds the requested number of conformers, relaxes "
            "them with UFF and writes a multi-model PDB (asks "
            "where to save).",
        )
        taut_pdb_btn.pack(side="left", padx=(10, 0))
        self._taut_result = ttk.Label(
            taut,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=320,
            justify="left",
        )
        grid_append(taut, self._taut_result, sticky="w")
        self._taut_report = _grid_text(taut, height=6, mono=self._mono)
        self._taut_report.insert(
            "1.0", "the 3D writer's report appears here (conformers, atoms, energies)"
        )
        grid_append(taut, self._taut_report, sticky="ew", pady=(6, 0))
        bind_enter(self._taut_smiles, taut_btn)

        # -- MACCS keys (the library's compute_maccs — 167 structural  #
        #    keys as a fingerprint matrix; the 100x-119 review) --------- #
        maccs = make_card(
            page.grid,
            "MACCS key fingerprint",
            row=6,
            column=1,
            subtitle="The 167-bit MACCS structural-key count for a pasted "
            "list of SMILES — the classic substructure "
            "fingerprint, one bit per structural rule.",
        )
        self._maccs_text = _grid_text(maccs, height=6, mono=self._mono)
        self._maccs_text.insert("1.0", "\n".join(_FEAT_DEFAULT_SMILES))
        grid_append(maccs, self._maccs_text, sticky="ew")
        maccs_buttons = ttk.Frame(maccs, style="Card.TFrame")
        grid_append(maccs, maccs_buttons, sticky="w", pady=(6, 0))
        maccs_btn = self._action_button(
            maccs_buttons,
            "Compute MACCS",
            self._maccs_run,
            primary=True,
            tooltip="compute_maccs: the 167-bit key vector per molecule, mean on-bits summarised.",
        )
        maccs_btn.pack(side="left")
        self._maccs_result = ttk.Label(
            maccs_buttons, text="—", style="CardMuted.TLabel", wraplength=300, justify="left"
        )
        self._maccs_result.pack(side="left", padx=(10, 0))

    def _rism_run(self) -> None:
        """Compute the RISM-KH solvation descriptors for the pasted array."""
        if (
            not self._require_pharmaml()
            or not self._require("pandas", "RISM-KH descriptors")
            or not self._require("rdkit", "RISM-KH descriptors")
        ):
            return
        smiles = parse_smiles_lines(self._rism_text.get("1.0", "end"))
        if not smiles:
            messagebox.showwarning("Empty array", "Paste at least one SMILES (one per line).")
            return
        solvent = self._rism_solvent_combo.get()
        try:
            temperature = parse_float(self._rism_temp_entry.get(), "temperature (K)")
            if temperature <= 0:
                raise ValueError("temperature (K) must be positive")
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        def work() -> Any:
            from pharmaml.chem.rism import compute_rism_descriptors

            return compute_rism_descriptors(
                smiles,
                solvent=solvent,
                temperature=temperature,
                progress=False,
            )

        def render(frame: Any) -> None:
            self._rism_frame = frame
            tree = self._rism_tree
            tree.delete(*tree.get_children())
            for _, row in frame.iterrows():
                molecule = str(row["SMILES"])
                for descriptor, (meaning, unit) in _RISM_MEANINGS.items():
                    value = row[descriptor]
                    tree.insert(
                        "",
                        "end",
                        values=(
                            _cell_text(molecule, limit=24),
                            descriptor,
                            _cell_text(value, limit=14),
                            f"{meaning} ({unit})",
                        ),
                    )
            gsolv = frame["RISM_Gsolv_kcalmol"]
            self._rism_summary.configure(
                text=(
                    f"{len(frame)} molecule(s) · {solvent.upper()} water · "
                    f"{temperature:.2f} K · Gsolv "
                    f"{gsolv.min():+.2f} … {gsolv.max():+.2f} kcal/mol"
                ),
                style="Field.TLabel",
            )

        self._start_job(f"computing RISM-KH ({solvent})", work, render)

    def _rism_save(self) -> None:
        frame = getattr(self, "_rism_frame", None)
        if frame is None:
            messagebox.showinfo("Nothing to save", "Compute the RISM-KH descriptors first.")
            return
        self._save_frame_dialog(
            frame, "Save the RISM-KH descriptors", "rism_kh.csv", "RISM-KH table"
        )

    # -- structure & table converters (100x-110) ------------------------ #
    def _conv_pick_input(self) -> None:
        path = filedialog.askopenfilename(
            title="Pick the converter input",
            filetypes=[
                ("Tables & structures", "*.csv *.tsv *.xlsx *.sdf *.smi"),
                ("All files", "*.*"),
            ],
        )
        if not path:
            return
        self._conv_input = Path(path)
        out = self._conv_output.name if self._conv_output else "—"
        self._conv_info.configure(text=f"input: {path}\noutput: {out}")

    def _conv_pick_output(self) -> None:
        mode = self._conv_mode.get()
        if mode.startswith("append pIC50"):
            messagebox.showinfo(
                "pIC50 mode",
                "The pIC50 mode keeps everything in memory -- use the "
                "'Save table CSV…' button after the run instead of an "
                "output file.",
            )
            return
        extension = (
            ".sdf"
            if "SDF" in mode and mode.startswith("CSV")
            else (".csv" if "CSV" in mode else ".smi")
        )
        path = filedialog.asksaveasfilename(
            title="Pick the converter output",
            defaultextension=extension,
            filetypes=[("Output file", f"*{extension}"), ("All files", "*.*")],
        )
        if not path:
            return
        self._conv_output = Path(path)
        inp = self._conv_input.name if self._conv_input else "—"
        self._conv_info.configure(text=f"input: {inp}\noutput: {path}")

    def _conv_run(self) -> None:
        """Run the selected structure/table conversion (worker thread)."""
        if not self._require_pharmaml() or not self._require("pandas", "structure conversion"):
            return
        mode = self._conv_mode.get()
        if self._conv_input is None:
            messagebox.showwarning("No input", "Pick the input file first.")
            return
        input_path = self._conv_input
        smiles_col = self._conv_smiles_col.get().strip() or "SMILES"
        name_col = self._conv_name_col.get().strip() or None
        embed_uff = bool(self._conv_embed_var.get())

        if mode.startswith("append pIC50"):
            source_col = self._conv_source_col.get().strip() or "IC50 (nM)"
            unit = self._conv_unit.get()

            def work() -> Any:
                from pharmaml.chem import add_pic50_column
                from pharmaml.utils.io import read_table

                frame = read_table(input_path)
                return add_pic50_column(
                    frame, source_col=source_col, out_col="pIC50", unit=unit, drop_invalid=False
                )

            def render(frame: Any) -> None:
                self._conv_frame = frame
                self._fill_dynamic_tree(self._conv_tree, frame)
                valid = int(frame["pIC50"].notna().sum()) if "pIC50" in frame else 0
                self._conv_summary.configure(
                    text=(
                        f"{len(frame):,} rows · {valid} pIC50 value(s) · "
                        f"{len(frame) - valid} unconvertible (kept as NaN, "
                        f"never fabricated)"
                    ),
                    style="Field.TLabel",
                )

            self._start_job(f"appending pIC50 to {input_path.name}", work, render)
            return

        if self._conv_output is None:
            messagebox.showwarning("No output", "Pick the output file for this mode first.")
            return
        output_path = self._conv_output

        if mode.startswith("CSV"):
            if not self._require("rdkit", "3D SDF embedding"):
                return

            def work() -> Any:
                from pharmaml.chem import table_to_sdf

                return table_to_sdf(
                    input_path,
                    output_path,
                    smiles_col=smiles_col,
                    name_col=name_col,
                    embed3d=embed_uff,
                    uff=embed_uff,
                )

            def render(report: Any) -> None:
                self._conv_frame = None
                tree = self._conv_tree
                tree.delete(*tree.get_children())
                tree["columns"] = ("report",)
                tree.heading("report", text="report")
                tree.column("report", width=340, stretch=True)
                for line in (
                    f"written: {report.output_sdf}",
                    f"molecules: {report.molecules}",
                    f"invalid SMILES rows: {report.failures}",
                    f"3D-embedded: {report.embedded_3d}",
                    *(f"note: {note}" for note in report.notes[:6]),
                ):
                    tree.insert("", "end", values=(line,))
                self._conv_summary.configure(
                    text=(
                        f"{report.molecules} molecule(s) → "
                        f"{Path(report.output_sdf).name} · "
                        f"{report.failures} invalid · "
                        f"{report.embedded_3d} embedded"
                    ),
                    style="Field.TLabel",
                )

            self._start_job(f"writing {output_path.name}", work, render)
            return

        if mode.startswith(".smi"):

            def work() -> Any:
                from pharmaml.chem import smi_to_csv

                return smi_to_csv(input_path, output_path)

            def render(written: Any) -> None:
                self._conv_frame = None
                tree = self._conv_tree
                tree.delete(*tree.get_children())
                tree["columns"] = ("report",)
                tree.heading("report", text="report")
                tree.column("report", width=340, stretch=True)
                tree.insert("", "end", values=(f"written: {written}",))
                self._conv_summary.configure(
                    text=f"SMILES list converted to {Path(written).name}", style="Field.TLabel"
                )

            self._start_job(f"converting {input_path.name}", work, render)
            return

        if mode.startswith("SDF"):

            def work() -> Any:
                from pharmaml.chem import sdf_to_table

                return sdf_to_table(input_path, smiles_col=smiles_col)

            def render(frame: Any) -> None:
                self._conv_frame = frame
                self._fill_dynamic_tree(self._conv_tree, frame)
                self._conv_summary.configure(
                    text=(
                        f"{len(frame):,} record(s) → table · "
                        f"{len(frame.columns)} columns (tags + SMILES + "
                        f"name)"
                    ),
                    style="Field.TLabel",
                )

            self._start_job(f"reading {input_path.name}", work, render)
            return

        # table -> .smi
        def work() -> Any:
            from pharmaml.chem import table_to_smi

            return table_to_smi(input_path, output_path, smiles_col=smiles_col, name_col=name_col)

        def render(written: Any) -> None:
            self._conv_frame = None
            tree = self._conv_tree
            tree.delete(*tree.get_children())
            tree["columns"] = ("report",)
            tree.heading("report", text="report")
            tree.column("report", width=340, stretch=True)
            tree.insert("", "end", values=(f"written: {written}",))
            self._conv_summary.configure(
                text=f"table exported as {Path(written).name}", style="Field.TLabel"
            )

        self._start_job(f"writing {output_path.name}", work, render)

    def _conv_save_table(self) -> None:
        frame = getattr(self, "_conv_frame", None)
        if frame is None:
            messagebox.showinfo(
                "Nothing to save",
                "The last conversion produced no in-memory table (file "
                "modes write directly; SDF→table and pIC50 do).",
            )
            return
        self._save_frame_dialog(frame, "Save the converted table", "converted.csv")

    # -- library similarity scan (100x-110) ------------------------------ #
    def _scan_pick_library(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "library loading"):
            return
        path = filedialog.askopenfilename(
            title="Open the library CSV",
            filetypes=[("Data files", "*.csv *.tsv *.txt"), ("All files", "*.*")],
        )
        if not path:
            return

        def work() -> Any:
            from pharmaml.utils.io import read_table

            frame = read_table(path)
            column = detect_smiles_column(frame)
            if column is None:
                raise ValueError(
                    "no SMILES column found -- expected a column named "
                    "SMILES/smiles/canonical_smiles holding molecules"
                )
            return frame[column].astype(str).tolist()

        def render(smiles: Any) -> None:
            self._scan_lib_text.delete("1.0", "end")
            self._scan_lib_text.insert("1.0", "\n".join(smiles))
            self._scan_lib_info.configure(
                text=f"{len(smiles)} SMILES loaded from {Path(path).name}"
            )

        self._start_job(f"loading {Path(path).name}", work, render)

    def _scan_run(self) -> None:
        """Compute the chosen Tanimoto relation (matrix / scan / top-k)."""
        if (
            not self._require_pharmaml()
            or not self._require("pandas", "similarity scan")
            or not self._require("rdkit", "similarity scan")
        ):
            return
        references = parse_smiles_lines(self._scan_ref_text.get("1.0", "end"))
        library = parse_smiles_lines(self._scan_lib_text.get("1.0", "end"))
        if not references or not library:
            messagebox.showwarning(
                "Empty input", "Paste reference SMILES and a library (or load a CSV)."
            )
            return
        mode = self._scan_mode.get()
        kind = self._scan_kind.get()
        try:
            n_bits = parse_int(self._scan_bits.get(), "bits", minimum=32, maximum=65536)
            radius = parse_int(self._scan_radius.get(), "radius", minimum=0, maximum=16)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        if mode.startswith("top-k"):
            try:
                k = parse_int(self._scan_k.get(), "k", minimum=1, maximum=1000)
            except ValueError as exc:
                messagebox.showerror("Input", str(exc))
                return
            query = references[0]

            def work() -> Any:
                from pharmaml.chem import top_matches

                return top_matches(
                    query, library, k=k, fingerprint=kind, n_bits=n_bits, radius=radius
                )

            def render(frame: Any) -> None:
                self._scan_frame = frame
                self._fill_dynamic_tree(
                    self._scan_tree, frame, widths={"target": 200, "similarity": 90}
                )
                best = frame["similarity"].max() if len(frame) else float("nan")
                self._scan_summary.configure(
                    text=(
                        f"top {len(frame)} of the library for the first "
                        f"reference · best Tanimoto {best:.3f} "
                        f"({kind}, {n_bits}-bit)"
                    ),
                    style="Field.TLabel",
                )

            self._start_job("scanning top matches", work, render)
            return

        if mode.startswith("scan"):
            try:
                threshold = parse_float(self._scan_threshold.get(), "threshold")
                if not 0.0 <= threshold <= 1.0:
                    raise ValueError("threshold must be within 0..1")
            except ValueError as exc:
                messagebox.showerror("Input", str(exc))
                return

            def work() -> Any:
                from pharmaml.chem import similarity_scan

                return similarity_scan(
                    references,
                    library,
                    threshold=threshold,
                    fingerprint=kind,
                    n_bits=n_bits,
                    radius=radius,
                )

            def render(frame: Any) -> None:
                self._scan_frame = frame
                self._fill_dynamic_tree(
                    self._scan_tree, frame, widths={"reference": 180, "target": 180}
                )
                self._scan_summary.configure(
                    text=(
                        f"{len(frame)} pair(s) ≥ {threshold:.2f} "
                        f"({len(references)} refs × {len(library)} "
                        f"library, {kind})"
                    ),
                    style="Field.TLabel",
                )

            self._start_job(f"scanning pairs ≥ {threshold:.2f}", work, render)
            return

        # matrix mode
        def work() -> Any:
            import numpy as np

            from pharmaml.chem import compute_fingerprints, tanimoto_matrix

            ref_bits, ref_ok = compute_fingerprints(
                references, kind=kind, radius=radius, n_bits=n_bits
            )
            lib_bits, lib_ok = compute_fingerprints(
                library, kind=kind, radius=radius, n_bits=n_bits
            )
            matrix = tanimoto_matrix(ref_bits, lib_bits)
            frame = np.round(matrix, 4)
            return frame, [references[i] for i in ref_ok], [library[i] for i in lib_ok]

        def render(result: Any) -> None:
            import pandas as pd

            matrix, refs, libs = result
            self._scan_matrix = (matrix, refs, libs)
            frame = (
                pd.DataFrame(
                    matrix,
                    index=[f"ref {i + 1}: {s[:20]}" for i, s in enumerate(refs)],
                    columns=[f"lib {i + 1}: {s[:16]}" for i, s in enumerate(libs)],
                )
                .reset_index()
                .rename(columns={"index": "reference"})
            )
            self._scan_frame = frame
            self._fill_dynamic_tree(self._scan_tree, frame)
            flat = matrix.reshape(-1)
            self._scan_summary.configure(
                text=(
                    f"{len(refs)} ref × {len(libs)} library matrix · "
                    f"min {flat.min():.3f} · mean {flat.mean():.3f} · "
                    f"max {flat.max():.3f} ({kind}, {n_bits}-bit)"
                ),
                style="Field.TLabel",
            )

        self._start_job("computing the similarity matrix", work, render)

    def _scan_save(self) -> None:
        frame = getattr(self, "_scan_frame", None)
        if frame is None:
            messagebox.showinfo("Nothing to save", "Run a scan first.")
            return
        self._save_frame_dialog(frame, "Save the similarity result", "similarity.csv")

    def _scan_plot_heatmap(self) -> None:
        """The matrix scan's labelled heat-map (plot_similarity_heatmap)."""
        stashed = getattr(self, "_scan_matrix", None)
        if stashed is None:
            messagebox.showinfo(
                "No matrix yet",
                "Run a matrix-mode scan first — the heat-map needs the "
                "references × library Tanimoto matrix.",
            )
            return
        if not self._require_pharmaml() or not self._require(
            "matplotlib", "the similarity heat-map"
        ):
            return
        _matrix, refs, libs = stashed
        kind = self._scan_kind.get()
        try:
            n_bits = parse_int(self._scan_bits.get(), "bits", minimum=32, maximum=65536)
            radius = parse_int(self._scan_radius.get(), "radius", minimum=0, maximum=16)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return
        combined = refs + libs

        def work() -> Any:
            from pharmaml.chem import compute_fingerprints, tanimoto_matrix
            from pharmaml.viz import plot_similarity_heatmap

            # plot_similarity_heatmap draws a square matrix -- build the
            # combined refs+library self-similarity (the §9 walkthrough
            # demo's shape: ref-ref, ref-lib and lib-lib blocks in one
            # picture)
            bits, ok = compute_fingerprints(combined, kind=kind, radius=radius, n_bits=n_bits)
            square = tanimoto_matrix(bits, bits)
            labels = [combined[i] for i in ok]
            labels = [f"{s[:18]}…" if len(s) > 18 else s for s in labels]
            annotate = len(labels) <= 10
            return plot_similarity_heatmap(
                square,
                labels=labels,
                annotate=annotate,
                title="Tanimoto similarity (references + library)",
            )

        def render(figure: Any) -> None:
            self._render_figure(self._scan_host, figure)

        self._start_job("similarity heat-map", work, render)

    def _tautomer_run(self) -> None:
        """Canonical tautomer of the card's SMILES (canonicalize_tautomer)."""
        if not self._require_pharmaml() or not self._require("rdkit", "tautomer canonicalization"):
            return
        smiles = self._taut_smiles.get().strip()
        if not smiles:
            messagebox.showwarning("Empty SMILES", "Type a SMILES string first.")
            return

        try:
            from pharmaml.chem import canonicalize_tautomer

            result = canonicalize_tautomer(smiles)
            self._taut_result.configure(text=result or "(none)")
        except Exception as exc:  # noqa: BLE001
            self._show_error("Tautomer canonicalization failed", exc)

    def _smiles_3d_run(self) -> None:
        """Multi-conformer 3D PDB writer (chem.smiles_to_pdb)."""
        if not self._require_pharmaml() or not self._require("rdkit", "the 3D embedder"):
            return
        smiles = self._taut_smiles.get().strip()
        if not smiles:
            messagebox.showwarning("Empty SMILES", "Type a SMILES string first.")
            return
        try:
            num_confs = parse_int(self._taut_confs.get(), "conformers", minimum=1, maximum=1000)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return
        path = filedialog.asksaveasfilename(
            title="Write 3D PDB",
            defaultextension=".pdb",
            initialfile="ligand_3d.pdb",
            filetypes=[("PDB file", "*.pdb")],
        )
        if not path:
            return

        def work() -> Any:
            from pharmaml.chem import smiles_to_pdb

            return smiles_to_pdb(smiles, path, num_confs=num_confs)

        def render(report: Any) -> None:
            lines = [
                f"3D PDB written → {report.output_path}",
                f"conformers         {report.num_conformers}",
                f"atoms / bonds      {report.num_atoms} / {report.num_bonds}",
                f"force field        {report.forcefield}",
                f"name               {report.name}",
            ]
            self._taut_report.delete("1.0", "end")
            self._taut_report.insert("1.0", "\n".join(lines))
            self._taut_result.configure(
                text=(
                    f"{report.num_conformers} conformers · "
                    f"{report.num_atoms} atoms · {report.forcefield} → "
                    f"{report.output_path}"
                )
            )

        self._start_job("3D embedding + UFF", work, render)

    def _maccs_run(self) -> None:
        """MACCS structural-key fingerprint card (compute_maccs)."""
        if (
            not self._require_pharmaml()
            or not self._require("numpy", "MACCS keys")
            or not self._require("rdkit", "MACCS keys")
        ):
            return
        smiles = parse_smiles_lines(self._maccs_text.get("1.0", "end"))
        if not smiles:
            messagebox.showwarning("Empty list", "Paste at least one SMILES.")
            return

        def work() -> Any:
            from pharmaml.chem import compute_maccs

            matrix, ok = compute_maccs(smiles)
            return matrix, [smiles[i] for i in ok]

        def render(payload: Any) -> None:
            matrix, kept = payload
            on_bits = matrix.sum(axis=1) if matrix.size else []
            if len(kept):
                per = "  ·  ".join(f"{s[:16]}: {int(bits)}/167" for s, bits in zip(kept, on_bits))
                mean = float(on_bits.mean())
                self._maccs_result.configure(
                    text=(f"{len(kept)} molecule(s) · mean {mean:.1f}/167 keys set\n{per}"),
                    style="Field.TLabel",
                    justify="left",
                )
            dropped = len(smiles) - len(kept)
            if dropped:
                self._maccs_result.configure(
                    text=f"{dropped} SMILES failed to parse — no MACCS keys"
                )

        self._start_job("MACCS keys", work, render)

    def _convert_affinity(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "conversion"):
            return
        from pharmaml.chem import ic50_to_pic50, ki_to_pki

        mode = self._aff_mode.get()
        func = ic50_to_pic50 if mode.startswith("IC50") else ki_to_pki
        try:
            value = func(self._aff_value.get().strip(), unit=self._aff_unit.get())
        except Exception as exc:  # noqa: BLE001
            self._show_error("Conversion failed", exc)
            return
        if value is None:
            self._aff_result.configure(text="n/a (unparseable entry)")
            return
        self._aff_result.configure(text=f"{value:.3f}")

    def _molar_mass(self) -> None:
        if not self._require_pharmaml():
            return
        from pharmaml.pharma.units import molar_mass

        try:
            value = molar_mass(self._formula.get().strip())
        except Exception as exc:  # noqa: BLE001
            self._show_error("Could not parse the formula", exc)
            return
        self._mass_result.configure(text=f"{value:,.3f} g/mol")

    def _analyse_smiles(self) -> None:
        if not self._require_pharmaml() or not self._require("rdkit", "descriptors"):
            return
        smiles = self._smiles_entry.get().strip()
        if not smiles:
            messagebox.showwarning("Empty SMILES", "Type a SMILES string first.")
            return

        def work() -> Any:
            from pharmaml.chem import compute_descriptors

            return compute_descriptors([smiles], progress=False)

        self._start_job(f"descriptors for {smiles[:28]}…", work, self._render_descriptors)

    def _render_descriptors(self, frame: Any) -> None:
        self._desc_frame = frame
        self._desc_rows = []
        self._desc_tree.delete(*self._desc_tree.get_children())
        items = sorted(zip(frame.columns, frame.iloc[0].tolist()))
        for name, value in items:
            text = _cell_text(value, limit=40)
            item = self._desc_tree.insert("", "end", values=(name, text))
            self._desc_rows.append((item, str(name), text))
        highlights = {
            "MolWt": "MW",
            "MolLogP": "LogP",
            "TPSA": "TPSA",
            "NumHBD": "H-bond donors",
            "NumHBA": "H-bond acceptors",
            "NumRotatableBonds": "rotatable bonds",
            "RingCount": "rings",
        }
        found = [
            f"{short} {format_number(frame.iloc[0][key])}"
            for key, short in highlights.items()
            if key in frame.columns
        ]
        self._smiles_summary.configure(
            text=("  ·  ".join(found) if found else f"{len(items)} descriptors")
        )
        self._filter_descriptors()

    def _filter_descriptors(self, _event: Any = None) -> None:
        query = self._desc_search.get().strip().lower()
        for item, name, _value in self._desc_rows:
            if query and query not in name.lower():
                self._desc_tree.detach(item)
            else:
                self._desc_tree.move(item, "", "end")

    def _save_descriptors(self) -> None:
        if self._desc_frame is None:
            messagebox.showinfo("Nothing to save", "Analyse a SMILES string first.")
            return
        self._save_frame_dialog(
            self._desc_frame, "Save descriptors", "descriptors.csv", "Descriptor table"
        )

    def _compare_similarity(self) -> None:
        if not self._require_pharmaml() or not self._require("rdkit", "fingerprints"):
            return
        from pharmaml.chem import compute_fingerprints, tanimoto_from_bitarrays

        first = self._tani_a.get().strip()
        second = self._tani_b.get().strip()
        if not first or not second:
            messagebox.showwarning("Missing SMILES", "Both molecules are needed.")
            return
        try:
            prints, valid = compute_fingerprints([first, second])
        except Exception as exc:  # noqa: BLE001
            self._show_error("Fingerprint failed", exc)
            return
        if len(valid) < 2:
            self._tani_result.configure(text="invalid SMILES")
            self._tani_verdict.configure(text="One of the two strings is not valid RDKit input.")
            return
        score = float(tanimoto_from_bitarrays(prints[0], prints[1]))
        if score >= 0.85:
            verdict = "near-identical fingerprints"
        elif score >= 0.6:
            verdict = "clearly related scaffolds"
        elif score >= 0.35:
            verdict = "loosely related"
        else:
            verdict = "essentially unrelated"
        self._tani_result.configure(text=f"{score:.3f}")
        self._tani_verdict.configure(text=f"{verdict} (1.0 = identical, 0.0 = nothing shared)")

    # -- feature factory card -------------------------------------------- #
    def _feat_refresh_source(self) -> None:
        """Show the CSV row or the pasted-SMILES box per the source radios."""
        if self._feat_source_var.get() == "CSV file":
            self._feat_csv_box.grid()
            self._feat_pasted_box.grid_remove()
        else:
            self._feat_csv_box.grid_remove()
            self._feat_pasted_box.grid()

    def _feat_update_width(self) -> None:
        """Re-pin the estimated column count from the ticked families."""
        selected = [
            family
            for family, _label in _FEATURE_FAMILY_LABELS
            if self._feat_family_vars[family].get()
        ]
        if not selected:
            self._feat_width_label.configure(text="no families selected — tick at least one")
            return
        width = feature_factory_width(selected, self._feat_descriptor_count)
        self._feat_width_label.configure(
            text=(f"{len(selected)} families selected · ~{width:,} columns will be computed")
        )

    def _feat_open_csv(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "CSV loading"):
            return
        path = filedialog.askopenfilename(
            title="Open a SMILES CSV",
            filetypes=[("SMILES table", "*.csv *.tsv"), ("All files", "*.*")],
        )
        if path:
            self._feat_load_path(Path(path))

    def _feat_load_example(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "CSV loading"):
            return
        path = EXAMPLES_DIR / "library_with_descriptors.csv"
        if not path.is_file():
            messagebox.showwarning(
                "Missing example",
                "examples/data/library_with_descriptors.csv was not found.",
            )
            return
        self._feat_load_path(path)

    def _feat_load_path(self, path: Path) -> None:
        try:
            from pharmaml.utils.io import read_table

            frame = read_table(path)
        except Exception as exc:  # noqa: BLE001
            self._show_error("Could not read the CSV", exc)
            return
        if frame.empty:
            messagebox.showwarning("Empty CSV", f"{path.name} has no rows.")
            return
        smiles_column = detect_smiles_column(frame)
        if smiles_column is None:
            messagebox.showwarning(
                "No SMILES column",
                f"{path.name} has no SMILES column (looked for smiles / smile / "
                "canonical_smiles / ...).",
            )
            return
        import pandas as pd

        candidates = [
            str(column)
            for column in frame.columns
            if str(column) != smiles_column and pd.api.types.is_numeric_dtype(frame[column])
        ]
        self._feat_csv_frame = frame
        self._feat_csv_path = path
        self._feat_smiles_column = smiles_column
        self._feat_target_combo["values"] = (_FEAT_NO_TARGET, *candidates)
        self._feat_target_combo.set(_FEAT_NO_TARGET)
        self._feat_source_info.configure(
            text=(
                f"{len(frame):,} rows · SMILES column '{smiles_column}' · "
                f"{len(candidates)} numeric target candidates — {path.name}"
            )
        )

    def _feat_compute(self) -> None:
        if not self._require_pharmaml():
            return
        if not self._require("rdkit", "the feature factory") or not self._require(
            "pandas", "the feature factory"
        ):
            return
        source = self._feat_source_var.get()
        target_frame: Any = None
        target_name: str | None = None
        if source == "CSV file":
            if self._feat_csv_frame is None or self._feat_smiles_column is None:
                messagebox.showwarning(
                    "No CSV loaded",
                    "Open a SMILES CSV first (or switch the source to Pasted SMILES).",
                )
                return
            smiles = [
                str(value) for value in self._feat_csv_frame[self._feat_smiles_column].tolist()
            ]
            picked = self._feat_target_combo.get()
            if picked and picked != _FEAT_NO_TARGET:
                target_name = picked
                target_frame = self._feat_csv_frame[picked]
        else:
            smiles = parse_smiles_lines(self._feat_pasted_text.get("1.0", "end"))
        if not smiles:
            messagebox.showwarning("No SMILES", "The selected source holds no SMILES to compute.")
            return
        families = [
            family
            for family, _label in _FEATURE_FAMILY_LABELS
            if self._feat_family_vars[family].get()
        ]
        if not families:
            messagebox.showwarning("No families", "Tick at least one feature family.")
            return
        try:
            k = parse_int(
                self._feat_k_entry.get(), "features to keep (K)", minimum=1, maximum=100000
            )
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return
        method = _FEAT_RANKER_METHODS.get(self._feat_ranker_combo.get(), "auto")
        task = _FEAT_TASK_METHODS.get(self._feat_task_combo.get(), "auto")
        # variance ranking needs numpy only; every model ranker needs sklearn
        if method != "variance" and not self._require("sklearn", "feature ranking"):
            return
        if method in ("random_forest", "lightgbm") and target_frame is None:
            messagebox.showwarning(
                "Ranker needs a target",
                f"{self._feat_ranker_combo.get()} ranking needs a target column "
                "-- pick one from the loaded CSV, or switch the ranker to "
                "Variance (no target needed).",
            )
            return

        def work() -> Any:
            from pharmaml.chem.features import (
                compute_feature_frame,
                rank_features,
                select_top_features,
            )

            frame, report = compute_feature_frame(smiles, families=families)
            target_values: list[float] | None = None
            if target_frame is not None:
                # align against the frame's original-row index (dropped
                # molecules take their target row with them)
                target_values = [float(value) for value in target_frame.iloc[list(frame.index)]]
            ranked = rank_features(frame, target_values, method=method, task=task)
            # select_top_features demands the scores in frame column order
            scores = ranked.reindex(frame.columns)
            selection = select_top_features(frame, scores, k, median_prefilter=True, method=method)
            # k >= the candidate count returns every median survivor, so the
            # survivor count for the summary comes from the same public call
            survivors = len(select_top_features(frame, scores, len(frame.columns)).selected)
            return frame, report, selection, survivors, target_values

        def render(payload: Any) -> None:
            self._feat_render(payload, k, target_name)

        label = f"computing {len(families)} families over {len(smiles)} molecules"
        self._start_job(label, work, render)

    def _feat_render(self, payload: Any, k: int, target_name: str | None) -> None:
        frame, report, selection, survivors, target_values = payload
        self._feat_frame = frame
        self._feat_report = report
        self._feat_selection = selection
        self._feat_smiles = list(report.smiles)
        self._feat_target_series = target_values
        self._feat_target_name = target_name
        self._feat_k = k
        tree = self._feat_tree
        tree.delete(*tree.get_children())
        if report.n_valid == 0:
            self._feat_summary.configure(
                text=(
                    f"{report.total_columns:,} features · 0 valid molecules "
                    f"({len(report.dropped)} dropped) — check the SMILES source"
                ),
                style="Field.TLabel",
            )
            self._feat_family_label.configure(text="selected per family: (none)")
            self._feat_more_label.configure(text="")
            return
        from pharmaml.chem.features import family_of_column

        dropped_note = f" ({len(report.dropped)} dropped)" if report.dropped else ""
        method_label = str(selection.method).replace("_", " ")
        self._feat_summary.configure(
            text=(
                f"{report.total_columns:,} features · {report.n_valid} "
                f"molecules{dropped_note} · kept top "
                f"{len(selection.selected):,} of {survivors:,} "
                f"median-survivors · {method_label}"
            ),
            style="Field.TLabel",
        )
        family_line = " · ".join(
            f"{family} {count}" for family, count in selection.family_counts.items()
        )
        self._feat_family_label.configure(
            text=(
                f"selected per family: {family_line}"
                if family_line
                else "selected per family: (none)"
            )
        )
        shown = list(selection.selected[:300])
        for rank, column in enumerate(shown, start=1):
            tree.insert(
                "",
                "end",
                values=(
                    rank,
                    column,
                    family_of_column(column),
                    format_number(float(selection.scores[column])),
                ),
            )
        hidden = len(selection.selected) - len(shown)
        self._feat_more_label.configure(
            text=(f"+{hidden:,} more rows — save the CSV for the full list" if hidden > 0 else "")
        )

    def _feat_save_csv(self) -> None:
        if self._feat_selection is None:
            messagebox.showinfo("Nothing to save", "Compute a feature selection first.")
            return
        if not self._require_pharmaml():
            return
        try:
            import pandas as pd

            out = pd.DataFrame({"SMILES": list(self._feat_smiles)})
            if self._feat_target_name is not None and self._feat_target_series is not None:
                out[self._feat_target_name] = list(self._feat_target_series)
            for column in self._feat_selection.selected:
                out[column] = self._feat_frame[column].tolist()
        except Exception as exc:  # noqa: BLE001
            self._show_error("Could not build the table", exc)
            return
        self._save_frame_dialog(
            out, "Save the selected features", "selected_features.csv", "Selected-feature table"
        )

    def _feat_save_json(self) -> None:
        if self._feat_selection is None:
            messagebox.showinfo("Nothing to save", "Compute a feature selection first.")
            return
        if not self._require_pharmaml():
            return
        path = filedialog.asksaveasfilename(
            title="Save the selection metadata",
            defaultextension=".json",
            initialfile="selection_metadata.json",
            filetypes=[("JSON metadata", "*.json")],
        )
        if not path:
            return
        try:
            from pharmaml.chem.features import selection_metadata

            meta = selection_metadata(self._feat_selection, self._feat_report, k=self._feat_k)
            if self._feat_target_name is not None:
                meta["target_column"] = self._feat_target_name
            with open(path, "w", encoding="utf-8") as handle:
                json.dump(meta, handle, indent=2, ensure_ascii=False)
            messagebox.showinfo("Saved", f"Metadata written to\n{path}")
        except Exception as exc:  # noqa: BLE001
            self._show_error("Could not save", exc)

    def _feat_plot_distributions(self) -> None:
        """Histogram grid over the last computed feature frame (100x-120).

        ``plot_descriptor_distributions`` finally has its GUI surface:
        after a compute, the button lays the frame's numeric columns out
        as a grid of histograms (first nine columns by default) --
        skew, bimodality and outliers become visible before any model
        sees the numbers.
        """
        frame = getattr(self, "_feat_frame", None)
        if frame is None or len(frame) == 0 or len(frame.columns) == 0:
            messagebox.showinfo(
                "No features yet",
                "Compute & select features first -- the histogram grid needs the computed frame.",
            )
            return
        if not self._require_pharmaml() or not self._require(
            "matplotlib", "the distribution histograms"
        ):
            return
        n_rows, n_cols = len(frame), len(frame.columns)

        def work() -> Any:
            from pharmaml.viz import plot_descriptor_distributions

            return plot_descriptor_distributions(
                frame,
                title=(
                    f"Descriptor distributions — {n_rows} molecules · "
                    f"{n_cols:,} columns (first grid)"
                ),
            )

        def render(figure: Any) -> None:
            self._render_figure(self._feat_host, figure)

        self._start_job("descriptor distributions", work, render)

    # ------------------------------------------------------------------ #
    # PK / PD tab
    # ------------------------------------------------------------------ #
    def _build_pk_tab(self) -> None:
        page = self._new_page("PK / PD")

        half = make_card(
            page.grid,
            "Half-life ↔ elimination",
            row=0,
            column=0,
            subtitle="k(e) = ln2 / t½  ·  accumulation over a dosing interval.",
        )
        self._thalf_a = ttk.Entry(half, width=14)
        self._thalf_a.insert(0, "4")
        form_row(half, "t½ (h)", self._thalf_a)
        self._ke_a = ttk.Entry(half, width=14)
        form_row(half, "k(e) (1/h)", self._ke_a)
        self._tau_a = ttk.Entry(half, width=14)
        self._tau_a.insert(0, "6")
        form_row(half, "dosing interval τ (h)", self._tau_a)
        button = self._action_button(
            half,
            "Compute",
            self._halflife_math,
            tooltip="Derives k(e), accumulation ratio and time to steady state.",
        )
        button.grid(row=half.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._half_result = ttk.Label(
            half,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=330,
            justify="left",
        )
        self._half_result.grid(row=button.grid_info()["row"], column=1, sticky="w", padx=(10, 0))
        bind_enter(self._tau_a, button)

        ivp = make_card(
            page.grid,
            "IV bolus concentration profile",
            row=0,
            column=1,
            subtitle="C(t) = C0·e^(−k(e)·t) with half-life reference lines.",
        )
        self._iv_c0 = ttk.Entry(ivp, width=14)
        self._iv_c0.insert(0, "10")
        form_row(ivp, "C0 (mg/L)", self._iv_c0)
        self._iv_thalf = ttk.Entry(ivp, width=14)
        self._iv_thalf.insert(0, "4")
        form_row(ivp, "t½ (h)", self._iv_thalf)
        self._iv_hours = ttk.Entry(ivp, width=14)
        self._iv_hours.insert(0, "24")
        form_row(ivp, "horizon (h)", self._iv_hours)
        button = self._action_button(
            ivp,
            "Plot profile",
            self._plot_iv_bolus,
            primary=True,
            tooltip="Draws the decay curve with 1·t½, 2·t½, 3·t½ markers.",
        )
        button.grid(row=ivp.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        # 100x-128: the per-card figure export, grid-layout edition.
        save_iv_figure_btn = self._action_button(
            ivp,
            "Save figure…",
            self._save_iv_figure,
            tooltip="Save the figure this card is currently showing -- the "
            "concentration decay curve with its half-life markers -- as "
            "PNG, SVG or PDF (unlike Ctrl+S, which saves the last figure "
            "drawn anywhere).",
        )
        save_iv_figure_btn.grid(row=ivp.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._iv_host = self._figure_host(ivp)

        oral = make_card(
            page.grid,
            "Oral absorption PK",
            row=1,
            column=0,
            subtitle="One-compartment first-order absorption.",
        )
        self._po_dose = ttk.Entry(oral, width=14)
        self._po_dose.insert(0, "250")
        form_row(oral, "dose (mg)", self._po_dose)
        self._po_ka = ttk.Entry(oral, width=14)
        self._po_ka.insert(0, "1.2")
        form_row(oral, "k(a) (1/h)", self._po_ka)
        self._po_ke = ttk.Entry(oral, width=14)
        self._po_ke.insert(0, "0.173")
        form_row(oral, "k(e) (1/h)", self._po_ke)
        self._po_vd = ttk.Entry(oral, width=14)
        self._po_vd.insert(0, "40")
        form_row(oral, "Vd (L)", self._po_vd)
        self._po_f = ttk.Entry(oral, width=14)
        self._po_f.insert(0, "90")
        form_row(oral, "bioavailability F (%)", self._po_f)
        button = self._action_button(oral, "Compute", self._oral_pk)
        button.grid(row=oral.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._oral_result = ttk.Label(
            oral,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=320,
            justify="left",
        )
        self._oral_result.grid(row=button.grid_info()["row"], column=1, sticky="w", padx=(10, 0))
        bind_enter(self._po_f, button)

        crcl = make_card(
            page.grid,
            "Cockcroft–Gault creatinine clearance",
            row=1,
            column=1,
            subtitle="Plus the renal dose adjustment for a normal regimen.",
        )
        self._cg_age = ttk.Entry(crcl, width=14)
        self._cg_age.insert(0, "55")
        form_row(crcl, "age (years)", self._cg_age)
        self._cg_weight = ttk.Entry(crcl, width=14)
        self._cg_weight.insert(0, "70")
        form_row(crcl, "weight (kg)", self._cg_weight)
        self._cg_scr = ttk.Entry(crcl, width=14)
        self._cg_scr.insert(0, "1.0")
        form_row(crcl, "serum creatinine (mg/dL)", self._cg_scr)
        self._cg_sex = ttk.Combobox(crcl, state="readonly", width=12, values=("male", "female"))
        self._cg_sex.set("male")
        form_row(crcl, "sex", self._cg_sex)
        self._cg_dose = ttk.Entry(crcl, width=14)
        self._cg_dose.insert(0, "500")
        form_row(crcl, "normal dose (mg)", self._cg_dose)
        button = self._action_button(crcl, "Compute", self._creatinine_math)
        button.grid(row=crcl.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._cg_result = ttk.Label(
            crcl,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=300,
            justify="left",
        )
        self._cg_result.grid(row=button.grid_info()["row"], column=1, sticky="w", padx=(10, 0))
        bind_enter(self._cg_dose, button)

        doses = make_card(page.grid, "Loading & maintenance dosing", row=2, column=0)
        self._md_cl = ttk.Entry(doses, width=14)
        self._md_cl.insert(0, "5")
        form_row(doses, "clearance CL (L/h)", self._md_cl)
        self._md_css = ttk.Entry(doses, width=14)
        self._md_css.insert(0, "8")
        form_row(doses, "target Css (mg/L)", self._md_css)
        self._md_tau = ttk.Entry(doses, width=14)
        self._md_tau.insert(0, "8")
        form_row(doses, "interval τ (h)", self._md_tau)
        self._md_f = ttk.Entry(doses, width=14)
        self._md_f.insert(0, "90")
        form_row(doses, "bioavailability F (%)", self._md_f)
        self._ld_vd = ttk.Entry(doses, width=14)
        self._ld_vd.insert(0, "40")
        form_row(doses, "Vd (L) — loading", self._ld_vd)
        self._ld_target = ttk.Entry(doses, width=14)
        self._ld_target.insert(0, "2")
        form_row(doses, "target C (mg/L)", self._ld_target)
        button = self._action_button(doses, "Compute both", self._dose_design)
        button.grid(row=doses.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._dose_result = ttk.Label(
            doses,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=320,
            justify="left",
        )
        self._dose_result.grid(row=button.grid_info()["row"], column=1, sticky="w", padx=(10, 0))
        bind_enter(self._ld_target, button)

        bsa = make_card(
            page.grid,
            "BSA & weight-based dosing",
            row=2,
            column=1,
            subtitle="Mosteller BSA; optional maximum doses cap the result.",
        )
        self._bsa_height = ttk.Entry(bsa, width=14)
        self._bsa_height.insert(0, "175")
        form_row(bsa, "height (cm)", self._bsa_height)
        self._bsa_weight = ttk.Entry(bsa, width=14)
        self._bsa_weight.insert(0, "70")
        form_row(bsa, "weight (kg)", self._bsa_weight)
        self._bsa_per_m2 = ttk.Entry(bsa, width=14)
        self._bsa_per_m2.insert(0, "100")
        form_row(bsa, "dose per m²", self._bsa_per_m2)
        self._bsa_max = ttk.Entry(bsa, width=14)
        form_row(bsa, "max dose (optional)", self._bsa_max)
        self._wt_per_kg = ttk.Entry(bsa, width=14)
        self._wt_per_kg.insert(0, "15")
        form_row(bsa, "dose per kg", self._wt_per_kg)
        button = self._action_button(bsa, "Compute", self._bsa_math)
        button.grid(row=bsa.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._bsa_result = ttk.Label(
            bsa,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=300,
            justify="left",
        )
        self._bsa_result.grid(row=button.grid_info()["row"], column=1, sticky="w", padx=(10, 0))
        bind_enter(self._wt_per_kg, button)

        peds = make_card(
            page.grid,
            "Pediatric dose rules",
            row=3,
            column=0,
            subtitle="Young's rule (age) and Clark's rule (weight in lb).",
        )
        self._young_age = ttk.Entry(peds, width=14)
        self._young_age.insert(0, "6")
        form_row(peds, "child age (years)", self._young_age)
        self._clark_lb = ttk.Entry(peds, width=14)
        self._clark_lb.insert(0, "40")
        form_row(peds, "child weight (lb)", self._clark_lb)
        self._adult_dose = ttk.Entry(peds, width=14)
        self._adult_dose.insert(0, "500")
        form_row(peds, "adult dose (mg)", self._adult_dose)
        button = self._action_button(peds, "Compute both", self._pediatric_math)
        button.grid(row=peds.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._ped_result = ttk.Label(
            peds,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=320,
            justify="left",
        )
        self._ped_result.grid(row=button.grid_info()["row"], column=1, sticky="w", padx=(10, 0))
        bind_enter(self._adult_dose, button)

        emax = make_card(
            page.grid,
            "Emax pharmacodynamics",
            row=3,
            column=1,
            subtitle="E = E0 + Emax·C/(EC50 + C) — table plus the full curve.",
        )
        self._pd_e0 = ttk.Entry(emax, width=14)
        self._pd_e0.insert(0, "5")
        form_row(emax, "baseline E0", self._pd_e0)
        self._pd_emax = ttk.Entry(emax, width=14)
        self._pd_emax.insert(0, "60")
        form_row(emax, "Emax", self._pd_emax)
        self._pd_ec50 = ttk.Entry(emax, width=14)
        self._pd_ec50.insert(0, "2.5")
        form_row(emax, "EC50", self._pd_ec50)
        self._pd_concs = ttk.Entry(emax, width=24)
        self._pd_concs.insert(0, "0.5, 1, 2.5, 5, 10, 25")
        form_row(emax, "concentrations (comma list)", self._pd_concs)
        button = self._action_button(emax, "Compute & plot", self._emax_math, primary=True)
        button.grid(row=emax.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._pd_result = ttk.Label(
            emax, text="—", style="CardMuted.TLabel", wraplength=300, justify="left"
        )
        self._pd_result.grid(row=button.grid_info()["row"], column=1, sticky="w", padx=(10, 0))
        save_pd_figure_btn = self._action_button(
            emax,
            "Save figure…",
            self._save_pd_figure,
            tooltip="Save the figure this card is currently showing -- the "
            "Emax effect curve over your concentrations -- as PNG, SVG or "
            "PDF (unlike Ctrl+S, which saves the last figure drawn "
            "anywhere).",
        )
        save_pd_figure_btn.grid(row=emax.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._pd_host = self._figure_host(emax, height=300)
        bind_enter(self._pd_concs, button)

        # -- non-compartmental analysis (the library's pharma.pk NCA) -- #
        nca = make_card(
            page.grid,
            "Non-compartmental analysis (NCA)",
            row=4,
            column=0,
            span=2,
            subtitle="Paste a concentration-time series (both comma lists, "
            "matched pairs): AUC / AUMC by the linear trapezoid, "
            "MRT, Cmax / Tmax, the terminal half-life — plus Vd and "
            "CL when a dose is given (Vd = dose / AUC after IV).",
        )
        self._nca_times = ttk.Entry(nca, width=34)
        self._nca_times.insert(0, _NCA_DEFAULT_TIMES)
        form_row(nca, "times (h)", self._nca_times)
        self._nca_concs = ttk.Entry(nca, width=34)
        self._nca_concs.insert(0, _NCA_DEFAULT_CONCS)
        form_row(nca, "concentrations", self._nca_concs)
        self._nca_dose = ttk.Entry(nca, width=14)
        form_row(nca, "IV dose (mg, optional)", self._nca_dose)
        nca_buttons = ttk.Frame(nca, style="Card.TFrame")
        grid_append(nca, nca_buttons, sticky="w", pady=(6, 0))
        nca_btn = self._action_button(
            nca_buttons,
            "Analyse",
            self._nca_run,
            primary=True,
            tooltip="Validates the series (sorted times, non-negative "
            "concentrations), then runs the trapezoid NCA.",
        )
        nca_btn.pack(side="left")
        nca_plot_btn = self._action_button(
            nca_buttons,
            "Plot profile",
            self._nca_plot,
            tooltip="The concentration-time profile with the AUC shaded under the curve.",
        )
        nca_plot_btn.pack(side="left", padx=(10, 0))
        nca_save_btn = self._action_button(
            nca_buttons,
            "Save summary CSV…",
            self._nca_save,
            tooltip="The NCA metrics as a one-row table.",
        )
        nca_save_btn.pack(side="left", padx=(10, 0))
        save_nca_figure_btn = self._action_button(
            nca_buttons,
            "Save figure…",
            self._save_nca_figure,
            tooltip="Save the figure this card is currently showing -- the "
            "concentration-time profile with its AUC -- as PNG, SVG or "
            "PDF (unlike Ctrl+S, which saves the last figure drawn "
            "anywhere).",
        )
        save_nca_figure_btn.pack(side="left", padx=(10, 0))
        self._nca_result = ttk.Label(
            nca,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=620,
            justify="left",
        )
        grid_append(nca, self._nca_result, sticky="w")
        self._nca_host = self._figure_host(nca, height=260)
        bind_enter(self._nca_concs, nca_btn)

        # -- IV infusion, steady state, Vd & bioavailability -------------- #
        infusion = make_card(
            page.grid,
            "IV infusion & distribution",
            row=5,
            column=0,
            subtitle="The infusion rate that holds a target Css "
            "(rate = CL·Css), the steady state a given rate "
            "reaches, Vd = CL / k(e), and absolute "
            "bioavailability F from paired EV/IV AUCs.",
        )
        self._inf_cl = ttk.Entry(infusion, width=14)
        self._inf_cl.insert(0, "5")
        form_row(infusion, "clearance CL (L/h)", self._inf_cl)
        self._inf_target = ttk.Entry(infusion, width=14)
        self._inf_target.insert(0, "8")
        form_row(infusion, "target Css (mg/L)", self._inf_target)
        self._inf_rate = ttk.Entry(infusion, width=14)
        self._inf_rate.insert(0, "40")
        form_row(infusion, "infusion rate (mg/h)", self._inf_rate)
        self._vd_ke = ttk.Entry(infusion, width=14)
        self._vd_ke.insert(0, "0.173")
        form_row(infusion, "k(e) (1/h) — for Vd", self._vd_ke)
        self._bio_ev_dose = ttk.Entry(infusion, width=14)
        form_row(infusion, "EV dose / AUC (optional)", self._bio_ev_dose)
        self._bio_iv_dose = ttk.Entry(infusion, width=14)
        form_row(infusion, "IV dose / AUC (optional)", self._bio_iv_dose)
        button = self._action_button(infusion, "Compute", self._infusion_math)
        button.grid(row=infusion.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._inf_result = ttk.Label(
            infusion,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=320,
            justify="left",
        )
        self._inf_result.grid(row=button.grid_info()["row"], column=1, sticky="w", padx=(10, 0))
        acc_row = ttk.Frame(infusion, style="Card.TFrame")
        grid_append(infusion, acc_row, sticky="w", pady=(8, 0))
        self._acc_dose = ttk.Entry(acc_row, width=10)
        self._acc_dose.insert(0, "250")
        self._acc_dose.pack(side="left")
        ttk.Label(acc_row, text="mg dose", style="CardMuted.TLabel").pack(side="left", padx=(4, 12))
        acc_btn = self._action_button(
            acc_row,
            "Plot repeated dosing",
            self._plot_accumulation,
            tooltip="The classic approach-to-steady-state picture: peaks "
            "and troughs over the dosing interval from t½ and τ "
            "(plot_dose_accumulation).",
        )
        acc_btn.pack(side="left")
        save_acc_figure_btn = self._action_button(
            acc_row,
            "Save figure…",
            self._save_acc_figure,
            tooltip="Save the figure this card is currently showing -- the "
            "approach-to-steady-state peaks and troughs -- as PNG, SVG "
            "or PDF (unlike Ctrl+S, which saves the last figure drawn "
            "anywhere).",
        )
        save_acc_figure_btn.pack(side="left", padx=(10, 0))
        self._acc_host = self._figure_host(infusion, height=240)
        bind_enter(self._inf_rate, button)

        # -- therapeutic drug monitoring --------------------------------- #
        tdm = make_card(
            page.grid,
            "TDM trough adjustment",
            row=5,
            column=1,
            subtitle="Dose individualisation from one measured trough: the "
            "linear-proportional new dose (with an optional floor).",
        )
        self._tdm_dose = ttk.Entry(tdm, width=14)
        self._tdm_dose.insert(0, "250")
        form_row(tdm, "current dose (mg)", self._tdm_dose)
        self._tdm_measured = ttk.Entry(tdm, width=14)
        self._tdm_measured.insert(0, "6.2")
        form_row(tdm, "measured trough", self._tdm_measured)
        self._tdm_target = ttk.Entry(tdm, width=14)
        self._tdm_target.insert(0, "10")
        form_row(tdm, "target trough", self._tdm_target)
        self._tdm_min = ttk.Entry(tdm, width=14)
        self._tdm_min.insert(0, "25")
        form_row(tdm, "minimum dose (mg)", self._tdm_min)
        button = self._action_button(tdm, "Adjust dose", self._tdm_math)
        button.grid(row=tdm.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._tdm_result = ttk.Label(
            tdm,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=300,
            justify="left",
        )
        self._tdm_result.grid(row=button.grid_info()["row"], column=1, sticky="w", padx=(10, 0))
        bind_enter(self._tdm_target, button)

        # -- PD model explorer (the full pharma.pd model family) --------- #
        family = make_card(
            page.grid,
            "PD model explorer",
            row=6,
            column=0,
            span=2,
            subtitle="The pharmacodynamic family beyond plain Emax: the "
            "sigmoid Emax with its Hill slope, the inhibitory Emax, "
            "and the linear effect — table, curve, and the reverse "
            "question (which concentration reaches a target "
            "effect?).",
        )
        family.columnconfigure(0, weight=1)
        family.columnconfigure(1, weight=1)
        fam_left = ttk.Frame(family, style="Card.TFrame")
        fam_left.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        self._pd_family_combo = ttk.Combobox(
            fam_left, state="readonly", width=24, values=_PD_FAMILY_MODES
        )
        self._pd_family_combo.set(_PD_FAMILY_MODES[0])
        Tooltip(
            self._pd_family_combo,
            "sigmoid Emax: E = E0 + Emax·C^h/(EC50^h + C^h); inhibitory "
            "Emax: E = E0 − Imax·C^h/(IC50^h + C^h); linear: E = "
            "slope·C + intercept.",
        )
        form_row(fam_left, "model", self._pd_family_combo)
        self._fam_e0 = ttk.Entry(fam_left, width=12)
        self._fam_e0.insert(0, "5")
        form_row(fam_left, "E0 (baseline)", self._fam_e0)
        self._fam_max = ttk.Entry(fam_left, width=12)
        self._fam_max.insert(0, "60")
        form_row(fam_left, "Emax / Imax", self._fam_max)
        self._fam_c50 = ttk.Entry(fam_left, width=12)
        self._fam_c50.insert(0, "2.5")
        form_row(fam_left, "EC50 / IC50", self._fam_c50)
        self._fam_hill = ttk.Entry(fam_left, width=12)
        self._fam_hill.insert(0, "1.5")
        form_row(fam_left, "Hill slope h", self._fam_hill)
        self._fam_slope = ttk.Entry(fam_left, width=12)
        self._fam_slope.insert(0, "4")
        form_row(fam_left, "slope (linear)", self._fam_slope)
        fam_right = ttk.Frame(family, style="Card.TFrame")
        fam_right.grid(row=0, column=1, sticky="nsew")
        self._fam_concs = ttk.Entry(fam_right, width=24)
        self._fam_concs.insert(0, "0.5, 1, 2.5, 5, 10, 25")
        form_row(fam_right, "concentrations (comma list)", self._fam_concs)
        self._fam_target = ttk.Entry(fam_right, width=12)
        self._fam_target.insert(0, "30")
        form_row(fam_right, "target effect (reverse EC50)", self._fam_target)
        fam_buttons = ttk.Frame(family, style="Card.TFrame")
        grid_append(family, fam_buttons, sticky="w", pady=(6, 0))
        fam_btn = self._action_button(
            fam_buttons,
            "Compute & plot",
            self._pd_family_math,
            primary=True,
            tooltip="Fills the effect table and draws the model curve over the concentration grid.",
        )
        fam_btn.pack(side="left")
        fam_rev_btn = self._action_button(
            fam_buttons,
            "Solve EC50 for target",
            self._pd_target_ec50,
            tooltip="The reverse question: which EC50 puts the model "
            "through the target effect at the given EC50 "
            "reference concentration?",
        )
        fam_rev_btn.pack(side="left", padx=(10, 0))
        save_fam_figure_btn = self._action_button(
            fam_buttons,
            "Save figure…",
            self._save_fam_figure,
            tooltip="Save the figure this card is currently showing -- the "
            "family effect curve through your points -- as PNG, SVG or "
            "PDF (unlike Ctrl+S, which saves the last figure drawn "
            "anywhere).",
        )
        save_fam_figure_btn.pack(side="left", padx=(10, 0))
        self._fam_result = ttk.Label(
            family, text="—", style="CardMuted.TLabel", wraplength=560, justify="left"
        )
        grid_append(family, self._fam_result, sticky="w")
        fam_tree_frame = ttk.Frame(family, style="Card.TFrame")
        grid_append(family, fam_tree_frame, sticky="nsew", pady=(4, 0), weight=True)
        self._fam_tree = ttk.Treeview(
            fam_tree_frame, show="headings", height=6, columns=("concentration", "effect")
        )
        self._fam_tree.heading("concentration", text="concentration")
        self._fam_tree.heading("effect", text="effect")
        self._fam_tree.column("concentration", width=160, anchor="e")
        self._fam_tree.column("effect", width=160, anchor="e")
        self._fam_tree.pack(side="left", fill="both", expand=True)
        self._fam_host = self._figure_host(family, height=280)
        bind_enter(self._fam_concs, fam_btn)

        # -- unit converter (UnitConverter, dimension-aware; 100x-121) -- #
        units_card = make_card(
            page.grid,
            "Unit converter",
            row=7,
            column=0,
            subtitle="Dimension-aware pharmaceutical unit conversion "
            "(UnitConverter): mass, volume, amount, concentration "
            "and time -- 500 mg → 0.5 g, 1 µM → 1000 nM -- with "
            "the honest UnitConversionError when a unit is unknown "
            "or the dimensions disagree.",
        )
        self._uc_dim_combo = ttk.Combobox(
            units_card, state="readonly", width=16, values=list(_UNIT_DIMENSIONS)
        )
        self._uc_dim_combo.set(_UNIT_DIMENSIONS[0])
        self._uc_dim_combo.bind("<<ComboboxSelected>>", lambda _e: self._uc_dimension_changed())
        Tooltip(
            self._uc_dim_combo,
            "Picking a dimension loads its units into both comboboxes "
            "(the entries stay editable -- a typo or a cross-dimension "
            "pick surfaces the library's own error, naming every "
            "supported unit).",
        )
        form_row(units_card, "dimension", self._uc_dim_combo)
        self._uc_value = ttk.Entry(units_card, width=14)
        self._uc_value.insert(0, "500")
        form_row(units_card, "value", self._uc_value)
        self._uc_from = ttk.Combobox(units_card, width=10)
        self._uc_from.set("mg")
        form_row(units_card, "from unit", self._uc_from)
        self._uc_to = ttk.Combobox(units_card, width=10)
        self._uc_to.set("g")
        form_row(units_card, "to unit", self._uc_to)
        uc_btn = self._action_button(
            units_card,
            "Convert",
            self._uc_convert,
            primary=True,
            tooltip="UnitConverter.convert(value, from, to) -- "
            "dimension-checked, with the conversion factor shown.",
        )
        uc_btn.grid(row=units_card.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._uc_result = ttk.Label(
            units_card,
            text="—",
            style="Result.TLabel",
            font=self._mono_result,
            wraplength=320,
            justify="left",
        )
        self._uc_result.grid(row=uc_btn.grid_info()["row"], column=1, sticky="w", padx=(10, 0))
        self._uc_units_hint = ttk.Label(
            units_card, text="", style="CardMuted.TLabel", wraplength=360, justify="left"
        )
        grid_append(units_card, self._uc_units_hint, sticky="w", pady=(2, 0))
        bind_enter(self._uc_value, uc_btn)
        bind_enter(self._uc_to, uc_btn)
        self._uc_dimension_changed()

    def _uc_dimension_changed(self) -> None:
        """Load the picked dimension's units into both comboboxes."""
        dimension = self._uc_dim_combo.get()
        choices = _UNIT_CHOICES.get(dimension, ())
        self._uc_from.configure(values=list(choices))
        self._uc_to.configure(values=list(choices))
        if choices:
            if dimension == "mass":
                self._uc_from.set("mg")
                self._uc_to.set("g")
            elif dimension == "concentration":
                self._uc_from.set("uM")
                self._uc_to.set("nM")
            elif dimension == "time":
                self._uc_from.set("h")
                self._uc_to.set("min")
            else:
                self._uc_from.set(choices[0])
                self._uc_to.set(choices[1] if len(choices) > 1 else choices[0])
        self._uc_units_hint.configure(text=f"{dimension}: " + " · ".join(choices))

    def _uc_convert(self) -> None:
        """One dimension-checked conversion (UnitConverter.convert)."""
        if not self._require_pharmaml():
            return
        from pharmaml.pharma import UnitConverter

        try:
            value = parse_float(self._uc_value.get(), "value")
            source = self._uc_from.get().strip()
            target = self._uc_to.get().strip()
            converted = UnitConverter.convert(value, source, target)
            dimension = UnitConverter.dimension_of(source)
        except Exception as exc:  # noqa: BLE001
            self._show_error("Conversion failed", exc)
            return
        factor = (converted / value) if value else None
        lines = [f"{value:g} {source}  =  {converted:.6g} {target}", f"{dimension} conversion"]
        if factor is not None:
            lines.append(f"factor  ×{factor:.6g}")
        self._uc_result.configure(text="\n".join(lines))

    def _halflife_math(self) -> None:
        if not self._require_pharmaml() or not self._require("numpy", "PK math"):
            return
        from pharmaml.pharma.pk import (
            accumulation_ratio,
            elimination_rate_constant,
            half_life,
        )

        try:
            t_half = parse_float(self._thalf_a.get(), "t½", minimum=1e-9)
            tau = parse_float(self._tau_a.get(), "τ", minimum=1e-9)
            ke = elimination_rate_constant(t_half)
            acc = accumulation_ratio(tau, t_half)
            t95 = math.log(20.0) / ke
            lines = [
                f"k(e) = {ke:.4f} 1/h",
                f"accumulation over τ = {acc:.2f}×",
                f"95% of steady state after {t95:.1f} h",
            ]
            raw_ke = self._ke_a.get().strip()
            if raw_ke:
                lines.append(
                    f"t½ from k(e) = {half_life(parse_float(raw_ke, 'k(e)', minimum=1e-12)):.2f} h"
                )
            self._half_result.configure(text="\n".join(lines))
        except Exception as exc:  # noqa: BLE001
            self._show_error("Calculation failed", exc)

    def _plot_iv_bolus(self) -> None:
        if not self._require_pharmaml() or not self._require("numpy", "PK math"):
            return
        if not self._require("matplotlib", "the decay curve"):
            return
        try:
            c0 = parse_float(self._iv_c0.get(), "C0", minimum=0.0)
            t_half = parse_float(self._iv_thalf.get(), "t½", minimum=1e-9)
            hours = parse_float(self._iv_hours.get(), "horizon", minimum=0.1)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        def work() -> Any:
            import numpy as np

            from pharmaml.pharma.pk import (
                elimination_rate_constant,
                iv_bolus_concentration,
            )

            ke = elimination_rate_constant(t_half)
            times = np.linspace(0.0, hours, 260)
            conc = np.asarray(iv_bolus_concentration(c0, ke, times), dtype=float)
            return ke, times, conc

        def render(payload: Any) -> None:
            ke, times, conc = payload
            from pharmaml.viz import PALETTE, new_figure

            fig, ax = new_figure(figsize=(5.2, 3.0))
            ax.plot(times, conc, color=PALETTE[0], lw=2.2, label="C(t)")
            for multiple in (1, 2, 3):
                mark = multiple * t_half
                if mark <= hours:
                    ax.axvline(mark, color=PALETTE[1], ls="--", lw=0.9, alpha=0.8)
                    ax.annotate(
                        f"{multiple}·t½",
                        xy=(mark, float(c0) * math.exp(-ke * mark)),
                        xytext=(4, 6),
                        textcoords="offset points",
                        fontsize=8,
                        color=MUTED,
                    )
            ax.set_xlabel("time (h)")
            ax.set_ylabel("concentration (mg/L)")
            ax.set_title(f"IV bolus decay — t½ {t_half:g} h, k(e) {ke:.3f} 1/h", loc="left")
            ax.legend(frameon=False, fontsize=8)
            self._render_figure(self._iv_host, fig)

        self._start_job("IV bolus profile", work, render)

    def _oral_pk(self) -> None:
        if not self._require_pharmaml() or not self._require("numpy", "PK math"):
            return
        from pharmaml.pharma.pk import oral_cmax, oral_tmax

        try:
            dose = parse_float(self._po_dose.get(), "dose", minimum=0.0)
            ka = parse_float(self._po_ka.get(), "k(a)", minimum=1e-9)
            ke = parse_float(self._po_ke.get(), "k(e)", minimum=1e-12)
            vd = parse_float(self._po_vd.get(), "Vd", minimum=1e-9)
            bio = parse_float(self._po_f.get(), "F %", minimum=0.0, maximum=100.0) / 100.0
            if ka <= ke:
                raise ValueError("k(a) must exceed k(e) for a peak to exist")
            t_max = oral_tmax(ka, ke)
            c_max = oral_cmax(dose, ka, ke, vd, f=bio)
            self._oral_result.configure(text=f"t(max) = {t_max:.2f} h\nC(max)  = {c_max:.3f} mg/L")
        except Exception as exc:  # noqa: BLE001
            self._show_error("Calculation failed", exc)

    def _creatinine_math(self) -> None:
        if not self._require_pharmaml() or not self._require("numpy", "PK math"):
            return
        from pharmaml.pharma.dosage import renal_dose_adjustment
        from pharmaml.pharma.pk import creatinine_clearance

        try:
            age = parse_float(self._cg_age.get(), "age", minimum=1.0, maximum=120.0)
            weight = parse_float(self._cg_weight.get(), "weight", minimum=0.1)
            scr = parse_float(self._cg_scr.get(), "serum creatinine", minimum=1e-6)
            sex = self._cg_sex.get()
            dose = parse_float(self._cg_dose.get(), "normal dose", minimum=0.0)
            clearance = creatinine_clearance(age, weight, scr, sex)
            adjusted = renal_dose_adjustment(dose, clearance)
            self._cg_result.configure(
                text=(f"CrCl = {clearance:.1f} mL/min\nadjusted dose = {adjusted:.1f} mg")
            )
        except Exception as exc:  # noqa: BLE001
            self._show_error("Calculation failed", exc)

    def _dose_design(self) -> None:
        if not self._require_pharmaml() or not self._require("numpy", "PK math"):
            return
        from pharmaml.pharma.dosage import loading_dose, maintenance_dose

        try:
            clearance = parse_float(self._md_cl.get(), "CL", minimum=1e-9)
            css = parse_float(self._md_css.get(), "target Css", minimum=1e-9)
            tau = parse_float(self._md_tau.get(), "τ", minimum=1e-9)
            bio = parse_float(self._md_f.get(), "F %", minimum=0.0, maximum=100.0) / 100.0
            vd = parse_float(self._ld_vd.get(), "Vd", minimum=1e-9)
            target = parse_float(self._ld_target.get(), "target C", minimum=1e-9)
            maintenance = maintenance_dose(clearance, css, tau, f=bio)
            loading = loading_dose(vd, target, f=bio)
            self._dose_result.configure(
                text=(f"maintenance = {maintenance:.1f} mg per τ\nloading      = {loading:.1f} mg")
            )
        except Exception as exc:  # noqa: BLE001
            self._show_error("Calculation failed", exc)

    def _bsa_math(self) -> None:
        if not self._require_pharmaml() or not self._require("numpy", "PK math"):
            return
        from pharmaml.pharma.dosage import bsa_mosteller, dose_by_bsa, dose_by_weight

        try:
            height = parse_float(self._bsa_height.get(), "height", minimum=1.0)
            weight = parse_float(self._bsa_weight.get(), "weight", minimum=0.1)
            per_m2 = parse_float(self._bsa_per_m2.get(), "dose per m²", minimum=0.0)
            per_kg = parse_float(self._wt_per_kg.get(), "dose per kg", minimum=0.0)
            raw_max = self._bsa_max.get().strip()
            cap = parse_float(raw_max, "max dose", minimum=0.0) if raw_max else None
            area = bsa_mosteller(height, weight)
            by_bsa = dose_by_bsa(per_m2, height, weight, max_dose=cap)
            by_weight = dose_by_weight(per_kg, weight, max_dose=cap)
            capped = " (capped)" if cap is not None and (by_bsa == cap or by_weight == cap) else ""
            self._bsa_result.configure(
                text=(
                    f"BSA = {area:.2f} m²\n"
                    f"BSA dose = {by_bsa:.1f} mg\n"
                    f"weight dose = {by_weight:.1f} mg{capped}"
                )
            )
        except Exception as exc:  # noqa: BLE001
            self._show_error("Calculation failed", exc)

    def _pediatric_math(self) -> None:
        if not self._require_pharmaml() or not self._require("numpy", "PK math"):
            return
        from pharmaml.pharma.dosage import clarks_rule, youngs_rule

        try:
            age = parse_float(self._young_age.get(), "child age", minimum=0.0, maximum=17.0)
            pounds = parse_float(self._clark_lb.get(), "child weight (lb)", minimum=0.1)
            adult = parse_float(self._adult_dose.get(), "adult dose", minimum=0.0)
            young = youngs_rule(age, adult)
            clark = clarks_rule(pounds, adult)
            self._ped_result.configure(
                text=f"Young (age)   = {young:.1f} mg\nClark (weight) = {clark:.1f} mg"
            )
        except Exception as exc:  # noqa: BLE001
            self._show_error("Calculation failed", exc)

    def _emax_math(self) -> None:
        if not self._require_pharmaml() or not self._require("numpy", "PD math"):
            return
        try:
            e0 = parse_float(self._pd_e0.get(), "E0")
            emax = parse_float(self._pd_emax.get(), "Emax")
            ec50 = parse_float(self._pd_ec50.get(), "EC50", minimum=1e-12)
            concs = [
                parse_float(part, "concentration", minimum=0.0)
                for part in self._pd_concs.get().split(",")
                if part.strip()
            ]
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return
        if not concs:
            messagebox.showwarning("Input", "Give at least one concentration.")
            return
        want_plot = self.deps.get("matplotlib")

        def work() -> Any:
            import numpy as np

            from pharmaml.pharma.pd import emax_effect

            effects = np.asarray(emax_effect(np.asarray(concs), e0, emax, ec50), dtype=float)
            grid = np.linspace(0.0, max(concs) * 1.15 or ec50 * 20, 240)
            curve = np.asarray(emax_effect(grid, e0, emax, ec50), dtype=float)
            return effects, grid, curve

        def render(payload: Any) -> None:
            effects, grid, curve = payload
            table = "  ·  ".join(
                f"C {format_number(c)} → E {format_number(e, 2)}" for c, e in zip(concs, effects)
            )
            self._pd_result.configure(text=table)
            if not want_plot:
                return
            try:
                from pharmaml.viz import PALETTE, new_figure

                fig, ax = new_figure(figsize=(5.2, 2.9))
                ax.plot(grid, curve, color=PALETTE[0], lw=2.2, label="E(C)")
                ax.scatter(concs, effects, color=PALETTE[1], zorder=3, label="your points")
                ax.axvline(ec50, color=MUTED, ls=":", lw=1.0)
                ax.annotate(
                    "EC50",
                    xy=(ec50, e0 + emax * 0.5),
                    xytext=(5, -2),
                    textcoords="offset points",
                    fontsize=8,
                    color=MUTED,
                )
                ax.set_xlabel("concentration")
                ax.set_ylabel("effect")
                ax.set_title("Emax model", loc="left")
                ax.legend(frameon=False, fontsize=8)
                self._render_figure(self._pd_host, fig)
            except Exception as exc:  # noqa: BLE001
                self._show_error("Plot failed", exc)

        self._start_job("Emax model", work, render)

    # -- NCA / infusion / TDM / PD-family cards (the 100x-119 review) -- #
    def _nca_series(self) -> tuple[list[float], list[float]]:
        """Parse + validate the NCA card's time/concentration lists."""
        times = [
            parse_float(part, "time") for part in self._nca_times.get().split(",") if part.strip()
        ]
        concs = [
            parse_float(part, "concentration")
            for part in self._nca_concs.get().split(",")
            if part.strip()
        ]
        if not times or not concs:
            raise ValueError("give at least one time and one concentration")
        if len(times) != len(concs):
            raise ValueError(
                f"{len(times)} times but {len(concs)} concentrations -- the "
                "two lists must be matched pairs"
            )
        return times, concs

    def _nca_run(self) -> None:
        """Trapezoid NCA over the pasted concentration-time series."""
        if not self._require_pharmaml() or not self._require("numpy", "NCA"):
            return
        try:
            times, concs = self._nca_series()
            dose_raw = self._nca_dose.get().strip()
            dose = parse_float(dose_raw, "IV dose") if dose_raw else None
            if dose is not None and dose <= 0:
                raise ValueError("IV dose must be positive")
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        def work() -> Any:
            from pharmaml.pharma.pk import (
                nca_summary,
                validate_concentration_series,
                vd_from_dose_auc,
            )

            t, c = validate_concentration_series(times, concs)
            summary = nca_summary(t, c)
            vd = vd_from_dose_auc(dose, summary.auc) if dose else None
            return summary, vd, t, c

        def render(payload: Any) -> None:
            summary, vd, t, c = payload
            self._nca_summary = summary
            parts = [
                f"AUC {format_number(summary.auc)} mg·h/L",
                f"AUMC {format_number(summary.aucm)} mg·h²/L",
                f"MRT {format_number(summary.mrt)} h",
                f"Cmax {format_number(summary.c_max)} mg/L",
                f"Tmax {format_number(summary.t_max)} h",
                f"t½(term) {format_number(summary.half_life_terminal)} h",
            ]
            if vd is not None:
                clearance = dose / summary.auc if summary.auc else float("nan")
                parts.append(f"Vd {format_number(vd)} L")
                parts.append(f"CL {format_number(clearance)} L/h")
            self._nca_result.configure(text=f"{len(t)} points · " + "  ·  ".join(parts))
            if self.deps.get("matplotlib"):
                try:
                    from pharmaml.viz import plot_concentration_profile

                    figure = plot_concentration_profile(t, c, summary=summary, auc=summary.auc)
                    self._render_figure(self._nca_host, figure)
                except Exception as exc:  # noqa: BLE001
                    self._show_error("Plot failed", exc)

        self._start_job("non-compartmental analysis", work, render)

    def _nca_plot(self) -> None:
        """Draw the concentration-time profile (AUC shaded) standalone."""
        if (
            not self._require_pharmaml()
            or not self._require("numpy", "NCA")
            or not self._require("matplotlib", "the concentration profile")
        ):
            return
        try:
            times, concs = self._nca_series()
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        def work() -> Any:
            from pharmaml.pharma.pk import (
                auc_trapezoid,
                nca_summary,
                validate_concentration_series,
            )

            t, c = validate_concentration_series(times, concs)
            return t, c, nca_summary(t, c), auc_trapezoid(t, c)

        def render(payload: Any) -> None:
            t, c, summary, auc = payload
            from pharmaml.viz import plot_concentration_profile

            figure = plot_concentration_profile(t, c, summary=summary, auc=auc)
            self._render_figure(self._nca_host, figure)

        self._start_job("concentration profile", work, render)

    def _nca_save(self) -> None:
        """Save the last NCA summary as a one-row table (five formats)."""
        summary = getattr(self, "_nca_summary", None)
        if summary is None:
            messagebox.showinfo("Nothing to save", "Run the NCA first.")
            return
        import pandas as pd

        frame = pd.DataFrame(
            [
                {
                    "auc_mg_h_L": summary.auc,
                    "aucm_mg_h2_L": summary.aucm,
                    "mrt_h": summary.mrt,
                    "c_max": summary.c_max,
                    "t_max": summary.t_max,
                    "half_life_terminal_h": summary.half_life_terminal,
                }
            ]
        )
        self._save_frame_dialog(frame, "Save NCA summary", "nca_summary.csv", "NCA summary")

    def _infusion_math(self) -> None:
        """Infusion rate / steady state / Vd / bioavailability card."""
        if not self._require_pharmaml() or not self._require("numpy", "PK math"):
            return
        try:
            clearance = parse_float(self._inf_cl.get(), "clearance CL")
            if clearance <= 0:
                raise ValueError("clearance must be positive")
            target = parse_float(self._inf_target.get(), "target Css")
            if target <= 0:
                raise ValueError("target Css must be positive")
            rate = parse_float(self._inf_rate.get(), "infusion rate")
            if rate <= 0:
                raise ValueError("infusion rate must be positive")
            ke = parse_float(self._vd_ke.get(), "k(e)")
            if ke <= 0:
                raise ValueError("k(e) must be positive")
            bio_pair = self._bio_ev_dose.get().strip()
            iv_pair = self._bio_iv_dose.get().strip()
            bio = None
            if bio_pair and iv_pair:
                ev_dose, ev_auc = _split_pair(bio_pair)
                iv_dose, iv_auc = _split_pair(iv_pair)
                for name, value in (
                    ("EV dose", ev_dose),
                    ("EV AUC", ev_auc),
                    ("IV dose", iv_dose),
                    ("IV AUC", iv_auc),
                ):
                    if value <= 0:
                        raise ValueError(f"{name} must be positive")
                bio = (ev_dose, ev_auc, iv_dose, iv_auc)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        try:
            from pharmaml.pharma.dosage import infusion_rate
            from pharmaml.pharma.pk import (
                bioavailability,
                iv_infusion_steady_state,
                volume_of_distribution,
            )

            need_rate = infusion_rate(clearance, target)
            css = iv_infusion_steady_state(rate, clearance)
            vd = volume_of_distribution(clearance, ke)
            parts = [
                (f"rate for Css {format_number(target)} = {format_number(need_rate)} mg/h"),
                (f"Css at {format_number(rate)} mg/h = {format_number(css)} mg/L"),
                f"Vd = {format_number(vd)} L",
            ]
            if bio is not None:
                ev_dose, ev_auc, iv_dose, iv_auc = bio
                f_abs = bioavailability(ev_dose, ev_auc, iv_dose, iv_auc)
                parts.append(f"F = {format_number(f_abs * 100)}%")
            self._inf_result.configure(text="  ·  ".join(parts))
        except Exception as exc:  # noqa: BLE001
            self._show_error("Computation failed", exc)

    def _plot_accumulation(self) -> None:
        """Repeated-dosing approach to steady state (plot_dose_accumulation)."""
        if not self._require_pharmaml() or not self._require("matplotlib", "the accumulation plot"):
            return
        try:
            dose = parse_float(self._acc_dose.get(), "dose")
            if dose <= 0:
                raise ValueError("dose must be positive")
            thalf = parse_float(self._thalf_a.get(), "t½")
            if thalf <= 0:
                raise ValueError("t½ must be positive")
            tau = parse_float(self._tau_a.get(), "dosing interval τ")
            if tau <= 0:
                raise ValueError("dosing interval must be positive")
            clearance = parse_float(self._inf_cl.get(), "clearance CL")
            ke = parse_float(self._vd_ke.get(), "k(e)")
            if clearance <= 0 or ke <= 0:
                raise ValueError(
                    "clearance and k(e) must be positive (they set Vd for the accumulation plot)"
                )
            vd = clearance / ke
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        def work() -> Any:
            from pharmaml.viz import plot_dose_accumulation

            return plot_dose_accumulation(dose, tau, t_half=thalf, vd=vd, n_doses=8)

        def render(figure: Any) -> None:
            self._render_figure(self._acc_host, figure)

        self._start_job("dose accumulation plot", work, render)

    def _tdm_math(self) -> None:
        """TDM trough adjustment card."""
        if not self._require_pharmaml():
            return
        try:
            dose = parse_float(self._tdm_dose.get(), "current dose")
            measured = parse_float(self._tdm_measured.get(), "measured trough")
            target = parse_float(self._tdm_target.get(), "target trough")
            if dose <= 0 or measured <= 0 or target <= 0:
                raise ValueError("dose and troughs must be positive")
            min_raw = self._tdm_min.get().strip()
            min_dose = parse_float(min_raw, "minimum dose") if min_raw else None
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        try:
            from pharmaml.pharma.dosage import tdm_trough_adjustment

            new_dose = tdm_trough_adjustment(dose, measured, target, min_dose=min_dose)
            capped = (
                min_dose is not None
                and new_dose == min_dose
                and dose * target / measured < min_dose
            )
            self._tdm_result.configure(
                text=(
                    f"new dose {format_number(new_dose)} mg"
                    + ("  (floored at the minimum)" if capped else "")
                )
            )
        except Exception as exc:  # noqa: BLE001
            self._show_error("Computation failed", exc)

    def _pd_family_math(self) -> None:
        """The PD model explorer: table + curve for the chosen model."""
        if not self._require_pharmaml() or not self._require("numpy", "PD math"):
            return
        model = self._pd_family_combo.get()
        try:
            e0 = parse_float(self._fam_e0.get(), "E0")
            top = parse_float(self._fam_max.get(), "Emax / Imax")
            c50 = parse_float(self._fam_c50.get(), "EC50 / IC50", minimum=1e-12)
            hill = parse_float(self._fam_hill.get(), "Hill slope")
            if hill <= 0:
                raise ValueError("Hill slope must be positive")
            slope = parse_float(self._fam_slope.get(), "slope")
            concs = [
                parse_float(part, "concentration", minimum=0.0)
                for part in self._fam_concs.get().split(",")
                if part.strip()
            ]
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return
        if not concs:
            messagebox.showwarning("Input", "Give at least one concentration.")
            return
        want_plot = self.deps.get("matplotlib")

        def work() -> Any:
            import numpy as np

            if model.startswith("sigmoid"):
                from pharmaml.pharma.pd import (
                    effect_table,
                    sigmoid_emax_effect,
                )

                # 100x-120: the table itself comes from the library's own
                # effect_table (the parallel-lists dict), the curve from
                # the scalar model -- one story, two library calls.
                table = effect_table(concs, e0, top, c50, hill)
                table_effects = np.asarray(table["effect"], dtype=float)

                def fn(c: Any) -> Any:
                    return sigmoid_emax_effect(c, e0, top, c50, hill)

                label = (
                    f"E = {format_number(e0)} + {format_number(top)}·C^{format_number(hill)}"
                    f"/({format_number(c50)}^{format_number(hill)} + C^{format_number(hill)})"
                )
            elif model.startswith("inhibitory"):
                from pharmaml.pharma.pd import inhibitory_emax_effect

                table = None

                def fn(c: Any) -> Any:  # type: ignore[no-redef]
                    return inhibitory_emax_effect(c, e0, top, c50, hill)

                label = (
                    f"E = {format_number(e0)} − {format_number(top)}·C^{format_number(hill)}"
                    f"/({format_number(c50)}^{format_number(hill)} + C^{format_number(hill)})"
                )
            else:
                from pharmaml.pharma.pd import linear_effect

                table = None

                def fn(c: Any) -> Any:  # type: ignore[no-redef]
                    return linear_effect(c, slope)

                label = f"E = {format_number(slope)}·C + 0"
            effects = np.asarray(fn(np.asarray(concs)), dtype=float)
            if table is not None:
                # the sigmoid table is effect_table's own output -- the
                # GUI renders the library's dict, not a recompute
                effects = table_effects
            grid = np.linspace(0.0, max(concs) * 1.15 or c50 * 20, 240)
            curve = np.asarray(fn(grid), dtype=float)
            return effects, grid, curve, label

        def render(payload: Any) -> None:
            effects, grid, curve, label = payload
            self._fam_tree.delete(*self._fam_tree.get_children())
            for conc, effect in zip(concs, effects):
                self._fam_tree.insert(
                    "", "end", values=(format_number(conc), format_number(effect, 2))
                )
            self._fam_result.configure(text=f"{model} · {label}", style="CardMuted.TLabel")
            if not want_plot:
                return
            try:
                from pharmaml.viz import PALETTE, new_figure

                fig, ax = new_figure(figsize=(5.2, 2.9))
                ax.plot(grid, curve, color=PALETTE[0], lw=2.2, label=label)
                ax.scatter(concs, effects, color=PALETTE[1], zorder=3, label="your points")
                if not model.startswith("linear"):
                    ax.axvline(c50, color=MUTED, ls=":", lw=1.0)
                ax.set_xlabel("concentration")
                ax.set_ylabel("effect")
                ax.set_title(model, loc="left")
                ax.legend(frameon=False, fontsize=8)
                self._render_figure(self._fam_host, fig)
            except Exception as exc:  # noqa: BLE001
                self._show_error("Plot failed", exc)

        self._start_job(f"PD model ({model})", work, render)

    def _pd_target_ec50(self) -> None:
        """Reverse question: the EC50 that hits a target effect."""
        if not self._require_pharmaml():
            return
        try:
            target = parse_float(self._fam_target.get(), "target effect")
            e0 = parse_float(self._fam_e0.get(), "E0")
            top = parse_float(self._fam_max.get(), "Emax / Imax")
            c50 = parse_float(self._fam_c50.get(), "EC50 / IC50", minimum=1e-12)
            hill = parse_float(self._fam_hill.get(), "Hill slope")
            if hill <= 0:
                raise ValueError("Hill slope must be positive")
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        try:
            from pharmaml.pharma.pd import ec50_for_target_effect

            needed = ec50_for_target_effect(target, c50, e0, top, hill)
            if needed is None or not math.isfinite(needed) or needed <= 0:
                self._fam_result.configure(
                    text=(
                        f"target {format_number(target, 2)} is outside the "
                        f"model's reachable range (E0 {format_number(e0)} "
                        f"→ plateau {format_number(e0 + top)}) — no EC50 "
                        "exists"
                    ),
                    style="CardMuted.TLabel",
                )
                return
            self._fam_result.configure(
                text=(
                    f"to reach E = {format_number(target, 2)}: "
                    f"EC50 = {format_number(needed)} "
                    f"(with E0 {format_number(e0)}, "
                    f"{'Emax' if top >= 0 else 'Imax'} {format_number(top)}, "
                    f"h {format_number(hill)})"
                ),
                style="CardMuted.TLabel",
            )
        except Exception as exc:  # noqa: BLE001
            self._show_error("Computation failed", exc)

    # ------------------------------------------------------------------ #
    # Cell Lines tab
    # ------------------------------------------------------------------ #
    def _build_cellline_tab(self) -> None:
        page = self._new_page("Cell Lines")
        self._bio_compound_var = tk.StringVar()

        screen = make_card(
            page.grid,
            "Response screen",
            span=2,
            row=0,
            column=0,
            subtitle="A GDSC/CCLE-style long table: one row per cell line × "
            "compound, one metric column (LN_IC50, AUC, ...).",
        )
        screen_buttons = ttk.Frame(screen, style="Card.TFrame")
        screen_buttons.grid(row=0, column=0, columnspan=2, sticky="w")
        open_btn = self._action_button(screen_buttons, "Open CSV…", self._bio_open_csv)
        open_btn.pack(side="left")
        example_btn = self._action_button(
            screen_buttons,
            "Load example",
            self._bio_load_example,
            tooltip="The bundled 23-line × 8-compound screen (examples/data/cellline_screen.csv).",
        )
        example_btn.pack(side="left", padx=(10, 0))
        bio_rep_btn = self._action_button(
            screen_buttons,
            "Replicate variability",
            self._bio_replicate_variability,
            tooltip="Per cell-line × compound pair with replicates: the "
            "metric's spread (range / CV) across the replicate "
            "measurements — the honest quality readout before "
            "collapsing them to a median.",
        )
        bio_rep_btn.pack(side="left", padx=(10, 0))
        bio_sum_btn = self._action_button(
            screen_buttons,
            "Compound summary",
            self._bio_summarize_compounds,
            tooltip="Per-compound statistics over the loaded metric (mean / "
            "median / std / min / max / n) — the one-table overview "
            "of the panel.",
        )
        bio_sum_btn.pack(side="left", padx=(10, 0))
        self._bio_collapse_var = tk.BooleanVar(value=True)
        collapse_check = ttk.Checkbutton(
            screen,
            text="collapse replicates (median per duplicated pair)",
            variable=self._bio_collapse_var,
        )
        collapse_check.grid(row=0, column=1, sticky="e")
        self._bio_info = ttk.Label(screen, text="no screen loaded", style="CardMuted.TLabel")
        self._bio_info.grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))
        self._bio_audit_text = _grid_text(screen, height=6, mono=self._mono)
        self._bio_audit_text.insert(
            "1.0", "the screen audit appears here (missing values, duplicate pairs, ...)"
        )
        grid_append(screen, self._bio_audit_text, sticky="ew", pady=(6, 0))

        matrix = make_card(
            page.grid,
            "Sensitivity matrix",
            span=2,
            row=1,
            column=0,
            subtitle="Pivot one metric into the classic cell line × compound table.",
        )
        self._bio_metric_combo = ttk.Combobox(matrix, state="readonly", width=22)
        form_row(matrix, "metric", self._bio_metric_combo)
        build_btn = self._action_button(
            matrix,
            "Build matrix",
            self._bio_build_matrix,
            primary=True,
            tooltip="Rows are cell lines, columns compounds; untested pairs stay blank.",
        )
        build_btn.grid(row=matrix.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._bio_matrix_info = ttk.Label(
            matrix,
            text="no matrix yet — load a screen and press Build matrix",
            style="CardMuted.TLabel",
        )
        self._bio_matrix_info.grid(
            row=build_btn.grid_info()["row"], column=1, sticky="w", padx=(10, 0)
        )
        matrix_frame = ttk.Frame(matrix, style="Card.TFrame")
        grid_append(matrix, matrix_frame, sticky="nsew", weight=True)
        self._bio_matrix_tree = ttk.Treeview(matrix_frame, show="tree headings", height=10)
        matrix_bar_x = ttk.Scrollbar(
            matrix_frame, orient="horizontal", command=self._bio_matrix_tree.xview
        )
        matrix_bar_y = ttk.Scrollbar(
            matrix_frame, orient="vertical", command=self._bio_matrix_tree.yview
        )
        self._bio_matrix_tree.configure(
            xscrollcommand=matrix_bar_x.set, yscrollcommand=matrix_bar_y.set
        )
        self._bio_matrix_tree.heading("#0", text="cell line")
        self._bio_matrix_tree.column("#0", width=110, stretch=True)
        self._bio_matrix_tree.pack(side="left", fill="both", expand=True)
        matrix_bar_y.pack(side="right", fill="y")
        matrix_bar_x.pack(side="bottom", fill="x")

        calls = make_card(
            page.grid,
            "Sensitive vs resistant",
            row=2,
            column=0,
            subtitle="Threshold one compound's panel into sensitivity calls.",
        )
        self._bio_compound_combo = ttk.Combobox(
            calls, state="readonly", width=22, textvariable=self._bio_compound_var
        )
        form_row(calls, "compound", self._bio_compound_combo)
        self._bio_q1 = ttk.Entry(calls, width=10)
        self._bio_q1.insert(0, "0.25")
        form_row(calls, "sensitive quantile", self._bio_q1)
        self._bio_q2 = ttk.Entry(calls, width=10)
        self._bio_q2.insert(0, "0.75")
        form_row(calls, "resistant quantile", self._bio_q2)
        self._bio_lower_var = tk.BooleanVar(value=True)
        lower_check = ttk.Checkbutton(
            calls,
            text="lower value = more sensitive (LN_IC50)",
            variable=self._bio_lower_var,
        )
        form_row(calls, "direction", lower_check)
        call_btn = self._action_button(calls, "Call", self._bio_call_sensitive)
        call_btn.grid(row=calls.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._bio_calls_summary = ttk.Label(
            calls, text="—", style="CardMuted.TLabel", wraplength=300, justify="left"
        )
        self._bio_calls_summary.grid(
            row=call_btn.grid_info()["row"], column=1, sticky="w", padx=(10, 0)
        )
        calls_frame = ttk.Frame(calls, style="Card.TFrame")
        grid_append(calls, calls_frame, sticky="nsew", weight=True)
        self._bio_calls_tree = ttk.Treeview(
            calls_frame, columns=("call",), show="tree headings", height=10
        )
        self._bio_calls_tree.heading("#0", text="cell line")
        self._bio_calls_tree.heading("call", text="call")
        self._bio_calls_tree.column("#0", width=130, stretch=True)
        self._bio_calls_tree.column("call", width=110, stretch=False)
        calls_bar = ttk.Scrollbar(
            calls_frame, orient="vertical", command=self._bio_calls_tree.yview
        )
        self._bio_calls_tree.configure(yscrollcommand=calls_bar.set)
        self._bio_calls_tree.pack(side="left", fill="both", expand=True)
        calls_bar.pack(side="right", fill="y")

        convert = make_card(
            page.grid,
            "LN_IC50 ↔ pIC50",
            row=2,
            column=1,
            subtitle="The GDSC and the chemist's scale, one number at a time.",
        )
        self._bio_ic50_entry = ttk.Entry(convert, width=22)
        self._bio_ic50_entry.insert(0, "0")
        form_row(convert, "value", self._bio_ic50_entry)
        convert_buttons = ttk.Frame(convert, style="Card.TFrame")
        convert_buttons.grid(
            row=convert.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(6, 0)
        )
        ln_btn = self._action_button(convert_buttons, "LN_IC50 → pIC50", self._bio_ln_to_pic50)
        ln_btn.pack(side="left")
        pi_btn = self._action_button(convert_buttons, "pIC50 → LN_IC50", self._bio_pic50_to_ln)
        pi_btn.pack(side="left", padx=(10, 0))
        bind_enter(self._bio_ic50_entry, ln_btn)
        result_row = ttk.Frame(convert, style="Card.TFrame")
        result_row.grid(row=convert.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(6, 0))
        self._bio_ic50_result = ttk.Label(
            result_row, text="—", style="Result.TLabel", font=self._mono_result
        )
        self._bio_ic50_result.pack(side="left")
        copy_btn = self._action_button(
            result_row, "Copy", lambda: self._copy(self._bio_ic50_result.cget("text"))
        )
        copy_btn.pack(side="left", padx=(10, 0))
        grid_append(
            convert,
            ttk.Label(
                convert,
                style="CardMuted.TLabel",
                wraplength=300,
                justify="left",
                text="GDSC convention: LN_IC50 = ln(IC50 in µM), so 0 → pIC50 6.",
            ),
            pady=(4, 0),
        )

        expression = make_card(
            page.grid,
            "Expression table",
            span=2,
            row=3,
            column=0,
            subtitle="Rows are cell lines, columns genes (log2 counts or "
            "intensities — normalisation happens inside the analysis).",
        )
        expression_buttons = ttk.Frame(expression, style="Card.TFrame")
        expression_buttons.grid(row=0, column=0, columnspan=2, sticky="w")
        expr_open_btn = self._action_button(
            expression_buttons, "Open expression CSV…", self._bio_open_expr_csv
        )
        expr_open_btn.pack(side="left")
        expr_example_btn = self._action_button(
            expression_buttons,
            "Load example",
            self._bio_load_expr_example,
            tooltip="The bundled 23-line × 300-gene table (examples/data/cellline_expression.csv).",
        )
        expr_example_btn.pack(side="left", padx=(10, 0))
        self._bio_expr_info = ttk.Label(
            expression, text="no expression table loaded", style="CardMuted.TLabel"
        )
        self._bio_expr_info.grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))
        # 100x-120: the MAD variability ranking (most_variable_genes) --
        # which genes carry signal at all, inspectable without a screen.
        expr_var_row = ttk.Frame(expression, style="Card.TFrame")
        expr_var_row.grid(row=2, column=0, columnspan=2, sticky="w", pady=(6, 0))
        expr_var_btn = self._action_button(
            expr_var_row,
            "Rank variable genes (MAD)",
            self._bio_rank_variable_genes,
            tooltip="The N genes with the highest median absolute deviation "
            "across the panel (most_variable_genes) -- the classic "
            "pre-filter before correlating 20,000 probes against a "
            "drug response.",
        )
        expr_var_btn.pack(side="left")
        ttk.Label(expr_var_row, text="top N", style="CardMuted.TLabel").pack(
            side="left", padx=(10, 4)
        )
        self._bio_mad_n = ttk.Entry(expr_var_row, width=7)
        self._bio_mad_n.insert(0, "20")
        self._bio_mad_n.pack(side="left")
        self._bio_mad_summary = ttk.Label(
            expr_var_row, text="", style="CardMuted.TLabel", wraplength=420, justify="left"
        )
        self._bio_mad_summary.pack(side="left", padx=(8, 0))
        self._bio_mad_text = _grid_text(expression, height=5, mono=self._mono)
        self._bio_mad_text.insert(
            "1.0", "the MAD-ranked gene list appears here (most variable first)"
        )
        self._bio_mad_text.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(6, 0))

        biomarkers = make_card(
            page.grid,
            "Biomarker discovery",
            span=2,
            row=4,
            column=0,
            subtitle="Correlate every gene's expression with one drug's response "
            "(Benjamini–Hochberg FDR control) — the EGFR / erlotinib "
            "story on the example data.",
        )
        self._bio_marker_compound_combo = ttk.Combobox(
            biomarkers,
            state="readonly",
            width=22,
            textvariable=self._bio_compound_var,
        )
        form_row(biomarkers, "compound", self._bio_marker_compound_combo)
        self._bio_method_combo = ttk.Combobox(
            biomarkers,
            state="readonly",
            width=22,
            values=("spearman", "pearson"),
        )
        self._bio_method_combo.set("spearman")
        form_row(biomarkers, "correlation method", self._bio_method_combo)
        self._bio_topn_entry = ttk.Entry(biomarkers, width=10)
        self._bio_topn_entry.insert(0, "10")
        form_row(biomarkers, "top N genes", self._bio_topn_entry)
        self._bio_marker_lower_var = tk.BooleanVar(value=True)
        marker_lower_check = ttk.Checkbutton(
            biomarkers,
            text="lower response = more sensitive (LN_IC50)",
            variable=self._bio_marker_lower_var,
        )
        form_row(biomarkers, "direction", marker_lower_check)
        marker_btn = self._action_button(
            biomarkers,
            "Discover biomarkers",
            self._bio_discover_biomarkers,
            primary=True,
            tooltip="Normalises + imputes the expression table, correlates every "
            "gene against the compound's response column, ranks by |rho|.",
        )
        marker_btn.grid(row=biomarkers.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._bio_marker_summary = ttk.Label(
            biomarkers,
            text="no discovery yet — load a screen and an expression table",
            style="CardMuted.TLabel",
            wraplength=620,
            justify="left",
        )
        self._bio_marker_summary.grid(
            row=marker_btn.grid_info()["row"], column=1, sticky="w", padx=(10, 0)
        )
        marker_frame = ttk.Frame(biomarkers, style="Card.TFrame")
        grid_append(biomarkers, marker_frame, sticky="nsew", weight=True)
        self._bio_marker_tree = ttk.Treeview(
            marker_frame,
            columns=("gene", "rho", "p_value", "fdr", "significant", "direction"),
            show="headings",
            height=10,
        )
        for column, width in (
            ("gene", 110),
            ("rho", 90),
            ("p_value", 110),
            ("fdr", 110),
            ("significant", 90),
            ("direction", 240),
        ):
            self._bio_marker_tree.heading(column, text=column)
            self._bio_marker_tree.column(
                column, width=width, minwidth=64, stretch=(column == "direction")
            )
        marker_bar_y = ttk.Scrollbar(
            marker_frame, orient="vertical", command=self._bio_marker_tree.yview
        )
        self._bio_marker_tree.configure(yscrollcommand=marker_bar_y.set)
        self._bio_marker_tree.pack(side="left", fill="both", expand=True)
        marker_bar_y.pack(side="right", fill="y")

    def _bio_open_csv(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "screen loading"):
            return
        path = filedialog.askopenfilename(
            title="Open a response screen",
            filetypes=[("Data files", "*.csv *.tsv *.txt"), ("All files", "*.*")],
        )
        if path:
            self._bio_load_path(Path(path))

    def _bio_load_example(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "screen loading"):
            return
        path = EXAMPLES_DIR / "cellline_screen.csv"
        if not path.is_file():
            messagebox.showwarning(
                "Missing example", "examples/data/cellline_screen.csv was not found."
            )
            return
        self._bio_load_path(path)

    def _bio_load_path(self, path: Path) -> None:
        try:
            from pharmaml.biology import (
                audit_response_table,
                collapse_replicates,
                load_response_table,
            )

            raw = load_response_table(path)
            audit_frame = audit_response_table(raw)
            screen = raw
            if bool(self._bio_collapse_var.get()):
                screen = collapse_replicates(raw)
        except Exception as exc:  # noqa: BLE001
            self._show_error("Could not read the response screen", exc)
            return
        self._bio_screen = screen
        self._bio_screen_path = path
        self._bio_collapsed = screen is not raw
        self._bio_matrix = None
        self._bio_matrix_metric = None

        # the audit always describes the ORIGINAL table, so replicate
        # issues stay visible even when they were just collapsed away
        self._bio_audit_text.delete("1.0", "end")
        if len(audit_frame):
            self._bio_audit_text.insert("1.0", audit_frame.to_string())
        else:
            self._bio_audit_text.insert(
                "1.0", "audit: no issues — identifiers, metric values and pairs all clean"
            )

        raw_rows = len(raw.frame)
        rows_note = f"{raw_rows:,} rows"
        if len(screen.frame) != raw_rows:
            rows_note += f" ({len(screen.frame):,} after collapsing replicates)"
        metrics = ", ".join(screen.metrics)
        self._bio_info.configure(
            text=(
                f"{path.name} — {rows_note} · {len(screen.cell_lines)} cell lines · "
                f"{len(screen.compounds)} compounds · metric(s): {metrics}"
            )
        )
        self._bio_metric_combo["values"] = list(screen.metrics)
        if screen.metrics:
            self._bio_metric_combo.set(screen.metrics[0])
        compounds = list(screen.compounds)
        self._bio_compound_combo["values"] = compounds
        self._bio_marker_compound_combo["values"] = compounds
        if compounds:
            self._bio_compound_var.set(compounds[0])

    def _bio_replicate_variability(self) -> None:
        """Replicate spread per duplicated pair (biology.replicate_variability)."""
        if not self._require_pharmaml() or not self._require("pandas", "the audit"):
            return
        if self._bio_screen is None:
            messagebox.showwarning("No screen", "Load a response screen first.")
            return
        path = getattr(self, "_bio_screen_path", None)

        def work() -> Any:
            from pharmaml.biology import load_response_table, replicate_variability

            # replicates must be audited BEFORE any collapsing -- reload
            # the raw table (the loaded screen may already be collapsed)
            raw = load_response_table(path) if path is not None else self._bio_screen
            return replicate_variability(raw)

        def render(frame: Any) -> None:
            self._bio_audit_text.delete("1.0", "end")
            if frame is None or not len(frame):
                self._bio_audit_text.insert(
                    "1.0",
                    "replicate variability: no duplicated cell-line × "
                    "compound pairs in this screen — nothing to compare",
                )
                return
            self._bio_audit_text.insert(
                "1.0",
                "replicate variability (per duplicated pair, "
                "before any collapsing):\n\n" + frame.to_string(index=False),
            )

        self._start_job("replicate variability", work, render)

    def _bio_summarize_compounds(self) -> None:
        """Per-compound statistics over the chosen metric (summarize_compounds)."""
        if not self._require_pharmaml() or not self._require("pandas", "the summary"):
            return
        if self._bio_screen is None:
            messagebox.showwarning("No screen", "Load a response screen first.")
            return
        metric = self._bio_metric_combo.get()
        if not metric:
            messagebox.showwarning("No metric", "Pick the response metric.")
            return
        lower_is_sensitive = bool(self._bio_lower_var.get())

        def work() -> Any:
            from pharmaml.biology import summarize_compounds

            return summarize_compounds(
                self._bio_screen, metric, higher_is_more_sensitive=not lower_is_sensitive
            )

        def render(frame: Any) -> None:
            self._bio_audit_text.delete("1.0", "end")
            header = (
                f"compound summary — {metric} "
                f"({'lower = more sensitive' if lower_is_sensitive else 'higher = more sensitive'}):\n\n"
            )
            self._bio_audit_text.insert("1.0", header + frame.to_string(index=False))

        self._start_job(f"compound summary ({metric})", work, render)

    def _bio_build_matrix(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "the matrix"):
            return
        if self._bio_screen is None:
            messagebox.showwarning("No screen", "Load a response screen first.")
            return
        metric = self._bio_metric_combo.get()
        if not metric:
            messagebox.showwarning("No metric", "Pick the response metric.")
            return

        def work() -> Any:
            from pharmaml.biology import response_matrix

            return response_matrix(self._bio_screen, metric), metric

        def render(payload: Any) -> None:
            matrix, used_metric = payload
            self._bio_render_matrix(matrix, used_metric)

        self._start_job(f"sensitivity matrix ({metric})", work, render)

    def _bio_render_matrix(self, matrix: Any, metric: str) -> None:
        self._bio_matrix = matrix
        self._bio_matrix_metric = metric
        tree = self._bio_matrix_tree
        tree.delete(*tree.get_children())
        compounds = [str(column) for column in matrix.columns]
        tree["columns"] = compounds
        for column in compounds:
            tree.heading(column, text=column)
            tree.column(column, width=96, minwidth=72, stretch=True)
        for cell_line, row in matrix.iterrows():
            values = [
                "" if isinstance(value, float) and math.isnan(value) else _cell_text(value)
                for value in row.tolist()
            ]
            tree.insert("", "end", text=str(cell_line), values=values)
        self._bio_matrix_info.configure(
            text=(
                f"{len(matrix.index)} cell lines × {len(matrix.columns)} compounds · "
                f"untested pairs blank · metric {metric}"
            )
        )

    def _bio_call_sensitive(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "sensitivity calls"):
            return
        if self._bio_screen is None:
            messagebox.showwarning("No screen", "Load a response screen first.")
            return
        compound = self._bio_compound_var.get()
        if not compound:
            messagebox.showwarning("No compound", "Pick the compound to call.")
            return
        try:
            sensitive_q = parse_float(
                self._bio_q1.get(), "sensitive quantile", minimum=0.0, maximum=1.0
            )
            resistant_q = parse_float(
                self._bio_q2.get(), "resistant quantile", minimum=0.0, maximum=1.0
            )
            if sensitive_q >= resistant_q:
                raise ValueError("the sensitive quantile must be below the resistant quantile")
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return
        lower = bool(self._bio_lower_var.get())
        metric = self._bio_metric_combo.get()

        def work() -> Any:
            from pharmaml.biology import call_sensitive_resistant, response_matrix

            matrix = self._bio_matrix
            built = matrix is None or self._bio_matrix_metric != metric
            if built:
                matrix = response_matrix(self._bio_screen, metric)
            calls = call_sensitive_resistant(
                matrix[compound], sensitive_q, resistant_q, lower_is_sensitive=lower
            )
            return matrix, metric, built, calls, compound

        def render(payload: Any) -> None:
            matrix, used_metric, built, calls, used_compound = payload
            if built:
                self._bio_render_matrix(matrix, used_metric)
            counts = calls.value_counts()
            labels = ("sensitive", "intermediate", "resistant", "not tested")
            summary = " · ".join(f"{int(counts.get(label, 0))} {label}" for label in labels)
            self._bio_calls_summary.configure(
                text=f"{used_compound}: {summary}", style="Field.TLabel"
            )
            self._bio_calls_tree.delete(*self._bio_calls_tree.get_children())
            rank = {label: index for index, label in enumerate(labels)}
            for cell_line, call in sorted(
                calls.items(), key=lambda item: (rank.get(item[1], 99), str(item[0]))
            ):
                self._bio_calls_tree.insert("", "end", text=str(cell_line), values=(call,))

        self._start_job(f"sensitivity calls ({compound})", work, render)

    def _bio_ln_to_pic50(self) -> None:
        self._bio_convert_ic50("ln")

    def _bio_pic50_to_ln(self) -> None:
        self._bio_convert_ic50("pic50")

    def _bio_convert_ic50(self, direction: str) -> None:
        if not self._require_pharmaml() or not self._require("numpy", "conversion"):
            return
        from pharmaml.biology import ln_ic50_to_pic50, pic50_to_ln_ic50

        try:
            value = parse_float(self._bio_ic50_entry.get(), "value")
            result = ln_ic50_to_pic50(value) if direction == "ln" else pic50_to_ln_ic50(value)
        except Exception as exc:  # noqa: BLE001
            self._show_error("Conversion failed", exc)
            return
        self._bio_ic50_result.configure(text=f"{result:.4f}")

    def _bio_open_expr_csv(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "expression loading"):
            return
        path = filedialog.askopenfilename(
            title="Open an expression table",
            filetypes=[("CSV table", "*.csv"), ("All files", "*.*")],
        )
        if path:
            self._bio_load_expr_path(Path(path))

    def _bio_load_expr_example(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "expression loading"):
            return
        path = EXAMPLES_DIR / "cellline_expression.csv"
        if not path.is_file():
            messagebox.showwarning(
                "Missing example", "examples/data/cellline_expression.csv was not found."
            )
            return
        self._bio_load_expr_path(path)

    def _bio_load_expr_path(self, path: Path) -> None:
        try:
            import pandas as pd

            try:
                frame = pd.read_csv(path, index_col="cell_line")
            except ValueError:
                # user tables name their identifier column differently --
                # fall back to the first column as the cell-line index
                frame = pd.read_csv(path, index_col=0)
        except Exception as exc:  # noqa: BLE001
            self._show_error("Could not read the expression table", exc)
            return
        if frame.empty:
            messagebox.showwarning("Empty table", f"{path.name} has no rows.")
            return
        self._bio_expr = frame
        self._bio_expr_norm = None
        self._bio_expr_info.configure(
            text=f"{path.name} — {len(frame):,} cell lines × {len(frame.columns):,} genes"
        )

    def _bio_rank_variable_genes(self) -> None:
        """The MAD variability ranking of the loaded table (100x-120).

        ``most_variable_genes`` finally has its GUI surface: the N
        genes with the highest median absolute deviation across the
        panel, listed most-variable-first with their MAD values --
        the classic pre-filter question ("which probes carry signal
        at all?") answerable without loading a screen.
        """
        if not self._require_pharmaml() or not self._require("pandas", "the MAD ranking"):
            return
        frame = getattr(self, "_bio_expr", None)
        if frame is None:
            messagebox.showwarning(
                "No expression table", "Open an expression CSV (or load the example) first."
            )
            return
        try:
            top_n = parse_int(self._bio_mad_n.get(), "top N genes", minimum=1, maximum=100000)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return
        n_genes = len(frame.columns)

        def work() -> Any:
            import pandas as pd

            from pharmaml.biology import most_variable_genes

            genes = most_variable_genes(frame, n=top_n)
            # MAD per kept gene, ranked -- recompute honestly from the
            # frame (the library returns names only)
            mads = (frame[genes] - frame[genes].median()).abs().median()
            ranked = pd.DataFrame({"gene": genes}).set_index("gene")
            ranked["MAD"] = mads
            return ranked

        def render(ranked: Any) -> None:
            self._bio_mad_text.delete("1.0", "end")
            self._bio_mad_text.insert("1.0", ranked.to_string())
            self._bio_mad_summary.configure(
                text=(
                    f"top {len(ranked)} of {n_genes:,} genes by MAD — "
                    f"most variable: {ranked.index[0]}"
                ),
                style="Field.TLabel",
            )

        self._start_job("MAD gene ranking", work, render)

    def _bio_discover_biomarkers(self) -> None:
        if not self._require_pharmaml():
            return
        for module in ("numpy", "pandas", "scipy"):
            if not self._require(module, "biomarker discovery"):
                return
        if self._bio_screen is None or self._bio_expr is None:
            messagebox.showwarning(
                "Missing data",
                "Biomarker discovery needs BOTH a response screen and an "
                "expression table — load one of each above, then try again.",
            )
            return
        compound = self._bio_compound_var.get()
        if not compound:
            messagebox.showwarning("No compound", "Pick the compound to analyse.")
            return
        method = self._bio_method_combo.get() or "spearman"
        try:
            top_n = parse_int(self._bio_topn_entry.get(), "top N genes", minimum=1, maximum=500)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return
        lower = bool(self._bio_marker_lower_var.get())
        metric = self._bio_metric_combo.get()

        def work() -> Any:
            from pharmaml.biology import (
                impute_expression,
                normalize_expression,
                response_matrix,
                sensitivity_associations,
                top_biomarkers,
            )

            norm = self._bio_expr_norm
            if norm is None:
                norm = impute_expression(normalize_expression(self._bio_expr))
            matrix = self._bio_matrix
            built = matrix is None or self._bio_matrix_metric != metric
            if built:
                matrix = response_matrix(self._bio_screen, metric)
            associations = sensitivity_associations(norm, matrix[compound], method=method)
            top = top_biomarkers(associations, n=top_n)
            return top, associations, norm, matrix, metric, built, compound

        def render(payload: Any) -> None:
            from pharmaml.biology import direction_of_association

            top, associations, norm, matrix, used_metric, built, used_compound = payload
            self._bio_expr_norm = norm
            if built:
                self._bio_render_matrix(matrix, used_metric)
            n_significant = int(associations["significant"].sum())
            strongest = float(associations["rho"].abs().max())
            self._bio_marker_summary.configure(
                text=(
                    f"{len(associations):,} genes correlated · "
                    f"{n_significant} significant at FDR < 0.05 · "
                    f"strongest |rho| {strongest:.3f} — {used_compound}"
                ),
                style="Field.TLabel",
            )
            self._bio_marker_tree.delete(*self._bio_marker_tree.get_children())
            for _, row in top.iterrows():
                try:
                    rho = float(row["rho"])
                except (TypeError, ValueError):
                    rho = float("nan")
                self._bio_marker_tree.insert(
                    "",
                    "end",
                    values=(
                        _cell_text(row["gene"], limit=18),
                        format_number(rho),
                        _cell_text(row["p_value"]),
                        _cell_text(row["fdr"]),
                        "Yes" if bool(row["significant"]) else "No",
                        direction_of_association(rho, lower_is_sensitive=lower),
                    ),
                )

        self._start_job(f"biomarkers for {compound}", work, render)

    # ------------------------------------------------------------------ #
    # Docking tab
    # ------------------------------------------------------------------ #
    def _build_docking_tab(self) -> None:
        page = self._new_page("Docking")

        # -- card 1: ligand library -> PDBQT campaign -------------------- #
        ligands = make_card(
            page.grid,
            "Ligand library → PDBQT",
            row=0,
            column=0,
            subtitle="A SMILES CSV becomes one folder per ligand, each with a "
            "3D l.pdbqt (Meeko + RDKit).",
        )
        lib_buttons = ttk.Frame(ligands, style="Card.TFrame")
        lib_buttons.grid(row=0, column=0, columnspan=2, sticky="w")
        lib_open_btn = self._action_button(lib_buttons, "Open CSV…", self._dock_open_csv)
        lib_open_btn.pack(side="left")
        lib_example_btn = self._action_button(
            lib_buttons,
            "Load example",
            self._dock_load_example,
            tooltip="The bundled 10-row library (8 valid SMILES, 2 broken "
            "rows on purpose) -- examples/data/ligand_library.csv.",
        )
        lib_example_btn.pack(side="left", padx=(10, 0))
        self._dock_lib_info = ttk.Label(ligands, text="no library loaded", style="CardMuted.TLabel")
        self._dock_lib_info.grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))
        out_buttons = ttk.Frame(ligands, style="Card.TFrame")
        out_buttons.grid(row=2, column=0, columnspan=2, sticky="w")
        out_btn = self._action_button(
            out_buttons, "Choose output folder…", self._dock_choose_out_dir
        )
        out_btn.pack(side="left")
        self._dock_out_info = ttk.Label(
            out_buttons,
            text="no output folder chosen",
            style="CardMuted.TLabel",
            wraplength=280,
            justify="left",
        )
        self._dock_out_info.pack(side="left", padx=(10, 0))
        prep_btn = self._action_button(
            ligands,
            "Prepare ligands",
            self._dock_prepare_ligands,
            primary=True,
            tooltip="Embeds and atom-types every valid SMILES in a worker "
            "thread; one sub-folder per ligand under the output root.",
        )
        prep_btn.grid(row=ligands.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._dock_prep_summary = ttk.Label(
            ligands,
            text="—",
            style="CardMuted.TLabel",
            wraplength=300,
            justify="left",
        )
        self._dock_prep_summary.grid(
            row=prep_btn.grid_info()["row"], column=1, sticky="w", padx=(10, 0)
        )
        lib_tree_frame = ttk.Frame(ligands, style="Card.TFrame")
        grid_append(ligands, lib_tree_frame, sticky="nsew", weight=True)
        self._dock_lib_tree = ttk.Treeview(
            lib_tree_frame,
            columns=("folder", "name", "ok", "atoms", "torsdof", "error"),
            show="headings",
            height=8,
        )
        for column, width in (
            ("folder", 120),
            ("name", 100),
            ("ok", 44),
            ("atoms", 60),
            ("torsdof", 66),
            ("error", 170),
        ):
            self._dock_lib_tree.heading(column, text=column)
            self._dock_lib_tree.column(
                column, width=width, minwidth=44, stretch=(column == "error")
            )
        lib_bar = ttk.Scrollbar(
            lib_tree_frame, orient="vertical", command=self._dock_lib_tree.yview
        )
        self._dock_lib_tree.configure(yscrollcommand=lib_bar.set)
        self._dock_lib_tree.pack(side="left", fill="both", expand=True)
        lib_bar.pack(side="right", fill="y")
        lib_save_btn = self._action_button(
            ligands, "Save report CSV…", self._dock_save_ligand_report
        )
        lib_save_btn.grid(
            row=ligands.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(6, 0)
        )

        # -- card 2: receptor preparation -------------------------------- #
        receptor = make_card(
            page.grid,
            "Receptor preparation",
            row=0,
            column=1,
            subtitle="PDB / CIF / PDBQT → a docking-ready receptor PDBQT "
            "(waters out, atom types in).",
        )
        rec_buttons = ttk.Frame(receptor, style="Card.TFrame")
        rec_buttons.grid(row=0, column=0, columnspan=2, sticky="w")
        rec_open_btn = self._action_button(
            rec_buttons, "Open PDB / CIF / PDBQT…", self._dock_open_receptor
        )
        rec_open_btn.pack(side="left")
        rec_example_btn = self._action_button(
            rec_buttons,
            "Load example",
            self._dock_load_receptor_example,
            tooltip="The bundled hen egg-white lysozyme (examples/data/lysozyme_1aki.pdb).",
        )
        rec_example_btn.pack(side="left", padx=(10, 0))
        self._dock_receptor_info = ttk.Label(
            receptor,
            text="no receptor source selected",
            style="CardMuted.TLabel",
            wraplength=300,
            justify="left",
        )
        self._dock_receptor_info.grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))
        self._dock_remove_waters_var = tk.BooleanVar(value=True)
        waters_check = ttk.Checkbutton(
            receptor, text="remove waters", variable=self._dock_remove_waters_var
        )
        form_row(receptor, "waters", waters_check)
        self._dock_keep_hetatm_var = tk.BooleanVar(value=False)
        hetatm_check = ttk.Checkbutton(
            receptor, text="keep HETATM ligands/ions", variable=self._dock_keep_hetatm_var
        )
        form_row(receptor, "HETATM", hetatm_check)
        self._dock_strip_h_var = tk.BooleanVar(value=True)
        strip_check = ttk.Checkbutton(
            receptor, text="strip hydrogens", variable=self._dock_strip_h_var
        )
        form_row(receptor, "hydrogens", strip_check)
        self._dock_bad_res_var = tk.BooleanVar(value=True)
        bad_res_check = ttk.Checkbutton(
            receptor, text="auto-remove bad residues", variable=self._dock_bad_res_var
        )
        Tooltip(
            bad_res_check,
            "When Meeko's templates cannot match a residue (broken "
            "density, non-standard chemistry), delete that residue and "
            "retry instead of failing -- Meeko CLI's --delete_bad_res, "
            "checkbox edition. Removed residues are named in the report.",
        )
        form_row(receptor, "bad residues", bad_res_check)
        self._dock_chain_entry = ttk.Entry(receptor, width=10)
        form_row(receptor, "chain (blank = all)", self._dock_chain_entry)
        rec_btn = self._action_button(
            receptor,
            "Prepare receptor",
            self._dock_prepare_receptor,
            primary=True,
            tooltip="Asks where to save the PDBQT, then prepares it in a worker thread.",
        )
        rec_btn.grid(row=receptor.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._dock_protein_text = _grid_text(receptor, height=10, mono=self._mono)
        self._dock_protein_text.insert(
            "1.0", "the receptor report appears here (mode, atoms, chains, ...)"
        )
        grid_append(receptor, self._dock_protein_text, sticky="ew", pady=(6, 0))
        dist_buttons = ttk.Frame(receptor, style="Card.TFrame")
        grid_append(receptor, dist_buttons, sticky="w", pady=(6, 0))
        dist_btn = self._action_button(
            dist_buttons,
            "Distribute into campaign…",
            self._dock_distribute_receptor,
            tooltip="Copies the prepared receptor into every ligand folder of a campaign root.",
        )
        dist_btn.pack(side="left")
        rec_plot_btn = self._action_button(
            dist_buttons,
            "Plot atom types",
            self._dock_plot_atom_types,
            tooltip="The prepared receptor's AutoDock atom-type census as "
            "chemistry-coloured bars (plot_receptor_atom_types) — "
            "a missing polar-hydrogen population is visible at a "
            "glance.",
        )
        rec_plot_btn.pack(side="left", padx=(10, 0))
        save_rec_figure_btn = self._action_button(
            dist_buttons,
            "Save figure…",
            self._save_dock_receptor_figure,
            tooltip="Save the figure this card is currently showing -- the "
            "receptor's AutoDock atom-type census bars -- as PNG, SVG "
            "or PDF (unlike Ctrl+S, which saves the last figure drawn "
            "anywhere).",
        )
        save_rec_figure_btn.pack(side="left", padx=(10, 0))
        self._dock_receptor_host = self._figure_host(receptor, height=240)
        self._dock_distribute_info = ttk.Label(
            dist_buttons,
            text="",
            style="CardMuted.TLabel",
            wraplength=260,
            justify="left",
        )
        self._dock_distribute_info.pack(side="left", padx=(10, 0))

        # -- card 3: grid box & docking configs -------------------------- #
        grid_card = make_card(
            page.grid,
            "Grid box & docking configs",
            row=1,
            column=0,
            subtitle="Enclose a reference ligand, then write the AutoDock4 "
            "r.gpf / r.dpf pair next to it.",
        )
        lig_buttons = ttk.Frame(grid_card, style="Card.TFrame")
        lig_buttons.grid(row=0, column=0, columnspan=2, sticky="w")
        lig_open_btn = self._action_button(
            lig_buttons, "Open reference ligand PDBQT…", self._dock_open_ligand
        )
        lig_open_btn.pack(side="left")
        self._dock_ligand_info = ttk.Label(
            lig_buttons,
            text="no ligand selected",
            style="CardMuted.TLabel",
            wraplength=220,
            justify="left",
        )
        self._dock_ligand_info.pack(side="left", padx=(10, 0))
        self._dock_padding_entry = ttk.Entry(grid_card, width=10)
        self._dock_padding_entry.insert(0, "4.0")
        form_row(grid_card, "padding (Å)", self._dock_padding_entry)
        self._dock_npts_entry = ttk.Entry(grid_card, width=12)
        self._dock_npts_entry.insert(0, "60 60 60")
        form_row(grid_card, "npts (x y z)", self._dock_npts_entry)
        self._dock_spacing_entry = ttk.Entry(grid_card, width=10)
        self._dock_spacing_entry.insert(0, "0.375")
        form_row(grid_card, "spacing (Å)", self._dock_spacing_entry)
        self._dock_receptor_name_entry = ttk.Entry(grid_card, width=14)
        self._dock_receptor_name_entry.insert(0, "r.pdbqt")
        form_row(grid_card, "receptor file", self._dock_receptor_name_entry)
        self._dock_ga_run_entry = ttk.Entry(grid_card, width=10)
        self._dock_ga_run_entry.insert(0, "100")
        form_row(grid_card, "ga_run", self._dock_ga_run_entry)
        self._dock_ga_pop_entry = ttk.Entry(grid_card, width=10)
        self._dock_ga_pop_entry.insert(0, "150")
        form_row(grid_card, "ga population", self._dock_ga_pop_entry)
        self._dock_receptor_types_entry = ttk.Entry(grid_card, width=20)
        form_row(grid_card, "receptor types (blank = default)", self._dock_receptor_types_entry)
        grid_btn = self._action_button(
            grid_card,
            "Compute box & write GPF/DPF",
            self._dock_compute_grid,
            primary=True,
            tooltip="Grid box from the ligand plus padding; GPF and DPF land "
            "in the ligand's own folder.",
        )
        grid_btn.grid(row=grid_card.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(6, 0))
        batch_btn = self._action_button(
            grid_card,
            "Batch GPF/DPF for campaign…",
            self._dock_write_config_batch,
            tooltip="Every sub-folder's ligand PDBQT gets its own r.gpf/"
            "r.dpf pair — the gpfer/dpfer batch loop, one row per "
            "folder. Set receptor types for Ni-bearing receptors "
            "(gpferreceptorni.py).",
        )
        batch_btn.grid(
            row=grid_card.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(6, 0)
        )
        self._dock_grid_text = _grid_text(grid_card, height=10, mono=self._mono)
        self._dock_grid_text.insert(
            "1.0", "box centre / size, ligand atom types and the written paths appear here"
        )
        grid_append(grid_card, self._dock_grid_text, sticky="ew", pady=(6, 0))

        # -- card 4: docking results (one tree, three sources) ----------- #
        results = make_card(
            page.grid,
            "Docking results",
            row=1,
            column=1,
            subtitle="One tree, three sources: a campaign scan, an AutoDock4 "
            "DLG cluster table, or a Vina mode table.",
        )
        scan_buttons = ttk.Frame(results, style="Card.TFrame")
        scan_buttons.grid(row=0, column=0, columnspan=2, sticky="w")
        scan_btn = self._action_button(
            scan_buttons, "Scan campaign folder…", self._dock_scan_campaign
        )
        scan_btn.pack(side="left")
        scan_example_btn = self._action_button(
            scan_buttons,
            "Load example campaign",
            self._dock_load_example_campaign,
            tooltip="The bundled 14-folder campaign (examples/data/docking_campaign).",
        )
        scan_example_btn.pack(side="left", padx=(10, 0))
        dlg_buttons = ttk.Frame(results, style="Card.TFrame")
        dlg_buttons.grid(row=1, column=0, columnspan=2, sticky="w", pady=(4, 0))
        dlg_btn = self._action_button(dlg_buttons, "Open DLG…", self._dock_open_dlg)
        dlg_btn.pack(side="left")
        dlg_example_btn = self._action_button(
            dlg_buttons,
            "Open example DLG",
            self._dock_open_example_dlg,
            tooltip="The aspirin run of the example campaign (01_aspirin/r.dlg): five clusters.",
        )
        dlg_example_btn.pack(side="left", padx=(10, 0))
        self._dock_heavyatoms_entry = ttk.Entry(dlg_buttons, width=6)
        self._dock_heavyatoms_entry.pack(side="left", padx=(10, 0))
        ttk.Label(
            dlg_buttons, text="heavy atoms (adds ligand efficiency)", style="CardMuted.TLabel"
        ).pack(side="left", padx=(4, 0))
        vina_row = ttk.Frame(results, style="Card.TFrame")
        vina_row.grid(row=2, column=0, columnspan=2, sticky="w", pady=(4, 0))
        vina_btn = self._action_button(vina_row, "Open Vina output…", self._dock_open_vina)
        vina_btn.pack(side="left")
        vina_scan_btn = self._action_button(
            vina_row,
            "Scan Vina results folder…",
            self._dock_scan_vina,
            tooltip="Every .log under a results tree, best affinity per "
            "ligand, strongest binder first (vina_reader.py).",
        )
        vina_scan_btn.pack(side="left", padx=(10, 0))
        self._dock_results_info = ttk.Label(
            results,
            text="no results yet — scan a campaign or open a log",
            style="CardMuted.TLabel",
            wraplength=320,
            justify="left",
        )
        self._dock_results_info.grid(row=3, column=0, columnspan=2, sticky="w", pady=(6, 0))
        results_tree_frame = ttk.Frame(results, style="Card.TFrame")
        grid_append(results, results_tree_frame, sticky="nsew", weight=True)
        self._dock_results_tree = ttk.Treeview(results_tree_frame, show="headings", height=8)
        results_bar = ttk.Scrollbar(
            results_tree_frame, orient="vertical", command=self._dock_results_tree.yview
        )
        self._dock_results_tree.configure(yscrollcommand=results_bar.set)
        self._dock_results_tree.pack(side="left", fill="both", expand=True)
        results_bar.pack(side="right", fill="y")
        results_save_btn = self._action_button(
            results, "Save results CSV…", self._dock_save_results
        )
        results_save_btn.grid(
            row=results.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(6, 0)
        )
        top_ligands_btn = self._action_button(
            results,
            "Plot top ligands",
            self._dock_plot_top_ligands,
            tooltip="The strongest binders of the last campaign scan as "
            "energy-annotated horizontal bars (plot_top_ligands).",
        )
        top_ligands_btn.grid(
            row=results.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(2, 0)
        )
        save_dock_fig_btn = self._action_button(
            results,
            "Save figure…",
            self._save_dock_results_figure,
            tooltip="Save the figure this card is currently showing -- the "
            "top-ligands energy bars of the last campaign scan -- as "
            "PNG, SVG or PDF (unlike Ctrl+S, which saves the last "
            "figure drawn anywhere).",
        )
        save_dock_fig_btn.grid(
            row=results.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(2, 0)
        )
        self._dock_results_host = self._figure_host(results, height=260)

        # -- card 5: campaign runner ------------------------------------- #
        runner = make_card(
            page.grid,
            "Campaign runner",
            row=2,
            column=0,
            subtitle="autogrid4 + autodock4 over every prepared ligand folder, "
            "or one AutoDock Vina run.",
        )
        self._dock_engine_combo = ttk.Combobox(
            runner, state="readonly", width=22, values=_DOCK_ENGINES
        )
        self._dock_engine_combo.set(_DOCK_ENGINES[0])
        form_row(runner, "engine", self._dock_engine_combo)
        # 100x-120: the single-folder mode re-uses the same folder picker
        # ("the campaign root" is simply "the ONE ligand folder" there);
        # the info label tells the two apart.
        self._dock_engine_combo.bind(
            "<<ComboboxSelected>>", lambda _e: self._dock_refresh_campaign_info()
        )
        root_buttons = ttk.Frame(runner, style="Card.TFrame")
        root_buttons.grid(row=runner.grid_size()[1], column=0, columnspan=2, sticky="w")
        root_btn = self._action_button(
            root_buttons, "Choose campaign root…", self._dock_choose_campaign_root
        )
        root_btn.pack(side="left")
        self._dock_campaign_info = ttk.Label(
            root_buttons,
            text="no campaign root chosen",
            style="CardMuted.TLabel",
            wraplength=240,
            justify="left",
        )
        self._dock_campaign_info.pack(side="left", padx=(10, 0))
        vina_in_buttons = ttk.Frame(runner, style="Card.TFrame")
        vina_in_buttons.grid(
            row=runner.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(4, 0)
        )
        vina_rec_btn = self._action_button(
            vina_in_buttons, "Receptor PDBQT…", self._dock_open_vina_receptor
        )
        vina_rec_btn.pack(side="left")
        vina_lig_btn = self._action_button(
            vina_in_buttons, "Ligand PDBQT…", self._dock_open_vina_ligand
        )
        vina_lig_btn.pack(side="left", padx=(10, 0))
        self._dock_vina_info = ttk.Label(
            vina_in_buttons,
            text="no receptor / ligand chosen",
            style="CardMuted.TLabel",
            wraplength=240,
            justify="left",
        )
        self._dock_vina_info.pack(side="left", padx=(10, 0))
        self._dock_center_entry = ttk.Entry(runner, width=12)
        self._dock_center_entry.insert(0, "0 0 0")
        form_row(runner, "centre (x y z, Vina)", self._dock_center_entry)
        self._dock_size_entry = ttk.Entry(runner, width=12)
        self._dock_size_entry.insert(0, "20 20 20")
        form_row(runner, "size (x y z, Vina)", self._dock_size_entry)
        self._dock_exhaust_entry = ttk.Entry(runner, width=10)
        self._dock_exhaust_entry.insert(0, "8")
        form_row(runner, "exhaustiveness (Vina)", self._dock_exhaust_entry)
        self._dock_workers_entry = ttk.Entry(runner, width=10)
        self._dock_workers_entry.insert(0, "4")
        form_row(runner, "workers (AutoDock4)", self._dock_workers_entry)
        self._dock_skip_existing_var = tk.BooleanVar(value=True)
        skip_check = ttk.Checkbutton(
            runner,
            text="skip completed folders (reuse .glg/.dlg)",
            variable=self._dock_skip_existing_var,
        )
        Tooltip(
            skip_check,
            "Reuse existing outputs: a .glg present is trusted, an "
            "existing .dlg only when it carries AutoDock's Successful "
            "Completion sentinel -- an interrupted run is re-run, never "
            "trusted blindly (run_autodock4's skip_existing).",
        )
        form_row(runner, "resume", skip_check)
        run_btn = self._action_button(
            runner,
            "Run docking",
            self._dock_run,
            primary=True,
            tooltip="Real docking takes minutes to hours per ligand -- the "
            "window stays responsive and the run lands in the logs.",
        )
        run_btn.grid(row=runner.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        self._dock_run_summary = ttk.Label(
            runner,
            text="—",
            style="CardMuted.TLabel",
            wraplength=320,
            justify="left",
        )
        self._dock_run_summary.grid(
            row=run_btn.grid_info()["row"], column=1, sticky="w", padx=(10, 0)
        )

        # -- card 6: consensus rescore (the explainable ranking) -------- #
        rescore = make_card(
            page.grid,
            "Consensus rescore",
            row=2,
            column=1,
            subtitle="Combine the loaded table's evidence into one 0–1 "
            "consensus, with the per-column units that explain "
            "the winner (the docking rescore CLI, mouse edition).",
        )
        rescore_buttons = ttk.Frame(rescore, style="Card.TFrame")
        rescore_buttons.grid(row=0, column=0, columnspan=2, sticky="w")
        rescore_csv_btn = self._action_button(
            rescore_buttons,
            "Open summary CSV…",
            self._dock_open_rescore_csv,
            tooltip="Any summary table (a saved scan, a rescored CSV, an "
            "enriched export) -- the --data twin.",
        )
        rescore_csv_btn.pack(side="left")
        self._dock_rescore_info = ttk.Label(
            rescore_buttons,
            text="rescores the results table above",
            style="CardMuted.TLabel",
            wraplength=240,
            justify="left",
        )
        self._dock_rescore_info.pack(side="left", padx=(10, 0))
        self._dock_rescore_columns_entry = ttk.Entry(rescore, width=32)
        self._dock_rescore_columns_entry.insert(0, "best_lowest_energy, best_num_in_cluster")
        form_row(rescore, "evidence columns", self._dock_rescore_columns_entry)
        self._dock_rescore_weights_entry = ttk.Entry(rescore, width=32)
        form_row(rescore, "weights (blank = uniform)", self._dock_rescore_weights_entry)
        self._dock_rescore_higher_entry = ttk.Entry(rescore, width=32)
        form_row(rescore, "higher-is-better (blank = auto)", self._dock_rescore_higher_entry)
        rescore_btn = self._action_button(
            rescore,
            "Rescore table",
            self._dock_rescore,
            primary=True,
            tooltip="consensus_rescore's explainable twin: one 0–1 _norm "
            "unit per evidence column plus the consensus. The "
            "leaderboard replaces the results tree; Save results "
            "CSV… writes the rescored table.",
        )
        rescore_btn.grid(row=rescore.grid_size()[1], column=0, sticky="w", pady=(6, 0))
        report_btn = self._action_button(
            rescore,
            "Save report…",
            self._dock_save_report,
            tooltip="Write the last rescore as the one-click visual "
            "bundle -- report.html + the consensus-ranking figure "
            "+ the breakdown table (the CLI --plots/--pdf-report "
            "story, mouse edition).",
        )
        report_btn.grid(row=rescore_btn.grid_info()["row"], column=1, sticky="w", padx=(10, 0))
        self._dock_pdf_var = tk.BooleanVar(value=False)
        pdf_check = ttk.Checkbutton(rescore, text="include report.pdf", variable=self._dock_pdf_var)
        Tooltip(
            pdf_check, "Also write the multi-page PDF document -- needs fpdf (pharmaml[reports])"
        )
        grid_append(rescore, pdf_check, sticky="w", pady=(2, 0))
        self._dock_rescore_text = _grid_text(rescore, height=7, mono=self._mono)
        self._dock_rescore_text.insert(
            "1.0",
            "the evidence recipe and the driving-evidence verdict appear here",
        )
        grid_append(rescore, self._dock_rescore_text, sticky="ew", pady=(6, 0))

        # -- card 7: SMILES array docking (the one-call batch) ---------- #
        array = make_card(
            page.grid,
            "SMILES array docking",
            span=2,
            row=3,
            column=0,
            subtitle="Paste a whole SMILES array and dock every molecule "
            "against one receptor in a single run — each ligand is "
            "prepared (Meeko + RDKit), the engine runs "
            "simultaneously across workers, and the best affinities "
            "land in the results table above.",
        )
        array.columnconfigure(0, weight=3)
        array.columnconfigure(1, weight=2)
        array_left = ttk.Frame(array, style="Card.TFrame")
        array_left.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        self._dock_smiles_text = _grid_text(array_left, height=6, mono=self._mono)
        self._dock_smiles_text.insert("1.0", "\n".join(_DOCK_SMILES_DEFAULTS))
        self._dock_smiles_text.pack(fill="both", expand=True)
        smiles_example_btn = self._action_button(
            array_left,
            "Fill example array",
            self._dock_smiles_example,
            tooltip="The bundled trivial-name drugs (aspirin, caffeine, "
            "paracetamol, ibuprofen, ...).",
        )
        smiles_example_btn.pack(anchor="w", pady=(6, 0))
        ttk.Label(
            array_left, text="one SMILES per line · # comments ignored", style="CardMuted.TLabel"
        ).pack(anchor="w", pady=(4, 0))

        array_right = ttk.Frame(array, style="Card.TFrame")
        array_right.grid(row=0, column=1, sticky="n")
        array_right.columnconfigure(1, weight=1)
        self._dock_smiles_engine_combo = ttk.Combobox(
            array_right, state="readonly", width=20, values=_SMILES_DOCK_ENGINES
        )
        self._dock_smiles_engine_combo.set(_SMILES_DOCK_ENGINES[0])
        Tooltip(
            self._dock_smiles_engine_combo,
            "vina = one Vina process per ligand (fast, the default); "
            "autodock4 = the full classic stack per ligand (receptor "
            "distributed, GPF + DPF written, autogrid4 + autodock4). "
            "Both run simultaneously across the workers below.",
        )
        form_row(array_right, "engine", self._dock_smiles_engine_combo)
        smiles_rec_buttons = ttk.Frame(array_right, style="Card.TFrame")
        smiles_rec_buttons.grid(row=array_right.grid_size()[1], column=0, columnspan=2, sticky="w")
        smiles_rec_btn = self._action_button(
            smiles_rec_buttons, "Receptor PDBQT…", self._dock_smiles_open_receptor
        )
        smiles_rec_btn.pack(side="left")
        self._dock_smiles_receptor_info = ttk.Label(
            smiles_rec_buttons,
            text="none — pick one (or prepare it above)",
            style="CardMuted.TLabel",
            wraplength=240,
            justify="left",
        )
        self._dock_smiles_receptor_info.pack(side="left", padx=(10, 0))
        smiles_out_buttons = ttk.Frame(array_right, style="Card.TFrame")
        smiles_out_buttons.grid(
            row=array_right.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(4, 0)
        )
        smiles_out_btn = self._action_button(
            smiles_out_buttons, "Output folder…", self._dock_smiles_choose_out
        )
        smiles_out_btn.pack(side="left")
        self._dock_smiles_out_info = ttk.Label(
            smiles_out_buttons,
            text="no output folder chosen",
            style="CardMuted.TLabel",
            wraplength=240,
            justify="left",
        )
        self._dock_smiles_out_info.pack(side="left", padx=(10, 0))
        self._dock_smiles_center_entry = ttk.Entry(array_right, width=12)
        self._dock_smiles_center_entry.insert(0, "0 0 0")
        form_row(array_right, "centre (x y z)", self._dock_smiles_center_entry)
        self._dock_smiles_size_entry = ttk.Entry(array_right, width=12)
        self._dock_smiles_size_entry.insert(0, "22.5 22.5 22.5")
        form_row(array_right, "size (x y z)", self._dock_smiles_size_entry)
        self._dock_smiles_exhaust_entry = ttk.Entry(array_right, width=10)
        self._dock_smiles_exhaust_entry.insert(0, "8")
        form_row(array_right, "exhaustiveness (Vina)", self._dock_smiles_exhaust_entry)
        self._dock_smiles_workers_entry = ttk.Entry(array_right, width=10)
        self._dock_smiles_workers_entry.insert(0, "4")
        Tooltip(
            self._dock_smiles_workers_entry,
            "Engine subprocesses to run simultaneously — real docking "
            "takes minutes per ligand, so 4 workers ≈ 4× throughput.",
        )
        form_row(array_right, "workers", self._dock_smiles_workers_entry)
        smiles_run_row = ttk.Frame(array_right, style="Card.TFrame")
        smiles_run_row.grid(
            row=array_right.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(6, 0)
        )
        smiles_run_btn = self._action_button(
            smiles_run_row,
            "Dock the array",
            self._dock_smiles_run,
            primary=True,
            tooltip="Prepares every SMILES into its own campaign folder, then "
            "docks them all with the chosen engine (simultaneously "
            "across workers); the ranked best-affinity table lands in "
            "the results card above and Save results CSV… writes it.",
        )
        smiles_run_btn.pack(side="left")
        self._dock_smiles_summary = ttk.Label(
            smiles_run_row,
            text="—",
            style="CardMuted.TLabel",
            wraplength=280,
            justify="left",
        )
        self._dock_smiles_summary.pack(side="left", padx=(10, 0))

        # -- audit card (100x-110): gpfreader / checker / niggamatch --- #
        # The rar's GPF reader, the campaign completion checker and the
        # torsion-consistency auditor, one card.
        audit = make_card(
            page.grid,
            "Grid, torsion & completion audit",
            row=4,
            column=0,
            subtitle="gpfreader / checker / niggamatch / mismatch2: parse "
            "one GPF into its typed parameters, list every "
            "sub-folder's ligand_types, audit TORSDOF vs active "
            "REMARKs vs BRANCH counts of prepared ligands, or "
            "check a campaign tree for missing / incomplete "
            "AutoDock4 runs.",
        )
        self._dock_audit_mode = ttk.Combobox(
            audit, state="readonly", width=30, values=_DOCK_AUDIT_MODES
        )
        self._dock_audit_mode.set(_DOCK_AUDIT_MODES[0])
        form_row(audit, "mode", self._dock_audit_mode)
        audit_pick = ttk.Frame(audit, style="Card.TFrame")
        grid_append(audit, audit_pick, sticky="w")
        audit_gpf_btn = self._action_button(audit_pick, "GPF file…", self._dock_audit_pick_gpf)
        audit_gpf_btn.pack(side="left")
        audit_folder_btn = self._action_button(audit_pick, "Folder…", self._dock_audit_pick_folder)
        audit_folder_btn.pack(side="left", padx=(10, 0))
        self._dock_audit_gpf: Path | None = None
        self._dock_audit_folder: Path | None = None
        self._dock_audit_info = ttk.Label(
            audit,
            text="pick a GPF file (parameters mode) or a campaign folder (the scan modes)",
            style="CardMuted.TLabel",
            wraplength=300,
            justify="left",
        )
        grid_append(audit, self._dock_audit_info, sticky="w", pady=(4, 0))
        self._dock_audit_log = ttk.Entry(audit, width=16)
        self._dock_audit_log.insert(0, "r.dlg")
        Tooltip(
            self._dock_audit_log,
            "Completion mode: the log file each sub-folder must carry "
            "(AutoDock4's r.dlg by default).",
        )
        form_row(audit, "log name (completion)", self._dock_audit_log)
        audit_run_row = ttk.Frame(audit, style="Card.TFrame")
        grid_append(audit, audit_run_row, sticky="w", pady=(6, 0))
        audit_run_btn = self._action_button(
            audit_run_row,
            "Audit",
            self._dock_audit_run,
            primary=True,
            tooltip="Reads the GPF or walks the tree in a worker thread; "
            "the typed parameter list or the per-folder status "
            "table lands below and Save CSV… writes it.",
        )
        audit_run_btn.pack(side="left")
        self._dock_audit_summary = ttk.Label(
            audit_run_row, text="—", style="CardMuted.TLabel", wraplength=300, justify="left"
        )
        self._dock_audit_summary.pack(side="left", padx=(8, 0))
        audit_save_btn = self._action_button(audit_run_row, "Save CSV…", self._dock_audit_save)
        audit_save_btn.pack(side="left", padx=(8, 0))
        audit_tree_frame = ttk.Frame(audit, style="Card.TFrame")
        grid_append(audit, audit_tree_frame, sticky="nsew", pady=(6, 0), weight=True)
        self._dock_audit_tree = ttk.Treeview(audit_tree_frame, show="headings", height=7)
        audit_bar = ttk.Scrollbar(
            audit_tree_frame, orient="vertical", command=self._dock_audit_tree.yview
        )
        self._dock_audit_tree.configure(yscrollcommand=audit_bar.set)
        self._dock_audit_tree.pack(side="left", fill="both", expand=True)
        audit_bar.pack(side="right", fill="y")
        self._dock_audit_frame: Any = None

        # -- vina config batch (100x-110): vinar_multiple.py ---------- #
        vbatch = make_card(
            page.grid,
            "Vina config batch",
            row=4,
            column=1,
            subtitle="vinar_multiple.py: one Vina config file docks "
            "every .pdbqt under a ligand tree (recursively, "
            "the receptor resolved relative to the config), "
            "several engine processes running simultaneously.",
        )
        vbatch_pick = ttk.Frame(vbatch, style="Card.TFrame")
        grid_append(vbatch, vbatch_pick, sticky="w")
        vbatch_conf_btn = self._action_button(vbatch_pick, "Config…", self._dock_vbatch_pick_conf)
        vbatch_conf_btn.pack(side="left")
        vbatch_lig_btn = self._action_button(
            vbatch_pick, "Ligands folder…", self._dock_vbatch_pick_ligands
        )
        vbatch_lig_btn.pack(side="left", padx=(10, 0))
        vbatch_out_btn = self._action_button(vbatch_pick, "Output…", self._dock_vbatch_pick_out)
        vbatch_out_btn.pack(side="left", padx=(10, 0))
        self._dock_vbatch_conf: Path | None = None
        self._dock_vbatch_ligands: Path | None = None
        self._dock_vbatch_out: Path | None = None
        self._dock_vbatch_info = ttk.Label(
            vbatch,
            text="pick a Vina config (with receptor = ...), a ligand tree and an output folder",
            style="CardMuted.TLabel",
            wraplength=300,
            justify="left",
        )
        grid_append(vbatch, self._dock_vbatch_info, sticky="w", pady=(4, 0))
        self._dock_vbatch_workers = ttk.Entry(vbatch, width=10)
        self._dock_vbatch_workers.insert(0, "2")
        Tooltip(
            self._dock_vbatch_workers,
            "Engine subprocesses running simultaneously (real docking takes minutes per ligand).",
        )
        form_row(vbatch, "workers", self._dock_vbatch_workers)
        vbatch_run_row = ttk.Frame(vbatch, style="Card.TFrame")
        grid_append(vbatch, vbatch_run_row, sticky="w", pady=(6, 0))
        vbatch_run_btn = self._action_button(
            vbatch_run_row,
            "Dock the batch",
            self._dock_vbatch_run,
            primary=True,
            tooltip="Every ligand PDBQT found under the tree is docked "
            "with the config itself (--config); outputs and logs "
            "land in the output folder and the per-ligand table "
            "below.",
        )
        vbatch_run_btn.pack(side="left")
        # 100x-120: parse the picked config (parse_vina_config) -- the
        # key\u2192value dump plus a one-click fill of the single-run form.
        vbatch_parse_btn = self._action_button(
            vbatch_run_row,
            "Parse config",
            self._dock_vbatch_parse,
            tooltip="Parses the picked Vina config (parse_vina_config) and "
            "shows every key\u2192value pair -- plus a button's worth "
            "of convenience: centre / size / exhaustiveness are "
            "copied into the Campaign runner's single-ligand form.",
        )
        vbatch_parse_btn.pack(side="left", padx=(10, 0))
        self._dock_vbatch_summary = ttk.Label(
            vbatch_run_row, text="—", style="CardMuted.TLabel", wraplength=300, justify="left"
        )
        self._dock_vbatch_summary.pack(side="left", padx=(8, 0))
        vbatch_tree_frame = ttk.Frame(vbatch, style="Card.TFrame")
        grid_append(vbatch, vbatch_tree_frame, sticky="nsew", pady=(6, 0), weight=True)
        self._dock_vbatch_tree = ttk.Treeview(vbatch_tree_frame, show="headings", height=7)
        vbatch_bar = ttk.Scrollbar(
            vbatch_tree_frame, orient="vertical", command=self._dock_vbatch_tree.yview
        )
        self._dock_vbatch_tree.configure(yscrollcommand=vbatch_bar.set)
        self._dock_vbatch_tree.pack(side="left", fill="both", expand=True)
        vbatch_bar.pack(side="right", fill="y")
        self._dock_vbatch_frame: Any = None

        # -- single SMILES -> PDBQT (100x-110): smilestopdbqt/smiqt --- #
        smi_pdbqt = make_card(
            page.grid,
            "SMILES → PDBQT (single ligand)",
            row=5,
            column=0,
            span=2,
            subtitle="smilestopdbqt.py / smiqt.py: one SMILES embedded in "
            "3D (ETKDG + MMFF), written as a docking-ready "
            "PDBQT with Meeko and repaired to AD4 atom types.",
        )
        smi_pdbqt.columnconfigure(1, weight=1)
        self._dock_smi_entry = ttk.Entry(smi_pdbqt, width=34)
        self._dock_smi_entry.insert(0, "CC(=O)Oc1ccccc1C(=O)O")
        form_row(smi_pdbqt, "SMILES", self._dock_smi_entry)
        self._dock_smi_name = ttk.Entry(smi_pdbqt, width=18)
        self._dock_smi_name.insert(0, "ligand")
        Tooltip(self._dock_smi_name, "Base filename (ligand.pdbqt); blank uses a safe SMILES slug.")
        form_row(smi_pdbqt, "name", self._dock_smi_name)
        smi_out_row = ttk.Frame(smi_pdbqt, style="Card.TFrame")
        grid_append(smi_pdbqt, smi_out_row, sticky="w")
        smi_out_btn = self._action_button(smi_out_row, "Output folder…", self._dock_smi_pick_out)
        smi_out_btn.pack(side="left")
        self._dock_smi_info = ttk.Label(
            smi_out_row,
            text="no output folder chosen",
            style="CardMuted.TLabel",
            wraplength=380,
            justify="left",
        )
        self._dock_smi_info.pack(side="left", padx=(10, 0))
        self._dock_smi_out: Path | None = None
        smi_run_row = ttk.Frame(smi_pdbqt, style="Card.TFrame")
        grid_append(smi_pdbqt, smi_run_row, sticky="w", pady=(6, 0))
        smi_run_btn = self._action_button(
            smi_run_row,
            "Prepare ligand",
            self._dock_smi_run,
            primary=True,
            tooltip="Embeds with a fixed seed, MMFF-optimises and writes "
            "the PDBQT (needs Meeko, part of pharmaml's docking "
            "extras); the torsion report follows the file name.",
        )
        smi_run_btn.pack(side="left")
        self._dock_smi_summary = ttk.Label(
            smi_run_row, text="—", style="CardMuted.TLabel", wraplength=380, justify="left"
        )
        self._dock_smi_summary.pack(side="left", padx=(10, 0))
        bind_enter(self._dock_smi_entry, smi_run_btn)

    # -- ligand library card ------------------------------------------- #
    def _dock_open_csv(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "library loading"):
            return
        path = filedialog.askopenfilename(
            title="Open a ligand library",
            filetypes=[("SMILES library", "*.csv *.tsv"), ("All files", "*.*")],
        )
        if path:
            self._dock_load_lib_path(Path(path))

    def _dock_load_example(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "library loading"):
            return
        path = EXAMPLES_DIR / "ligand_library.csv"
        if not path.is_file():
            messagebox.showwarning(
                "Missing example", "examples/data/ligand_library.csv was not found."
            )
            return
        self._dock_load_lib_path(path)

    def _dock_load_lib_path(self, path: Path) -> None:
        try:
            from pharmaml.docking import load_ligand_csv

            library = load_ligand_csv(path)
        except Exception as exc:  # noqa: BLE001
            self._show_error("Could not read the ligand library", exc)
            return
        if library.frame.empty:
            messagebox.showwarning("Empty library", f"{path.name} has no rows.")
            return
        self._dock_library = library
        self._dock_lib_path = path
        valid = int((library.frame["status"] == "valid").sum())
        self._dock_lib_info.configure(
            text=(
                f"{path.name} — {len(library.frame)} rows · {valid} valid "
                f"SMILES · {len(library.frame) - valid} invalid"
            )
        )

    def _dock_choose_out_dir(self) -> None:
        path = filedialog.askdirectory(title="Choose the ligand output folder")
        if path:
            self._dock_out_dir = Path(path)
            self._dock_out_info.configure(text=f"campaign output: {path}")

    def _dock_prepare_ligands(self) -> None:
        if not self._require_pharmaml():
            return
        if not self._require("pandas", "ligand preparation") or not self._require(
            "rdkit", "ligand preparation"
        ):
            return
        if self._dock_library is None:
            messagebox.showwarning("No library", "Load a ligand library first.")
            return
        if self._dock_out_dir is None:
            messagebox.showwarning(
                "No output folder",
                "Choose the campaign output folder first (the tab creates one "
                "sub-folder per ligand inside it).",
            )
            return
        library, output_root = self._dock_library, self._dock_out_dir

        def work() -> Any:
            from pharmaml.docking import prepare_ligand_library

            return prepare_ligand_library(library, output_root)

        def render(report: Any) -> None:
            self._dock_render_ligand_report(report)

        self._start_job("preparing ligands", work, render)

    def _dock_render_ligand_report(self, report: Any) -> None:
        self._dock_report = report
        frame = report.frame
        ok_count = int(frame["ok"].sum())
        failed = len(frame) - ok_count
        self._dock_prep_summary.configure(
            text=(
                f"{ok_count}/{len(frame)} prepared · {failed} failed · campaign at {report.root}"
            ),
            style="Field.TLabel",
        )
        tree = self._dock_lib_tree
        tree.delete(*tree.get_children())
        for row in frame.to_dict("records"):
            tree.insert(
                "",
                "end",
                values=(
                    _cell_text(row["folder"], limit=22),
                    _cell_text(row["name"], limit=16),
                    "Yes" if bool(row["ok"]) else "No",
                    _cell_text(row["atoms"]),
                    _cell_text(row["torsdof"]),
                    _cell_text(row["error"], limit=60),
                ),
            )

    def _dock_save_ligand_report(self) -> None:
        if self._dock_report is None:
            messagebox.showinfo("Nothing to save", "Prepare a ligand library first.")
            return
        self._save_frame_dialog(
            self._dock_report.frame,
            "Save the ligand preparation report",
            "ligand_report.csv",
            "Preparation report",
        )

    # -- receptor card -------------------------------------------------- #
    def _dock_open_receptor(self) -> None:
        if not self._require_pharmaml() or not self._require("rdkit", "receptor preparation"):
            return
        path = filedialog.askopenfilename(
            title="Open a receptor structure",
            filetypes=[("Structure files", "*.pdb *.cif *.pdbqt"), ("All files", "*.*")],
        )
        if path:
            self._dock_set_receptor_source(Path(path))

    def _dock_load_receptor_example(self) -> None:
        if not self._require_pharmaml() or not self._require("rdkit", "receptor preparation"):
            return
        path = EXAMPLES_DIR / "lysozyme_1aki.pdb"
        if not path.is_file():
            messagebox.showwarning(
                "Missing example", "examples/data/lysozyme_1aki.pdb was not found."
            )
            return
        self._dock_set_receptor_source(path)

    def _dock_set_receptor_source(self, path: Path) -> None:
        self._dock_receptor_source = path
        self._dock_receptor_info.configure(text=f"{path.name}")

    def _dock_prepare_receptor(self) -> None:
        if not self._require_pharmaml() or not self._require("rdkit", "receptor preparation"):
            return
        if self._dock_receptor_source is None:
            messagebox.showwarning("No receptor", "Open a PDB / CIF / PDBQT structure first.")
            return
        source = self._dock_receptor_source
        output_pdbqt = filedialog.asksaveasfilename(
            title="Save the prepared receptor",
            defaultextension=".pdbqt",
            initialfile="receptor.pdbqt",
            filetypes=[("PDBQT receptor", "*.pdbqt")],
        )
        if not output_pdbqt:
            return
        remove_waters = bool(self._dock_remove_waters_var.get())
        keep_hetatm = bool(self._dock_keep_hetatm_var.get())
        strip_hydrogens = bool(self._dock_strip_h_var.get())
        allow_bad_res = bool(getattr(self, "_dock_bad_res_var", tk.BooleanVar(value=True)).get())
        chain = self._dock_chain_entry.get().strip() or None
        target = Path(output_pdbqt)

        def work() -> Any:
            from pharmaml.docking import prepare_protein

            return prepare_protein(
                source,
                output_pdbqt=target,
                remove_waters=remove_waters,
                keep_hetatm=keep_hetatm,
                chain=chain,
                strip_hydrogens=strip_hydrogens,
                allow_bad_res=allow_bad_res,
            )

        def render(report: Any) -> None:
            self._dock_render_protein_report(report)

        self._start_job(f"preparing {source.name}", work, render)

    def _dock_render_protein_report(self, report: Any) -> None:
        self._dock_protein_report = report
        self._dock_receptor_path = Path(report.output_pdbqt)
        # a freshly prepared receptor becomes the SMILES array card's
        # default too (its own explicit pick always wins)
        if self._dock_smiles_receptor is None:
            with contextlib.suppress(Exception):
                self._dock_smiles_receptor_info.configure(text=f"prepared: {report.output_pdbqt}")
        chains = ", ".join(report.chains) if report.chains else "—"
        types = " · ".join(
            f"{name} {count:,}"
            for name, count in sorted(report.atom_types.items(), key=lambda item: -item[1])
        )
        lines = [
            f"mode            {report.mode} ({report.source.suffix or 'input'})",
            (f"input           {report.input_atoms:,} atoms · {report.input_hetatms:,} HETATM"),
            (
                f"removed         {report.waters_removed:,} waters · "
                f"{report.hetatm_removed:,} HETATM · "
                f"{report.altloc_removed:,} altloc · "
                f"{report.hydrogens_removed:,} hydrogens"
                + (
                    f" · {report.bad_residues_removed} bad residues "
                    f"({', '.join(report.bad_residue_ids)})"
                    if getattr(report, "bad_residue_ids", None)
                    else ""
                )
            ),
            f"chains          {chains}",
            f"residues        {report.residues:,}",
            f"output          {report.output_atoms:,} atoms ({types})",
            (
                f"charges         {report.charge_min:+.3f} … {report.charge_max:+.3f} "
                f"(mean {report.charge_mean:+.4f})"
            ),
            f"written to      {report.output_pdbqt}",
        ]
        if report.notes:
            lines.append("notes           " + " · ".join(str(note) for note in report.notes))
        else:
            lines.append("notes           (none)")
        self._dock_protein_text.delete("1.0", "end")
        self._dock_protein_text.insert("1.0", "\n".join(lines))

    def _dock_distribute_receptor(self) -> None:
        if not self._require_pharmaml():
            return
        receptor = self._dock_receptor_path
        if receptor is None:
            messagebox.showinfo(
                "No receptor yet",
                "Prepare a receptor above first -- or pick an already-prepared "
                "PDBQT in the next dialog.",
            )
            path = filedialog.askopenfilename(
                title="Open the prepared receptor PDBQT",
                filetypes=[("PDBQT receptor", "*.pdbqt"), ("All files", "*.*")],
            )
            if not path:
                return
            receptor = self._dock_receptor_path = Path(path)
        root = filedialog.askdirectory(title="Choose the campaign root")
        if not root:
            return
        campaign_root = Path(root)

        def work() -> Any:
            from pharmaml.docking import distribute_receptor

            return distribute_receptor(receptor, campaign_root)

        def render(copies: Any) -> None:
            self._dock_distribute_info.configure(
                text=f"receptor copied into {len(copies)} folders "
                f"({receptor.name} → {campaign_root})",
                style="Field.TLabel",
            )

        self._start_job("distributing receptor", work, render)

    # -- grid box card --------------------------------------------------- #
    def _dock_open_ligand(self) -> None:
        if not self._require_pharmaml():
            return
        path = filedialog.askopenfilename(
            title="Open a reference ligand PDBQT",
            filetypes=[("PDBQT ligand", "*.pdbqt"), ("All files", "*.*")],
        )
        if path:
            self._dock_set_ligand_path(Path(path))

    def _dock_set_ligand_path(self, path: Path) -> None:
        self._dock_ligand_path = path
        self._dock_ligand_info.configure(text=path.name)

    def _dock_compute_grid(self) -> None:
        if not self._require_pharmaml():
            return
        if self._dock_ligand_path is None:
            messagebox.showwarning("No ligand", "Open a reference ligand PDBQT first.")
            return
        ligand = self._dock_ligand_path
        try:
            padding = parse_float(self._dock_padding_entry.get(), "padding", minimum=0.0)
            npts = parse_int_triple(self._dock_npts_entry.get(), "npts", minimum=1)
            spacing = parse_float(self._dock_spacing_entry.get(), "spacing", minimum=0.01)
            receptor_file = self._dock_receptor_name_entry.get().strip()
            if not receptor_file:
                raise ValueError("receptor file: pick a file name (e.g. r.pdbqt)")
            ga_run = parse_int(self._dock_ga_run_entry.get(), "ga_run", minimum=1)
            ga_pop = parse_int(self._dock_ga_pop_entry.get(), "ga population", minimum=1)
            receptor_types = self._dock_receptor_types_entry.get().strip() or None
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        def work() -> Any:
            from pharmaml.docking import (
                compute_grid_box,
                extract_pdbqt_atom_types,
                write_dpf,
                write_gpf,
            )

            box = compute_grid_box(ligand, padding=padding, npts=npts, spacing=spacing)
            atom_types = extract_pdbqt_atom_types(ligand)
            gpf_kwargs: dict[str, Any] = {
                "receptor_file": receptor_file,
                "box": box,
                "output_path": ligand.parent / "r.gpf",
            }
            if receptor_types is not None:
                gpf_kwargs["receptor_types"] = receptor_types
            gpf = write_gpf(ligand, **gpf_kwargs)
            dpf = write_dpf(
                ligand,
                receptor_file=receptor_file,
                output_path=ligand.parent / "r.dpf",
                ga_run=ga_run,
                ga_pop_size=ga_pop,
            )
            return box, atom_types, gpf, dpf, ga_run, ga_pop, receptor_types

        def render(payload: Any) -> None:
            box, atom_types, gpf, dpf, used_run, used_pop, used_types = payload
            self._dock_box = box
            centre = (box.center_x, box.center_y, box.center_z)
            size = box.size
            self._dock_grid_text.delete("1.0", "end")
            self._dock_grid_text.insert(
                "1.0",
                "\n".join(
                    [
                        (f"box centre     ({centre[0]:.3f}, {centre[1]:.3f}, {centre[2]:.3f}) Å"),
                        (
                            f"box size       ({size[0]:.3f}, {size[1]:.3f}, {size[2]:.3f}) Å "
                            f"· npts {box.npts} at {box.spacing:g} Å"
                        ),
                        f"ligand types   {' '.join(atom_types)}",
                        (f"receptor types {used_types or 'A C HD N NA OA SA (default)'}"),
                        f"r.gpf          {gpf}",
                        f"r.dpf          {dpf}   (ga_run {used_run} · pop {used_pop})",
                    ]
                ),
            )

        self._start_job(f"grid box for {ligand.name}", work, render)

    def _dock_write_config_batch(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "the config batch"):
            return
        path = filedialog.askdirectory(title="Choose the campaign root (one sub-folder per ligand)")
        if not path:
            return
        root = Path(path)
        try:
            padding = parse_float(self._dock_padding_entry.get(), "padding", minimum=0.0)
            npts = parse_int_triple(self._dock_npts_entry.get(), "npts", minimum=1)
            spacing = parse_float(self._dock_spacing_entry.get(), "spacing", minimum=0.01)
            receptor_file = self._dock_receptor_name_entry.get().strip()
            if not receptor_file:
                raise ValueError("receptor file: pick a file name (e.g. r.pdbqt)")
            ga_run = parse_int(self._dock_ga_run_entry.get(), "ga_run", minimum=1)
            ga_pop = parse_int(self._dock_ga_pop_entry.get(), "ga population", minimum=1)
            receptor_types = self._dock_receptor_types_entry.get().strip() or None
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        def work() -> Any:
            from pharmaml.docking import write_config_batch

            return write_config_batch(
                root,
                receptor_file=receptor_file,
                padding=padding,
                npts=npts,
                spacing=spacing,
                receptor_types=receptor_types,
                ga_run=ga_run,
                ga_pop_size=ga_pop,
            )

        def render(report: Any) -> None:
            ok = int((report["status"] == "ok").sum())
            skipped = int((report["status"] == "skipped (r.gpf exists)").sum())
            no_ligand = int((report["status"] == "no ligand PDBQT").sum())
            failed = int(report["status"].str.startswith("failed").sum())
            lines = [
                f"campaign root  {root}",
                (
                    f"configured      {ok}/{len(report)} folders"
                    + (f" · {skipped} skipped (r.gpf exists)" if skipped else "")
                    + (f" · {no_ligand} without a ligand" if no_ligand else "")
                    + (f" · {failed} failed" if failed else "")
                ),
            ]
            for row in report.to_dict("records"):
                centre = str(row.get("centre") or "")
                lines.append(
                    f"  {row['folder']:<20} {row['status']:<26}"
                    + (f" box {centre}" if centre else "")
                )
            self._dock_grid_text.delete("1.0", "end")
            self._dock_grid_text.insert("1.0", "\n".join(lines))

        self._start_job(f"writing configs for {root.name}", work, render)

    # -- docking results card -------------------------------------------- #
    def _dock_scan_campaign(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "the campaign scan"):
            return
        path = filedialog.askdirectory(title="Choose the campaign root to scan")
        if path:
            self._dock_scan_campaign_path(Path(path))

    def _dock_load_example_campaign(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "the campaign scan"):
            return
        path = EXAMPLES_DIR / "docking_campaign"
        if not path.is_dir():
            messagebox.showwarning(
                "Missing example", "examples/data/docking_campaign was not found."
            )
            return
        self._dock_scan_campaign_path(path)

    def _dock_scan_campaign_path(self, root: Path) -> None:
        def work() -> Any:
            from pharmaml.docking import scan_docking_directory

            return scan_docking_directory(root)

        def render(frame: Any) -> None:
            self._dock_results_frame = frame
            self._dock_results_source = "campaign"
            tree = self._dock_results_tree
            tree.delete(*tree.get_children())
            columns = ["folder", "n_clusters", "top_lowest_energy", "best_lowest_energy", "status"]
            tree["columns"] = columns
            for column in columns:
                tree.heading(column, text=column)
                tree.column(
                    column,
                    width=150 if column == "folder" else 130,
                    minwidth=80,
                    stretch=(column == "folder"),
                )
            for _, row in frame.iterrows():
                values = [
                    _cell_text(
                        None
                        if (isinstance(row[column], float) and math.isnan(row[column]))
                        else row[column],
                        limit=48,
                    )
                    for column in columns
                ]
                tree.insert("", "end", values=values)
            ok = int((frame["status"] == "OK").sum())
            self._dock_results_info.configure(
                text=(
                    f"{len(frame)} folders scanned · {ok} OK · "
                    f"{len(frame) - ok} incomplete — {root.name}"
                ),
                style="Field.TLabel",
            )
            self._dock_rescore_prefill()

        self._start_job(f"scanning {root.name}", work, render)

    def _dock_open_dlg(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "DLG parsing"):
            return
        path = filedialog.askopenfilename(
            title="Open an AutoDock4 DLG log",
            filetypes=[("AutoDock DLG log", "*.dlg"), ("All files", "*.*")],
        )
        if path:
            self._dock_parse_dlg_path(Path(path))

    def _dock_open_example_dlg(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "DLG parsing"):
            return
        path = EXAMPLES_DIR / "docking_campaign" / "01_aspirin" / "r.dlg"
        if not path.is_file():
            messagebox.showwarning(
                "Missing example",
                "examples/data/docking_campaign/01_aspirin/r.dlg was not found.",
            )
            return
        self._dock_parse_dlg_path(path)

    def _dock_parse_dlg_path(self, path: Path) -> None:
        heavy_raw = self._dock_heavyatoms_entry.get().strip()
        heavy_atoms: int | None = None
        if heavy_raw:
            try:
                heavy_atoms = parse_int(heavy_raw, "heavy atoms", minimum=1, maximum=500)
            except ValueError as exc:
                messagebox.showerror("Input", str(exc))
                return

        def work() -> Any:
            import pandas as pd

            from pharmaml.docking import (
                ligand_efficiency_series,
                parse_dlg_cluster_table,
                parse_dlg_summary,
            )

            clusters = parse_dlg_cluster_table(path)
            summary = parse_dlg_summary(path)
            frame = pd.DataFrame(
                [
                    {
                        "rank": cluster.rank,
                        "lowest_energy": cluster.lowest_energy,
                        "mean_energy": cluster.mean_energy,
                        "num_in_cluster": cluster.num_in_cluster,
                    }
                    for cluster in clusters
                ]
            )
            if heavy_atoms is not None:
                frame["n_heavy"] = heavy_atoms
                frame["LE (kcal/mol/atom)"] = ligand_efficiency_series(
                    frame, affinity_col="lowest_energy", atoms_col="n_heavy"
                )
            return frame, summary, heavy_atoms

        def render(payload: Any) -> None:
            frame, summary, used_atoms = payload
            self._dock_results_frame = frame
            self._dock_results_source = "dlg"
            tree = self._dock_results_tree
            tree.delete(*tree.get_children())
            columns = [str(column) for column in frame.columns if column != "n_heavy"]
            tree["columns"] = columns
            for column in columns:
                tree.heading(column, text=column)
                tree.column(
                    column,
                    width=170 if column.startswith("LE") else 120,
                    minwidth=80,
                    stretch=False,
                )
            for row in frame.to_dict("records"):
                values = [
                    _cell_text(
                        None
                        if (isinstance(row[column], float) and math.isnan(row[column]))
                        else row[column],
                        limit=40,
                    )
                    for column in columns
                ]
                tree.insert("", "end", values=values)
            info = (
                f"{summary['n_clusters']} clusters · top cluster rank "
                f"{summary['top_rank']} at "
                f"{summary['top_lowest_energy']:.2f} kcal/mol "
                f"({summary['top_num_in_cluster']} poses) · largest cluster "
                f"rank {summary['best_rank']} "
                f"({summary['best_num_in_cluster']} poses)"
            )
            if used_atoms is not None:
                info += f" · LE over {used_atoms} heavy atoms"
            self._dock_results_info.configure(text=info, style="Field.TLabel")
            self._dock_rescore_prefill()

        self._start_job(f"parsing {path.name}", work, render)

    def _dock_scan_vina(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "Vina scanning"):
            return
        path = filedialog.askdirectory(title="Choose the Vina results root to scan")
        if not path:
            return
        root = Path(path)

        def work() -> Any:
            from pharmaml.docking import scan_vina_directory

            return scan_vina_directory(root)

        def render(frame: Any) -> None:
            self._dock_results_frame = frame
            self._dock_results_source = "vina"
            tree = self._dock_results_tree
            tree.delete(*tree.get_children())
            columns = [str(column) for column in frame.columns]
            tree["columns"] = columns
            for column in columns:
                tree.heading(column, text=column)
                tree.column(column, width=120, minwidth=80, stretch=False)
            for row in frame.to_dict("records"):
                tree.insert(
                    "",
                    "end",
                    values=[_cell_text(row[column]) for column in columns],
                )
            n_logs = len(frame)
            if n_logs and frame["best_affinity"].notna().any():
                best = float(frame["best_affinity"].min())
                best_ligand = str(frame.loc[frame["best_affinity"].idxmin(), "ligand"])
                info = (
                    f"{n_logs} Vina logs · best {best:.2f} kcal/mol "
                    f"({best_ligand}) — strongest binder first"
                )
            elif n_logs:
                info = f"{n_logs} Vina logs · none scored a pose (check the logs for crashes)"
            else:
                info = "no Vina logs found under the chosen folder"
            self._dock_results_info.configure(text=info, style="Field.TLabel")
            self._dock_rescore_prefill()

        self._start_job(f"scanning {root.name} for Vina logs", work, render)

    def _dock_open_vina(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "Vina parsing"):
            return
        path = filedialog.askopenfilename(
            title="Open a Vina output",
            filetypes=[("Vina output", "*.pdbqt *.log *.txt"), ("All files", "*.*")],
        )
        if path:
            self._dock_parse_vina_path(Path(path))

    def _dock_parse_vina_path(self, path: Path) -> None:
        def work() -> Any:
            import pandas as pd

            from pharmaml.docking import parse_vina_output

            poses = parse_vina_output(path)
            frame = pd.DataFrame(
                [
                    {
                        "mode": pose.mode,
                        "affinity": pose.affinity,
                        "rmsd_ub": pose.rmsd_ub,
                        "rmsd_lb": pose.rmsd_lb,
                    }
                    for pose in poses
                ]
            )
            return frame

        def render(frame: Any) -> None:
            self._dock_results_frame = frame
            self._dock_results_source = "vina"
            tree = self._dock_results_tree
            tree.delete(*tree.get_children())
            columns = [str(column) for column in frame.columns]
            tree["columns"] = columns
            for column in columns:
                tree.heading(column, text=column)
                tree.column(column, width=120, minwidth=80, stretch=False)
            for row in frame.to_dict("records"):
                tree.insert(
                    "",
                    "end",
                    values=[_cell_text(row[column]) for column in columns],
                )
            best = float(frame["affinity"].min()) if len(frame) else float("nan")
            self._dock_results_info.configure(
                text=f"{len(frame)} modes · best affinity {best:.2f} kcal/mol — {path.name}",
                style="Field.TLabel",
            )
            self._dock_rescore_prefill()

        self._start_job(f"parsing {path.name}", work, render)

    def _dock_save_results(self) -> None:
        if self._dock_results_frame is None:
            messagebox.showinfo("Nothing to save", "Scan a campaign or parse a log first.")
            return
        self._save_frame_dialog(
            self._dock_results_frame, "Save the docking results", "docking_results.csv", "Results"
        )

    # -- receptor atom-type census + top-ligand bars (100x-119) -------- #
    def _dock_plot_atom_types(self) -> None:
        """The prepared receptor's atom-type census (plot_receptor_atom_types)."""
        report = getattr(self, "_dock_protein_report", None)
        if report is None:
            messagebox.showinfo(
                "No receptor yet",
                "Prepare a receptor first — the atom-type census needs the prepared PDBQT.",
            )
            return
        if not self._require_pharmaml() or not self._require("matplotlib", "the atom-type chart"):
            return

        def work() -> Any:
            from pharmaml.viz import plot_receptor_atom_types

            return plot_receptor_atom_types(report)

        def render(figure: Any) -> None:
            self._render_figure(self._dock_receptor_host, figure)

        self._start_job("receptor atom types", work, render)

    def _dock_plot_top_ligands(self) -> None:
        """Strongest binders of the last scan as bars (plot_top_ligands)."""
        frame = getattr(self, "_dock_results_frame", None)
        if frame is None:
            messagebox.showinfo(
                "No results yet",
                "Scan a campaign first — the top-ligand bars need the ranked summary table.",
            )
            return
        if "folder" not in [str(c) for c in frame.columns]:
            messagebox.showinfo(
                "Campaign scans only",
                "The top-ligand bars need a campaign-scan table (the "
                "folder-ranked summary). Scan a campaign folder first — a "
                "DLG cluster table or a Vina log has no ligand ranking.",
            )
            return
        if not self._require_pharmaml() or not self._require("matplotlib", "the top-ligand chart"):
            return

        def work() -> Any:
            from pharmaml.viz import plot_top_ligands

            return plot_top_ligands(frame, top_n=12)

        def render(figure: Any) -> None:
            self._render_figure(self._dock_results_host, figure)

        self._start_job("top-ligand bars", work, render)

    # -- consensus rescore card ------------------------------------------ #
    def _dock_open_rescore_csv(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "summary loading"):
            return
        path = filedialog.askopenfilename(
            title="Open a docking summary table",
            filetypes=[("Summary table", "*.csv *.tsv"), ("All files", "*.*")],
        )
        if path:
            self._dock_load_rescore_csv(Path(path))

    def _dock_load_rescore_csv(self, path: Path) -> None:
        def work() -> Any:
            from pharmaml.utils.io import read_table

            return read_table(path)

        def render(frame: Any) -> None:
            if frame.empty:
                messagebox.showwarning("Empty table", f"{path.name} has no rows.")
                return
            self._dock_results_frame = frame
            self._dock_results_source = "csv"
            tree = self._dock_results_tree
            tree.delete(*tree.get_children())
            columns = [str(column) for column in frame.columns]
            tree["columns"] = columns
            for column in columns:
                tree.heading(column, text=column)
                tree.column(
                    column,
                    width=150 if column == columns[0] else 120,
                    minwidth=80,
                    stretch=(column == columns[0]),
                )
            for row in frame.to_dict("records"):
                values = [
                    _cell_text(
                        None
                        if (isinstance(row[column], float) and math.isnan(row[column]))
                        else row[column],
                        limit=40,
                    )
                    for column in columns
                ]
                tree.insert("", "end", values=values)
            self._dock_results_info.configure(
                text=f"{len(frame)} row(s) · {path.name} — rescore ready",
                style="Field.TLabel",
            )
            self._dock_rescore_prefill()

        self._start_job(f"reading {path.name}", work, render)

    def _dock_rescore_prefill(self) -> None:
        """Seed the evidence-columns entry from the loaded table.

        Preference-ordered: the toolkit's canonical evidence names win;
        otherwise the numeric columns (minus the identity) are listed.
        """
        frame = self._dock_results_frame
        if frame is None:
            return
        available = {str(column) for column in frame.columns}
        preferred = [name for name in _RESCORE_PREFERRED_COLUMNS if name in available]
        if not preferred:
            preferred = [str(column) for column in frame.columns[1:8]]
        if preferred:
            entry = self._dock_rescore_columns_entry
            entry.delete(0, "end")
            entry.insert(0, ", ".join(preferred[:6]))

    def _dock_rescore(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "consensus rescoring"):
            return
        frame = self._dock_results_frame
        if frame is None:
            messagebox.showwarning(
                "No table loaded",
                "Scan a campaign, open a DLG / Vina log or a summary CSV "
                "first -- the rescore ranks the loaded results table.",
            )
            return
        columns = [
            name.strip()
            for name in self._dock_rescore_columns_entry.get().split(",")
            if name.strip()
        ]
        if not columns:
            messagebox.showerror("Input", "name at least one evidence column")
            return
        weights: list[float] | None = None
        raw_weights = self._dock_rescore_weights_entry.get().strip()
        if raw_weights:
            try:
                weights = [
                    parse_float(raw, "weight", minimum=0.0, maximum=100.0)
                    for raw in raw_weights.split(",")
                ]
            except ValueError as exc:
                messagebox.showerror("Input", str(exc))
                return
        higher_is_better: dict[str, bool] = {}
        raw_higher = self._dock_rescore_higher_entry.get().strip()
        if raw_higher:
            higher_is_better = {
                name.strip(): True for name in raw_higher.split(",") if name.strip()
            }

        def work() -> Any:
            from pharmaml.docking import consensus_breakdown

            breakdown = consensus_breakdown(
                frame,
                columns,
                weights=weights,
                higher_is_better=higher_is_better or None,
            )
            rescored = frame.copy()
            for column in breakdown.columns:
                rescored[column] = breakdown[column].to_numpy()
            return rescored.sort_values(
                "consensus", ascending=False, na_position="last"
            ).reset_index(drop=True)

        def render(rescored: Any) -> None:
            self._dock_results_frame = rescored
            self._dock_results_source = "rescore"
            source_label = (
                self._dock_results_info.cget("text")
                if self._dock_results_info.winfo_exists()
                else "loaded table"
            )
            self._dock_rescore_last = (
                rescored,
                columns,
                weights,
                dict(higher_is_better),
                source_label,
            )
            tree = self._dock_results_tree
            tree.delete(*tree.get_children())
            identity = str(rescored.columns[0])
            norm_columns = [f"{column}_norm" for column in columns]
            show = [identity] + [
                column for column in norm_columns + ["consensus"] if column != identity
            ]
            tree["columns"] = show
            for column in show:
                tree.heading(column, text=column)
                tree.column(
                    column,
                    width=150 if column == identity else 130,
                    minwidth=80,
                    stretch=(column == identity),
                )
            for row in rescored.to_dict("records"):
                values = [
                    _cell_text(
                        None
                        if (isinstance(row[column], float) and math.isnan(row[column]))
                        else row[column],
                        limit=40,
                    )
                    for column in show
                ]
                tree.insert("", "end", values=values)
            # The introspection lines, the CLI's recipe + verdict.
            directions = higher_is_better or {}
            recipe = ", ".join(
                f"{column} ("
                + (
                    "higher"
                    if directions.get(column, not column.endswith(("energy", "affinity")))
                    else "lower"
                )
                + "=better"
                + (f", weight {weight:g}" if weights else "")
                + ")"
                for column, weight in zip(columns, weights or [1.0] * len(columns))
            )
            lines = [f"evidence: {recipe}"]
            lines.append(
                f"{len(rescored)} row(s) rescored -- consensus = weighted "
                "mean of the _norm columns, higher is better"
            )
            valid = rescored["consensus"].dropna()
            if len(valid):
                # Column-wise access keeps each dtype: .loc[scalar] would
                # upcast the whole row Series to float64 and render the
                # integer identity ("rank 4") as "4.0".
                top_index = int(valid.idxmax())
                identity_value = rescored[identity].iloc[top_index]
                top_consensus = float(rescored["consensus"].iloc[top_index])
                top_norms = {
                    column: float(rescored[column].iloc[top_index]) for column in norm_columns
                }
                driver = max(top_norms, key=lambda name: top_norms[name])
                lines.append(
                    f"{identity_value} tops the table (consensus "
                    f"{top_consensus:.3f}): {driver} = "
                    f"{top_norms[driver]:.3f} is the driving evidence"
                )
            self._dock_rescore_text.delete("1.0", "end")
            self._dock_rescore_text.insert("1.0", "\n".join(lines))
            self._dock_rescore_info.configure(
                text=f"rescored · {len(rescored)} row(s) · {len(columns)} "
                f"evidence column(s) -- Save results CSV… writes the table",
                style="Field.TLabel",
            )
            self._dock_results_info.configure(
                text=f"{len(rescored)} row(s) · consensus ranking "
                f"({len(columns)} evidence columns)",
                style="Field.TLabel",
            )

        self._start_job("rescoring the loaded table", work, render)

    def _dock_save_report(self) -> None:
        """Write the last rescore as the one-click visual bundle.

        The same ``report.html`` + figures + tables bundle the CLI's
        ``docking rescore --plots`` writes (plus the multi-page
        ``report.pdf`` when the checkbox is ticked -- the
        ``--pdf-report`` twin), rebuilt from the stored rescore and
        saved into a folder the user picks.  Figures are created under
        the package's forced-Agg backend inside the worker thread; they
        never touch Tk.
        """
        if not self._require_pharmaml() or not self._require("matplotlib", "the report figures"):
            return
        if self._dock_rescore_last is None:
            messagebox.showwarning(
                "No rescore yet",
                "Rescore a table first -- the report needs the explainable "
                "leaderboard of the last rescore.",
            )
            return
        want_pdf = bool(self._dock_pdf_var.get())
        if want_pdf and not fpdf_available():
            messagebox.showwarning(
                "PDF needs fpdf",
                "The multi-page PDF document needs fpdf -- install it "
                "with:  pip install 'pharmaml[reports]'\n"
                "(the HTML report works without it -- untick the box to "
                "continue).",
            )
            return
        if filedialog is None:  # pragma: no cover - headless fallback
            return
        target = filedialog.askdirectory(title="Choose the report folder")
        if not target:
            return
        rescored, columns, weights, higher_is_better, source_label = self._dock_rescore_last
        directions = higher_is_better or {}

        def work() -> Any:
            from pharmaml.exceptions import DataValidationError
            from pharmaml.viz import (
                plot_consensus_ranking,
                plot_energy_distribution,
                save_visual_bundle,
            )

            figures: dict[str, Any] = {"consensus_ranking": plot_consensus_ranking(rescored)}
            try:
                # scan-shaped tables also carry the energy landscape; a
                # consensus-only table simply skips it (the CLI's skip
                # pattern, byte for byte).
                figures["energy_distribution"] = plot_energy_distribution(rescored)
            except DataValidationError:
                pass
            recipe = ", ".join(
                f"{column} ("
                + (
                    "higher"
                    if directions.get(column, not column.endswith(("energy", "affinity")))
                    else "lower"
                )
                + "=better"
                + (f", weight {weight:g}" if weights else "")
                + ")"
                for column, weight in zip(columns, weights or [1.0] * len(columns))
            )
            return save_visual_bundle(
                figures,
                tables={"consensus_breakdown": rescored},
                out_dir=target,
                title=(f"playground docking rescore — {len(columns)} evidence column(s)"),
                subtitle=f"{recipe} — {source_label}",
                pdf_report=want_pdf,
            )

        def render(written: Any) -> None:
            names = [path.name for path in written]
            extra = " + report.pdf" if want_pdf else ""
            self._job_label.configure(text=f"report saved · {target} ({len(written)} files{extra})")
            messagebox.showinfo(
                "Report saved",
                f"{len(written)} files written to {target}:\n"
                + "\n".join(names[:8])
                + ("\n…" if len(names) > 8 else ""),
            )

        self._start_job("writing the report bundle", work, render)

    # -- campaign runner card -------------------------------------------- #
    def _dock_choose_campaign_root(self) -> None:
        title = (
            "Choose the AutoDock4 campaign root"
            if self._dock_engine_combo.get() != "AutoDock4 single folder"
            else "Choose the ONE ligand folder (r.gpf / r.dpf)"
        )
        path = filedialog.askdirectory(title=title)
        if path:
            self._dock_campaign_root = Path(path)
            self._dock_refresh_campaign_info()

    def _dock_refresh_campaign_info(self) -> None:
        """The folder picker's label, engine-aware (100x-120).

        Campaign mode names the root's sub-folders; single-folder mode
        names the one folder ``run_autodock4`` will drive.
        """
        root = self._dock_campaign_root
        if self._dock_engine_combo.get() == "AutoDock4 single folder":
            text = (
                f"ligand folder: {root}"
                if root is not None
                else "no ligand folder chosen — pick the ONE folder holding r.gpf / r.dpf"
            )
        else:
            text = f"campaign root: {root}" if root is not None else "no campaign root chosen"
        try:
            self._dock_campaign_info.configure(text=text)
        except tk.TclError:  # pragma: no cover - label not built yet
            pass

    def _dock_open_vina_receptor(self) -> None:
        path = filedialog.askopenfilename(
            title="Open the receptor PDBQT",
            filetypes=[("PDBQT receptor", "*.pdbqt"), ("All files", "*.*")],
        )
        if path:
            self._dock_vina_receptor = Path(path)
            self._dock_refresh_vina_info()

    def _dock_open_vina_ligand(self) -> None:
        path = filedialog.askopenfilename(
            title="Open the ligand PDBQT",
            filetypes=[("PDBQT ligand", "*.pdbqt"), ("All files", "*.*")],
        )
        if path:
            self._dock_vina_ligand = Path(path)
            self._dock_refresh_vina_info()

    def _dock_refresh_vina_info(self) -> None:
        receptor = self._dock_vina_receptor.name if self._dock_vina_receptor else "—"
        ligand = self._dock_vina_ligand.name if self._dock_vina_ligand else "—"
        self._dock_vina_info.configure(text=f"receptor {receptor} · ligand {ligand}")

    def _dock_missing_engine_dialog(self, engine: str) -> None:
        binaries = ", ".join(docking_engine_binaries(engine))
        if engine in ("AutoDock4 campaign", "AutoDock4 single folder", "autodock4"):
            hint = (
                f"AutoDock4 docking needs the {binaries} binaries on "
                "PATH (Scripps AutoDock Tools, or conda-forge):\n\n"
                "    conda install -c conda-forge autodock\n\n"
                "Install them, reopen this terminal, then run again."
            )
        else:
            hint = (
                f"Vina docking needs the {binaries} binary on PATH (Scripps "
                "AutoDock Vina, or conda-forge):\n\n"
                "    conda install -c conda-forge vina\n\n"
                "Install it, reopen this terminal, then run again."
            )
        messagebox.showinfo("Docking engine not installed", hint)

    # -- audit / vina-batch / single-pdbqt cards (100x-110) -------------- #
    def _dock_audit_pick_gpf(self) -> None:
        path = filedialog.askopenfilename(
            title="Open the GPF file",
            filetypes=[("AutoDock grid parameter file", "*.gpf"), ("All files", "*.*")],
        )
        if not path:
            return
        self._dock_audit_gpf = Path(path)
        self._dock_audit_info.configure(
            text=f"GPF: {path}"
            + (f"\nfolder: {self._dock_audit_folder}" if self._dock_audit_folder else "")
        )

    def _dock_audit_pick_folder(self) -> None:
        path = filedialog.askdirectory(title="Pick the campaign folder")
        if not path:
            return
        self._dock_audit_folder = Path(path)
        self._dock_audit_info.configure(
            text=f"folder: {path}"
            + (f"\nGPF: {self._dock_audit_gpf}" if self._dock_audit_gpf else "")
        )

    def _dock_audit_run(self) -> None:
        """Run the selected audit (GPF params / scans / completion)."""
        if not self._require_pharmaml() or not self._require("pandas", "the docking audit"):
            return
        mode = self._dock_audit_mode.get()

        if mode.startswith("GPF"):
            if self._dock_audit_gpf is None:
                messagebox.showwarning("No GPF", "Pick a GPF file first.")
                return
            gpf_path = self._dock_audit_gpf

            def work() -> Any:
                from pharmaml.docking import read_gpf

                params = read_gpf(gpf_path)
                rows = [
                    ("ligand_types", " ".join(params["ligand_types"])),
                    ("receptor_types", " ".join(params["receptor_types"])),
                    ("npts", " ".join(str(n) for n in params["npts"])),
                    ("spacing", str(params["spacing"])),
                    (
                        "gridcenter",
                        (
                            " ".join(f"{v:g}" for v in params["gridcenter"])
                            if params["gridcenter"] is not None
                            else "absent"
                        ),
                    ),
                    ("receptor", str(params["receptor"])),
                    ("maps", " ".join(params["maps"])),
                    ("smooth", str(params["smooth"])),
                    ("dielectric", str(params["dielectric"])),
                ]
                return _frame_from_records(("parameter", "value"), rows)

            def render(frame: Any) -> None:
                self._dock_audit_frame = frame
                tree = self._dock_audit_tree
                tree.delete(*tree.get_children())
                tree["columns"] = ("parameter", "value")
                for column, width in (("parameter", 120), ("value", 220)):
                    tree.heading(column, text=column)
                    tree.column(column, width=width, stretch=(column == "value"))
                for _, row in frame.iterrows():
                    tree.insert(
                        "",
                        "end",
                        values=(str(row["parameter"]), _cell_text(row["value"], limit=48)),
                    )
                self._dock_audit_summary.configure(
                    text=f"{gpf_path.name} parsed ({len(frame)} parameters)", style="Field.TLabel"
                )

            self._start_job(f"reading {gpf_path.name}", work, render)
            return

        if self._dock_audit_folder is None:
            messagebox.showwarning("No folder", "Pick the campaign folder for the scan modes.")
            return
        folder = self._dock_audit_folder

        if mode.startswith("folder: ligand_types"):

            def work() -> Any:
                from pharmaml.docking import scan_gpf_ligand_types

                return scan_gpf_ligand_types(folder)

            def render(frame: Any) -> None:
                self._dock_audit_frame = frame
                self._fill_dynamic_tree(
                    self._dock_audit_tree, frame, widths={"folder": 120, "ligand_types": 200}
                )
                found = (
                    int(frame["ligand_types"].astype(str).ne("not found").sum())
                    if len(frame)
                    else 0
                )
                self._dock_audit_summary.configure(
                    text=(f"{len(frame)} sub-folder(s) · {found} with a parsed r.gpf"),
                    style="Field.TLabel",
                )

            self._start_job("scanning ligand_types", work, render)
            return

        if mode.startswith("folder: torsion"):

            def work() -> Any:
                from pharmaml.docking import scan_torsion_consistency

                return scan_torsion_consistency(folder)

            def render(frame: Any) -> None:
                self._dock_audit_frame = frame
                self._fill_dynamic_tree(self._dock_audit_tree, frame, widths={"ligand": 200})
                ok = int((frame["status"] == "OK").sum()) if len(frame) else 0
                self._dock_audit_summary.configure(
                    text=(
                        f"{len(frame)} ligand(s) audited · {ok} "
                        f"consistent · {len(frame) - ok} mismatch"
                    ),
                    style="Field.TLabel",
                )

            self._start_job("auditing torsion consistency", work, render)
            return

        # completion check
        log_name = self._dock_audit_log.get().strip() or "r.dlg"

        def work() -> Any:
            from pharmaml.docking import check_docking_completion

            return check_docking_completion(folder, log_name=log_name)

        def render(frame: Any) -> None:
            self._dock_audit_frame = frame
            self._fill_dynamic_tree(
                self._dock_audit_tree, frame, widths={"folder": 200, "status": 110}
            )
            ok = int((frame["status"] == "OK").sum()) if len(frame) else 0
            self._dock_audit_summary.configure(
                text=(
                    f"{len(frame)} sub-folder(s) · {ok} OK · "
                    f"{len(frame) - ok} incomplete / missing "
                    f"'{log_name}'"
                ),
                style="Field.TLabel",
            )

        self._start_job("checking completion", work, render)

    def _dock_audit_save(self) -> None:
        frame = getattr(self, "_dock_audit_frame", None)
        if frame is None:
            messagebox.showinfo("Nothing to save", "Run an audit first.")
            return
        self._save_frame_dialog(frame, "Save the audit table", "audit.csv")

    def _dock_vbatch_pick_conf(self) -> None:
        path = filedialog.askopenfilename(
            title="Open the Vina config",
            filetypes=[("Vina config", "*.conf *.txt"), ("All files", "*.*")],
        )
        if not path:
            return
        self._dock_vbatch_conf = Path(path)
        self._dock_vbatch_refresh_info()

    def _dock_vbatch_pick_ligands(self) -> None:
        path = filedialog.askdirectory(title="Pick the ligand tree")
        if path:
            self._dock_vbatch_ligands = Path(path)
            self._dock_vbatch_refresh_info()

    def _dock_vbatch_pick_out(self) -> None:
        path = filedialog.askdirectory(title="Pick the output folder")
        if path:
            self._dock_vbatch_out = Path(path)
            self._dock_vbatch_refresh_info()

    def _dock_vbatch_refresh_info(self) -> None:
        conf = self._dock_vbatch_conf.name if self._dock_vbatch_conf else "—"
        lig = self._dock_vbatch_ligands.name if self._dock_vbatch_ligands else "—"
        out = self._dock_vbatch_out.name if self._dock_vbatch_out else "—"
        self._dock_vbatch_info.configure(text=f"config: {conf}\nligands: {lig}\noutput: {out}")

    def _dock_vbatch_parse(self) -> None:
        """Parse the picked Vina config and show it (100x-120).

        ``parse_vina_config`` finally has its GUI surface: every
        key\u2192value pair of the picked config is dumped into the info
        label, and the centre / size / exhaustiveness keys are copied
        into the Campaign runner's single-ligand form so a re-run of
        one ligand needs zero retyping.
        """
        if not self._require_pharmaml():
            return
        if self._dock_vbatch_conf is None:
            messagebox.showwarning("No config picked", "Pick the Vina config first.")
            return
        try:
            from pharmaml.docking import parse_vina_config

            parsed = parse_vina_config(self._dock_vbatch_conf)
        except Exception as exc:  # noqa: BLE001
            self._show_error("Could not parse the config", exc)
            return
        pairs = [f"{key} = {value}" for key, value in parsed.items()]
        shown = "\n".join(pairs[:10]) + (
            f"\n… (+{len(pairs) - 10} more)" if len(pairs) > 10 else ""
        )
        self._dock_vbatch_info.configure(
            text=f"config: {self._dock_vbatch_conf.name} — parsed {len(parsed)} keys\n{shown}"
        )
        # convenience: copy the box into the single-run form
        filled: list[str] = []
        try:
            center = (parsed.get("center_x"), parsed.get("center_y"), parsed.get("center_z"))
            size = (parsed.get("size_x"), parsed.get("size_y"), parsed.get("size_z"))
            if all(part is not None for part in center):
                self._dock_center_entry.delete(0, "end")
                self._dock_center_entry.insert(0, " ".join(center))
                filled.append("centre")
            if all(part is not None for part in size):
                self._dock_size_entry.delete(0, "end")
                self._dock_size_entry.insert(0, " ".join(size))
                filled.append("size")
            if parsed.get("exhaustiveness") is not None:
                self._dock_exhaust_entry.delete(0, "end")
                self._dock_exhaust_entry.insert(0, str(parsed["exhaustiveness"]))
                filled.append("exhaustiveness")
        except tk.TclError:  # pragma: no cover - form not built
            filled.clear()
        if filled:
            self._dock_vbatch_summary.configure(
                text=f"copied {' · '.join(filled)} into the single-ligand form",
                style="Field.TLabel",
            )

    def _dock_vbatch_run(self) -> None:
        """Dock every PDBQT under the ligand tree with one Vina config."""
        if not self._require_pharmaml():
            return
        if (
            self._dock_vbatch_conf is None
            or self._dock_vbatch_ligands is None
            or self._dock_vbatch_out is None
        ):
            messagebox.showwarning(
                "Missing paths",
                "Pick the Vina config, the ligand folder and the output folder first.",
            )
            return
        if shutil.which("vina") is None:
            self._dock_missing_engine_dialog("vina")
            return
        try:
            workers = parse_int(self._dock_vbatch_workers.get(), "workers", minimum=1, maximum=64)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return
        conf, ligands, out = (
            self._dock_vbatch_conf,
            self._dock_vbatch_ligands,
            self._dock_vbatch_out,
        )

        def work() -> Any:
            from pharmaml.docking import run_vina_batch

            return run_vina_batch(conf, ligands, out_dir=out, max_parallel=workers)

        def render(results: Any) -> None:
            rows = [
                (
                    Path(r.directory).name,
                    "OK" if r.ok else "FAILED",
                    f"{r.seconds:.1f}s",
                    _cell_text(Path(r.log_file).name if r.log_file else (r.error or ""), limit=28),
                )
                for r in results
            ]
            frame = _frame_from_records(("ligand", "status", "time", "log / error"), rows)
            self._dock_vbatch_frame = frame
            self._fill_dynamic_tree(
                self._dock_vbatch_tree,
                frame,
                widths={"ligand": 150, "status": 70, "time": 60, "log / error": 150},
            )
            ok = sum(1 for r in results if r.ok)
            self._dock_vbatch_summary.configure(
                text=(f"{ok}/{len(results)} ligand(s) docked into {out.name}"), style="Field.TLabel"
            )

        self._start_job(f"vina batch ({workers} workers)", work, render)

    def _dock_smi_pick_out(self) -> None:
        path = filedialog.askdirectory(title="Pick the PDBQT output folder")
        if path:
            self._dock_smi_out = Path(path)
            self._dock_smi_info.configure(text=f"output: {path}")

    def _dock_smi_run(self) -> None:
        """Prepare one SMILES as a docking-ready PDBQT ligand."""
        if not self._require_pharmaml() or not self._require("rdkit", "ligand preparation"):
            return
        smiles = self._dock_smi_entry.get().strip()
        if not smiles:
            messagebox.showwarning("Empty SMILES", "Type a SMILES first.")
            return
        if self._dock_smi_out is None:
            messagebox.showwarning("No output folder", "Pick the output folder first.")
            return
        name = self._dock_smi_name.get().strip() or None
        out_dir = self._dock_smi_out

        def work() -> Any:
            from pharmaml.docking import smiles_to_pdbqt

            return smiles_to_pdbqt(smiles, out_dir, name=name)

        def render(written: Any) -> None:
            size_kb = Path(written).stat().st_size / 1024 if Path(written).exists() else 0.0
            self._dock_smi_summary.configure(
                text=(f"written {Path(written).name} ({size_kb:.1f} KB) in {out_dir.name}"),
                style="Field.TLabel",
            )

        self._start_job("preparing the ligand", work, render)

    def _dock_run(self) -> None:
        if not self._require_pharmaml():
            return
        engine = self._dock_engine_combo.get()
        binaries = docking_engine_binaries(engine)
        missing = [name for name in binaries if shutil.which(name) is None]
        if missing:
            # pre-empt pharmaml's own RuntimeError with a friendly hint
            self._dock_missing_engine_dialog(engine)
            return

        if engine == "AutoDock4 campaign":
            if self._dock_campaign_root is None:
                messagebox.showwarning(
                    "No campaign root",
                    "Choose the campaign root (the folder of prepared ligand "
                    "sub-directories) first.",
                )
                return
            try:
                workers = parse_int(
                    self._dock_workers_entry.get(), "workers", minimum=1, maximum=64
                )
            except ValueError as exc:
                messagebox.showerror("Input", str(exc))
                return
            root = self._dock_campaign_root

            def work() -> Any:
                from pharmaml.docking import batch_run_directories

                return batch_run_directories(root, workers=workers)

            def render(results: Any) -> None:
                ok_runs = sum(1 for result in results if result.ok)
                failed_runs = len(results) - ok_runs
                total_seconds = sum(result.seconds for result in results)
                self._dock_run_summary.configure(
                    text=(
                        f"{len(results)} folders docked · {ok_runs} ok · "
                        f"{failed_runs} failed · {total_seconds:.0f} s total "
                        f"— {root.name}"
                    ),
                    style="Field.TLabel",
                )

            self._start_job(f"AutoDock4 campaign ({root.name})", work, render)
            return

        # -- AutoDock4 single folder (100x-120) -------------------------- #
        if engine == "AutoDock4 single folder":
            if self._dock_campaign_root is None:
                messagebox.showwarning(
                    "No ligand folder",
                    "Choose the ONE ligand folder (holding r.gpf / r.dpf) "
                    "first -- the same picker as the campaign root.",
                )
                return
            skip_existing = bool(self._dock_skip_existing_var.get())
            root = self._dock_campaign_root

            def work_single() -> Any:
                from pharmaml.docking import run_autodock4

                return run_autodock4(root, skip_existing=skip_existing)

            def render_single(result: Any) -> None:
                state = "ok" if result.ok else f"FAILED — {result.error}"
                dlg_note = f" · dlg {result.dlg.name}" if result.dlg else ""
                cluster_note = ""
                if result.dlg is not None:
                    # 100x-121: the parsed DLG cluster summary rides the
                    # verdict line (parse_dlg_summary: best + most populated
                    # cluster + extremes, the columns the rar exported to
                    # Excel).
                    try:
                        from pharmaml.docking import parse_dlg_summary

                        summary = parse_dlg_summary(result.dlg)
                        cluster_note = (
                            f" · {summary['n_clusters']} clusters · "
                            f"top {summary['top_lowest_energy']:.2f} "
                            f"(n={summary['top_num_in_cluster']}) · "
                            f"best-populated {summary['best_lowest_energy']:.2f} "
                            f"(n={summary['best_num_in_cluster']})"
                        )
                    except Exception:  # noqa: BLE001 - best effort note
                        cluster_note = ""
                self._dock_run_summary.configure(
                    text=(
                        f"autogrid4+autodock4 {state} · "
                        f"{result.seconds:.1f} s{dlg_note}{cluster_note}"
                        f" — {root.name}"
                    ),
                    style="Field.TLabel",
                )

            self._start_job(f"AutoDock4 single ({root.name})", work_single, render_single)
            return

        # -- Vina single ligand ------------------------------------------ #
        if self._dock_vina_receptor is None or self._dock_vina_ligand is None:
            messagebox.showwarning(
                "Missing inputs", "Open both the receptor and ligand PDBQT first."
            )
            return
        try:
            center = parse_float_triple(self._dock_center_entry.get(), "centre")
            size = parse_float_triple(self._dock_size_entry.get(), "size")
            exhaustiveness = parse_int(
                self._dock_exhaust_entry.get(), "exhaustiveness", minimum=1, maximum=256
            )
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return
        receptor, ligand = self._dock_vina_receptor, self._dock_vina_ligand
        out = ligand.parent / "out.pdbqt"

        def work() -> Any:
            from pharmaml.docking import run_vina

            return run_vina(
                receptor, ligand, out=out, center=center, size=size, exhaustiveness=exhaustiveness
            )

        def render(result: Any) -> None:
            state = "ok" if result.ok else f"FAILED — {result.error}"
            self._dock_run_summary.configure(
                text=(f"Vina run {state} · {result.seconds:.1f} s · output {out}"),
                style="Field.TLabel",
            )

        self._start_job(f"Vina run ({ligand.name})", work, render)

    # -- SMILES array docking card ------------------------------------- #
    def _dock_smiles_example(self) -> None:
        """Refill the array box with the bundled trivial-name drugs."""
        self._dock_smiles_text.delete("1.0", "end")
        self._dock_smiles_text.insert("1.0", "\n".join(_DOCK_SMILES_DEFAULTS))
        self._dock_smiles_summary.configure(
            text=f"{len(_DOCK_SMILES_DEFAULTS)} example SMILES loaded"
        )

    def _dock_smiles_open_receptor(self) -> None:
        path = filedialog.askopenfilename(
            title="Open the receptor PDBQT",
            filetypes=[("PDBQT receptor", "*.pdbqt"), ("All files", "*.*")],
        )
        if not path:
            return
        self._dock_smiles_receptor = Path(path)
        self._dock_smiles_receptor_info.configure(text=path)

    def _dock_smiles_choose_out(self) -> None:
        path = filedialog.askdirectory(title="Choose the SMILES-array campaign output folder")
        if not path:
            return
        self._dock_smiles_out = Path(path)
        self._dock_smiles_out_info.configure(text=f"campaign output: {path}")

    def _dock_smiles_receptor_or_none(self) -> Path | None:
        """The array card's receptor: its own pick, or the prepared one."""
        if self._dock_smiles_receptor is not None:
            return self._dock_smiles_receptor
        return self._dock_receptor_path or self._dock_vina_receptor

    def _dock_smiles_run(self) -> None:
        """Dock the whole pasted SMILES array with the chosen engine."""
        if (
            not self._require_pharmaml()
            or not self._require("pandas", "SMILES docking")
            or not self._require("rdkit", "SMILES docking")
        ):
            return
        smiles = parse_smiles_lines(self._dock_smiles_text.get("1.0", "end"))
        if not smiles:
            messagebox.showwarning("Empty array", "Paste at least one SMILES (one per line).")
            return
        receptor = self._dock_smiles_receptor_or_none()
        if receptor is None:
            messagebox.showwarning(
                "No receptor",
                "Pick a prepared receptor PDBQT first (or prepare one in the receptor card above).",
            )
            return
        if self._dock_smiles_out is None:
            messagebox.showwarning(
                "No output folder",
                "Choose the campaign output folder first -- the prepared "
                "ligands and engine outputs land there.",
            )
            return
        engine = self._dock_smiles_engine_combo.get()
        binaries = docking_engine_binaries(engine)
        missing = [name for name in binaries if shutil.which(name) is None]
        if missing:
            self._dock_missing_engine_dialog(engine)
            return
        try:
            center = parse_float_triple(self._dock_smiles_center_entry.get(), "centre")
            size = parse_float_triple(self._dock_smiles_size_entry.get(), "size")
            exhaustiveness = parse_int(
                self._dock_smiles_exhaust_entry.get(), "exhaustiveness", minimum=1, maximum=256
            )
            workers = parse_int(
                self._dock_smiles_workers_entry.get(), "workers", minimum=1, maximum=64
            )
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return
        out_root = self._dock_smiles_out
        receptor_path = receptor

        def work(report: Any) -> Any:
            from pharmaml.docking import dock_smiles_array

            return dock_smiles_array(
                smiles,
                receptor_path,
                out_root,
                engine=engine,
                center=center,
                size=size,
                exhaustiveness=exhaustiveness,
                workers=workers,
                progress=report,
            )

        def render(frame: Any) -> None:
            self._dock_smiles_last = frame
            self._dock_results_frame = frame
            self._dock_results_source = "smiles"
            tree = self._dock_results_tree
            tree.delete(*tree.get_children())
            columns = [str(column) for column in frame.columns]
            tree["columns"] = columns
            for column in columns:
                width = 210 if column in ("smiles", "error") else 96
                tree.heading(column, text=column)
                tree.column(
                    column, width=width, minwidth=56, stretch=(column in ("smiles", "error"))
                )
            for row in frame.to_dict("records"):
                values = [
                    _cell_text(
                        None
                        if (isinstance(row[column], float) and math.isnan(row[column]))
                        else row[column],
                        limit=52,
                    )
                    for column in columns
                ]
                tree.insert("", "end", values=values)
            ok = int(frame["ok"].sum())
            best = frame.loc[frame["ok"], "best_score"]
            best_text = f" · best {best.min():.2f} kcal/mol" if ok else ""
            self._dock_results_info.configure(
                text=(
                    f"{len(frame)} SMILES docked ({engine}) · {ok} ok · "
                    f"{len(frame) - ok} failed{best_text} — {out_root.name}"
                ),
                style="Field.TLabel",
            )
            self._dock_smiles_summary.configure(
                text=(f"{ok}/{len(frame)} docked{best_text} · folders under {out_root.name}"),
                style="Field.TLabel",
            )
            self._dock_rescore_prefill()

        self._start_job(
            f"docking {len(smiles)} SMILES ({engine}, {workers} worker(s))",
            work,
            render,
        )

    # ------------------------------------------------------------------ #
    # Data & ML tab
    # ------------------------------------------------------------------ #
    def _build_ml_tab(self) -> None:
        page = self._new_page("Data & ML")
        self._ml_page = page

        data = make_card(
            page.grid,
            "Dataset",
            span=2,
            row=0,
            column=0,
            subtitle="Any CSV the toolkit's read_table can sniff, or a bundled example.",
        )
        open_btn = self._action_button(data, "Open CSV…", self._ml_open_csv)
        open_btn.grid(row=0, column=0, sticky="w")
        example_files = [
            name
            for name in (
                "qsar_regression.csv",
                "qsar_classification.csv",
                "qsar_multiclass.csv",
                "cellline_screen.csv",
                "pk_profile.csv",
            )
            if (EXAMPLES_DIR / name).is_file()
        ]
        self._example_combo = ttk.Combobox(data, state="readonly", width=26, values=example_files)
        if example_files:
            self._example_combo.set(example_files[0])
        self._example_combo.grid(row=0, column=1, sticky="w", padx=(12, 0))
        load_btn = self._action_button(data, "Load example", self._ml_load_example)
        load_btn.grid(row=0, column=2, sticky="w", padx=(12, 0))
        self._ml_info = ttk.Label(data, text="no dataset loaded", style="CardMuted.TLabel")
        self._ml_info.grid(row=1, column=0, columnspan=3, sticky="w", pady=(6, 0))
        # non-numerical data remover (100x-110): the rar's own script as
        # one button -- drop every non-numeric column except the target
        # and the keep list, with the dropped names reported, then export.
        clean_row = ttk.Frame(data, style="Card.TFrame")
        clean_row.grid(row=2, column=0, columnspan=3, sticky="w", pady=(6, 0))
        self._ml_keep_entry = ttk.Entry(clean_row, width=30)
        self._ml_keep_entry.insert(0, "SMILES,name,Ligand")
        Tooltip(
            self._ml_keep_entry,
            "Comma-separated metadata columns that survive the numeric "
            "cleanup (case-insensitive; missing ones are simply "
            "ignored) -- the SMILES column belongs in a QSAR table "
            "even though it is not a feature.",
        )
        self._ml_keep_entry.pack(side="left")
        clean_btn = self._action_button(
            clean_row,
            "Drop non-numeric columns",
            self._ml_clean_frame,
            tooltip="The rar's 'Non-numerical data remover.py': every "
            "non-numeric column except the target and the keep "
            "list is dropped (names reported in the status line); "
            "'Save cleaned CSV…' then writes the numeric frame.",
        )
        clean_btn.pack(side="left", padx=(10, 0))
        clean_save_btn = self._action_button(
            clean_row,
            "Save cleaned CSV…",
            self._ml_clean_save,
            tooltip="The last cleaned frame (train immediately, or keep "
            "it as the numeric dataset).",
        )
        clean_save_btn.pack(side="left", padx=(10, 0))
        self._ml_cleaned_frame: Any = None

        preview = make_card(page.grid, "Preview (first 12 rows)", span=2, row=1, column=0)
        tree_frame = ttk.Frame(preview, style="Card.TFrame")
        grid_append(preview, tree_frame, sticky="nsew", weight=True)
        self._preview_tree = ttk.Treeview(tree_frame, show="headings", height=8)
        preview_bar_x = ttk.Scrollbar(
            tree_frame, orient="horizontal", command=self._preview_tree.xview
        )
        preview_bar_y = ttk.Scrollbar(
            tree_frame, orient="vertical", command=self._preview_tree.yview
        )
        self._preview_tree.configure(
            xscrollcommand=preview_bar_x.set, yscrollcommand=preview_bar_y.set
        )
        self._preview_tree.pack(side="left", fill="both", expand=True)
        preview_bar_y.pack(side="right", fill="y")
        preview_bar_x.pack(side="bottom", fill="x")

        config = make_card(
            page.grid,
            "Train a model",
            span=2,
            row=2,
            column=0,
            subtitle="Features = the numeric columns except the target "
            "(helpers like SMILES ids are dropped automatically).",
        )
        self._target_combo = ttk.Combobox(config, state="readonly", width=26)
        form_row(config, "target column", self._target_combo)
        self._task_combo = ttk.Combobox(
            config, state="readonly", width=26, values=("auto", "regression", "classification")
        )
        self._task_combo.set("auto")
        form_row(config, "task", self._task_combo)
        self._model_combo = ttk.Combobox(config, state="readonly", width=26, values=("auto",))
        self._model_combo.set("auto")
        form_row(config, "model", self._model_combo)
        # manual model settings (100x-106): the CV fold count the
        # Train button threads into train_model (tune on) and the
        # leaderboard button's own 3-fold convention stays untouched.
        self._ml_cv_spin = ttk.Spinbox(config, from_=2, to=10, increment=1, width=10)
        self._ml_cv_spin.set("5")
        Tooltip(
            self._ml_cv_spin,
            "Cross-validation folds for Train & evaluate with the tune "
            "tick on (and the CV columns of the saved report). The "
            "leaderboard button keeps its own 3-fold convention.",
        )
        form_row(config, "cv folds", self._ml_cv_spin)
        self._tune_var = tk.BooleanVar(value=False)
        tune_check = ttk.Checkbutton(
            config, text="tune hyperparameters (grid search, slower)", variable=self._tune_var
        )
        form_row(config, "options", tune_check)
        buttons = ttk.Frame(config, style="Card.TFrame")
        buttons.grid(row=config.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(8, 0))
        train_btn = self._action_button(
            buttons,
            "Train & evaluate",
            self._ml_train,
            primary=True,
            tooltip="80/20 split, the toolkit's own preprocessing "
            "pipeline, then held-out metrics + figure.",
        )
        train_btn.pack(side="left")
        compare_btn = self._action_button(
            buttons,
            "Compare models (3-fold CV)",
            self._ml_compare,
            tooltip="Cross-validated leaderboard over the available registry.",
        )
        compare_btn.pack(side="left", padx=(10, 0))
        self._ml_pdf_var = tk.BooleanVar(value=False)
        pdf_check = ttk.Checkbutton(buttons, text="include report.pdf", variable=self._ml_pdf_var)
        Tooltip(
            pdf_check, "Also write the multi-page PDF document -- needs fpdf (pharmaml[reports])"
        )
        pdf_check.pack(side="left", padx=(10, 0))
        report_btn = self._action_button(
            buttons,
            "Save report…",
            self._ml_save_report,
            tooltip="Write the last training run as the one-click visual "
            "bundle -- report.html + figures + tables (+ report.pdf "
            "when ticked), the CLI --plots/--pdf-report story.",
        )
        report_btn.pack(side="left", padx=(10, 0))
        check_btn = self._action_button(
            buttons,
            "Check CSV…",
            self._ml_check_csv,
            tooltip="Audit any CSV against the last trained model before "
            "predicting -- missing features, extra columns, "
            "reordering and version drift, all named (the ml check "
            "story, mouse edition; the training target is dropped "
            "automatically when present).",
        )
        check_btn.pack(side="left", padx=(10, 0))

        # picking a concrete task re-lists the models for it, and any
        # model selection rebuilds the manual-hyperparameter card
        # (100x-106): programmatic set() never fires <<ComboboxSelected>>,
        # so every code path that moves these combos calls the refresh
        # itself (load, apply-best, restore, reset).
        self._task_combo.bind("<<ComboboxSelected>>", self._ml_task_changed)
        self._model_combo.bind(
            "<<ComboboxSelected>>",
            lambda _event: self._ml_refresh_hyperparam_panel(),
        )

        manual = make_card(
            page.grid,
            "Manual hyperparameters",
            span=2,
            row=3,
            column=0,
            subtitle="The selected model's registry knobs, editable by hand "
            "— each field starts at the estimator's own default; "
            "blank keeps that default. Pinned keys are excluded "
            "from the grid search, so tick 'tune' to search only "
            "the slots you leave blank. Per-model values persist "
            "with the session.",
        )
        self._ml_params_var = tk.StringVar(value="{}")
        self._ml_params_host = ttk.Frame(manual, style="Card.TFrame")
        grid_append(manual, self._ml_params_host, sticky="ew")
        self._ml_param_entries: dict[str, ttk.Entry] = {}
        self._ml_params_status = ttk.Label(
            manual,
            text="pick a model to edit its hyperparameters",
            style="CardMuted.TLabel",
            wraplength=620,
            justify="left",
        )
        grid_append(manual, self._ml_params_status, sticky="w", pady=(6, 0))
        manual_buttons = ttk.Frame(manual, style="Card.TFrame")
        grid_append(manual, manual_buttons, sticky="w", pady=(8, 0))
        reset_params_btn = self._action_button(
            manual_buttons,
            "Reset to defaults",
            self._ml_params_reset,
            tooltip="Clear every field back to the estimator's own "
            "defaults (the blank state — nothing is pinned, the "
            "grid search gets all its slots back).",
        )
        reset_params_btn.pack(side="left")

        tuner = make_card(
            page.grid,
            "Hyperparameter search",
            span=2,
            row=4,
            column=0,
            subtitle="The ml tune story, mouse edition: a keras-tuner-style "
            "search over a whole estimator family (not the "
            "per-model grid search above). RandomSearch samples "
            "full-budget trials; Hyperband starts brackets of "
            "configs at a fraction of the resource budget (ann's "
            "max_iter, dnn's epochs -- the ladder is the family's "
            "own declared grid) and keeps only the top 1/η per "
            "rung. Every trial is scored by mean CV on the SAME "
            "shuffled folds; the family's defaults are scored too "
            "-- the number the search has to beat; the winner is "
            "refit and scored on the held-out 20%.",
        )
        self._tune_estimator_combo = ttk.Combobox(
            tuner, state="readonly", width=26, values=_TUNE_ESTIMATORS
        )
        self._tune_estimator_combo.set("ann")
        Tooltip(
            self._tune_estimator_combo,
            "ann = the sklearn MLP hypermodel; dnn = the torch deep MLP "
            "(batchnorm searchable, needs torch); hsvr = the hierarchical "
            "SVR (regression only). The same families the CLI's "
            "ml tune --estimator accepts.",
        )
        form_row(tuner, "estimator", self._tune_estimator_combo)
        self._tune_searcher_combo = ttk.Combobox(
            tuner, state="readonly", width=26, values=_TUNE_SEARCHERS
        )
        self._tune_searcher_combo.set("random")
        Tooltip(
            self._tune_searcher_combo,
            "random = RandomSearch, every trial at the full budget "
            "(the trials spinbox decides how many); hyperband = "
            "successive halving over the family's resource slot -- "
            "brackets start many configs at a small budget and keep "
            "only the top 1/η per rung, so the trials spinbox is "
            "ignored (the brackets decide; ann and dnn only -- hsvr "
            "declares no resource slot). The same tokens the CLI's "
            "ml tune --searcher accepts.",
        )
        form_row(tuner, "searcher", self._tune_searcher_combo)
        self._tune_trials = ttk.Spinbox(tuner, from_=4, to=40, increment=1, width=10)
        self._tune_trials.set("8")
        Tooltip(
            self._tune_trials,
            "RandomSearch only: how many full-budget trials to draw. "
            "Hyperband ignores this -- its brackets fix the trial "
            "count from η and the resource ladder.",
        )
        form_row(tuner, "trials", self._tune_trials)
        self._tune_eta = ttk.Spinbox(tuner, from_=2, to=4, increment=1, width=10)
        self._tune_eta.set("3")
        Tooltip(
            self._tune_eta,
            "Hyperband only: the halving factor η -- every rung keeps "
            "the top ceil(n/η) configs and multiplies their budget by "
            "η. Bigger η = more brackets, more trials at tiny budgets; "
            "smaller η = fewer, deeper brackets. RandomSearch ignores "
            "this.",
        )
        form_row(tuner, "η (hyperband)", self._tune_eta)
        self._tune_cv = ttk.Spinbox(tuner, from_=2, to=5, increment=1, width=10)
        self._tune_cv.set("3")
        form_row(tuner, "cv folds", self._tune_cv)
        tune_buttons = ttk.Frame(tuner, style="Card.TFrame")
        grid_append(tuner, tune_buttons, sticky="w", pady=(8, 0))
        search_btn = self._action_button(
            tune_buttons,
            "Run search",
            self._ml_tune,
            tooltip="Search the chosen family's space -- RandomSearch "
            "samples full-budget trials, Hyperband halves the "
            "resource rung by rung; trials ranked by mean CV score "
            "on the leaderboard card below; the summary line "
            "carries best vs defaults (the gain) and the held-out "
            "verdict. Deterministic end-to-end (the same seed "
            "folds the same way twice).",
        )
        search_btn.pack(side="left")
        apply_btn = self._action_button(
            tune_buttons,
            "Apply best",
            self._ml_tune_apply,
            tooltip="Carry the winning configuration forward: ann/hsvr point "
            "the model combobox at the family; dnn prefills the whole "
            "Deep Learning tab (layers, dropout, learning rate, "
            "activation, batchnorm, epochs) and switches to it.",
        )
        apply_btn.pack(side="left", padx=(10, 0))
        save_trials_btn = self._action_button(
            tune_buttons,
            "Save trials CSV…",
            self._ml_tune_save_trials,
            tooltip="Write the full trials table (one row per trial: score, "
            "std, every hyperparameter) -- the CLI --out story.",
        )
        save_trials_btn.pack(side="left", padx=(10, 0))
        self._tune_summary = ttk.Label(
            tuner,
            text="no search yet — pick an estimator family and run it",
            style="CardMuted.TLabel",
            wraplength=620,
            justify="left",
        )
        grid_append(tuner, self._tune_summary, sticky="w", pady=(6, 0))

        results = make_card(page.grid, "Results", span=2, row=5, column=0)
        ml_result_buttons = ttk.Frame(results, style="Card.TFrame")
        grid_append(results, ml_result_buttons, sticky="w")
        calib_btn = self._action_button(
            ml_result_buttons,
            "Calibration curve",
            self._ml_plot_calibration,
            tooltip="The reliability diagram of the last trained "
            "CLASSIFIER (plot_calibration_curve): predicted "
            "probability vs observed frequency per bin -- the "
            "honest answer to 'can I trust p = 0.7?'.",
        )
        calib_btn.pack(side="left")
        self._calib_bins = ttk.Entry(ml_result_buttons, width=5)
        self._calib_bins.insert(0, "10")
        self._calib_bins.pack(side="left", padx=(8, 0))
        ttk.Label(ml_result_buttons, text="bins", style="CardMuted.TLabel").pack(
            side="left", padx=(2, 0)
        )
        # 100x-120: the learning-curve figure -- "should we assay more
        # compounds?" answered with a picture instead of a guess.
        curve_btn = self._action_button(
            ml_result_buttons,
            "Learning curve",
            self._ml_plot_learning_curve,
            tooltip="Train-set size vs CV score (plot_learning_curve): the "
            "honest answer to 'should we assay 500 more compounds?' "
            "-- a curve still climbing means yes, a plateau means "
            "the model has extracted what this chemistry can give.",
        )
        curve_btn.pack(side="left", padx=(10, 0))
        self._curve_cv = ttk.Entry(ml_result_buttons, width=4)
        self._curve_cv.insert(0, "5")
        self._curve_cv.pack(side="left", padx=(8, 0))
        ttk.Label(ml_result_buttons, text="folds", style="CardMuted.TLabel").pack(
            side="left", padx=(2, 0)
        )
        # 100x-128: the per-card export -- the parity, calibration or
        # learning-curve figure, whichever drew LAST on this card.
        save_ml_figure_btn = self._action_button(
            ml_result_buttons,
            "Save figure…",
            self._save_ml_figure,
            tooltip="Save the figure this card is currently showing -- the "
            "parity plot, calibration or learning curve, whichever "
            "drew last -- as PNG, SVG or PDF (unlike Ctrl+S, which "
            "saves the last figure drawn anywhere).",
        )
        save_ml_figure_btn.pack(side="left", padx=(10, 0))
        ml_result_note = ttk.Label(
            ml_result_buttons, text="", style="CardMuted.TLabel", wraplength=430, justify="left"
        )
        ml_result_note.pack(side="left", padx=(10, 0))
        self._ml_result_note = ml_result_note
        self._ml_metrics = ttk.Frame(results, style="Card.TFrame")
        grid_append(results, self._ml_metrics, sticky="ew")
        ttk.Label(
            self._ml_metrics, text="train a model to see metrics", style="CardMuted.TLabel"
        ).pack(anchor="w")
        self._ml_host = self._figure_host(results, height=330)

        board = make_card(
            page.grid,
            "Leaderboard",
            span=2,
            row=6,
            column=0,
            subtitle="Compare models fills it with the cross-validated "
            "registry ranking; a hyperparameter search fills it "
            "with the trial ranking, best first.",
        )
        self._board_status = ttk.Label(
            board,
            text="empty — run Compare models or a hyperparameter search",
            style="CardMuted.TLabel",
            wraplength=620,
            justify="left",
        )
        grid_append(board, self._board_status, sticky="w")
        board_frame = ttk.Frame(board, style="Card.TFrame")
        grid_append(board, board_frame, sticky="nsew", weight=True)
        self._board_tree = ttk.Treeview(board_frame, show="headings", height=6)
        board_bar = ttk.Scrollbar(board_frame, orient="vertical", command=self._board_tree.yview)
        self._board_tree.configure(yscrollcommand=board_bar.set)
        self._board_tree.pack(side="left", fill="both", expand=True)
        board_bar.pack(side="right", fill="y")
        board_buttons = ttk.Frame(board, style="Card.TFrame")
        grid_append(board, board_buttons, sticky="w", pady=(6, 0))
        board_plot_btn = self._action_button(
            board_buttons,
            "Plot leaderboard",
            self._ml_plot_leaderboard,
            tooltip="The leaderboard as horizontal bars "
            "(plot_model_comparison) -- the cross-validated score "
            "per model, error bars where the table carries them.",
        )
        board_plot_btn.pack(side="left")
        save_board_figure_btn = self._action_button(
            board_buttons,
            "Save figure…",
            self._save_board_figure,
            tooltip="Save the figure this card is currently showing -- the "
            "cross-validated leaderboard bars -- as PNG, SVG or PDF "
            "(unlike Ctrl+S, which saves the last figure drawn "
            "anywhere).",
        )
        save_board_figure_btn.pack(side="left", padx=(10, 0))
        self._board_host = self._figure_host(board, height=300)

        # -- ensemble builder (voting + stacking, members by hand) ---- #
        ensemble = make_card(
            page.grid,
            "Ensemble builder (voting & stacking)",
            span=2,
            row=7,
            column=0,
            subtitle="Combine several registry models into one ensemble: "
            "voting averages the members' predictions (soft = "
            "probability averaging, hard = majority vote; "
            "regression always averages), stacking trains a "
            "meta-learner on the members' cross-validated "
            "predictions. The same ensembles are registry models "
            "too (pick 'voting' / 'stacking' in the model "
            "combobox above for the default RF + SVM + KNN trio).",
        )
        ens_members = ttk.Frame(ensemble, style="Card.TFrame")
        grid_append(ensemble, ens_members, sticky="ew")
        self._ens_member_vars: dict[str, Any] = {}
        for index, (token, label) in enumerate(_ENSEMBLE_MEMBER_LABELS):
            member_var = tk.BooleanVar(value=token in _ENSEMBLE_DEFAULT_MEMBERS)
            self._ens_member_vars[token] = member_var
            member_check = ttk.Checkbutton(ens_members, text=label, variable=member_var)
            member_check.grid(row=index // 6, column=index % 6, sticky="w", padx=(0, 16), pady=2)
        ens_controls = ttk.Frame(ensemble, style="Card.TFrame")
        grid_append(ensemble, ens_controls, sticky="ew", pady=(6, 0))
        ens_controls.columnconfigure(1, weight=1)
        self._ens_kind_combo = ttk.Combobox(
            ens_controls, state="readonly", width=18, values=("voting", "stacking")
        )
        self._ens_kind_combo.set("voting")
        Tooltip(
            self._ens_kind_combo,
            "voting = averaged predictions (the Voting.py family); "
            "stacking = a meta-learner over the members' "
            "cross-validated predictions (the Stacking.py family).",
        )
        form_row(ens_controls, "kind", self._ens_kind_combo)
        self._ens_voting_combo = ttk.Combobox(
            ens_controls, state="readonly", width=18, values=("soft", "hard")
        )
        self._ens_voting_combo.set("soft")
        Tooltip(
            self._ens_voting_combo,
            "Classification only: soft averages class probabilities, "
            "hard takes the majority vote. Regression ignores this.",
        )
        form_row(ens_controls, "voting rule", self._ens_voting_combo)
        self._ens_meta_combo = ttk.Combobox(ens_controls, state="readonly", width=18)
        self._ens_meta_combo.set("auto")
        Tooltip(
            self._ens_meta_combo,
            "Stacking only: the level-1 blender -- 'auto' picks "
            "logistic_regression (classification) or ridge "
            "(regression).",
        )
        form_row(ens_controls, "meta model", self._ens_meta_combo)
        self._ens_meta_combo["values"] = ["auto"] + [
            token for token, _label in _ENSEMBLE_MEMBER_LABELS
        ]
        ens_buttons = ttk.Frame(ens_controls, style="Card.TFrame")
        ens_buttons.grid(
            row=ens_controls.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(8, 0)
        )
        ens_train_btn = self._action_button(
            ens_buttons,
            "Train ensemble",
            self._ens_train,
            primary=True,
            tooltip="Builds the ensemble from the ticked members with the "
            "chosen rule / meta-learner, fits it on the same 80/20 "
            "split as Train & evaluate, and renders the held-out "
            "metrics + figure in the Results card (Save report… "
            "and Save model bundle… then work on it too).",
        )
        ens_train_btn.pack(side="left")
        self._ens_summary = ttk.Label(
            ens_buttons, text="—", style="CardMuted.TLabel", wraplength=520, justify="left"
        )
        self._ens_summary.pack(side="left", padx=(10, 0))

        # -- model persistence (save trained bundles, reuse them) ----- #
        persist = make_card(
            page.grid,
            "Model persistence (save & reuse)",
            span=2,
            row=8,
            column=0,
            subtitle="One half saves the last trained model as a "
            "provenance-carrying bundle (joblib + metadata: "
            "feature order, hyperparameters, metrics, library "
            "versions, timestamp); the other half loads any "
            "bundle back, audits new data against its feature "
            "contract and predicts.",
        )
        persist.columnconfigure(0, weight=1)
        persist.columnconfigure(1, weight=1)
        save_side = ttk.Frame(persist, style="Card.TFrame")
        save_side.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        ttk.Label(save_side, text="Save the last trained model", style="CardTitle.TLabel").pack(
            anchor="w"
        )
        ttk.Label(
            save_side,
            text="writes <name>.joblib + a human-readable <name>.json sidecar",
            style="CardMuted.TLabel",
            wraplength=430,
            justify="left",
        ).pack(anchor="w", pady=(2, 0))
        save_bundle_btn = self._action_button(
            save_side,
            "Save model bundle…",
            self._ml_save_model_bundle,
            primary=True,
            tooltip="The ml save CLI story, mouse edition: the fitted "
            "estimator plus its provenance metadata (name, task, "
            "feature order, best hyperparameters, held-out "
            "metrics, pharmaml/sklearn/numpy versions, UTC "
            "timestamp) -- everything a model loaded two years "
            "later needs to know about itself.",
        )
        save_bundle_btn.pack(anchor="w", pady=(8, 0))
        self._ml_save_info = ttk.Label(
            save_side,
            text="no run yet — train a model (or an ensemble) first",
            style="CardMuted.TLabel",
            wraplength=430,
            justify="left",
        )
        self._ml_save_info.pack(anchor="w", pady=(4, 0))

        load_side = ttk.Frame(persist, style="Card.TFrame")
        load_side.grid(row=0, column=1, sticky="nsew")
        ttk.Label(load_side, text="Load a bundle & predict", style="CardTitle.TLabel").pack(
            anchor="w"
        )
        ttk.Label(
            load_side,
            text="any bundle this toolkit (or the CLI) ever wrote",
            style="CardMuted.TLabel",
            wraplength=430,
            justify="left",
        ).pack(anchor="w", pady=(2, 0))
        load_buttons = ttk.Frame(load_side, style="Card.TFrame")
        load_buttons.pack(anchor="w", pady=(8, 0))
        load_bundle_btn = self._action_button(
            load_buttons,
            "Open model bundle…",
            self._ml_load_model_bundle,
            tooltip="Loads the estimator and its metadata sidecar; the "
            "card shows the provenance summary (name, task, "
            "trained-at, versions, feature count).",
        )
        load_bundle_btn.pack(side="left")
        predict_csv_btn = self._action_button(
            load_buttons,
            "Predict on CSV…",
            self._ml_predict_with_bundle,
            tooltip="Opens a CSV, audits every column against the "
            "bundle's recorded feature contract (missing / extra "
            "/ reordered features are named up front), predicts "
            "with the loaded estimator and shows the result "
            "table; Save predictions CSV… writes it.",
        )
        predict_csv_btn.pack(side="left", padx=(10, 0))
        self._ml_bundle_info = ttk.Label(
            load_side,
            text="no bundle loaded",
            style="CardMuted.TLabel",
            wraplength=430,
            justify="left",
        )
        self._ml_bundle_info.pack(anchor="w", pady=(4, 0))
        predict_buttons = ttk.Frame(load_side, style="Card.TFrame")
        predict_buttons.pack(anchor="w", pady=(4, 0))
        save_pred_btn = self._action_button(
            predict_buttons,
            "Save predictions CSV…",
            self._ml_save_predictions,
            tooltip="The last bundle prediction table -- input columns "
            "plus the prediction column (probabilities too for "
            "classifiers).",
        )
        save_pred_btn.pack(side="left")
        self._predict_tree_frame = ttk.Frame(load_side, style="Card.TFrame")
        self._predict_tree_frame.pack(fill="both", expand=True, pady=(6, 0))
        self._predict_tree = ttk.Treeview(self._predict_tree_frame, show="headings", height=7)
        predict_bar = ttk.Scrollbar(
            self._predict_tree_frame, orient="vertical", command=self._predict_tree.yview
        )
        self._predict_tree.configure(yscrollcommand=predict_bar.set)
        self._predict_tree.pack(side="left", fill="both", expand=True)
        predict_bar.pack(side="right", fill="y")

        # -- applicability domain (100x-118: the uploaded script as a
        #    first-class card) ------------------------------------------ #
        ad = make_card(
            page.grid,
            "Applicability domain & prediction reliability",
            span=2,
            row=9,
            column=0,
            subtitle="The uploaded Applicability_domain_analysis.py: is the "
            "query compound inside the training descriptor space "
            "(mean kNN distance vs a percentile threshold), and how "
            "much does the model's answer wobble under bootstrap "
            "resampling (ensemble spread vs its own training-side "
            "threshold)? Both answers fold into one reliable / "
            "not-reliable verdict per compound.",
        )
        ad_source_row = ttk.Frame(ad, style="Card.TFrame")
        grid_append(ad, ad_source_row, sticky="ew")
        ttk.Label(ad_source_row, text="model source", style="CardMuted.TLabel").pack(side="left")
        self._ad_source_combo = ttk.Combobox(
            ad_source_row,
            state="readonly",
            width=22,
            values=("last trained model", "loaded bundle"),
        )
        Tooltip(
            self._ad_source_combo,
            "The last trained model (or ensemble) carries its own "
            "80/20 split -- the query set is its held-out rows, no "
            "file picking needed. A loaded bundle (the persistence "
            "card) needs the original train and test CSVs, exactly "
            "like the uploaded script's optimized train/test sets.",
        )
        self._ad_source_combo.set("last trained model")
        self._ad_source_combo.pack(side="left", padx=(8, 0))
        self._ad_source_combo.bind("<<ComboboxSelected>>", self._ml_ad_source_changed)
        self._ad_source_info = ttk.Label(
            ad_source_row,
            text="no run yet",
            style="CardMuted.TLabel",
            wraplength=560,
            justify="left",
        )
        self._ad_source_info.pack(side="left", padx=(12, 0))
        # bundle-mode file pickers (only meaningful for the bundle source)
        self._ad_bundle_row = ttk.Frame(ad, style="Card.TFrame")
        grid_append(ad, self._ad_bundle_row, sticky="ew", pady=(6, 0))
        ad_train_btn = self._action_button(
            self._ad_bundle_row,
            "Open train CSV…",
            self._ml_ad_pick_train_csv,
            tooltip="The bundle mode's training table -- the descriptor "
            "columns the domain is measured in and the target the "
            "bootstrap ensemble refits on (the upload's "
            "Optimized_Train_set CSV).",
        )
        ad_train_btn.pack(side="left")
        self._ad_train_label = ttk.Label(
            self._ad_bundle_row,
            text="no file",
            style="CardMuted.TLabel",
            wraplength=200,
            justify="left",
        )
        self._ad_train_label.pack(side="left", padx=(8, 0))
        ad_test_btn = self._action_button(
            self._ad_bundle_row,
            "Open test CSV…",
            self._ml_ad_pick_test_csv,
            tooltip="The bundle mode's query table -- the compounds judged "
            "inside/outside the domain (the upload's "
            "Optimized_Test_set CSV).",
        )
        ad_test_btn.pack(side="left", padx=(14, 0))
        self._ad_test_label = ttk.Label(
            self._ad_bundle_row,
            text="no file",
            style="CardMuted.TLabel",
            wraplength=200,
            justify="left",
        )
        self._ad_test_label.pack(side="left", padx=(8, 0))
        ad_knobs = ttk.Frame(ad, style="Card.TFrame")
        grid_append(ad, ad_knobs, sticky="ew", pady=(6, 0))
        self._ad_k_spin = ttk.Spinbox(ad_knobs, from_=1, to=20, increment=1, width=8)
        self._ad_k_spin.set("5")
        Tooltip(
            self._ad_k_spin,
            "Nearest neighbours of the distance domain (the upload's "
            "k = 5). Training distances exclude each point's own "
            "self-match, so the threshold is not deflated.",
        )
        form_row(ad_knobs, "k (neighbours)", self._ad_k_spin)
        self._ad_pct_spin = ttk.Spinbox(ad_knobs, from_=50.0, to=99.9, increment=0.5, width=8)
        self._ad_pct_spin.set("95.0")
        Tooltip(
            self._ad_pct_spin,
            "Percentile of the training distances (and of the "
            "training-side ensemble spread) both thresholds are cut "
            "at -- the upload's 95th.",
        )
        form_row(ad_knobs, "threshold percentile", self._ad_pct_spin)
        self._ad_boot_spin = ttk.Spinbox(ad_knobs, from_=0, to=200, increment=1, width=8)
        self._ad_boot_spin.set("30")
        Tooltip(
            self._ad_boot_spin,
            "Bootstrap ensemble size for the uncertainty half (the "
            "upload's 30 CatBoost models -- here clones of the trained "
            "estimator itself). 0 = kNN-only quick pass, no extra fits. "
            "Every member predicts on the query AND training rows in "
            "one pass, so this costs half the upload's 2 x n fits.",
        )
        form_row(ad_knobs, "bootstrap models", self._ad_boot_spin)
        ad_buttons = ttk.Frame(ad, style="Card.TFrame")
        grid_append(ad, ad_buttons, sticky="ew", pady=(8, 0))
        ad_run_btn = self._action_button(
            ad_buttons,
            "Analyse applicability domain",
            self._ml_ad_run,
            primary=True,
            tooltip="Runs the upload's workflow end-to-end: standardise the "
            "descriptor space, kNN distances + percentile "
            "threshold, bootstrap-ensemble spread + its own "
            "threshold, then the per-compound reliability table "
            "and the combined two-panel figure. The status bar "
            "carries per-member progress for the bootstrap fits.",
        )
        ad_run_btn.pack(side="left")
        ad_save_btn = self._action_button(
            ad_buttons,
            "Save AD results CSV…",
            self._ml_ad_save,
            tooltip="The last reliability table -- the upload's Applicability_Domain_Results.csv.",
        )
        ad_save_btn.pack(side="left", padx=(10, 0))
        save_ad_figure_btn = self._action_button(
            ad_buttons,
            "Save figure…",
            self._save_ad_figure,
            tooltip="Save the figure this card is currently showing -- the "
            "two-panel reliability picture (distance + ensemble "
            "spread) -- as PNG, SVG or PDF (unlike Ctrl+S, which "
            "saves the last figure drawn anywhere).",
        )
        save_ad_figure_btn.pack(side="left", padx=(10, 0))
        self._ad_status = ttk.Label(
            ad_buttons,
            text="run the analysis to see the verdict",
            style="CardMuted.TLabel",
            wraplength=520,
            justify="left",
        )
        self._ad_status.pack(side="left", padx=(10, 0))
        ad_results = ttk.Frame(ad, style="Card.TFrame")
        grid_append(ad, ad_results, sticky="nsew", pady=(6, 0), weight=True)
        # minsize guarantees the figure column its share even when the
        # table's natural (heading-driven) width would swallow the row
        ad_results.columnconfigure(0, weight=3, minsize=320)
        ad_results.columnconfigure(1, weight=4, minsize=430)
        ad_results.rowconfigure(0, weight=1)
        ad_table_frame = ttk.Frame(ad_results, style="Card.TFrame")
        ad_table_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        self._ad_tree = ttk.Treeview(ad_table_frame, show="headings", height=8)
        ad_bar = ttk.Scrollbar(ad_table_frame, orient="vertical", command=self._ad_tree.yview)
        self._ad_tree.configure(yscrollcommand=ad_bar.set)
        self._ad_tree.pack(side="left", fill="both", expand=True)
        ad_bar.pack(side="right", fill="y")
        # a manual figure host (the _figure_host helper grids into its
        # parent's next row; this one lives beside the table in column 1)
        self._ad_host = tk.Frame(ad_results, background=CARD, height=300)
        self._ad_host.grid(row=0, column=1, sticky="nsew")
        self._ad_host.pack_propagate(False)
        self._ml_ad_refresh_source()

    def _ml_open_csv(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "CSV loading"):
            return
        path = filedialog.askopenfilename(
            title="Open a dataset",
            filetypes=[("Data files", "*.csv *.tsv *.txt"), ("All files", "*.*")],
        )
        if path:
            self._ml_load_path(Path(path))

    def _ml_clean_frame(self) -> None:
        """Drop non-numeric columns (the rar's own remover script).

        The target column and the keep list survive; everything else
        non-numeric is dropped with its name reported -- and the cleaned
        frame can become the active dataset with one confirmation, so
        the next Train run uses exactly what the rar script produced.
        """
        if not self._require_pharmaml() or not self._require("pandas", "the numeric cleanup"):
            return
        if getattr(self, "_ml_frame", None) is None:
            messagebox.showwarning("No dataset", "Load a dataset first.")
            return
        frame = self._ml_frame
        keep_raw = [
            token.strip() for token in self._ml_keep_entry.get().split(",") if token.strip()
        ]
        lower_map = {str(column).lower(): column for column in frame.columns}
        keep_cols = [lower_map[token.lower()] for token in keep_raw if token.lower() in lower_map]
        target = self._target_combo.get() or None

        def work() -> Any:
            from pharmaml.ml import clean_numeric_frame

            return clean_numeric_frame(frame, target_col=target, keep_cols=keep_cols)

        def render(cleaned: Any) -> None:
            self._ml_cleaned_frame = cleaned
            dropped = [
                str(column) for column in frame.columns if column not in list(cleaned.columns)
            ]
            self._ml_info.configure(
                text=(
                    f"cleaned: {len(cleaned):,} rows × "
                    f"{len(cleaned.columns)} numeric columns · dropped "
                    f"{len(dropped)}"
                    + (
                        f": {', '.join(dropped[:8])}" + (" …" if len(dropped) > 8 else "")
                        if dropped
                        else " (already numeric)"
                    )
                )
            )
            if dropped and messagebox.askyesno(
                "Use the cleaned frame?",
                f"Dropped {len(dropped)} non-numeric column(s).\n\n"
                "Make the cleaned numeric frame the active dataset\n"
                "(the next Train / leaderboard run uses it)?",
            ):
                self._ml_frame = cleaned
                columns = [str(column) for column in cleaned.columns]
                self._preview_tree.delete(*self._preview_tree.get_children())
                self._preview_tree["columns"] = columns
                for column in columns:
                    self._preview_tree.heading(column, text=column)
                    self._preview_tree.column(column, width=96, minwidth=64, stretch=True)
                for _, row in cleaned.head(12).iterrows():
                    self._preview_tree.insert(
                        "", "end", values=[_cell_text(value) for value in row.tolist()]
                    )
                chosen = default_target_column(cleaned) or columns[-1]
                self._target_combo["values"] = columns
                self._target_combo.set(chosen)
                self._refresh_model_choices(self._infer_task(chosen, cleaned))

        self._start_job("dropping non-numeric columns", work, render)

    def _ml_clean_save(self) -> None:
        frame = getattr(self, "_ml_cleaned_frame", None)
        if frame is None:
            messagebox.showinfo("Nothing to save", "Run the numeric cleanup first.")
            return
        self._save_frame_dialog(frame, "Save the cleaned dataset", "cleaned_dataset.csv")

    def _ml_load_example(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "CSV loading"):
            return
        name = self._example_combo.get()
        path = EXAMPLES_DIR / name
        if not path.is_file():
            messagebox.showwarning("Missing example", f"{name} was not found.")
            return
        self._ml_load_path(path)

    def _ml_load_path(self, path: Path) -> None:
        try:
            from pharmaml.utils.io import read_table

            frame = read_table(path)
        except Exception as exc:  # noqa: BLE001
            self._show_error("Could not read the dataset", exc)
            return
        if frame.empty:
            messagebox.showwarning("Empty dataset", f"{path.name} has no rows.")
            return
        self._ml_frame = frame
        self._ml_path = path
        columns = [str(column) for column in frame.columns]
        self._preview_tree.delete(*self._preview_tree.get_children())
        self._preview_tree["columns"] = columns
        for column in columns:
            self._preview_tree.heading(column, text=column)
            self._preview_tree.column(column, width=96, minwidth=64, stretch=True)
        for _, row in frame.head(12).iterrows():
            self._preview_tree.insert(
                "", "end", values=[_cell_text(value) for value in row.tolist()]
            )
        self._target_combo["values"] = columns
        chosen = default_target_column(frame) or columns[-1]
        self._target_combo.set(chosen)
        self._ml_info.configure(text=f"{path.name} — {len(frame):,} rows × {len(columns)} columns")
        self._refresh_model_choices(self._infer_task(chosen, frame))

    def _infer_task(self, target: str, frame: Any = None) -> str:
        """Classify a target column as a regression or a classification label.

        ``frame`` defaults to the Data & ML tab's dataset; the Deep
        Learning tab passes its own so both loaders share one rule.
        """
        if frame is None:
            frame = self._ml_frame
        if frame is None:
            return "regression"
        column = frame[target]
        if str(column.dtype) == "object":
            return "classification"
        if column.nunique() <= 6:
            return "classification"
        return "regression"

    def _refresh_model_choices(self, task: str) -> None:
        try:
            from pharmaml.ml.models import list_models

            names = [entry["name"] for entry in list_models(task, only_available=True)]
        except Exception:  # noqa: BLE001 - fall back to a safe fast pair
            names = ["ridge"] if task == "regression" else ["logistic_regression"]
        if not names:
            names = ["ridge"] if task == "regression" else ["logistic_regression"]
        self._model_combo["values"] = ["auto"] + names
        self._model_combo.set("auto")
        self._ml_refresh_hyperparam_panel()

    def _ml_task_changed(self, _event: Any = None) -> None:
        """A concrete task pick re-lists its models and the manual knobs."""
        task = self._task_combo.get()
        if task != "auto":
            self._refresh_model_choices(task)
        self._ml_refresh_hyperparam_panel()

    def _ml_params_saved(self) -> dict[str, dict[str, str]]:
        """The persisted per-model manual values (``{model: {param: raw}}``).
        One JSON string variable (``_ml_params_var``) carries every
        model's manual values, so the session machinery saves and
        restores them with zero extra plumbing — and switching models
        back and forth never loses an edit.
        """
        try:
            payload = json.loads(self._ml_params_var.get() or "{}")
        except ValueError:
            return {}
        if not isinstance(payload, dict):
            return {}
        return {
            str(model): {str(key): str(value) for key, value in values.items()}
            for model, values in payload.items()
            if isinstance(values, dict)
        }

    def _ml_sync_params_var(self) -> None:
        """Persist the CURRENT model's fields into the JSON variable."""
        payload = self._ml_params_saved()
        model = self._model_combo.get()
        values = {
            key: entry.get().strip()
            for key, entry in getattr(self, "_ml_param_entries", {}).items()
            if entry.get().strip()
        }
        if values:
            payload[model] = values
        else:
            payload.pop(model, None)
        self._ml_params_var.set(json.dumps(payload, sort_keys=True))

    def _ml_refresh_hyperparam_panel(self) -> None:
        """Rebuild the manual-hyperparameter rows for the selected model.

        The registry's own ``param_grid`` decides WHICH knobs are
        editable (the toolkit's curated tunable set), and the freshly
        built estimator supplies each default — so the card can never
        drift from the models it configures.  A model with an empty
        grid says so instead of pretending.
        """
        host = getattr(self, "_ml_params_host", None)
        if host is None:  # built before the ML tab exists (safety)
            return
        for child in host.winfo_children():
            child.destroy()
        self._ml_param_entries = {}
        selection = self._model_combo.get()
        task = self._task_combo.get()
        if task == "auto" and self._ml_frame is not None:
            target = self._target_combo.get()
            if target in [str(column) for column in self._ml_frame.columns]:
                task = self._infer_task(target)
        if selection == "auto" or task not in ("regression", "classification"):
            self._ml_params_status.configure(
                text="pick a model to edit its hyperparameters"
                + ("" if selection != "auto" else " (the model combobox above)")
            )
            return
        try:
            from pharmaml.ml.models import (
                MODEL_REGISTRY,
                build_model,
                resolve_model_name,
            )

            spec = MODEL_REGISTRY[resolve_model_name(selection)]
            defaults = build_model(selection, task).get_params()
            grid = dict(spec.param_grid)
        except Exception as exc:  # noqa: BLE001 - unusable model, say so
            self._ml_params_status.configure(
                text=f"{selection} could not be built here ({exc}) — its defaults are used as-is"
            )
            return
        if not grid:
            self._ml_params_status.configure(
                text=f"{spec.name} exposes no registry search grid — its "
                "estimator defaults are used as-is"
            )
            return
        saved = self._ml_params_saved().get(selection, {})
        for index, key in enumerate(grid):
            row = ttk.Frame(host, style="Card.TFrame")
            row.grid(row=index, column=0, sticky="ew", pady=(0, 4))
            ttk.Label(row, text=key, style="Field.TLabel").grid(row=0, column=0, sticky="w")
            entry = ttk.Entry(row, width=16)
            entry.grid(row=0, column=1, sticky="w", padx=(10, 0))
            # BLANK means "keep the estimator's default" — the hint
            # label names that default, so the field itself stays empty
            # unless the user pins something (only edited keys pin, and
            # only unpinned keys keep their grid-search slots).
            prefill = saved.get(key, "")
            if prefill:
                entry.insert(0, prefill)
            entry.bind("<KeyRelease>", lambda _e: self._ml_sync_params_var())
            self._ml_param_entries[key] = entry
            grid_hint = " · ".join(_cell_text(value, limit=14) for value in grid[key])
            default_text = _cell_text(defaults.get(key, ""), limit=14)
            ttk.Label(
                row,
                text=f"default {default_text} · grid {grid_hint}",
                style="CardMuted.TLabel",
                wraplength=430,
                justify="left",
            ).grid(row=0, column=2, sticky="w", padx=(10, 0))
        pinned = sum(1 for key, entry in self._ml_param_entries.items() if entry.get().strip())
        self._ml_params_status.configure(
            text=f"{spec.name} · {len(grid)} knob(s) · blank = default · "
            f"{pinned} pinned · pinned keys are excluded from the "
            "grid search"
        )

    def _ml_params_reset(self) -> None:
        """The manual card's own reset — every field back to default.

        Drops the current model's saved values from the JSON variable
        and rebuilds the panel, which prefills each field with the
        estimator's own default — the exact state a fresh selection
        shows (never blank-with-hidden-values).
        """
        payload = self._ml_params_saved()
        payload.pop(self._model_combo.get(), None)
        self._ml_params_var.set(json.dumps(payload, sort_keys=True))
        self._ml_refresh_hyperparam_panel()
        if getattr(self, "_ml_param_entries", {}):
            self._ml_params_status.configure(
                text="manual values cleared — estimator defaults in effect"
            )

    def _ml_manual_params(self, model_name: str, task: str) -> dict[str, Any] | None:
        """Parse the manual fields into ``train_model``'s pinned values.

        Blank fields keep their default and are simply not pinned; a
        field that fails its type parse raises :class:`ValueError`
        naming the parameter — the pre-flight convention every other
        input on the tab follows.
        """
        entries = getattr(self, "_ml_param_entries", {})
        if not entries or model_name == "auto":
            return None
        try:
            from pharmaml.ml.models import build_model

            defaults = build_model(model_name, task).get_params()
        except Exception:  # noqa: BLE001 - degrade to defaults, never block
            return None
        params: dict[str, Any] = {}
        for key, entry in entries.items():
            raw = entry.get().strip()
            if not raw:
                continue
            try:
                params[key] = parse_typed_value(raw, defaults.get(key))
            except ValueError as exc:
                raise ValueError(f"{key}: {exc}") from None
        return params or None

    def _ml_train(self) -> None:
        if not self._require_pharmaml():
            return
        if not self._require("pandas", "model training") or not self._require(
            "sklearn", "model training"
        ):
            return
        if self._ml_frame is None:
            messagebox.showwarning("No dataset", "Open a CSV or load an example first.")
            return
        target = self._target_combo.get()
        if not target:
            messagebox.showwarning("No target", "Pick the column to predict.")
            return
        # pre-flight (100x-62): same rule as the Deep Learning tab -- a
        # zero-numeric-feature dataset fails BEFORE the job starts.
        numeric, dropped = numeric_feature_columns(self._ml_frame, target)
        if not numeric:
            messagebox.showwarning(
                "No numeric features",
                "Every non-target column is non-numeric"
                + (f" ({', '.join(dropped)})" if dropped else "")
                + ".  The models need numeric feature columns -- compute "
                "descriptors first (the Chemistry tab's feature factory).",
            )
            return
        task = self._task_combo.get()
        if task == "auto":
            task = self._infer_task(target)
        model_name = self._model_combo.get()
        if model_name == "auto":
            model_name = "ridge" if task == "regression" else "logistic_regression"
        tune = bool(self._tune_var.get())
        # manual hyperparameters + cv folds (100x-106): parsed BEFORE
        # the job starts, naming the offending field -- the tab's
        # pre-flight convention.
        try:
            model_params = self._ml_manual_params(model_name, task)
            cv = parse_int(self._ml_cv_spin.get(), "cv folds", minimum=2, maximum=10)
        except ValueError as exc:
            messagebox.showwarning("Check the manual settings", str(exc))
            return

        def work() -> Any:
            from pharmaml.ml import evaluate_model, train_model
            from pharmaml.ml.preprocessing import make_train_test_split

            frame = self._ml_frame
            y = frame[target]
            numeric, dropped = numeric_feature_columns(frame, target)
            x_train, x_test, y_train, y_test = make_train_test_split(
                frame[numeric], y, random_state=42
            )
            trained = train_model(
                model_name,
                task,
                x_train,
                y_train,
                tune=tune,
                cv=cv,
                n_jobs=1,
                model_params=model_params,
            )
            report = evaluate_model(
                trained.model,
                x_test,
                y_test,
                task,
                keep_predictions=(task == "regression"),
            )
            return trained, report, task, dropped, x_train, y_train, x_test, y_test

        def render(payload: Any) -> None:
            trained, report, task, dropped, x_train, y_train, x_test, y_test = payload
            # the Save-report button rebuilds the CLI bundle from this run;
            # the Check-CSV button audits new data against it (the training
            # target rides along as the automatic --target drop); the AD
            # card reuses the split for the domain + query sets.
            self._ml_last_run = (trained, report, task, x_train, y_train, x_test, y_test, target)
            gp = self._ml_gp_sigma(trained, x_test)
            self._fill_ml_metrics(trained, report, task, dropped, gp=gp)
            self._ml_ad_refresh_source()
            if not self.deps.get("matplotlib"):
                return
            try:
                from pharmaml.viz import (
                    plot_confusion_matrix,
                    plot_gp_uncertainty,
                    plot_predicted_vs_actual,
                )

                if task == "regression":
                    if gp is not None:
                        # GP runs get their own honest readout: the parity
                        # scatter with ±1.96·σ error bars and the coverage
                        # annotation (plot_gp_uncertainty draws both).
                        figure = plot_gp_uncertainty(
                            y_test,
                            gp[0],
                            gp[1],
                            metrics={
                                "R²": report.r2,
                                "RMSE": report.rmse,
                                "MAE": report.mae,
                            },
                        )
                    else:
                        figure = plot_predicted_vs_actual(
                            y_test,
                            report.predictions,
                            metrics={
                                "R²": report.r2,
                                "RMSE": report.rmse,
                                "MAE": report.mae,
                            },
                        )
                else:
                    figure = plot_confusion_matrix(report.confusion, labels=report.labels)
                self._render_figure(self._ml_host, figure)
            except Exception as exc:  # noqa: BLE001
                self._show_error("Plot failed", exc)

        self._start_job(f"training {model_name} ({task})", work, render)

    # -- ensemble builder card ------------------------------------------ #
    def _ens_train(self) -> None:
        """Train a voting / stacking ensemble of the ticked members."""
        if not self._require_pharmaml():
            return
        if not self._require("pandas", "ensemble training") or not self._require(
            "sklearn", "ensemble training"
        ):
            return
        if self._ml_frame is None:
            messagebox.showwarning("No dataset", "Open a CSV or load an example first.")
            return
        target = self._target_combo.get()
        if not target:
            messagebox.showwarning("No target", "Pick the column to predict.")
            return
        numeric, dropped = numeric_feature_columns(self._ml_frame, target)
        if not numeric:
            messagebox.showwarning(
                "No numeric features",
                "Every non-target column is non-numeric.  Compute descriptors "
                "first (the Chemistry tab's feature factory).",
            )
            return
        members = [token for token, var in self._ens_member_vars.items() if var.get()]
        if not members:
            messagebox.showwarning("No members", "Tick at least one base model for the ensemble.")
            return
        kind = self._ens_kind_combo.get()
        voting_rule = self._ens_voting_combo.get()
        meta_token = self._ens_meta_combo.get()
        task = self._task_combo.get()
        if task == "auto":
            task = self._infer_task(target)
        if kind == "voting" and task == "regression":
            voting_rule = "soft"  # ignored by VotingRegressor; keep valid

        def work() -> Any:
            from pharmaml.ml.evaluation import evaluate_model
            from pharmaml.ml.models import build_stacking, build_voting
            from pharmaml.ml.preprocessing import make_train_test_split
            from pharmaml.ml.training import TrainingResult

            frame = self._ml_frame
            y = frame[target]
            x_train, x_test, y_train, y_test = make_train_test_split(
                frame[numeric], y, random_state=42
            )
            if kind == "voting":
                estimator = build_voting(task, members, voting=voting_rule)
                name = f"voting ({'+'.join(members)})"
            else:
                meta = meta_token if meta_token != "auto" else None
                estimator = build_stacking(task, members, meta_model=meta)
                name = f"stacking ({'+'.join(members)} → {meta_token})"
            import time as _time

            started = _time.perf_counter()
            estimator.fit(x_train, y_train)
            fit_seconds = _time.perf_counter() - started
            trained = TrainingResult(
                model=estimator,
                name=name,
                task=task,
                best_params={},
                cv_scores=None,
                cv_mean=None,
                cv_std=None,
                fit_seconds=fit_seconds,
            )
            report = evaluate_model(
                estimator,
                x_test,
                y_test,
                task,
                keep_predictions=(task == "regression"),
            )
            return trained, report, task, dropped, x_train, y_train, x_test, y_test

        def render(payload: Any) -> None:
            trained, report, task, dropped, x_train, y_train, x_test, y_test = payload
            self._ml_last_run = (trained, report, task, x_train, y_train, x_test, y_test, target)
            self._fill_ml_metrics(trained, report, task, dropped)
            self._ml_ad_refresh_source()
            members_named = "+".join(members)
            self._ens_summary.configure(
                text=(
                    f"{kind} ({members_named}) trained — metrics in the "
                    "Results card; Save report… / Save model bundle… "
                    "carry it forward"
                ),
                style="Field.TLabel",
            )
            self._ml_save_info.configure(
                text=(f"last run: {trained.name} — ready to save as a bundle")
            )
            if not self.deps.get("matplotlib"):
                return
            try:
                from pharmaml.viz import (
                    plot_confusion_matrix,
                    plot_predicted_vs_actual,
                )

                if task == "regression":
                    figure = plot_predicted_vs_actual(
                        y_test,
                        report.predictions,
                        metrics={
                            "R²": report.r2,
                            "RMSE": report.rmse,
                            "MAE": report.mae,
                        },
                    )
                else:
                    figure = plot_confusion_matrix(report.confusion, labels=report.labels)
                self._render_figure(self._ml_host, figure)
            except Exception as exc:  # noqa: BLE001
                self._show_error("Plot failed", exc)

        self._start_job(f"training {kind} ensemble ({len(members)} members)", work, render)

    # -- model persistence card ----------------------------------------- #
    def _ml_save_model_bundle(self) -> None:
        """Save the last trained model (or ensemble) as a provenance bundle."""
        if not self._require_pharmaml():
            return
        if self._ml_last_run is None:
            messagebox.showwarning(
                "No run yet",
                "Train a model (or an ensemble) first -- the bundle saves "
                "the last run's fitted estimator and its metrics.",
            )
            return
        trained, report, task, _x_train, _y_train, _x_test, _y_test, target = self._ml_last_run
        path = filedialog.asksaveasfilename(
            title="Save the model bundle",
            defaultextension=".joblib",
            initialfile=f"{trained.name.replace(' ', '_').replace('(', '').replace(')', '')}.joblib",
            filetypes=[("Model bundle", "*.joblib *.pkl"), ("All files", "*.*")],
        )
        if not path:
            return
        frame = self._ml_frame
        numeric, _dropped = (
            numeric_feature_columns(frame, target) if (frame is not None) else ([], [])
        )
        metrics: dict[str, Any] = {}
        for key in (
            "r2",
            "rmse",
            "mae",
            "accuracy",
            "balanced_accuracy",
            "precision_macro",
            "recall_macro",
            "mcc",
            "roc_auc",
        ):
            value = getattr(report, key, None)
            if isinstance(value, (int, float)):
                metrics[key] = float(value)

        def work() -> Any:
            from pharmaml.ml.persistence import save_model, write_metadata_sidecar

            written = save_model(
                trained.model,
                path,
                name=trained.name,
                task=task,
                features=list(numeric) if numeric else None,
                best_params=dict(getattr(trained, "best_params", {}) or {}),
                metrics=metrics,
                target=target,
            )
            sidecar = write_metadata_sidecar(written)
            return written, sidecar

        def render(payload: Any) -> None:
            written, sidecar = payload
            self._ml_save_info.configure(
                text=(
                    f"bundle written: {written.name} (+ {sidecar.name}) — "
                    "load it back below or with the CLI"
                ),
                style="Field.TLabel",
            )
            messagebox.showinfo(
                "Saved",
                f"Model bundle written to\n{written}\n\nProvenance sidecar: {sidecar}",
            )

        self._start_job("saving model bundle", work, render)

    def _ml_load_model_bundle(self) -> None:
        """Load a saved bundle and show its provenance summary."""
        if not self._require_pharmaml():
            return
        path = filedialog.askopenfilename(
            title="Open a model bundle",
            filetypes=[("Model bundle", "*.joblib *.pkl"), ("All files", "*.*")],
        )
        if not path:
            return
        bundle_path = Path(path)

        def work() -> Any:
            from pharmaml.ml.persistence import load_model

            model, metadata = load_model(bundle_path)
            return model, metadata

        def render(payload: Any) -> None:
            model, metadata = payload
            self._ml_bundle = (model, metadata, bundle_path)
            features = metadata.get("features")
            feature_text = f"{len(features)} features" if features else "feature count contract"
            self._ml_bundle_info.configure(
                text=(
                    f"{metadata.get('name', '?')} · {metadata.get('task', '?')}"
                    f" · trained {str(metadata.get('trained_at', '?'))[:19]}"
                    f" · {feature_text} · pharmaml "
                    f"{metadata.get('pharmaml_version', '?')} · sklearn "
                    f"{metadata.get('sklearn_version', '?')}"
                ),
                style="Field.TLabel",
            )
            self._ml_predictions = None
            self._predict_tree.delete(*self._predict_tree.get_children())

        self._start_job(f"loading {bundle_path.name}", work, render)

    def _ml_predict_with_bundle(self) -> None:
        """Audit a CSV against the loaded bundle's contract and predict."""
        if not self._require_pharmaml() or not self._require("pandas", "bundle prediction"):
            return
        if self._ml_bundle is None:
            messagebox.showwarning("No bundle", "Open a model bundle first (the button above).")
            return
        path = filedialog.askopenfilename(
            title="Open the data to predict on",
            filetypes=[("Data files", "*.csv *.tsv *.txt"), ("All files", "*.*")],
        )
        if not path:
            return
        model, metadata, bundle_path = self._ml_bundle
        task = str(metadata.get("task", "regression"))

        def work() -> Any:
            import pandas as pd

            from pharmaml.ml.persistence import validate_bundle_input

            frame = pd.read_csv(path)
            # the training target rides along when the scored CSV is the
            # training table itself -- the bundle records its name, and
            # the audit drops it automatically (the ml check convention)
            target_name = metadata.get("target")
            if target_name and target_name in frame.columns:
                frame = frame.drop(columns=[target_name])
            audit = validate_bundle_input(bundle_path, frame)
            if not audit.ok:
                raise ValueError(
                    f"the CSV does not satisfy the bundle's feature contract:\n{audit}"
                )
            features = metadata.get("features")
            if features:
                x = frame[list(features)]
            else:
                x = frame.select_dtypes("number")
            prediction = model.predict(x)
            result = frame.copy()
            result["prediction"] = prediction
            if task == "classification" and hasattr(model, "predict_proba"):
                proba = model.predict_proba(x)
                classes = list(getattr(model, "classes_", []))
                for index, cls in enumerate(classes):
                    result[f"p_{cls}"] = proba[:, index]
            return result, str(audit)

        def render(payload: Any) -> None:
            result, _audit_text = payload
            self._ml_predictions = result
            tree = self._predict_tree
            tree.delete(*tree.get_children())
            columns = [str(column) for column in result.columns]
            tree["columns"] = columns
            for column in columns:
                width = 190 if column.lower() in ("smiles", "prediction") else 110
                tree.heading(column, text=column)
                tree.column(
                    column,
                    width=width,
                    minwidth=56,
                    stretch=(column.lower() in ("smiles", "prediction")),
                )
            for row in result.head(30).to_dict("records"):
                tree.insert(
                    "", "end", values=[_cell_text(row[column], limit=40) for column in columns]
                )
            self._ml_bundle_info.configure(
                text=(
                    f"predicted {len(result)} row(s) — audit OK "
                    f"({bundle_path.name}); Save predictions CSV… writes "
                    "the full table"
                ),
                style="Field.TLabel",
            )

        self._start_job(f"predicting with {bundle_path.name}", work, render)

    def _ml_save_predictions(self) -> None:
        frame = getattr(self, "_ml_predictions", None)
        if frame is None:
            messagebox.showinfo("Nothing to save", "Predict with a loaded bundle first.")
            return
        self._save_frame_dialog(frame, "Save the predictions", "predictions.csv", "Predictions")

    # -- applicability-domain card (100x-118: the upload) ------------- #
    def _ml_ad_refresh_source(self) -> None:
        """Refresh the AD card's source line + bundle-mode visibility.

        Called at build time, whenever a model finishes training, and on
        every combobox change: 'last trained model' shows the run's
        split summary; 'loaded bundle' shows the bundle's provenance and
        the train/test CSV pickers.
        """
        mode = self._ad_source_combo.get()
        bundle_mode = mode == "loaded bundle"
        if bundle_mode:
            self._ad_bundle_row.grid()
        else:
            self._ad_bundle_row.grid_remove()
        if not bundle_mode:
            if self._ml_last_run is None:
                self._ad_source_info.configure(
                    text="no run yet — train a model (or an ensemble) first"
                )
            else:
                trained = self._ml_last_run[0]
                x_train, x_test = self._ml_last_run[3], self._ml_last_run[5]
                self._ad_source_info.configure(
                    text=(
                        f"{trained.name} — {len(x_train)} train / "
                        f"{len(x_test)} held-out query rows (its own "
                        "80/20 split)"
                    ),
                    style="Field.TLabel",
                )
            return
        if self._ml_bundle is None:
            self._ad_source_info.configure(
                text="no bundle loaded — open one in the persistence card above"
            )
            return
        _model, metadata, _path = self._ml_bundle
        features = metadata.get("features")
        self._ad_source_info.configure(
            text=(
                f"{metadata.get('name', '?')} · {metadata.get('task', '?')}"
                f" · {len(features) if features else '?'} features — pick "
                "the original train + test CSVs below"
            ),
            style="Field.TLabel",
        )

    def _ml_ad_source_changed(self, _event: Any = None) -> None:
        """Combobox callback — re-render the source line."""
        self._ml_ad_refresh_source()

    def _ml_ad_pick_train_csv(self) -> None:
        """Pick the bundle mode's training CSV."""
        path = filedialog.askopenfilename(
            title="Open the training CSV",
            filetypes=[("Data files", "*.csv *.tsv *.txt"), ("All files", "*.*")],
        )
        if not path:
            return
        self._ml_ad_train_path = Path(path)
        self._ad_train_label.configure(text=Path(path).name, style="Field.TLabel")

    def _ml_ad_pick_test_csv(self) -> None:
        """Pick the bundle mode's query CSV."""
        path = filedialog.askopenfilename(
            title="Open the test CSV",
            filetypes=[("Data files", "*.csv *.tsv *.txt"), ("All files", "*.*")],
        )
        if not path:
            return
        self._ml_ad_test_path = Path(path)
        self._ad_test_label.configure(text=Path(path).name, style="Field.TLabel")

    def _ml_ad_bundle_frames(self) -> tuple[Any, Any, Any, Any, Any]:
        """Load + contract-check the bundle mode's train/test CSVs.

        Returns ``(model, X_train, y_train, X_test, test_frame)`` where
        ``test_frame`` is the raw query table (for the SMILES lookup).
        Raises ``ValueError`` with a user-facing message on any contract
        violation.  A SMILES / name column riding along is fine -- it is
        metadata for the reliability table, not a feature (the upload's
        own CSVs carry SMILES in the first column).
        """
        import pandas as pd

        from pharmaml.ml.persistence import validate_bundle_input

        model, metadata, bundle_path = self._ml_bundle
        if self._ml_ad_train_path is None or self._ml_ad_test_path is None:
            raise ValueError(
                "pick both the training and the test CSV first (the "
                "bundle mode needs the original tables)."
            )
        train_frame = pd.read_csv(self._ml_ad_train_path)
        test_frame = pd.read_csv(self._ml_ad_test_path)
        target = metadata.get("target")
        if target is None or target not in train_frame.columns:
            raise ValueError(
                "the training CSV must carry the bundle's target column "
                f"({target!r}) -- the bootstrap ensemble refits on it."
            )
        y_train = train_frame[target]
        features = metadata.get("features")
        if features:
            missing_train = [c for c in features if c not in train_frame.columns]
            missing_test = [c for c in features if c not in test_frame.columns]
            if missing_train or missing_test:
                raise ValueError(
                    "the CSVs are missing recorded feature column(s): "
                    f"train {missing_train or '—'} · test {missing_test or '—'}"
                )
            # selecting by the recorded names IS the contract (missing /
            # extra / reordered all resolved); the SMILES column survives
            # outside the matrices as table metadata
            x_train = train_frame[list(features)]
            x_test = test_frame[list(features)]
        else:
            # no recorded order: audit the numeric views (target dropped)
            train_features = train_frame.drop(columns=[target])
            audit = validate_bundle_input(bundle_path, train_features)
            if not audit.ok:
                raise ValueError(
                    f"the training CSV does not satisfy the bundle's feature contract:\n{audit}"
                )
            audit = validate_bundle_input(bundle_path, test_frame.select_dtypes("number"))
            if not audit.ok:
                raise ValueError(
                    f"the test CSV does not satisfy the bundle's feature contract:\n{audit}"
                )
            x_train = train_features.select_dtypes("number")
            x_test = test_frame.select_dtypes("number")
        return model, x_train, y_train, x_test, test_frame

    def _ml_ad_run(self) -> None:
        """The uploaded workflow, one click (see the card subtitle)."""
        if not self._require_pharmaml() or not self._require(
            "sklearn", "applicability-domain analysis"
        ):
            return
        mode = self._ad_source_combo.get()
        if mode == "loaded bundle" and self._ml_bundle is None:
            messagebox.showwarning(
                "No bundle",
                "Open a model bundle first (the persistence "
                "card above), or switch the source to the last trained model.",
            )
            return
        if mode != "loaded bundle" and self._ml_last_run is None:
            messagebox.showwarning(
                "No run yet",
                "Train a model (or an ensemble) first -- the analysis "
                "reuses its split, or switch the source to a loaded bundle.",
            )
            return
        try:
            k = parse_int(self._ad_k_spin.get(), "k (neighbours)", minimum=1, maximum=20)
            percentile = parse_float(
                self._ad_pct_spin.get(), "threshold percentile", minimum=50.0, maximum=99.9
            )
            n_models = parse_int(
                self._ad_boot_spin.get(), "bootstrap models", minimum=0, maximum=200
            )
        except ValueError as exc:
            messagebox.showwarning("Check the settings", str(exc))
            return
        bundle_mode = mode == "loaded bundle"
        query_names: list[str] | None = None
        if not bundle_mode:
            trained = self._ml_last_run[0]
            x_train = self._ml_last_run[3]
            y_train = self._ml_last_run[4]
            x_test = self._ml_last_run[5]
            model = trained.model
            task = self._ml_last_run[2]
            target = self._ml_last_run[7]
            # the reliability table's name column: the original frame's
            # SMILES (or first column) looked up through the preserved
            # split index -- the upload's test_df.iloc[:, 0]
            frame = self._ml_frame
            smiles = detect_smiles_column(frame) if frame is not None else None
            if smiles is not None:
                try:
                    query_names = frame.loc[x_test.index, smiles].tolist()
                except Exception:  # noqa: BLE001 - index drift: generic names
                    query_names = None
            label = f"{trained.name} ({task})"
        else:
            try:
                model, x_train, y_train, x_test, test_frame = self._ml_ad_bundle_frames()
            except ValueError as exc:
                messagebox.showwarning("Bundle mode", str(exc))
                return
            task = str(self._ml_bundle[1].get("task", "regression"))
            target = str(self._ml_bundle[1].get("target", "value"))
            smiles = detect_smiles_column(test_frame)
            if smiles is not None:
                query_names = test_frame[smiles].tolist()
            label = str(self._ml_bundle[1].get("name", "bundle"))
        if n_models == 0 and len(x_train) <= k:
            messagebox.showwarning(
                "Too few training rows",
                f"k={k} needs at least {k + 1} training rows; only "
                f"{len(x_train)} available -- lower k or skip the analysis.",
            )
            return

        def work(report: Any) -> Any:
            from pharmaml.ml import applicability_domain

            def on_fit(done: int, total: int) -> None:
                report(done, total, f"bootstrap member {done}/{total}")

            return applicability_domain(
                model,
                x_train,
                y_train,
                x_test,
                k=k,
                percentile=percentile,
                n_models=max(n_models, 1),
                uncertainty=n_models > 0,
                progress=on_fit,
            )

        def render(payload: Any) -> None:
            self._ml_ad_result = payload
            table = payload.to_frame(names=query_names)
            self._ml_ad_frame = table
            self._fill_dynamic_tree(
                self._ad_tree,
                table,
                max_rows=200,
                widths={
                    "name": 200,
                    "predicted": 90,
                    "prediction_sd": 90,
                    "knn_distance": 100,
                    "inside_ad": 80,
                    "low_uncertainty": 100,
                    "reliable": 80,
                },
            )
            inside = int(payload.inside_ad.sum())
            total = int(payload.inside_ad.size)
            if payload.reliable is not None:
                reliable = int(payload.reliable.sum())
                low = int(payload.low_uncertainty.sum())
                self._ad_status.configure(
                    text=(
                        f"distance threshold {payload.distance_threshold:.3g} "
                        f"(p{percentile:g}, k={k}) — {inside}/{total} inside AD · "
                        f"{payload.n_models}-member ensemble in "
                        f"{payload.fit_seconds:.1f} s · uncertainty threshold "
                        f"{payload.uncertainty_threshold:.3g} — {low}/{total} "
                        f"low-uncertainty · {reliable}/{total} reliable"
                    ),
                    style="Field.TLabel",
                )
            else:
                self._ad_status.configure(
                    text=(
                        f"distance threshold {payload.distance_threshold:.3g} "
                        f"(p{percentile:g}, k={k}) — {inside}/{total} inside AD "
                        "(kNN-only pass: bootstrap models = 0)"
                    ),
                    style="Field.TLabel",
                )
            if not self.deps.get("matplotlib"):
                return
            try:
                from pharmaml.viz import plot_applicability_domain

                y_label = f"predicted {target}" if task == "regression" else "predicted P(positive)"
                figure = plot_applicability_domain(
                    payload, y_label=y_label, title=f"Applicability domain — {label}"
                )
                self._render_figure(self._ad_host, figure)
            except Exception as exc:  # noqa: BLE001
                self._show_error("AD plot failed", exc)

        self._start_job(f"applicability domain ({label})", work, render)

    def _ml_ad_save(self) -> None:
        """Save the last reliability table (the upload's results CSV)."""
        frame = getattr(self, "_ml_ad_frame", None)
        if frame is None:
            messagebox.showinfo("Nothing to save", "Run the applicability-domain analysis first.")
            return
        self._save_frame_dialog(
            frame, "Save the applicability-domain results", "Applicability_Domain_Results.csv"
        )

    def _ml_gp_sigma(self, trained: Any, x_test: Any) -> tuple[Any, Any] | None:
        """Predictive ``(mean, sigma)`` when the run's model is a GP.

        ``predict_with_uncertainty`` raises its typed ModelError for
        every non-GP family -- that error IS the probe, caught locally
        so ordinary runs never pay anything for the check.  Returns
        ``None`` when pharmaml (or the GP itself) is unavailable.
        """
        try:
            from pharmaml.exceptions import ModelError
            from pharmaml.ml.evaluation import predict_with_uncertainty
        except Exception:  # noqa: BLE001 - pharmaml missing or older
            return None
        try:
            return predict_with_uncertainty(trained.model, x_test)
        except ModelError:
            return None

    def _ml_save_report(self) -> None:
        """Write the last training run as the one-click visual bundle.

        The same ``report.html`` + figures + tables bundle the CLI's
        ``ml train --plots`` writes (plus the multi-page ``report.pdf``
        when the checkbox is ticked -- the ``--pdf-report`` twin),
        rebuilt from the stored run and saved into a folder the user
        picks.  Figures are created under the package's forced-Agg
        backend inside the worker thread; they never touch Tk.
        """
        if not self._require_pharmaml() or not self._require("matplotlib", "the report figures"):
            return
        if self._ml_last_run is None:
            messagebox.showwarning(
                "No run yet",
                "Train a model first -- the report needs the held-out "
                "metrics and figures of the last run.",
            )
            return
        want_pdf = bool(self._ml_pdf_var.get())
        if want_pdf and not fpdf_available():
            messagebox.showwarning(
                "PDF needs fpdf",
                "The multi-page PDF document needs fpdf -- install it "
                "with:  pip install 'pharmaml[reports]'\n"
                "(the HTML report works without it -- untick the box to "
                "continue).",
            )
            return
        if filedialog is None:  # pragma: no cover - headless fallback
            return
        target = filedialog.askdirectory(title="Choose the report folder")
        if not target:
            return
        trained, report, task, _x_train, _y_train, x_test, y_test, _train_target = self._ml_last_run
        model_name = trained.name

        def work() -> Any:
            import pandas as pd

            from pharmaml.exceptions import DataValidationError
            from pharmaml.viz import (
                metrics_to_dataframe,
                ml_plots,
                save_visual_bundle,
            )

            figures: dict[str, Any] = {}
            tables: dict[str, Any] = {}
            if task == "classification":
                figures["confusion_matrix"] = ml_plots.plot_confusion_matrix(report)
                if hasattr(trained.model, "predict_proba"):
                    figures["roc_curves"] = ml_plots.plot_roc_curves(trained.model, x_test, y_test)
                counts = pd.Series(y_test).value_counts(sort=False).to_dict()
                figures["class_distribution"] = ml_plots.plot_class_distribution(counts)
                tables["class_counts"] = pd.DataFrame(
                    {"class": list(counts), "count": list(counts.values())}
                )
            else:
                y_pred = trained.model.predict(x_test)
                figures["predicted_vs_actual"] = ml_plots.plot_predicted_vs_actual(
                    y_test, y_pred, metrics=report.as_dict()
                )
                figures["residuals"] = ml_plots.plot_residuals(y_test, y_pred)
                gp = self._ml_gp_sigma(trained, x_test)
                if gp is not None:
                    # the GP twin: parity with ±1.96·σ error bars plus
                    # the coverage annotation (the figure the GUI shows).
                    figures["gp_uncertainty"] = ml_plots.plot_gp_uncertainty(
                        y_test, gp[0], gp[1], metrics=report.as_dict()
                    )
            if trained.cv_scores is not None:
                figures["cv_scores"] = ml_plots.plot_cv_scores(trained)
            try:
                figures["feature_importance"] = ml_plots.plot_feature_importance(trained.model)
            except DataValidationError:  # kernel SVM / KNN: no importances
                pass
            tables["held_out_metrics"] = metrics_to_dataframe(report)
            return save_visual_bundle(
                figures,
                tables,
                metrics=report,
                out_dir=target,
                title=f"playground ml train — {model_name} ({task})",
                subtitle=self._ml_path.name if self._ml_path else "playground run",
                pdf_report=want_pdf,
            )

        def render(written: Any) -> None:
            names = [path.name for path in written]
            extra = " + report.pdf" if want_pdf else ""
            self._job_label.configure(text=f"report saved · {target} ({len(written)} files{extra})")
            messagebox.showinfo(
                "Report saved",
                f"{len(written)} files written to {target}:\n"
                + "\n".join(names[:8])
                + ("\n…" if len(names) > 8 else ""),
            )

        self._start_job("writing the report bundle", work, render)

    def _ml_check_csv(self) -> None:
        """Audit any CSV against the last trained model (``ml check``, GUI).

        The production failure mode this closes, mouse edition: a model
        trained months ago, a regenerated CSV, and a crash deep inside
        sklearn.  The handler reads the chosen file, drops the training
        target column when the CSV still carries it (the GUI's automatic
        ``--target`` -- it knows the name, the CLI asks), writes a
        throwaway bundle from the stored run inside a temp directory and
        renders the verdict of :func:`validate_bundle_input`: missing
        features, extra columns, reordering and version drift, every
        difference named.  The temp bundle is deleted with its directory;
        nothing touches the user's tree.
        """
        if not self._require_pharmaml() or not self._require("pandas", "CSV auditing"):
            return
        if self._ml_last_run is None:
            messagebox.showwarning(
                "No run yet",
                "Train a model first -- the audit checks a new dataset "
                "against the model bundle of the last run.",
            )
            return
        if filedialog is None:  # pragma: no cover - headless fallback
            return
        chosen = filedialog.askopenfilename(
            title="Choose the dataset to audit",
            filetypes=[("Data files", "*.csv *.tsv *.txt"), ("All files", "*.*")],
        )
        if not chosen:
            return
        path = Path(chosen)
        trained, _report, task, _x_train, _y_train, x_test, _y_test, train_target = (
            self._ml_last_run
        )
        model_name = trained.name

        def work() -> Any:
            import tempfile

            from pharmaml.ml import save_model, validate_bundle_input
            from pharmaml.utils.io import read_table

            frame = read_table(path)
            if train_target and train_target in frame.columns:
                # the automatic --target: re-auditing the very CSV the
                # model was trained on works out of the box.
                frame = frame.drop(columns=[train_target])
            with tempfile.TemporaryDirectory() as tmp:
                bundle = Path(tmp) / "playground_model.joblib"
                save_model(
                    trained.model,
                    bundle,
                    name=trained.name,
                    task=task,
                    features=list(x_test.columns),
                )
                return validate_bundle_input(bundle, frame)

        def render(audit: Any) -> None:
            verdict = "OK" if audit.ok else "FAIL"
            self._job_label.configure(text=f"audit: {verdict} · {path.name}")
            message = (
                f"{path.name} vs the {model_name} bundle:\n\n{audit}\n\n"
                "The CLI twin:\n"
                "  pharmaml ml check --model <bundle> --data "
                f"{path.name}"
            )
            if train_target:
                message += f" --target {train_target}"
            messagebox.showinfo(f"Dataset audit: {verdict}", message)

        self._start_job(f"auditing {path.name}", work, render)

    def _fill_ml_metrics(
        self,
        trained: Any,
        report: Any,
        task: str,
        dropped: list[str],
        gp: tuple[Any, Any] | None = None,
    ) -> None:
        for child in self._ml_metrics.winfo_children():
            child.destroy()
        cv_line = "no CV"
        if trained.cv_mean is not None:
            spread = trained.cv_std if trained.cv_std is not None else 0.0
            cv_line = f"{trained.cv_mean:.3f} ± {spread:.3f}"
        if task == "regression":
            pairs = [
                ("model", f"{trained.name} ({task})"),
                ("R²", format_number(getattr(report, "r2", float("nan")))),
                ("RMSE", format_number(report.rmse)),
                ("MAE", format_number(report.mae)),
                ("CV score", cv_line),
                ("fit time", f"{trained.fit_seconds:.2f} s"),
            ]
            if gp is not None:
                # the GP's honest uncertainty line: the median predictive
                # sigma across the held-out set (the error-bar scale the
                # figure draws at ±1.96σ).
                import numpy as _np

                sigma = _np.asarray(gp[1], dtype=float)
                pairs.append(("predictive σ (median)", format_number(float(_np.median(sigma)))))
        else:
            auc = getattr(report, "roc_auc", None)
            pairs = [
                ("model", f"{trained.name} ({task})"),
                ("accuracy", format_number(report.accuracy)),
                ("balanced accuracy", format_number(report.balanced_accuracy)),
                ("precision (macro)", format_number(report.precision_macro)),
                ("recall (macro)", format_number(report.recall_macro)),
                ("MCC", format_number(report.mcc)),
                ("ROC AUC", format_number(auc) if auc is not None else "n/a"),
                ("CV score", cv_line),
                ("fit time", f"{trained.fit_seconds:.2f} s"),
            ]
        if dropped:
            pairs.append(("dropped non-numeric", ", ".join(dropped)))
        for index, (name, value) in enumerate(pairs):
            ttk.Label(self._ml_metrics, text=name, style="CardMuted.TLabel").grid(
                row=index // 4, column=(index % 4) * 2, sticky="w", padx=(0, 6)
            )
            ttk.Label(self._ml_metrics, text=value, style="Field.TLabel", font=self._mono).grid(
                row=index // 4, column=(index % 4) * 2 + 1, sticky="w", padx=(0, 18)
            )

    def _ml_tune(self) -> None:
        """Run a hyperparameter search over the chosen family.

        The ``ml tune`` story, mouse edition: RandomSearch samples
        full-budget trials; Hyperband (``--searcher hyperband``)
        successive-halves the family's resource slot -- ann's
        ``max_iter``, dnn's ``epochs`` -- with the rung ladder sized
        from the family's own declared grid via the public
        ``resource_bounds`` (so every rung stays inside the declared
        space and the final rung is exactly the full budget).  Both
        searchers score every trial AND the hypermodel's defaults
        under the same public ``make_cv_splitter`` folds (the
        apples-to-apples baseline the search has to beat), and the
        winner is refit on the train split and scored on the held-out
        20% -- all inside the worker thread, deterministically
        (seed 42, the tab's own convention).
        """
        if not self._require_pharmaml():
            return
        if not self._require("pandas", "the search") or not self._require("sklearn", "the search"):
            return
        if self._ml_frame is None:
            messagebox.showwarning("No dataset", "Open a CSV or load an example first.")
            return
        target = self._target_combo.get()
        if not target:
            messagebox.showwarning("No target", "Pick the column to predict.")
            return
        # pre-flight (100x-62): the search shares the tab's rule -- a
        # zero-numeric-feature dataset fails before any job starts.
        numeric, dropped = numeric_feature_columns(self._ml_frame, target)
        if not numeric:
            messagebox.showwarning(
                "No numeric features",
                "Every non-target column is non-numeric"
                + (f" ({', '.join(dropped)})" if dropped else "")
                + ".  The hypermodels need numeric feature columns -- compute "
                "descriptors first (the Chemistry tab's feature factory).",
            )
            return
        task = self._task_combo.get()
        if task == "auto":
            task = self._infer_task(target)
        estimator = self._tune_estimator_combo.get()
        hypermodel_name = _TUNE_HYPERMODELS.get((estimator, task))
        if hypermodel_name is None:
            messagebox.showwarning(
                "hsvr is regression-only",
                "The HierarchicalSVR hypermodel has no classification "
                "variant -- pick ann or dnn for a classification target.",
            )
            return
        if estimator == "dnn" and not self._require("torch", "the dnn search"):
            return
        searcher = self._tune_searcher_combo.get()
        resource = _TUNE_RESOURCES.get(estimator)
        if searcher == "hyperband" and resource is None:
            messagebox.showwarning(
                "hsvr has no resource slot",
                "Hyperband halves a resource budget rung by rung -- ann's "
                "max_iter, dnn's epochs. The HierarchicalSVR hypermodel "
                "declares no resource slot, so there is nothing to halve. "
                "Pick ann or dnn, or switch the searcher back to random.",
            )
            return
        try:
            max_trials = parse_int(self._tune_trials.get(), "trials", minimum=4, maximum=40)
            cv = parse_int(self._tune_cv.get(), "cv folds", minimum=2, maximum=5)
            eta = parse_int(self._tune_eta.get(), "eta", minimum=2, maximum=4)
        except ValueError as exc:
            messagebox.showwarning("Check the search settings", str(exc))
            return

        def work(report: Any) -> Any:
            from sklearn.model_selection import cross_val_score

            import pharmaml.ml.tuner as tuner_module
            from pharmaml.ml import evaluate_model
            from pharmaml.ml.preprocessing import make_train_test_split
            from pharmaml.ml.tuner import (
                Hyperband,
                HyperParameters,
                RandomSearch,
                make_cv_splitter,
                resource_bounds,
            )

            def on_trial(info: dict[str, Any]) -> None:
                # the status bar's heartbeat (100x-106): trial/total
                # drive the determinate bar + ETA, best-so-far rides
                # along as the note.
                note = ""
                if info.get("best_score") is not None:
                    note = f"best {info['best_score']:.3f}"
                if info.get("error") is not None:
                    note = (note + " · " if note else "") + "trial failed"
                report(info["trial"], info.get("total"), note)

            hypermodel = getattr(tuner_module, hypermodel_name)
            objective = "r2" if task == "regression" else "accuracy"
            frame = self._ml_frame
            y = frame[target]
            numeric, _dropped = numeric_feature_columns(frame, target)
            x_train, x_test, y_train, y_test = make_train_test_split(
                frame[numeric], y, random_state=42
            )
            ladder: tuple[int, int] | None = None
            if searcher == "hyperband":
                # the ladder IS the family's declared resource grid --
                # r_min its smallest value, R its largest (the full
                # budget a plain Train runs at).
                r_min, r_max = resource_bounds(hypermodel, resource or "epochs")
                ladder = (r_min, r_max)
                tuner: Any = Hyperband(
                    hypermodel,
                    objective=objective,
                    resource=resource or "epochs",
                    max_resource=r_max,
                    min_resource=r_min,
                    eta=eta,
                    cv=cv,
                    task=task,
                    seed=42,
                    on_trial=on_trial,
                )
            else:
                tuner = RandomSearch(
                    hypermodel,
                    objective=objective,
                    max_trials=max_trials,
                    cv=cv,
                    task=task,
                    seed=42,
                    on_trial=on_trial,
                )
            results = tuner.search(x_train, y_train)
            # the baseline: the hypermodel's defaults under the tuner's
            # own fold protocol (the public splitter -- same folds, only
            # the configuration differs).
            defaults = hypermodel(HyperParameters())
            base = cross_val_score(
                defaults,
                x_train,
                y_train,
                scoring=objective,
                cv=make_cv_splitter(task, y_train, cv),
            )
            # the held-out verdict: the winner was refit on the train
            # split inside search(); score it like any trained model.
            report = evaluate_model(
                results.best_estimator,
                x_test,
                y_test,
                task,
                keep_predictions=False,
            )
            return results, float(base.mean()), float(base.std()), report, objective, ladder

        def render(payload: Any) -> None:
            results, base_mean, base_std, report, objective, ladder = payload
            self._tune_last = (results, estimator, task, target)
            held_out = report.r2 if task == "regression" else report.accuracy
            held_label = "held-out R²" if task == "regression" else "held-out accuracy"
            gain = results.best_score - base_mean
            self._tune_summary.configure(
                text=f"best {results.best_score:.4f} ± "
                f"{results.best_trial.score_std:.4f} CV {objective} · "
                f"defaults {base_mean:.4f} ± {base_std:.4f} → gain "
                f"{gain:+.4f} · {held_label} {held_out:.4f} · winner: "
                + tune_config_text(results.best_params)
            )
            ranked = sorted(
                (t for t in results.trials if not t.failed),
                key=lambda t: t.score,
                reverse=True,
            )
            failed = [t for t in results.trials if t.failed]
            self._board_tree.delete(*self._board_tree.get_children())
            if ladder is None:
                columns = ["rank", "trial", "configuration", "score", "± std"]
            else:
                columns = ["rank", "trial", "configuration", "resource", "score", "± std"]
            self._board_tree["columns"] = columns
            for column in columns:
                self._board_tree.heading(column, text=column)
                self._board_tree.column(column, width=140, minwidth=72, stretch=True)

            def row_values(rank: int | str, trial: Any) -> list[str]:
                cells = [
                    str(rank),
                    str(trial.trial_id),
                    _cell_text(tune_config_text(trial.hyperparameters), limit=52),
                ]
                if ladder is not None:
                    cells.append("" if trial.resource is None else f"{trial.resource:g}")
                cells.append(f"{trial.score:.4f}")
                cells.append(f"{trial.score_std:.4f}")
                return cells

            for rank, trial in enumerate(ranked, start=1):
                self._board_tree.insert("", "end", values=row_values(rank, trial))
            for trial in failed:
                self._board_tree.insert("", "end", values=row_values("—", trial))
            if ladder is None:
                self._board_status.configure(
                    text=f"RandomSearch over {estimator} ({task}) — "
                    f"{len(results.trials)} trial(s), objective {objective}; "
                    f"ranked by mean CV score, failed trials last"
                )
            else:
                r_min, r_max = ladder
                spent = sum(t.resource or 0.0 for t in results.trials)
                naive = len(results.trials) * r_max
                saved = 100.0 * (1.0 - spent / naive) if naive > 0 else 0.0
                self._board_status.configure(
                    text=f"Hyperband over {estimator} ({task}) — "
                    f"{len(results.trials)} trial(s), objective {objective} · "
                    f"η {eta}, resource {resource} {r_min}–{r_max} · "
                    f"budget {spent:g} of a naive {naive:g} {resource} "
                    f"({saved:.0f}% saved) · ranked by mean CV score, "
                    "failed trials last (promotions keep the top ⌈n/η⌉)"
                )

        self._start_job(f"tuning {estimator} ({task})", work, render)

    def _ml_tune_apply(self) -> None:
        """Carry the winning configuration forward (Apply best).

        ``ann`` / ``hsvr``: point the model combobox at the family so
        Train & evaluate picks it up (the registry's own defaults --
        the winning hyperparameters live in the leaderboard and the
        trials CSV).  ``dnn``: prefill the whole Deep Learning tab from
        the winning parameters (layers, dropout, learning rate,
        activation, batchnorm, epochs -- the hypermodel's own knobs) and
        switch to it, dataset included, so the loss curves and the
        report pipeline run on the exact winner.
        """
        if self._tune_last is None:
            messagebox.showwarning(
                "No search yet",
                "Run a hyperparameter search first -- Apply best carries "
                "the winning configuration of the last search forward.",
            )
            return
        results, estimator, task, target = self._tune_last
        params = results.best_params
        if estimator == "dnn":
            if not self._require("torch", "the Deep Learning tab"):
                return
            if self._ml_path is not None:
                self._dl_load_path(self._ml_path)
            if target in list(self._dl_target_combo["values"]):
                self._dl_target_combo.set(target)
            self._dl_task_combo.set(task)
            units = int(params.get("units", 64))
            n_layers = int(params.get("n_layers", 2))
            self._dl_hidden_entry.delete(0, "end")
            self._dl_hidden_entry.insert(0, ", ".join(str(units) for _ in range(n_layers)))
            self._dl_dropout.set(f"{float(params.get('dropout', 0.1)):g}")
            self._dl_lr_entry.delete(0, "end")
            self._dl_lr_entry.insert(0, f"{float(params.get('learning_rate', 1e-3)):g}")
            activation = str(params.get("activation", "relu"))
            if activation in _DL_ACTIVATIONS:
                self._dl_activation_combo.set(activation)
            self._dl_batchnorm_var.set(bool(params.get("batchnorm", False)))
            self._dl_epochs.set(str(int(params.get("epochs", 80))))
            self._dl_patience.set("10")  # the hypermodel's own fixed value
            self._tune_summary.configure(
                text="applied to the Deep Learning tab — hit Train & evaluate "
                "there for the loss curves and the report bundle"
            )
            with contextlib.suppress(tk.TclError):
                self._book.select(self._dl_page)
            return
        self._task_combo.set(task)
        self._refresh_model_choices(task)
        self._model_combo.set(estimator)
        self._ml_refresh_hyperparam_panel()
        # carry the winning configuration into the manual card too
        # (100x-106): every winner key that is a registry knob of the
        # family gets pinned, so the very next Train runs the winner
        # instead of the defaults.
        entries = getattr(self, "_ml_param_entries", {})
        filled = 0
        for key, entry in entries.items():
            if key in params:
                entry.delete(0, "end")
                entry.insert(0, str(params[key]))
                filled += 1
        self._ml_sync_params_var()
        self._ml_params_status.configure(
            text=f"{len(entries)} knob(s) · {filled} pinned from the winning "
            "configuration · hit Train & evaluate to refit at these values"
        )
        self._tune_summary.configure(
            text=f"applied — model set to {estimator}; hit Train & evaluate "
            "for the full report pipeline (the winning config: "
            + tune_config_text(params)
            + "; the manual hyperparameters card carries it)"
        )

    def _ml_tune_save_trials(self) -> None:
        """Write the last search's trials table (the CLI ``--out`` story)."""
        if not self._require_pharmaml() or not self._require("pandas", "the trials table"):
            return
        if self._tune_last is None:
            messagebox.showwarning(
                "No search yet",
                "Run a hyperparameter search first -- the trials table is "
                "the leaderboard's full record (score, std, every "
                "hyperparameter, failed flag).",
            )
            return
        if filedialog is None:  # pragma: no cover - headless fallback
            return
        path = filedialog.asksaveasfilename(
            title="Save the trials table",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if not path:
            return
        results, _estimator, _task, _target = self._tune_last
        try:
            from pharmaml.utils.io import write_table

            written = write_table(results.trials_frame(), Path(path))
        except Exception as exc:  # noqa: BLE001
            self._show_error("Could not write the trials table", exc)
            return
        self._job_label.configure(
            text=f"trials saved · {Path(written).name} ({len(results.trials)} rows)"
        )

    def _ml_compare(self) -> None:
        if not self._require_pharmaml():
            return
        if not self._require("pandas", "cross-validation") or not self._require(
            "sklearn", "cross-validation"
        ):
            return
        if self._ml_frame is None:
            messagebox.showwarning("No dataset", "Open a CSV or load an example first.")
            return
        target = self._target_combo.get()
        if not target:
            messagebox.showwarning("No target", "Pick the column to predict.")
            return
        # pre-flight (100x-62): the compare flow shares the rule -- a
        # zero-numeric-feature dataset fails before any CV job starts.
        numeric, dropped = numeric_feature_columns(self._ml_frame, target)
        if not numeric:
            messagebox.showwarning(
                "No numeric features",
                "Every non-target column is non-numeric"
                + (f" ({', '.join(dropped)})" if dropped else "")
                + ".  The models need numeric feature columns -- compute "
                "descriptors first (the Chemistry tab's feature factory).",
            )
            return
        task = self._task_combo.get()
        if task == "auto":
            task = self._infer_task(target)

        def work(report: Any) -> Any:
            from pharmaml.ml import compare_models

            frame = self._ml_frame
            y = frame[target]
            numeric, _dropped = numeric_feature_columns(frame, target)

            def on_model(info: dict[str, Any]) -> None:
                # one heartbeat per leaderboard row (100x-106): the
                # model name is the note, index/total the fraction.
                report(info["index"], info["total"], info["model"])

            return compare_models(frame[numeric], y, task, cv=3, n_jobs=1, on_model=on_model)

        def render(board: Any) -> None:
            self._board_frame = board
            self._board_tree.delete(*self._board_tree.get_children())
            columns = [str(column) for column in board.columns]
            self._board_tree["columns"] = columns
            for column in columns:
                self._board_tree.heading(column, text=column)
                self._board_tree.column(column, width=140, minwidth=80, stretch=True)
            for _, row in board.iterrows():
                self._board_tree.insert(
                    "", "end", values=[_cell_text(value, limit=30) for value in row.tolist()]
                )
            self._board_status.configure(
                text="3-fold CV over the available registry — the score column "
                "is the task's objective (higher is better)"
            )

        self._start_job(f"comparing models ({task})", work, render)

    # -- calibration + leaderboard figures (the 100x-119 review) ----- #
    def _ml_plot_calibration(self) -> None:
        """Reliability diagram of the last trained classifier."""
        run = getattr(self, "_ml_last_run", None)
        if run is None:
            messagebox.showinfo("No trained model", "Train a classification model first.")
            return
        trained, _report, task, _x_tr, _y_tr, x_test, y_test, target = run
        if task != "classification":
            messagebox.showinfo(
                "Classification only",
                f"The last run trained a {task} model — the reliability "
                "diagram needs predicted probabilities (a classifier).",
            )
            return
        if not self._require_pharmaml() or not self._require("matplotlib", "the calibration curve"):
            return
        try:
            bins = parse_int(self._calib_bins.get(), "calibration bins", minimum=2, maximum=20)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        def work() -> Any:
            from pharmaml.viz import plot_calibration_curve

            return plot_calibration_curve(
                trained.model,
                x_test,
                y_test,
                n_bins=bins,
                title=f"Calibration — {trained.name} ({target})",
            )

        def render(figure: Any) -> None:
            self._render_figure(self._ml_host, figure)
            self._ml_result_note.configure(
                text="reliability diagram replaces the parity figure — "
                "Train & evaluate brings it back"
            )

        self._start_job("calibration curve", work, render)

    def _ml_plot_leaderboard(self) -> None:
        """The compare-models leaderboard as a bar figure."""
        board = getattr(self, "_board_frame", None)
        if board is None:
            messagebox.showinfo(
                "No leaderboard yet",
                "Run Compare models first — the bar chart needs the cross-validated ranking table.",
            )
            return
        if not self._require_pharmaml() or not self._require("matplotlib", "the leaderboard bars"):
            return

        def work() -> Any:
            from pharmaml.viz import plot_model_comparison

            return plot_model_comparison(board, title="Cross-validated model leaderboard")

        def render(figure: Any) -> None:
            self._render_figure(self._board_host, figure)

        self._start_job("leaderboard bars", work, render)

    def _ml_plot_learning_curve(self) -> None:
        """Train-set size vs CV score for the last trained model (100x-120).

        ``plot_learning_curve`` gains its GUI surface: the last run's
        train+test rows are reassembled (the held-out rows are the most
        honest extra points the curve can have) and refit at growing
        train sizes -- the "should we assay more compounds?" figure.
        """
        run = getattr(self, "_ml_last_run", None)
        if run is None:
            messagebox.showinfo(
                "No trained model",
                "Train a model first -- the learning curve needs the last run's data.",
            )
            return
        trained, _report, _task, x_train, y_train, x_test, y_test, target = run
        if not self._require_pharmaml() or not self._require("matplotlib", "the learning curve"):
            return
        if not self._require("sklearn", "the learning curve"):
            return
        try:
            folds = parse_int(self._curve_cv.get(), "CV folds", minimum=2, maximum=10)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return
        model_name = trained.name

        def work() -> Any:
            import numpy as np
            import pandas as pd

            from pharmaml.viz import plot_learning_curve

            if isinstance(x_train, pd.DataFrame):
                full_x = pd.concat([x_train, x_test], ignore_index=True)
                full_y = pd.concat([pd.Series(y_train), pd.Series(y_test)], ignore_index=True)
            else:
                full_x = np.concatenate([np.asarray(x_train), np.asarray(x_test)], axis=0)
                full_y = np.concatenate([np.asarray(y_train), np.asarray(y_test)], axis=0)
            return plot_learning_curve(
                trained.model,
                full_x,
                full_y,
                cv=folds,
                title=f"Learning curve — {model_name} ({target})",
            )

        def render(figure: Any) -> None:
            self._render_figure(self._ml_host, figure)
            self._ml_result_note.configure(
                text="learning curve replaces the parity figure — Train & evaluate brings it back"
            )

        self._start_job("learning curve", work, render)

    # ------------------------------------------------------------------ #
    # Deep Learning tab (100x-61) -- the pharmaml.ml.neural estimators
    # ------------------------------------------------------------------ #
    def _build_dl_tab(self) -> None:
        page = self._new_page("Deep Learning")
        self._dl_page = page
        self._dl_frame = None
        self._dl_path = None
        self._dl_history: list[dict[str, Any]] = []
        self._dl_last_run: tuple[Any, str, str, Any, str] | None = None

        data = make_card(
            page.grid,
            "Dataset",
            span=2,
            row=0,
            column=0,
            subtitle="Any CSV the toolkit's read_table can sniff, or a "
            "bundled example. Features = the numeric columns "
            "except the target (same rule as the Data & ML tab).",
        )
        open_btn = self._action_button(data, "Open CSV…", self._dl_open_csv)
        open_btn.grid(row=0, column=0, sticky="w")
        example_files = [
            name
            for name in (
                "qsar_regression.csv",
                "qsar_classification.csv",
                "qsar_multiclass.csv",
            )
            if (EXAMPLES_DIR / name).is_file()
        ]
        self._dl_example_combo = ttk.Combobox(
            data, state="readonly", width=26, values=example_files
        )
        if example_files:
            self._dl_example_combo.set(example_files[0])
        self._dl_example_combo.grid(row=0, column=1, sticky="w", padx=(12, 0))
        load_btn = self._action_button(data, "Load example", self._dl_load_example)
        load_btn.grid(row=0, column=2, sticky="w", padx=(12, 0))
        self._dl_target_combo = ttk.Combobox(data, state="readonly", width=26)
        form_row(data, "target column", self._dl_target_combo)
        self._dl_task_combo = ttk.Combobox(
            data, state="readonly", width=26, values=("auto", "regression", "classification")
        )
        self._dl_task_combo.set("auto")
        form_row(data, "task", self._dl_task_combo)
        self._dl_info = ttk.Label(data, text="no dataset loaded", style="CardMuted.TLabel")
        self._dl_info.grid(row=3, column=0, columnspan=3, sticky="w", pady=(6, 0))

        preview = make_card(page.grid, "Preview (first 12 rows)", span=2, row=1, column=0)
        tree_frame = ttk.Frame(preview, style="Card.TFrame")
        grid_append(preview, tree_frame, sticky="nsew", weight=True)
        self._dl_preview_tree = ttk.Treeview(tree_frame, show="headings", height=8)
        preview_bar_x = ttk.Scrollbar(
            tree_frame, orient="horizontal", command=self._dl_preview_tree.xview
        )
        preview_bar_y = ttk.Scrollbar(
            tree_frame, orient="vertical", command=self._dl_preview_tree.yview
        )
        self._dl_preview_tree.configure(
            xscrollcommand=preview_bar_x.set, yscrollcommand=preview_bar_y.set
        )
        self._dl_preview_tree.pack(side="left", fill="both", expand=True)
        preview_bar_y.pack(side="right", fill="y")
        preview_bar_x.pack(side="bottom", fill="x")

        net = make_card(
            page.grid,
            "Network & training",
            span=2,
            row=2,
            column=0,
            subtitle="The pharmaml.ml.neural estimators: Adam with weight "
            "decay, per-feature standardisation and early stopping "
            "on a held-out validation fraction. Hidden layers are "
            "comma-separated widths -- empty = a single linear "
            "layer, the regularised baseline. Batch norm (1.2.36) "
            "inserts a BatchNorm1d between every hidden linear "
            "map and its activation.",
        )
        self._dl_arch_combo = ttk.Combobox(
            net, state="readonly", width=26, values=_DL_ARCHITECTURES
        )
        self._dl_arch_combo.set(_DL_ARCHITECTURES[0])
        form_row(net, "architecture", self._dl_arch_combo)
        self._dl_hidden_entry = ttk.Entry(net, width=16)
        self._dl_hidden_entry.insert(0, "64, 32")
        form_row(net, "hidden layers", self._dl_hidden_entry)
        self._dl_activation_combo = ttk.Combobox(
            net, state="readonly", width=16, values=_DL_ACTIVATIONS
        )
        self._dl_activation_combo.set("relu")
        form_row(net, "activation", self._dl_activation_combo)
        self._dl_dropout = ttk.Spinbox(net, from_=0.0, to=0.9, increment=0.05, width=10)
        self._dl_dropout.set("0.1")
        form_row(net, "dropout", self._dl_dropout)
        self._dl_epochs = ttk.Spinbox(net, from_=10, to=2000, increment=10, width=10)
        self._dl_epochs.set("150")
        form_row(net, "epochs (max)", self._dl_epochs)
        self._dl_batch = ttk.Spinbox(net, from_=1, to=512, increment=8, width=10)
        self._dl_batch.set("32")
        form_row(net, "batch size", self._dl_batch)
        self._dl_lr_entry = ttk.Entry(net, width=12)
        self._dl_lr_entry.insert(0, "0.001")
        form_row(net, "learning rate", self._dl_lr_entry)
        self._dl_wd_entry = ttk.Entry(net, width=12)
        self._dl_wd_entry.insert(0, "0.0")
        form_row(net, "weight decay", self._dl_wd_entry)
        self._dl_patience = ttk.Spinbox(net, from_=1, to=100, increment=1, width=10)
        self._dl_patience.set("15")
        form_row(net, "patience", self._dl_patience)
        self._dl_valsplit = ttk.Spinbox(net, from_=0.0, to=0.5, increment=0.05, width=10)
        self._dl_valsplit.set("0.15")
        form_row(net, "val split", self._dl_valsplit)
        self._dl_seed_entry = ttk.Entry(net, width=12)
        self._dl_seed_entry.insert(0, "42")
        form_row(net, "random seed", self._dl_seed_entry)
        self._dl_batchnorm_var = tk.BooleanVar(value=False)
        batchnorm_check = ttk.Checkbutton(
            net,
            text="batch normalisation between the hidden layers",
            variable=self._dl_batchnorm_var,
        )
        Tooltip(
            batchnorm_check,
            "batchnorm=True (1.2.36): a BatchNorm1d after every hidden "
            "linear map, before its activation -- residual blocks "
            "normalise BEFORE the skip add. Running statistics ride in "
            "the portable weight dict, so predict/pickle work unchanged. "
            "Needs batch size >= 2 (singleton tail batches are skipped "
            "with a debug log).",
        )
        form_row(net, "batch norm", batchnorm_check)
        buttons = ttk.Frame(net, style="Card.TFrame")
        buttons.grid(row=net.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(8, 0))
        train_btn = self._action_button(
            buttons,
            "Train & evaluate",
            self._dl_train,
            primary=True,
            tooltip="80/20 split, the estimator's own standardisation and "
            "stratified early stopping, then held-out metrics, the "
            "parity/confusion figure and the loss curves.",
        )
        train_btn.pack(side="left")
        check_btn = self._action_button(
            buttons,
            "Check CSV…",
            self._dl_check_csv,
            tooltip="Audit any CSV against the last trained network before "
            "predicting -- missing features, extra columns, "
            "reordering and version drift, all named (the ml check "
            "story, deep edition; the training target is dropped "
            "automatically when present).",
        )
        check_btn.pack(side="left", padx=(10, 0))

        results = make_card(page.grid, "Results", span=2, row=3, column=0)
        self._dl_metrics = ttk.Frame(results, style="Card.TFrame")
        grid_append(results, self._dl_metrics, sticky="ew")
        ttk.Label(
            self._dl_metrics, text="train a network to see metrics", style="CardMuted.TLabel"
        ).pack(anchor="w")
        # 100x-128: the per-card export -- this card had no button row
        # of its own until now (the train buttons live on the Network
        # card), so the Results card gets one.
        dl_save_row = ttk.Frame(results, style="Card.TFrame")
        grid_append(results, dl_save_row, sticky="w", pady=(6, 0))
        save_dl_figure_btn = self._action_button(
            dl_save_row,
            "Save figure…",
            self._save_dl_figure,
            tooltip="Save the figure this card is currently showing -- the "
            "parity plot or the confusion matrix of the last trained "
            "network -- as PNG, SVG or PDF (unlike Ctrl+S, which saves "
            "the last figure drawn anywhere).",
        )
        save_dl_figure_btn.pack(side="left")
        self._dl_host = self._figure_host(results, height=330)

        hist = make_card(
            page.grid,
            "Training history",
            span=2,
            row=4,
            column=0,
            subtitle="Per-epoch training/validation loss -- the "
            "early-stopping verdict rides on the figure title.",
        )
        self._dl_hist_summary = ttk.Label(
            hist, text="train a network to see the loss curves", style="CardMuted.TLabel"
        )
        grid_append(hist, self._dl_hist_summary, sticky="w")
        self._dl_hist_host = self._figure_host(hist, height=300)
        hist_buttons = ttk.Frame(hist, style="Card.TFrame")
        grid_append(hist, hist_buttons, sticky="w", pady=(6, 0))
        save_btn = self._action_button(
            hist_buttons,
            "Save history as CSV…",
            self._dl_save_history,
            tooltip="The exact per-epoch records the estimator kept -- "
            "epoch, train_loss, val_loss.",
        )
        save_btn.pack(side="left")
        ttk.Label(hist_buttons, text="CV folds", style="CardMuted.TLabel").pack(
            side="left", padx=(14, 4)
        )
        self._dl_cv_entry = ttk.Entry(hist_buttons, width=4)
        self._dl_cv_entry.insert(0, "5")
        self._dl_cv_entry.pack(side="left")
        curve_btn = self._action_button(
            hist_buttons,
            "Learning curve…",
            self._dl_plot_learning_curve,
            tooltip="plot_learning_curve over the FULL dataset (100x-121): "
            "training-set size vs CV score -- are more rows still "
            "buying accuracy?  The estimator clones refit with the "
            "network's own epochs, so a big curve takes its time.",
        )
        curve_btn.pack(side="left", padx=(10, 0))
        # 100x-128: the per-card export -- the history card holds TWO
        # figure hosts (loss curves + learning curve), newest wins.
        save_dl_hist_figure_btn = self._action_button(
            hist_buttons,
            "Save figure…",
            self._save_dl_history_figure,
            tooltip="Save the figure this card is currently showing -- the "
            "training loss curves or the learning curve, whichever "
            "drew last -- as PNG, SVG or PDF (unlike Ctrl+S, which "
            "saves the last figure drawn anywhere).",
        )
        save_dl_hist_figure_btn.pack(side="left", padx=(10, 0))
        self._dl_curve_host = self._figure_host(hist, height=300)

    def _dl_open_csv(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "CSV loading"):
            return
        path = filedialog.askopenfilename(
            title="Open a dataset",
            filetypes=[("Data files", "*.csv *.tsv *.txt"), ("All files", "*.*")],
        )
        if path:
            self._dl_load_path(Path(path))

    def _dl_load_example(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "CSV loading"):
            return
        name = self._dl_example_combo.get()
        path = EXAMPLES_DIR / name
        if not path.is_file():
            messagebox.showwarning("Missing example", f"{name} was not found.")
            return
        self._dl_load_path(path)

    def _dl_load_path(self, path: Path) -> None:
        try:
            from pharmaml.utils.io import read_table

            frame = read_table(path)
        except Exception as exc:  # noqa: BLE001
            self._show_error("Could not read the dataset", exc)
            return
        if frame.empty:
            messagebox.showwarning("Empty dataset", f"{path.name} has no rows.")
            return
        self._dl_frame = frame
        self._dl_path = path
        columns = [str(column) for column in frame.columns]
        self._dl_preview_tree.delete(*self._dl_preview_tree.get_children())
        self._dl_preview_tree["columns"] = columns
        for column in columns:
            self._dl_preview_tree.heading(column, text=column)
            self._dl_preview_tree.column(column, width=96, minwidth=64, stretch=True)
        for _, row in frame.head(12).iterrows():
            self._dl_preview_tree.insert(
                "", "end", values=[_cell_text(value) for value in row.tolist()]
            )
        self._dl_target_combo["values"] = columns
        self._dl_target_combo.set(default_target_column(frame) or columns[-1])
        self._dl_info.configure(text=f"{path.name} — {len(frame):,} rows × {len(columns)} columns")

    def _dl_train(self) -> None:
        if not self._require_pharmaml():
            return
        for module in ("pandas", "sklearn", "torch"):
            if not self._require(module, "network training"):
                return
        if self._dl_frame is None:
            messagebox.showwarning("No dataset", "Open a CSV or load an example first.")
            return
        target = self._dl_target_combo.get()
        if not target:
            messagebox.showwarning("No target", "Pick the column to predict.")
            return
        # pre-flight (100x-62): a dataset with zero numeric feature
        # columns used to surface as a mid-job DataValidationError --
        # catch it BEFORE the job starts, naming the dropped columns and
        # the remedy (the feature factory computes descriptors).
        numeric, dropped = numeric_feature_columns(self._dl_frame, target)
        if not numeric:
            messagebox.showwarning(
                "No numeric features",
                "Every non-target column is non-numeric"
                + (f" ({', '.join(dropped)})" if dropped else "")
                + ".  The estimators need numeric feature columns -- compute "
                "descriptors first (the Chemistry tab's feature factory).",
            )
            return
        try:
            hidden = parse_hidden_layers(self._dl_hidden_entry.get())
            learning_rate = parse_float(self._dl_lr_entry.get(), "learning rate", minimum=1e-8)
            weight_decay = parse_float(self._dl_wd_entry.get(), "weight decay", minimum=0.0)
            dropout = parse_float(self._dl_dropout.get(), "dropout", minimum=0.0, maximum=0.9)
            val_split = parse_float(self._dl_valsplit.get(), "val split", minimum=0.0, maximum=0.5)
            epochs = parse_int(self._dl_epochs.get(), "epochs", minimum=1)
            batch_size = parse_int(self._dl_batch.get(), "batch size", minimum=1)
            patience = parse_int(self._dl_patience.get(), "patience", minimum=1)
            seed = parse_int(self._dl_seed_entry.get(), "random seed", minimum=0)
        except ValueError as exc:
            messagebox.showwarning("Check the network settings", str(exc))
            return
        batchnorm = bool(self._dl_batchnorm_var.get())
        if batchnorm and batch_size < 2:
            # the estimator's own guard, surfaced before the job starts
            # (the GUI's pre-flight convention): BatchNorm1d cannot run on
            # single-row batches.
            messagebox.showwarning(
                "Batch norm needs batches",
                "Batch normalisation needs a batch size of at least 2 -- "
                "BatchNorm1d cannot estimate statistics from single rows. "
                "Raise the batch size or untick batch norm.",
            )
            return
        task = self._dl_task_combo.get()
        if task == "auto":
            task = self._infer_task(target, self._dl_frame)
        architecture = self._dl_arch_combo.get()
        activation = self._dl_activation_combo.get()
        estimator_name = deep_estimator_name(architecture, task)

        def work(notify: Any) -> Any:
            import time as _time

            from pharmaml.ml import evaluate_model, neural
            from pharmaml.ml.preprocessing import make_train_test_split

            def on_epoch(info: dict[str, Any]) -> None:
                # epoch/epochs drive the bar + ETA (100x-106); the
                # validation loss rides along once it exists.
                # (``notify`` -- not ``report`` -- because this work
                # function's own evaluation payload is named report.)
                if info.get("val_loss") is not None:
                    note = f"val_loss {info['val_loss']:.3g}"
                else:
                    note = f"train_loss {info['train_loss']:.3g}"
                notify(info["epoch"], info["epochs"], note)

            frame = self._dl_frame
            y = frame[target]
            numeric, dropped = numeric_feature_columns(frame, target)
            x_train, x_test, y_train, y_test = make_train_test_split(
                frame[numeric], y, random_state=seed
            )
            estimator_cls = getattr(neural, estimator_name)
            network = estimator_cls(
                hidden_layers=hidden,
                dropout=dropout,
                activation=activation,
                epochs=epochs,
                batch_size=batch_size,
                learning_rate=learning_rate,
                weight_decay=weight_decay,
                patience=patience,
                val_split=val_split,
                batchnorm=batchnorm,
                random_state=seed,
            )
            started = _time.perf_counter()
            network.fit(x_train, y_train, on_epoch=on_epoch)
            seconds = _time.perf_counter() - started
            report = evaluate_model(
                network,
                x_test,
                y_test,
                task,
                keep_predictions=(task == "regression"),
            )
            return network, report, task, dropped, y_test, seconds, x_test

        def render(payload: Any) -> None:
            network, report, task, dropped, y_test, seconds, x_test = payload
            self._dl_history = list(network.history_)
            # the audit state (100x-81): the fitted network plus the run's
            # feature contract -- set before the matplotlib guard so Check
            # CSV also works when plotting is unavailable.
            self._dl_last_run = (network, estimator_name, task, x_test, target)
            self._fill_dl_metrics(network, report, task, dropped, seconds)
            self._fill_dl_history_summary(network)
            if not self.deps.get("matplotlib"):
                return
            try:
                from pharmaml.viz import (
                    plot_confusion_matrix,
                    plot_predicted_vs_actual,
                    plot_training_history,
                )

                if task == "regression":
                    figure = plot_predicted_vs_actual(
                        y_test,
                        report.predictions,
                        metrics={
                            "R²": report.r2,
                            "RMSE": report.rmse,
                            "MAE": report.mae,
                        },
                    )
                else:
                    figure = plot_confusion_matrix(report.confusion, labels=report.labels)
                self._render_figure(self._dl_host, figure)
                history_figure = plot_training_history(
                    network.history_,
                    title=f"{type(network).__name__} · {target}",
                )
                self._render_figure(self._dl_hist_host, history_figure)
            except Exception as exc:  # noqa: BLE001
                self._show_error("Plot failed", exc)

        self._start_job(f"training {estimator_name} ({task})", work, render)

    def _fill_dl_metrics(
        self, network: Any, report: Any, task: str, dropped: list[str], seconds: float
    ) -> None:
        """Fill the Results card's metric grid for a finished deep run."""
        for child in self._dl_metrics.winfo_children():
            child.destroy()
        hidden = network.get_params()["hidden_layers"]  # the sklearn contract
        pairs = [
            ("network", f"{type(network).__name__} ({task})"),
            ("hidden layers", " × ".join(str(width) for width in hidden) or "linear (none)"),
            ("features", str(network.n_features_in_)),
        ]
        if task == "regression":
            pairs += [
                ("R²", format_number(getattr(report, "r2", float("nan")))),
                ("RMSE", format_number(report.rmse)),
                ("MAE", format_number(report.mae)),
            ]
        else:
            pairs += [
                ("accuracy", format_number(report.accuracy)),
                ("balanced accuracy", format_number(report.balanced_accuracy)),
                ("MCC", format_number(report.mcc)),
            ]
        best_val: float | None = None
        for entry in network.history_:
            value = entry.get("val_loss")
            if value is not None and (best_val is None or value < best_val):
                best_val = float(value)
        pairs += [
            ("epochs run", str(network.n_iter_)),
            ("best val loss", "n/a" if best_val is None else format_number(best_val)),
            ("fit time", f"{seconds:.2f} s"),
        ]
        if dropped:
            pairs.append(("dropped non-numeric", ", ".join(dropped)))
        for index, (name, value) in enumerate(pairs):
            ttk.Label(self._dl_metrics, text=name, style="CardMuted.TLabel").grid(
                row=index // 4, column=(index % 4) * 2, sticky="w", padx=(0, 6)
            )
            ttk.Label(
                self._dl_metrics, text=str(value), style="Field.TLabel", font=self._mono
            ).grid(row=index // 4, column=(index % 4) * 2 + 1, sticky="w", padx=(0, 18))

    def _fill_dl_history_summary(self, network: Any) -> None:
        """One muted line above the loss curves: what actually happened."""
        val_losses = [
            entry.get("val_loss") for entry in network.history_ if entry.get("val_loss") is not None
        ]
        if val_losses:
            self._dl_hist_summary.configure(
                text=f"{type(network).__name__} · {network.n_iter_} epochs run · "
                f"best val loss {format_number(min(val_losses))}"
            )
        else:
            self._dl_hist_summary.configure(
                text=f"{type(network).__name__} · {network.n_iter_} epochs run · "
                "no validation split (val split = 0)"
            )

    def _dl_save_history(self) -> None:
        if not self._dl_history:
            messagebox.showinfo("Nothing to save", "Train a network first.")
            return
        import pandas as pd

        frame = pd.DataFrame(self._dl_history)
        self._save_frame_dialog(
            frame, "Save training history", "dl_history.csv", "Training history"
        )

    def _dl_plot_learning_curve(self) -> None:
        """Training-set size vs CV score for the last network (100x-121).

        The deep twin of the ML Results card's learning curve: the same
        ``plot_learning_curve`` over the FULL dataset (train + test rows
        re-joined), the estimator cloned per fold exactly like the
        sklearn registry models -- "should we assay more compounds?"
        answered with a curve, not a single CV number.
        """
        if self._dl_last_run is None:
            messagebox.showinfo("No network", "Train a network first.")
            return
        if not self._require_pharmaml() or not self._require("matplotlib", "the learning curve"):
            return
        network, _name, _task, _x_test, target = self._dl_last_run
        frame = self._dl_frame
        if frame is None or target not in frame.columns:
            messagebox.showinfo("No dataset", "Open the training CSV again.")
            return
        try:
            folds = parse_int(self._dl_cv_entry.get(), "CV folds", minimum=2, maximum=10)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return
        numeric, _dropped = numeric_feature_columns(frame, target)
        if not numeric:
            messagebox.showwarning(
                "No numeric features", "The dataset no longer has numeric feature columns."
            )
            return
        x_full = frame[numeric]
        y_full = frame[target]

        def work() -> Any:
            from pharmaml.viz import plot_learning_curve

            return plot_learning_curve(
                network,
                x_full,
                y_full,
                cv=folds,
                title=(
                    f"Learning curve — {type(network).__name__} · "
                    f"{len(x_full)} rows × {len(numeric)} features · "
                    f"{folds}-fold CV"
                ),
            )

        def render(figure: Any) -> None:
            self._render_figure(self._dl_curve_host, figure)

        self._start_job("deep learning curve", work, render)

    def _dl_check_csv(self) -> None:
        """Audit any CSV against the last trained network (``ml check``).

        The deep twin of ``_ml_check_csv`` (100x-79): the neural
        estimators satisfy the same sklearn contract -- ``n_features_in_``
        and ``feature_names_in_`` recorded at fit, joblib-serialisable --
        so :func:`validate_bundle_input` audits them exactly like the
        registry models.  The handler reads the chosen file, drops the
        training target column when the CSV still carries it (the GUI's
        automatic ``--target``), writes a throwaway bundle from the
        stored run inside a temp directory and renders the verdict:
        missing features, extra columns, reordering and version drift,
        every difference named.  The temp bundle is deleted with its
        directory; nothing touches the user's tree.
        """
        if not self._require_pharmaml() or not self._require("pandas", "CSV auditing"):
            return
        if self._dl_last_run is None:
            messagebox.showwarning(
                "No run yet",
                "Train a network first -- the audit checks a new dataset "
                "against the model bundle of the last run.",
            )
            return
        if filedialog is None:  # pragma: no cover - headless fallback
            return
        chosen = filedialog.askopenfilename(
            title="Choose the dataset to audit",
            filetypes=[("Data files", "*.csv *.tsv *.txt"), ("All files", "*.*")],
        )
        if not chosen:
            return
        path = Path(chosen)
        network, estimator_name, task, x_test, train_target = self._dl_last_run

        def work() -> Any:
            import tempfile

            from pharmaml.ml import save_model, validate_bundle_input
            from pharmaml.utils.io import read_table

            frame = read_table(path)
            if train_target and train_target in frame.columns:
                # the automatic --target: re-auditing the very CSV the
                # network was trained on works out of the box.
                frame = frame.drop(columns=[train_target])
            with tempfile.TemporaryDirectory() as tmp:
                bundle = Path(tmp) / "playground_model.joblib"
                save_model(
                    network,
                    bundle,
                    name=estimator_name,
                    task=task,
                    features=list(x_test.columns),
                )
                return validate_bundle_input(bundle, frame)

        def render(audit: Any) -> None:
            verdict = "OK" if audit.ok else "FAIL"
            self._job_label.configure(text=f"audit: {verdict} · {path.name}")
            message = (
                f"{path.name} vs the {estimator_name} bundle:\n\n{audit}\n\n"
                "The CLI twin:\n"
                "  pharmaml ml check --model <bundle> --data "
                f"{path.name}"
            )
            if train_target:
                message += f" --target {train_target}"
            messagebox.showinfo(f"Dataset audit: {verdict}", message)

        self._start_job(f"auditing {path.name}", work, render)

    # ------------------------------------------------------------------ #
    # Generative tab
    # ------------------------------------------------------------------ #
    def _build_generative_tab(self) -> None:
        page = self._new_page("Generative")

        corpus = make_card(
            page.grid,
            "Corpus / seed molecules",
            row=0,
            column=0,
            subtitle="One SMILES per line. Empty text = the bundled 244-molecule drug-like corpus.",
        )
        self._corpus_text = _grid_text(corpus, height=9, mono=self._mono)
        grid_append(corpus, self._corpus_text, sticky="nsew", weight=True)
        corpus_buttons = ttk.Frame(corpus, style="Card.TFrame")
        grid_append(corpus, corpus_buttons, sticky="w", pady=(6, 0))
        example_btn = self._action_button(
            corpus_buttons,
            "Load example corpus",
            self._load_example_corpus,
            tooltip="The 12 seed molecules shipped in examples/data.",
        )
        example_btn.pack(side="left")
        clear_btn = self._action_button(
            corpus_buttons,
            "Clear (built-in corpus)",
            lambda: self._corpus_text.delete("1.0", "end"),
        )
        clear_btn.pack(side="left", padx=(10, 0))
        self._seed_mode_var = tk.BooleanVar(value=False)
        seed_check = ttk.Checkbutton(
            corpus,
            text="treat the lines as seed molecules (seeded mode; otherwise they are "
            "the sampling pool)",
            variable=self._seed_mode_var,
        )
        grid_append(corpus, seed_check, pady=(4, 0))

        controls = make_card(page.grid, "Objective & evolution", row=0, column=1)
        self._objective_combo = ttk.Combobox(
            controls, state="readonly", width=26, values=_OBJECTIVE_KINDS
        )
        self._objective_combo.set(_OBJECTIVE_KINDS[0])
        self._objective_combo.bind("<<ComboboxSelected>>", self._objective_hint)
        form_row(controls, "objective", self._objective_combo)
        self._obj_lo = ttk.Entry(controls, width=12)
        self._obj_lo.insert(0, "1.0")
        form_row(controls, "window low", self._obj_lo)
        self._obj_hi = ttk.Entry(controls, width=12)
        self._obj_hi.insert(0, "3.0")
        form_row(controls, "window high", self._obj_hi)
        # (100x-122) the reference row for the three new objectives: a
        # SMILES seed (similarity) or a SMARTS pattern (substructure).
        # Swapped out exactly like the GA/RL frames below -- grid_remove
        # collapses the row, re-grid restores the remembered position.
        obj_ref_frame = ttk.Frame(controls, style="Card.TFrame")
        grid_append(controls, obj_ref_frame, sticky="ew")
        obj_ref_frame.columnconfigure(1, weight=1)
        self._obj_ref_label = ttk.Label(obj_ref_frame, text="reference", style="Field.TLabel")
        self._obj_ref_label.grid(row=0, column=0, sticky="w", pady=(3, 2))
        self._obj_ref = ttk.Entry(obj_ref_frame, width=26)
        self._obj_ref.insert(0, "CC(=O)Oc1ccccc1C(=O)O")  # aspirin
        self._obj_ref.grid(row=0, column=1, sticky="ew", pady=(3, 2))
        Tooltip(
            self._obj_ref,
            "Similarity objective: the reference molecule.  Substructure "
            "objective: the required SMARTS (e.g. c1ccccc1 for any "
            "benzene ring).  Other objectives ignore this row.",
        )
        obj_ref_frame.grid_remove()  # window objectives do not need it
        self._obj_ref_frame = obj_ref_frame
        self._objective_hint_label = ttk.Label(
            controls, text="", style="CardMuted.TLabel", wraplength=280, justify="left"
        )
        self._objective_hint_label.grid(
            row=controls.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(2, 4)
        )
        self._objective_hint()
        # the optimiser itself: the GA (structure-space search) or the RL
        # policy-gradient fine-tuning of an on-the-fly SMILES RNN prior
        self._method_combo = ttk.Combobox(
            controls,
            state="readonly",
            width=26,
            values=("genetic algorithm", "reinforcement learning (RL)"),
        )
        self._method_combo.set("genetic algorithm")
        self._method_combo.bind("<<ComboboxSelected>>", self._on_method_change)
        form_row(controls, "optimiser", self._method_combo)
        # GA-specific rows live in their own frame so the RL selection can
        # swap the whole block out (grid_remove collapses the row; re-grid
        # restores the remembered position -- the card never reshuffles)
        ga_frame = ttk.Frame(controls, style="Card.TFrame")
        grid_append(controls, ga_frame, sticky="ew")
        ga_frame.columnconfigure(1, weight=1)
        self._pop_size = ttk.Spinbox(ga_frame, from_=8, to=96, increment=4, width=10)
        self._pop_size.set("24")
        form_row(ga_frame, "population", self._pop_size)
        self._generations = ttk.Spinbox(ga_frame, from_=4, to=48, increment=4, width=10)
        self._generations.set("16")
        form_row(ga_frame, "generations", self._generations)
        self._mutation_combo = ttk.Combobox(
            ga_frame, state="readonly", width=18, values=("uniform", "scaffold", "topology")
        )
        self._mutation_combo.set("topology")
        form_row(ga_frame, "mutation", self._mutation_combo)
        self._crossover_combo = ttk.Combobox(
            ga_frame, state="readonly", width=18, values=("splice", "scaffold_hop")
        )
        self._crossover_combo.set("splice")
        form_row(ga_frame, "crossover", self._crossover_combo)
        self._operator_combo = ttk.Combobox(
            ga_frame, state="readonly", width=18, values=("uniform", "adaptive")
        )
        self._operator_combo.set("uniform")
        form_row(ga_frame, "operator selection", self._operator_combo)
        # RL-specific rows: swapped in when the optimiser combo says RL
        rl_frame = ttk.Frame(controls, style="Card.TFrame")
        grid_append(controls, rl_frame, sticky="ew")
        rl_frame.columnconfigure(1, weight=1)
        self._rl_iterations = ttk.Spinbox(rl_frame, from_=2, to=60, increment=2, width=10)
        self._rl_iterations.set("12")
        form_row(rl_frame, "iterations", self._rl_iterations)
        self._rl_batch = ttk.Spinbox(rl_frame, from_=8, to=64, increment=8, width=10)
        self._rl_batch.set("16")
        form_row(rl_frame, "batch size", self._rl_batch)
        self._rl_prior_epochs = ttk.Spinbox(rl_frame, from_=1, to=16, increment=1, width=10)
        self._rl_prior_epochs.set("8")
        Tooltip(
            self._rl_prior_epochs,
            "Epochs for the on-the-fly SMILES prior -- 8 is the library "
            "default; fewer than ~6 undertrains it and the agent mostly "
            "samples invalid strings (the run reports no valid molecules).",
        )
        form_row(rl_frame, "prior epochs", self._rl_prior_epochs)
        self._rl_anchor = ttk.Entry(rl_frame, width=12)
        self._rl_anchor.insert(0, "0.1")
        form_row(rl_frame, "anchor weight", self._rl_anchor)
        rl_frame.grid_remove()  # the GA rows are the default
        self._rl_frame = rl_frame
        self._ga_frame = ga_frame
        self._ga_seed = ttk.Entry(controls, width=12)
        self._ga_seed.insert(0, "42")
        form_row(controls, "random seed", self._ga_seed)
        run_btn = self._action_button(
            controls,
            "Run evolution",
            self._run_evolution,
            primary=True,
            tooltip="Runs in a worker thread; results appear below "
            "with the leaderboard (and the learning curve "
            "when adaptive).",
        )
        run_btn.grid(row=controls.grid_size()[1], column=0, columnspan=2, sticky="w", pady=(8, 0))

        results = make_card(page.grid, "Results", span=2, row=1, column=0)
        self._ga_summary = ttk.Label(
            results,
            text="no run yet — pick an objective and press Run evolution",
            style="CardMuted.TLabel",
            wraplength=640,
        )
        grid_append(results, self._ga_summary)
        tree_frame = ttk.Frame(results, style="Card.TFrame")
        grid_append(results, tree_frame, sticky="nsew", weight=True)
        self._ga_tree = ttk.Treeview(tree_frame, show="headings", height=8)
        ga_bar = ttk.Scrollbar(tree_frame, orient="vertical", command=self._ga_tree.yview)
        self._ga_tree.configure(yscrollcommand=ga_bar.set)
        self._ga_tree.pack(side="left", fill="both", expand=True)
        ga_bar.pack(side="right", fill="y")
        self._ga_stats_text = _grid_text(results, height=7, mono=self._mono)
        self._ga_stats_text.insert("1.0", "operator statistics appear here on adaptive runs")
        grid_append(results, self._ga_stats_text, sticky="ew", pady=(4, 0))
        stats_buttons = ttk.Frame(results, style="Card.TFrame")
        grid_append(results, stats_buttons, sticky="w", pady=(4, 0))
        save_btn = self._action_button(
            stats_buttons, "Save leaderboard as CSV…", self._save_ga_leaderboard
        )
        save_btn.pack(side="left")
        # (100x-124) the leaderboard's top rows as 2D structures -- the
        # ranked molecules become visible, each panel carrying its
        # total score as a dedicated score row.
        draw_top_btn = self._action_button(
            stats_buttons,
            "Draw top molecules",
            self._gen_draw_top,
            tooltip="A 2D structure panel per leaderboard row (top 12, rank 1 "
            "first) with each molecule's score under it -- the run's "
            "ranking becomes visible, not just tabulated.",
        )
        draw_top_btn.pack(side="left", padx=(10, 0))
        # (100x-127) the per-card export the Pareto card shipped in round
        # 126, now on the Results card too -- the ONLY card with two
        # figure hosts, so the save takes whichever of the card's own
        # figures drew last (grid or history), never the global
        # Ctrl+S last-drawn-anywhere figure.
        save_ga_figure_btn = self._action_button(
            stats_buttons,
            "Save figure…",
            self._save_ga_figure,
            tooltip="Save the figure this card is currently showing -- the "
            "leaderboard structure grid or the evolution history, "
            "whichever drew last -- as PNG, SVG or PDF (unlike Ctrl+S, "
            "which saves the last figure drawn anywhere).",
        )
        save_ga_figure_btn.pack(side="left", padx=(10, 0))
        self._ga_grid_host = self._figure_host(results, height=380)
        self._ga_host = self._figure_host(results, height=340)

        # -- Pareto front card (100x-58) ------------------------------ #
        pareto = make_card(
            page.grid,
            "Pareto front",
            span=2,
            row=2,
            column=0,
            subtitle="Molecules no other candidate dominates — the trade-offs "
            "a blended leaderboard hides. Filled after every "
            "multi-objective run.",
        )
        self._pareto_summary = ttk.Label(
            pareto,
            text="no multi-objective run yet — pick 'QED + LogP blend' or "
            "'Multi-objective (QED × MW × TPSA)' and press Run evolution",
            style="CardMuted.TLabel",
            wraplength=640,
            justify="left",
        )
        grid_append(pareto, self._pareto_summary)
        pareto_tree_frame = ttk.Frame(pareto, style="Card.TFrame")
        grid_append(pareto, pareto_tree_frame, sticky="nsew", weight=True)
        self._pareto_tree = ttk.Treeview(pareto_tree_frame, show="headings", height=6)
        pareto_bar = ttk.Scrollbar(
            pareto_tree_frame, orient="vertical", command=self._pareto_tree.yview
        )
        self._pareto_tree.configure(yscrollcommand=pareto_bar.set)
        self._pareto_tree.pack(side="left", fill="both", expand=True)
        pareto_bar.pack(side="right", fill="y")
        pareto_buttons = ttk.Frame(pareto, style="Card.TFrame")
        grid_append(pareto, pareto_buttons, sticky="w", pady=(6, 0))
        ttk.Label(pareto_buttons, text="plot", style="Field.TLabel").pack(side="left")
        self._pareto_x_combo = ttk.Combobox(pareto_buttons, state="readonly", width=14, values=())
        self._pareto_x_combo.pack(side="left", padx=(6, 3))
        ttk.Label(pareto_buttons, text="×", style="CardMuted.TLabel").pack(side="left")
        self._pareto_y_combo = ttk.Combobox(pareto_buttons, state="readonly", width=14, values=())
        self._pareto_y_combo.pack(side="left", padx=(3, 6))
        plot_front_btn = self._action_button(
            pareto_buttons,
            "Plot front",
            self._plot_pareto_front,
            tooltip="Scatter of the two selected objectives: dominated molecules "
            "muted, the front highlighted and connected.",
        )
        plot_front_btn.pack(side="left")
        save_front_btn = self._action_button(
            pareto_buttons, "Save front as CSV…", self._save_pareto_front
        )
        save_front_btn.pack(side="left", padx=(10, 0))
        # (100x-125) the front's molecules as 2D structure panels -- the
        # table and the scatter kept them invisible until now.  Boundary
        # corners accented, interior trade-offs muted; each panel's score
        # row carries the member's objective values.
        draw_front_btn = self._action_button(
            pareto_buttons,
            "Draw front",
            self._gen_draw_front,
            tooltip="The front's molecules as 2D structure panels, boundary "
            "corners (best/worst on some objective) accented and interior "
            "trade-offs muted, objective values under each panel -- Plot "
            "front brings the scatter back.",
        )
        draw_front_btn.pack(side="left", padx=(10, 0))
        # (100x-126) the front card had no per-card export: the colour
        # grid (or the scatter) could only leave the app through the
        # global Ctrl+S path, which silently saves whatever figure drew
        # LAST anywhere.  This button saves the figure THIS card shows.
        save_front_figure_btn = self._action_button(
            pareto_buttons,
            "Save figure…",
            self._save_pareto_figure,
            tooltip="Save the figure this card is currently showing -- the "
            "colour-coded structure grid or the objective scatter, "
            "whichever drew last -- as PNG, SVG or PDF (unlike Ctrl+S, "
            "which saves the last figure drawn anywhere).",
        )
        save_front_figure_btn.pack(side="left", padx=(10, 0))
        self._pareto_host = self._figure_host(pareto, height=300)

        # (100x-122) molecule surgery -- the two standalone what-if tools
        # the GA absorbed until now: enumerate one molecule's ring-size
        # move set, or breed two parents with the scaffold-hop crossover
        # (the same operator the GA's crossover combobox selects).
        moves = make_card(
            page.grid,
            "Ring topology moves",
            row=3,
            column=0,
            subtitle="Every distinct one-step ring-size mutant of one "
            "molecule — contraction and expansion over each "
            "saturated ring (fused/spiro rings are never touched).",
        )
        self._topo_smiles = ttk.Entry(moves, width=30)
        self._topo_smiles.insert(0, "C1CCNCC1")  # piperidine: 3 mutants
        form_row(moves, "molecule", self._topo_smiles)
        moves_buttons = ttk.Frame(moves, style="Card.TFrame")
        grid_append(moves, moves_buttons, sticky="w", pady=(6, 0))
        enumerate_btn = self._action_button(
            moves_buttons,
            "Enumerate mutants",
            self._gen_topology_moves,
            tooltip="One line per mutant, most first — the exact move set "
            "the GA's 'topology' mutation draws from.",
        )
        enumerate_btn.pack(side="left")
        # (100x-123) the mutants' structures, not just their SMILES --
        # a 2D panel per mutant makes the ring-size change visible.
        draw_topo_btn = self._action_button(
            moves_buttons,
            "Draw mutants",
            self._gen_draw_topology,
            tooltip="A 2D structure panel per enumerated mutant (RDKit "
            "drawing) — the contraction/expansion becomes visible "
            "instead of a line of text.",
        )
        draw_topo_btn.pack(side="left", padx=(10, 0))
        # (100x-127) the per-card figure export -- the mutant grid leaves
        # the app through this card's own button, not just the global
        # Ctrl+S (which would silently save some other card's figure).
        save_topo_figure_btn = self._action_button(
            moves_buttons,
            "Save figure…",
            self._save_topo_figure,
            tooltip="Save the mutant structure grid this card is currently "
            "showing as PNG, SVG or PDF (unlike Ctrl+S, which saves the "
            "last figure drawn anywhere).",
        )
        save_topo_figure_btn.pack(side="left", padx=(10, 0))
        self._topo_summary = ttk.Label(
            moves, text="no enumeration yet", style="Field.TLabel", wraplength=300, justify="left"
        )
        grid_append(moves, self._topo_summary, pady=(6, 0))
        self._topo_text = _grid_text(moves, height=6, mono=self._mono)
        self._topo_host = self._figure_host(moves, height=320)

        breed = make_card(
            page.grid,
            "Breed two molecules",
            row=3,
            column=1,
            subtitle="Scaffold-hop crossover: homologous cuts on two parents "
            "breed hybrid children — bridge, ring-merge and linker "
            "transplant geometries compete for each draw.",
        )
        self._breed_a = ttk.Entry(breed, width=30)
        self._breed_a.insert(0, "CC(=O)Oc1ccccc1C(=O)O")  # aspirin
        form_row(breed, "parent A", self._breed_a)
        self._breed_b = ttk.Entry(breed, width=30)
        self._breed_b.insert(0, "CC(C)Cc1ccc(O)cc1")  # ibuprofen core
        form_row(breed, "parent B", self._breed_b)
        self._breed_count = ttk.Spinbox(breed, from_=1, to=8, increment=1, width=8)
        self._breed_count.set("4")
        form_row(breed, "children", self._breed_count)
        self._breed_seed = ttk.Entry(breed, width=10)
        self._breed_seed.insert(0, "42")
        form_row(breed, "random seed", self._breed_seed)
        breed_buttons = ttk.Frame(breed, style="Card.TFrame")
        grid_append(breed, breed_buttons, sticky="w", pady=(6, 0))
        breed_btn = self._action_button(
            breed_buttons,
            "Breed",
            self._gen_breed,
            primary=True,
            tooltip="Each child is one crossover draw from the seeded rng — "
            "change the seed for a different litter.  A draw can "
            "honestly fail (no viable cut pair) and says so.",
        )
        breed_btn.pack(side="left")
        # (100x-123) parents and children side by side — the hybrid
        # geometry of each crossover draw becomes visible.
        draw_breed_btn = self._action_button(
            breed_buttons,
            "Draw litter",
            self._gen_draw_breed,
            tooltip="One 2D panel per parent and per viable child (RDKit "
            "drawing) — the bridge / ring-merge / linker-transplant "
            "geometry of each draw becomes visible.",
        )
        draw_breed_btn.pack(side="left", padx=(10, 0))
        # (100x-127) the per-card figure export -- parents-and-litter
        # grid out through this card's own button, same honest contract
        # as the other figure cards.
        save_breed_figure_btn = self._action_button(
            breed_buttons,
            "Save figure…",
            self._save_breed_figure,
            tooltip="Save the parents-and-children structure grid this card "
            "is currently showing as PNG, SVG or PDF (unlike Ctrl+S, "
            "which saves the last figure drawn anywhere).",
        )
        save_breed_figure_btn.pack(side="left", padx=(10, 0))
        self._breed_summary = ttk.Label(
            breed, text="no children yet", style="Field.TLabel", wraplength=300, justify="left"
        )
        grid_append(breed, self._breed_summary, pady=(6, 0))
        self._breed_text = _grid_text(breed, height=6, mono=self._mono)
        self._breed_host = self._figure_host(breed, height=420)

    def _objective_hint(self, _event: Any = None) -> None:
        kind = self._objective_combo.get()
        hints = {
            "QED drug-likeness": "QED weights eight drug-likeness properties; the window "
            "values are ignored.",
            "LogP window": "Scores 1 inside the [low, high] LogP window, falling off outside.",
            "Molecular weight window": "Target a molecular-weight band (e.g. 250–450).",
            "TPSA window": "Target a polar-surface-area band (e.g. 40–90 Å²).",
            "QED + LogP blend": "0.7 × QED + 0.3 × the LogP window.",
            "Multi-objective (QED \u00d7 MW \u00d7 TPSA)": "Equal-weight triple (MW 150–450, TPSA 30–90); the Pareto "
            "front card below shows the trade-offs the blend hides.",
            "Similarity to reference SMILES": "Tanimoto similarity (Morgan) to the reference molecule — "
            "analog exploration: stay close, let the operators vary "
            "the rest.  Window values are ignored.",
            "Novelty vs corpus": "1 − the best Tanimoto against the corpus above (built-in "
            "corpus when empty): pushes evolution away from known "
            "structures.  Window values are ignored.",
            "Contains substructure (SMARTS)": "A hard pharmacophore constraint: 1.0 when the SMARTS "
            "matches, 0.0 otherwise.  Window values are ignored.",
        }
        self._objective_hint_label.configure(text=hints.get(kind, ""))
        # (100x-122) swap the reference row in only for the objectives
        # that need it; the label names what to type (same grid_remove
        # collapse as the GA/RL frames in _on_method_change).
        ref_label = _OBJECTIVE_REFERENCE_KINDS.get(kind)
        if ref_label is None:
            self._obj_ref_frame.grid_remove()
        else:
            self._obj_ref_label.configure(text=ref_label)
            self._obj_ref_frame.grid()

    def _load_example_corpus(self) -> None:
        path = EXAMPLES_DIR / "seed_molecules.csv"
        if not path.is_file():
            messagebox.showinfo(
                "Example missing", "examples/data/seed_molecules.csv was not found."
            )
            return
        with path.open(newline="", encoding="utf-8") as handle:
            smiles = [(row.get("smiles") or "").strip() for row in csv.DictReader(handle)]
        smiles = [entry for entry in smiles if entry]
        self._corpus_text.delete("1.0", "end")
        self._corpus_text.insert("1.0", "\n".join(smiles))

    # -- molecule surgery (100x-122) ---------------------------------- #
    def _gen_topology_moves(self) -> None:
        """Enumerate one molecule's one-step ring-size mutants."""
        if not self._require_pharmaml() or not self._require("rdkit", "ring topology moves"):
            return
        smiles = self._topo_smiles.get().strip()
        if not smiles:
            messagebox.showerror("Input", "Type a SMILES in the molecule row first.")
            return

        def work() -> Any:
            from pharmaml.generative import ring_topology_moves

            return ring_topology_moves(smiles), smiles

        def render(payload: tuple[list[str], str]) -> None:
            mutants, source = payload
            self._topo_last = (source, mutants)
            self._topo_text.delete("1.0", "end")
            self._topo_text.insert("1.0", "\n".join(mutants))
            if mutants:
                self._topo_summary.configure(
                    text=(
                        f"{len(mutants)} distinct one-step ring-size "
                        f"mutant(s) of {source} — contraction and "
                        f"expansion candidates, sorted."
                    ),
                    style="Field.TLabel",
                )
            else:
                self._topo_summary.configure(
                    text=(
                        f"{source} has no qualifying saturated ring — "
                        f"aromatic or fused/spiro rings are never "
                        f"re-sized, and acyclic molecules have no moves."
                    ),
                    style="Field.TLabel",
                )

        self._start_job("ring topology moves", work, render)

    def _gen_breed(self) -> None:
        """Breed children from two parents via scaffold-hop crossover."""
        if not self._require_pharmaml() or not self._require("rdkit", "scaffold-hop crossover"):
            return
        try:
            parent_a = self._breed_a.get().strip()
            parent_b = self._breed_b.get().strip()
            if not parent_a or not parent_b:
                raise ValueError("both parent SMILES are required")
            children = parse_int(self._breed_count.get(), "children", minimum=1, maximum=8)
            seed = parse_int(self._breed_seed.get(), "seed", minimum=0)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        def work() -> Any:
            import random

            from pharmaml.generative import scaffold_hop_crossover

            rng = random.Random(seed)
            litter: list[str | None] = []
            for _ in range(children):
                litter.append(scaffold_hop_crossover(parent_a, parent_b, rng))
            return litter, children

        def render(payload: tuple[list[str | None], int]) -> None:
            litter, count = payload
            viable = [child for child in litter if child]
            self._breed_last = (parent_a, parent_b, litter)
            self._breed_text.delete("1.0", "end")
            lines = [child if child else "(no viable crossover on this draw)" for child in litter]
            self._breed_text.insert("1.0", "\n".join(lines))
            self._breed_summary.configure(
                text=(
                    f"{len(viable)}/{count} viable children — bridge / "
                    f"ring-merge / linker-transplant cuts competed for "
                    f"each draw (seed {seed})."
                ),
                style="Field.TLabel",
            )

        self._start_job("scaffold-hop crossover", work, render)

    def _gen_draw_topology(self) -> None:
        """Draw the last enumerated ring-size mutants as structures."""
        last = getattr(self, "_topo_last", None)
        if last is None:
            messagebox.showinfo(
                "No enumeration yet",
                "Enumerate mutants first -- the structure grid draws the "
                "last move set (a new enumeration replaces it).",
            )
            return
        if not self._require_pharmaml() or not self._require(
            "matplotlib", "the mutant structure grid"
        ):
            return
        source, mutants = last

        def work() -> Any:
            entries = [
                (
                    f"mutant {index + 1}\n{_truncate_caption_text(smiles)}",
                    smiles,
                )
                for index, smiles in enumerate(mutants)
            ]
            return molecule_grid_figure(
                entries,
                title=(
                    f"Ring topology moves — {len(mutants)} mutant(s) of "
                    f"{_truncate_caption_text(source, 28)}"
                ),
            )

        def render(figure: Any) -> None:
            self._render_figure(self._topo_host, figure)

        self._start_job("mutant structure grid", work, render)

    def _gen_draw_top(self) -> None:
        """Draw the leaderboard's top molecules as a 2D structure grid.

        (100x-124) The Results card tabulated the top 20 rows as text;
        the molecules themselves stayed invisible.  The grid takes the
        last run's ranked frame (rank 1 first), keeps twelve panels,
        and carries each row's total score as the panel's score row --
        the objective's ranking becomes visible, not just listed.
        """
        if self._ga_result is None:
            messagebox.showinfo(
                "No run yet",
                "Run an evolution first -- the structure grid draws the "
                "leaderboard's top molecules (a new run replaces it).",
            )
            return
        if not self._require_pharmaml() or not self._require(
            "rdkit", "the top-molecule grid"
        ) or not self._require("matplotlib", "the top-molecule grid"):
            return

        def work() -> Any:
            frame = self._ga_result.to_dataframe()
            top = frame.head(12)
            entries: list[tuple[str, str]] = []
            scores: list[str] = []
            for row in top.itertuples(index=False):
                cells = row._asdict()
                rank = cells.get("rank")
                smiles = str(cells.get("smiles", ""))
                score = cells.get("score")
                entries.append(
                    (f"#{rank} · {_truncate_caption_text(smiles, 26)}", smiles)
                )
                try:
                    scores.append(f"score {float(score):.3f}")
                except (TypeError, ValueError):
                    scores.append("score —")
            return molecule_grid_figure(
                entries,
                title=(
                    f"Top {len(entries)} molecules — the last run's leaderboard "
                    "(rank 1 first)"
                ),
                scores=scores,
            )

        def render(figure: Any) -> None:
            self._render_figure(self._ga_grid_host, figure)

        self._start_job("top-molecule structure grid", work, render)

    def _gen_draw_breed(self) -> None:
        """Draw the parents and viable children of the last litter."""
        last = getattr(self, "_breed_last", None)
        if last is None:
            messagebox.showinfo(
                "No litter yet",
                "Breed two molecules first -- the structure grid draws the "
                "last litter (a new breed replaces it).",
            )
            return
        if not self._require_pharmaml() or not self._require(
            "matplotlib", "the litter structure grid"
        ):
            return
        parent_a, parent_b, litter = last
        viable = [child for child in litter if child]

        def work() -> Any:
            entries = [
                (f"parent A\n{_truncate_caption_text(parent_a)}", parent_a),
                (f"parent B\n{_truncate_caption_text(parent_b)}", parent_b),
            ]
            entries.extend(
                (f"child {index}\n{_truncate_caption_text(child)}", child)
                for index, child in enumerate(viable, start=1)
            )
            return molecule_grid_figure(
                entries,
                title=(
                    f"Scaffold-hop litter — {len(viable)}/{len(litter)} viable "
                    f"children (parents first)"
                ),
            )

        def render(figure: Any) -> None:
            self._render_figure(self._breed_host, figure)

        self._start_job("litter structure grid", work, render)

    def _on_method_change(self, _event: Any = None) -> None:
        """Swap the GA / RL parameter blocks (grid_remove collapses the row)."""
        if self._method_combo.get() == "reinforcement learning (RL)":
            self._ga_frame.grid_remove()
            self._rl_frame.grid()
        else:
            self._rl_frame.grid_remove()
            self._ga_frame.grid()

    def _run_evolution(self) -> None:
        method = self._method_combo.get()
        if method == "reinforcement learning (RL)":
            if not self._require_pharmaml() or not self._require("torch", "the RL optimiser"):
                return
        elif not self._require_pharmaml() or not self._require("rdkit", "the GA"):
            return
        try:
            kind = self._objective_combo.get()
            lo = parse_float(self._obj_lo.get(), "window low")
            hi = parse_float(self._obj_hi.get(), "window high")
            if lo > hi:
                raise ValueError("window low exceeds window high")
            # (100x-122) the reference-driven objectives need their extra
            # row read and validated BEFORE the worker thread starts (Tk
            # widgets are main-thread only -- the factory call itself
            # moved into work() below with everything else).
            reference = self._obj_ref.get().strip()
            if kind == "Similarity to reference SMILES" and not reference:
                raise ValueError(
                    "the similarity objective needs a reference SMILES in the reference row"
                )
            if kind == "Contains substructure (SMARTS)" and not reference:
                raise ValueError(
                    "the substructure objective needs a SMARTS "
                    "pattern in the SMARTS row (e.g. c1ccccc1)"
                )
            seed = parse_int(self._ga_seed.get(), "seed", minimum=0)
            if method == "reinforcement learning (RL)":
                iterations = parse_int(self._rl_iterations.get(), "iterations", minimum=1)
                batch_size = parse_int(self._rl_batch.get(), "batch size", minimum=1)
                prior_epochs = parse_int(self._rl_prior_epochs.get(), "prior epochs", minimum=1)
                anchor_weight = parse_float(self._rl_anchor.get(), "anchor weight")
                if anchor_weight < 0:
                    raise ValueError("anchor weight cannot be negative")
                population = generations = 0
                mutation = crossover = operator_selection = ""
            else:
                iterations = batch_size = prior_epochs = 0
                anchor_weight = 0.0
                population = parse_int(self._pop_size.get(), "population", minimum=4)
                generations = parse_int(self._generations.get(), "generations", minimum=1)
                mutation = self._mutation_combo.get()
                crossover = self._crossover_combo.get()
                operator_selection = self._operator_combo.get()
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return
        lines = parse_smiles_lines(self._corpus_text.get("1.0", "end"))
        seed_mode = bool(self._seed_mode_var.get())
        # the novelty objective's reference pool: the card's own corpus
        # (None hands the library its built-in 244-molecule default)
        novelty_corpus: Any = list(lines) if lines else None
        if method == "reinforcement learning (RL)":
            want_plot = bool(self.deps.get("matplotlib"))
        else:
            want_plot = operator_selection == "adaptive" and self.deps.get("matplotlib")

        def work() -> Any:
            objective = build_objective(kind, lo, hi, reference=reference, corpus=novelty_corpus)
            if method == "reinforcement learning (RL)":
                from pharmaml.generative import DEFAULT_CORPUS, ReinventOptimizer

                # the CLI idiom: seeded mode anchors the on-the-fly prior's
                # corpus with the user's molecules ahead of the bundle
                if not lines:
                    corpus_arg: Any = None
                elif seed_mode:
                    corpus_arg = list(dict.fromkeys([*lines, *DEFAULT_CORPUS]))
                else:
                    corpus_arg = lines
                optimizer: Any = ReinventOptimizer(
                    objective,
                    corpus=corpus_arg,
                    iterations=iterations,
                    batch_size=batch_size,
                    prior_epochs=prior_epochs,
                    anchor_weight=anchor_weight,
                    seed=seed,
                )
            else:
                from pharmaml.generative import GeneticOptimizer

                optimizer = GeneticOptimizer(
                    objective,
                    population_size=population,
                    generations=generations,
                    mutation=mutation,
                    crossover=crossover,
                    operator_selection=operator_selection,
                    seed=seed,
                )
                if not lines:
                    return optimizer.optimize()
                if seed_mode:
                    return optimizer.optimize(seed_smiles=lines)
                return optimizer.optimize(corpus=lines)
            return optimizer.optimize()

        def render(result: Any) -> None:
            self._ga_result = result
            elapsed = result.metadata.get("elapsed_s")
            timing = f" · {elapsed:.1f} s" if isinstance(elapsed, (int, float)) else ""
            mode = (
                "seeded"
                if seed_mode and lines
                else ("custom corpus" if lines else "built-in corpus")
            )
            if method == "reinforcement learning (RL)":
                mode = f"RL · {mode}"
            self._ga_summary.configure(
                text=(
                    f"best {result.best_score:.3f} — {result.best}   "
                    f"({len(result.smiles)} unique molecules, {mode}{timing})"
                ),
                style="Field.TLabel",
            )
            frame = result.to_dataframe()
            self._ga_tree.delete(*self._ga_tree.get_children())
            columns = [str(column) for column in frame.columns]
            self._ga_tree["columns"] = columns
            for column in columns:
                self._ga_tree.heading(column, text=column)
                width = 320 if column == "smiles" else 96
                self._ga_tree.column(column, width=width, stretch=(column == "smiles"))
            for _, row in frame.head(20).iterrows():
                self._ga_tree.insert(
                    "",
                    "end",
                    values=[_cell_text(value, limit=60) for value in row.tolist()],
                )
            if method == "reinforcement learning (RL)":
                stats = _format_rl_history(result)
            else:
                stats = _format_operator_stats(result.metadata)
            self._ga_stats_text.delete("1.0", "end")
            self._ga_stats_text.insert("1.0", stats)
            if want_plot:
                try:
                    if method == "reinforcement learning (RL)":
                        from pharmaml.viz import plot_rl_introspection

                        figure = plot_rl_introspection(result)
                    else:
                        from pharmaml.viz import plot_operator_trajectory

                        figure = plot_operator_trajectory(result)
                    self._render_figure(self._ga_host, figure)
                except Exception as exc:  # noqa: BLE001
                    self._show_error("Introspection plot failed", exc)
            else:
                self._close_embedded(self._ga_host)
                for child in self._ga_host.winfo_children():
                    child.destroy()
            self._render_pareto(result)
            if method == "reinforcement learning (RL)" and not result.smiles:
                # an undertrained prior samples mostly invalid strings:
                # the honest advisory instead of an empty leaderboard
                messagebox.showinfo(
                    "No valid molecules yet",
                    "The RL run finished but sampled no valid SMILES -- the "
                    "prior is still undertrained.\n\n"
                    "Raise 'prior epochs' (8+ is the CLI default), keep "
                    "iterations at 10+, and re-run: the anchor needs a "
                    "prior that already writes chemistry.",
                )

        if method == "reinforcement learning (RL)":
            label = f"RL optimising {iterations} iterations (anchor {anchor_weight:g})"
        else:
            label = f"evolving {generations} generations ({operator_selection})"
        self._start_job(label, work, render)

    def _save_ga_leaderboard(self) -> None:
        if self._ga_result is None:
            messagebox.showinfo("Nothing to save", "Run an evolution first.")
            return
        self._save_frame_dialog(
            self._ga_result.to_dataframe(), "Save leaderboard", "ga_leaderboard.csv", "Leaderboard"
        )

    # -- the Pareto front card (100x-58) ------------------------------- #
    def _render_pareto(self, result: Any) -> None:
        """Fill the Pareto-front card from a finished run.

        A single-objective run carries no per-objective breakdown, so the
        card explains itself instead; a MultiObjective run gets the audit
        line, the front table, the plottable objective pair and — when
        matplotlib is available — the auto-drawn trade-off scatter.
        """
        self._pareto_front = None
        self._pareto_result = None
        self._pareto_tree.delete(*self._pareto_tree.get_children())
        self._pareto_x_combo.set("")
        self._pareto_y_combo.set("")
        self._pareto_x_combo["values"] = ()
        self._pareto_y_combo["values"] = ()
        self._close_embedded(self._pareto_host)
        for child in self._pareto_host.winfo_children():
            child.destroy()
        if not any(result.breakdown):
            self._pareto_summary.configure(
                text="this run optimises a single objective — the Pareto front "
                "needs a multi-objective run ('QED + LogP blend' or "
                "'Multi-objective (QED × MW × TPSA)')",
                style="CardMuted.TLabel",
            )
            return
        try:
            from pharmaml.generative import pareto_front

            front = pareto_front(result)
        except Exception as exc:  # noqa: BLE001 - surfaced inline, not modal
            self._pareto_summary.configure(
                text=f"Pareto front unavailable: {exc}", style="CardMuted.TLabel"
            )
            return
        self._pareto_front = front
        self._pareto_result = result
        summary = str(front)
        deepest = (
            max(
                (result.smiles.index(smiles) for smiles in front.smiles),
                default=0,
            )
            + 1
        )
        if deepest > 1:
            summary += (
                "\ndeepest front member sits at leaderboard rank "
                f"{deepest} of {len(result)} — a trade-off the blended ranking hides"
            )
        self._pareto_summary.configure(text=summary, style="Field.TLabel")
        frame = front.to_dataframe()
        self._pareto_tree.delete(*self._pareto_tree.get_children())
        columns = [str(column) for column in frame.columns]
        self._pareto_tree["columns"] = columns
        for column in columns:
            self._pareto_tree.heading(column, text=column)
            width = 320 if column == "smiles" else 96
            self._pareto_tree.column(column, width=width, stretch=(column == "smiles"))
        for _, row in frame.head(24).iterrows():
            self._pareto_tree.insert(
                "",
                "end",
                values=[_cell_text(value, limit=60) for value in row.tolist()],
            )
        self._pareto_x_combo["values"] = list(front.objectives)
        self._pareto_y_combo["values"] = list(front.objectives)
        self._pareto_x_combo.set(front.objectives[0])
        self._pareto_y_combo.set(front.objectives[1])
        if self.deps.get("matplotlib"):
            self._plot_pareto_front()

    def _plot_pareto_front(self) -> None:
        """Draw the trade-off scatter for the selected objective pair."""
        if self._pareto_result is None or self._pareto_front is None:
            messagebox.showinfo("Nothing to plot", "Run a multi-objective evolution first.")
            return
        if not self._require("matplotlib", "the Pareto plot"):
            return
        x = self._pareto_x_combo.get()
        y = self._pareto_y_combo.get()
        try:
            from pharmaml.viz import plot_pareto_front

            figure = plot_pareto_front(self._pareto_result, x=x, y=y)
            self._render_figure(self._pareto_host, figure)
        except Exception as exc:  # noqa: BLE001
            self._show_error("Pareto plot failed", exc)

    def _save_pareto_front(self) -> None:
        """Write the front table of the last multi-objective run (5 formats)."""
        if self._pareto_front is None:
            messagebox.showinfo("Nothing to save", "Run a multi-objective evolution first.")
            return
        self._save_frame_dialog(
            self._pareto_front.to_dataframe(),
            "Save Pareto front",
            "pareto_front.csv",
            "Pareto front",
        )

    def _gen_draw_front(self) -> None:
        """Draw the front's molecules as a colour-coded 2D grid (100x-125).

        The front card tabulated its members and scattered them in
        objective space, but the molecules themselves stayed invisible.
        The grid gives every member a panel -- its objective values as
        the score row -- and encodes NSGA-II's crowding verdict in
        colour: boundary members (best or worst on some objective,
        crowding distance +inf) accented teal, interior trade-offs
        muted neutral.  ``Plot front`` brings the scatter back; a new
        multi-objective run re-plots it (the established
        figure-replaces-figure pattern of the ML card's learning curve).
        """
        front = self._pareto_front
        if front is None:
            messagebox.showinfo(
                "Nothing to draw",
                "Run a multi-objective evolution first -- the structure grid "
                "draws that run's Pareto front.",
            )
            return
        if not self._require_pharmaml() or not self._require(
            "rdkit", "the front structure grid"
        ) or not self._require("matplotlib", "the front structure grid"):
            return

        def work() -> Any:
            import math

            crowding = front.crowding_distance()
            shown = min(len(front.smiles), 12)
            entries: list[tuple[str, str]] = []
            scores: list[str] = []
            colors: list[str] = []
            corners = 0
            for position in range(shown):
                smiles = str(front.smiles[position])
                values = front.values[position]
                scores.append(
                    " · ".join(
                        f"{name} {float(values[name]):.3g}" for name in front.objectives
                    )
                )
                entries.append(
                    (f"#{position + 1} · {_truncate_caption_text(smiles, 26)}", smiles)
                )
                if position < len(crowding) and math.isinf(crowding[position]):
                    colors.append("#0F766E")  # teal -- a boundary corner
                    corners += 1
                else:
                    colors.append("#525252")  # neutral -- interior trade-off
            title = (
                f"Pareto front — {len(front)} member(s), boundary corners "
                f"accented ({corners} of the {shown} shown)"
            )
            if len(front.smiles) > shown:
                title += f", first {shown} in leaderboard order"
            return molecule_grid_figure(
                entries, title=title, scores=scores, colors=colors
            )

        def render(figure: Any) -> None:
            self._render_figure(self._pareto_host, figure)

        self._start_job("Pareto front structure grid", work, render)

    def _save_card_figure(
        self, hosts: Any, *, dialog_title: str, empty_hint: str
    ) -> None:
        """Save ONE card's live figure -- the generalised per-card export (100x-127).

        Round 126 shipped this for the Pareto front card alone; this is
        the same honest contract, factored so every figure card can
        carry it: read the figure the card's OWN host currently shows
        (NOT the global ``Ctrl+S`` last-drawn-anywhere figure) and save
        it through the library's ``save_figure`` with the menu path's
        PNG/SVG/PDF filetypes.

        A card may hold MORE than one figure host -- the Generative
        Results card carries both the leaderboard structure grid and
        the evolution history.  ``_render_figure`` stamps every host
        with a monotonic ``_pg_figure_seq``; among the card's hosts
        that hold a live figure, the NEWEST stamp wins (whichever drew
        last on that card -- still strictly narrower than the global
        shortcut, which spans every card in the app).
        """
        live = [
            (getattr(host, "_pg_figure_seq", 0), host)
            for host in hosts
            if getattr(host, "_pg_figure", None) is not None
        ]
        if not live:
            messagebox.showinfo("No figure on the card yet", empty_hint)
            return
        live.sort(key=lambda pair: pair[0])
        figure = getattr(live[-1][1], "_pg_figure", None)
        if figure is None:  # unreachable -- kept for the type checker
            messagebox.showinfo("No figure on the card yet", empty_hint)
            return
        if not self._require_pharmaml():
            return
        path = filedialog.asksaveasfilename(
            title=dialog_title,
            defaultextension=".png",
            filetypes=[
                ("PNG figure", "*.png"),
                ("SVG figure", "*.svg"),
                ("PDF figure", "*.pdf"),
            ],
        )
        if not path:
            return
        try:
            from pharmaml.viz import save_figure

            saved = save_figure(figure, path)
            messagebox.showinfo("Figure saved", f"Written to\n{saved}")
        except Exception as exc:  # noqa: BLE001
            self._show_error("Could not save the figure", exc)

    def _save_pareto_figure(self) -> None:
        """Save the front card's LIVE figure -- grid or scatter (100x-126).

        The card renders two different figures into the same host (the
        structure grid and the objective scatter, whichever drew last),
        and until round 126 neither had a per-card export: the only
        paths were the global ``Ctrl+S`` (which saves whatever figure
        drew last ANYWHERE -- run any other calculation in between and
        the front is no longer what gets saved) and the session report
        (PDF/HTML bundles).  This reads the host's ``_pg_figure`` -- the
        exact object the card shows -- and saves it through the
        library's ``save_figure`` with the same PNG/SVG/PDF filetypes
        as the menu path.  (100x-127) the mechanics moved into
        :meth:`_save_card_figure`, shared with the other figure cards.
        """
        self._save_card_figure(
            [self._pareto_host],
            dialog_title="Save Pareto front figure",
            empty_hint=(
                "Draw the front (the structure grid) or plot the objective "
                "scatter first -- this saves the figure the card is "
                "currently showing."
            ),
        )

    def _save_ga_figure(self) -> None:
        """Save the Results card's live figure (100x-127).

        The Results card is the one card that holds TWO figure hosts --
        the leaderboard's structure grid (``Draw top molecules``) and
        the evolution history the run auto-plots -- so the per-card
        export saves whichever of the card's own figures drew LAST
        (still the card's, never the global last-drawn-anywhere figure
        ``Ctrl+S`` would catch after any other calculation ran).
        """
        self._save_card_figure(
            [self._ga_grid_host, self._ga_host],
            dialog_title="Save evolution results figure",
            empty_hint=(
                "Run an evolution (or press Draw top molecules) first -- "
                "this saves the figure the Results card is currently "
                "showing: the leaderboard structure grid or the evolution "
                "history, whichever drew last."
            ),
        )

    def _save_topo_figure(self) -> None:
        """Save the ring-topology card's mutant structure grid (100x-127)."""
        self._save_card_figure(
            [self._topo_host],
            dialog_title="Save ring topology figure",
            empty_hint=(
                "Enumerate mutants and press Draw mutants first -- this "
                "saves the structure grid the card is currently showing."
            ),
        )

    def _save_breed_figure(self) -> None:
        """Save the breeding card's litter structure grid (100x-127)."""
        self._save_card_figure(
            [self._breed_host],
            dialog_title="Save crossover litter figure",
            empty_hint=(
                "Breed two molecules and press Draw litter first -- this "
                "saves the structure grid the card is currently showing."
            ),
        )

    # -- 100x-128: the per-card export on EVERY remaining figure card -- #
    # Rounds 126/127 shipped the Generative cards; this closes the set:
    # the ML results / leaderboard / AD, the DL results and history, the
    # PK & PD figures, the feature factory, the similarity scan, the
    # docking receptor & results, the NCA profile and the utilities
    # reconciliation -- one button per card, each saving the figure the
    # card's OWN host shows (never the global Ctrl+S last-drawn).

    def _save_ml_figure(self) -> None:
        """Save the ML results card's live figure (100x-128).

        The card's single host carries whichever of the parity plot,
        the calibration curve or the learning curve drew last -- the
        honest per-card answer to ``Ctrl+S`` racing some other card's
        figure.
        """
        self._save_card_figure(
            [self._ml_host],
            dialog_title="Save ML results figure",
            empty_hint=(
                "Train a model (or draw the calibration / learning "
                "curve) first -- this saves the figure the results "
                "card is currently showing."
            ),
        )

    def _save_board_figure(self) -> None:
        """Save the leaderboard card's comparison bars (100x-128)."""
        self._save_card_figure(
            [self._board_host],
            dialog_title="Save leaderboard figure",
            empty_hint=(
                "Run Compare models and press Plot leaderboard first -- "
                "this saves the bars the card is currently showing."
            ),
        )

    def _save_ad_figure(self) -> None:
        """Save the applicability-domain card's two-panel figure (100x-128)."""
        self._save_card_figure(
            [self._ad_host],
            dialog_title="Save applicability domain figure",
            empty_hint=(
                "Run the applicability-domain analysis first -- this "
                "saves the two-panel reliability figure the card is "
                "currently showing."
            ),
        )

    def _save_dl_figure(self) -> None:
        """Save the DL results card's parity/confusion figure (100x-128)."""
        self._save_card_figure(
            [self._dl_host],
            dialog_title="Save network results figure",
            empty_hint=(
                "Train & evaluate a network first -- this saves the "
                "parity plot or confusion matrix the card is currently "
                "showing."
            ),
        )

    def _save_dl_history_figure(self) -> None:
        """Save the DL history card's live figure (100x-128).

        The history card holds TWO figure hosts -- the training loss
        curves and the learning curve -- so the export saves whichever
        of the card's own figures drew LAST (the same newest-stamp
        semantics the Generative Results card uses).
        """
        self._save_card_figure(
            [self._dl_hist_host, self._dl_curve_host],
            dialog_title="Save training history figure",
            empty_hint=(
                "Train a network (or plot its learning curve) first -- "
                "this saves the loss curves or the learning curve, "
                "whichever drew last."
            ),
        )

    def _save_iv_figure(self) -> None:
        """Save the IV bolus card's decay-curve figure (100x-128)."""
        self._save_card_figure(
            [self._iv_host],
            dialog_title="Save IV bolus profile figure",
            empty_hint=(
                "Press Plot profile first -- this saves the decay curve "
                "with its half-life markers."
            ),
        )

    def _save_pd_figure(self) -> None:
        """Save the Emax pharmacodynamics card's effect curve (100x-128)."""
        self._save_card_figure(
            [self._pd_host],
            dialog_title="Save Emax effect figure",
            empty_hint=(
                "Press Compute & plot first -- this saves the effect "
                "curve the card is currently showing."
            ),
        )

    def _save_nca_figure(self) -> None:
        """Save the NCA card's concentration-time profile (100x-128)."""
        self._save_card_figure(
            [self._nca_host],
            dialog_title="Save NCA profile figure",
            empty_hint=(
                "Run the non-compartmental analysis first -- this saves "
                "the concentration-time profile with its AUC."
            ),
        )

    def _save_acc_figure(self) -> None:
        """Save the infusion card's accumulation figure (100x-128)."""
        self._save_card_figure(
            [self._acc_host],
            dialog_title="Save dose accumulation figure",
            empty_hint=(
                "Press Plot repeated dosing first -- this saves the "
                "approach-to-steady-state picture."
            ),
        )

    def _save_fam_figure(self) -> None:
        """Save the pharmacology family card's effect curve (100x-128)."""
        self._save_card_figure(
            [self._fam_host],
            dialog_title="Save family effect figure",
            empty_hint=(
                "Compute a family fit first -- this saves the effect "
                "curve through your points."
            ),
        )

    def _save_feat_figure(self) -> None:
        """Save the feature factory card's histogram grid (100x-128)."""
        self._save_card_figure(
            [self._feat_host],
            dialog_title="Save descriptor distributions figure",
            empty_hint=(
                "Compute features and press Plot distributions first -- "
                "this saves the histogram grid the card is currently "
                "showing."
            ),
        )

    def _save_scan_figure(self) -> None:
        """Save the similarity scan card's heat-map figure (100x-128)."""
        self._save_card_figure(
            [self._scan_host],
            dialog_title="Save similarity heatmap figure",
            empty_hint=(
                "Run a matrix scan and press Plot heatmap first -- this "
                "saves the labelled heat-map the card is currently "
                "showing."
            ),
        )

    def _save_dock_receptor_figure(self) -> None:
        """Save the docking receptor card's atom-type census (100x-128)."""
        self._save_card_figure(
            [self._dock_receptor_host],
            dialog_title="Save receptor atom types figure",
            empty_hint=(
                "Prepare a receptor and press Plot atom types first -- "
                "this saves the atom-type census bars."
            ),
        )

    def _save_dock_results_figure(self) -> None:
        """Save the docking results card's top-ligands bars (100x-128)."""
        self._save_card_figure(
            [self._dock_results_host],
            dialog_title="Save docking results figure",
            empty_hint=(
                "Scan a campaign and press Plot top ligands first -- "
                "this saves the energy-annotated bars."
            ),
        )

    def _save_util_cmp_figure(self) -> None:
        """Save the utilities reconciliation card's overlap figure (100x-128)."""
        self._save_card_figure(
            [self._util_cmp_host],
            dialog_title="Save reconciliation figure",
            empty_hint=(
                "Run a reconciliation and press Plot reconciliation "
                "first -- this saves the overlap figure the card is "
                "currently showing."
            ),
        )

    # ------------------------------------------------------------------ #
    # Utilities tab -- the rar's own file & table operations, one by one
    # (100x-110: the coverage audit found these scripts covered by the
    # library/CLI but missing from the playground's GUI surface)
    # ------------------------------------------------------------------ #
    def _build_utilities_tab(self) -> None:
        """The ``others/General`` scripts of the archive, mouse edition.

        Five cards, one per rar workflow family:

        * **Table merge & split** -- ``CSV_merger.py``, ``filemerger.py``
          and ``Split CSV file.py`` (both copies): stack tables, merge a
          folder, or stream one big CSV into parts.
        * **Table compare & annotate** -- ``common_between_two_excel.py``,
          ``notcommon.py`` and ``smilesgetter.py``: set reconciliation
          of a ligand column, or SMILES lookup onto name columns.
        * **Approved drugs → report** -- ``approved.py``: filter a
          regulatory-approval column and export the names (CSV or the
          rar's .docx, now a real bordered Word table).
        * **Campaign file tools** -- ``extaacter.py``,
          ``dlg_extracter.py``, ``ligand_pdbqt_extracter.py``,
          ``Nameextracter.py``, ``adder.py``, ``deleter.py`` and
          ``delete.py``: collect / list / distribute / delete / cleanup,
          dry-run by default on every destructive path.
        * **Reindex by number** -- ``Prettier_extracted_dlgs.py`` (all
          three copies): align sparse per-ligand rows onto a dense
          0..N index so missing runs show as gaps, not silence.
        """
        page = self._new_page("Utilities")

        # -- card 1: table merge & split -------------------------------- #
        merge = make_card(
            page.grid,
            "Table merge & split",
            span=2,
            row=0,
            column=0,
            subtitle="The rar's CSV_merger / filemerger / Split CSV file "
            "trio: stack several tables into one (named columns "
            "first, the rest sorted), merge every table in a "
            "folder, or stream one big CSV into fixed-size parts.",
        )
        self._util_merge_mode = ttk.Combobox(
            merge, state="readonly", width=24, values=_UTIL_MERGE_MODES
        )
        self._util_merge_mode.set(_UTIL_MERGE_MODES[0])
        self._util_merge_files: list[Path] = []
        self._util_merge_folder: Path | None = None
        self._util_merge_split_file: Path | None = None
        self._util_merge_mode.bind(
            "<<ComboboxSelected>>", lambda _e: self._util_merge_mode_changed()
        )
        form_row(merge, "mode", self._util_merge_mode)
        merge_pick = ttk.Frame(merge, style="Card.TFrame")
        grid_append(merge, merge_pick, sticky="w")
        for label, command in (
            ("Pick tables…", self._util_merge_pick_files),
            ("Pick folder…", self._util_merge_pick_folder),
            ("Pick big CSV…", self._util_merge_pick_split_file),
        ):
            button = self._action_button(merge_pick, label, command)
            button.pack(side="left")
        self._util_merge_info = ttk.Label(
            merge,
            text="no tables, folder or file picked yet",
            style="CardMuted.TLabel",
            wraplength=620,
            justify="left",
        )
        grid_append(merge, self._util_merge_info, sticky="w", pady=(4, 0))
        self._util_merge_firstcols = ttk.Entry(merge, width=44)
        self._util_merge_firstcols.insert(0, "")
        Tooltip(
            self._util_merge_firstcols,
            "Comma-separated columns to keep first in the merged "
            "output (the CSV_merger column-ordering contract); blank "
            "keeps source order. Only used by the merge modes.",
        )
        form_row(merge, "first columns", self._util_merge_firstcols)
        merge_opts = ttk.Frame(merge, style="Card.TFrame")
        grid_append(merge, merge_opts, sticky="w")
        merge_opts.columnconfigure(1, weight=1)
        self._util_merge_ext = ttk.Entry(merge_opts, width=8)
        self._util_merge_ext.insert(0, ".csv")
        Tooltip(
            self._util_merge_ext,
            "Folder-merge mode: the extension collected from the folder (csv / xlsx / tsv ...).",
        )
        form_row(merge_opts, "extension", self._util_merge_ext)
        self._util_merge_chunk = ttk.Entry(merge_opts, width=12)
        self._util_merge_chunk.insert(0, "1500000")
        Tooltip(
            self._util_merge_chunk,
            "Split mode: maximum rows per part file (the rar's "
            "default was 1.5M; parts land in a folder you pick).",
        )
        form_row(merge_opts, "rows per part", self._util_merge_chunk)
        merge_run_row = ttk.Frame(merge, style="Card.TFrame")
        grid_append(merge, merge_run_row, sticky="w", pady=(6, 0))
        merge_run_btn = self._action_button(
            merge_run_row,
            "Run",
            self._util_merge_run,
            primary=True,
            tooltip="Merging reads every picked table/folder entry and "
            "stacks them; splitting streams the big CSV lazily so "
            "memory stays flat no matter the file size.",
        )
        merge_run_btn.pack(side="left")
        self._util_merge_summary = ttk.Label(
            merge_run_row, text="—", style="CardMuted.TLabel", wraplength=520, justify="left"
        )
        self._util_merge_summary.pack(side="left", padx=(10, 0))
        self._util_merge_save_btn = self._action_button(
            merge_run_row,
            "Save merged CSV…",
            self._util_merge_save,
            tooltip="The merged table from the last run (merge modes only).",
        )
        self._util_merge_save_btn.pack(side="left", padx=(10, 0))
        merge_tree_frame = ttk.Frame(merge, style="Card.TFrame")
        grid_append(merge, merge_tree_frame, sticky="nsew", pady=(6, 0), weight=True)
        self._util_merge_tree = ttk.Treeview(merge_tree_frame, show="headings", height=7)
        merge_bar = ttk.Scrollbar(
            merge_tree_frame, orient="vertical", command=self._util_merge_tree.yview
        )
        merge_bar_x = ttk.Scrollbar(
            merge_tree_frame, orient="horizontal", command=self._util_merge_tree.xview
        )
        self._util_merge_tree.configure(
            yscrollcommand=merge_bar.set, xscrollcommand=merge_bar_x.set
        )
        self._util_merge_tree.pack(side="left", fill="both", expand=True)
        merge_bar.pack(side="right", fill="y")
        merge_bar_x.pack(side="bottom", fill="x")

        # -- card 2: table compare & annotate --------------------------- #
        compare = make_card(
            page.grid,
            "Table compare & annotate",
            row=1,
            column=0,
            subtitle="common_between_two_excel + notcommon + smilesgetter: "
            "reconcile one ligand-name column across two tables "
            "(common / only-A / only-B, name-normalised), or join "
            "SMILES onto name columns from a reference table.",
        )
        self._util_cmp_mode = ttk.Combobox(
            compare, state="readonly", width=26, values=_UTIL_COMPARE_MODES
        )
        self._util_cmp_mode.set(_UTIL_COMPARE_MODES[0])
        form_row(compare, "mode", self._util_cmp_mode)
        cmp_pick = ttk.Frame(compare, style="Card.TFrame")
        grid_append(compare, cmp_pick, sticky="w")
        for label, command in (
            ("Table A…", self._util_cmp_pick_a),
            ("Table B / reference…", self._util_cmp_pick_b),
        ):
            button = self._action_button(cmp_pick, label, command)
            button.pack(side="left")
        self._util_cmp_a: Path | None = None
        self._util_cmp_b: Path | None = None
        self._util_cmp_info = ttk.Label(
            compare,
            text="pick two tables (csv / tsv / xlsx)",
            style="CardMuted.TLabel",
            wraplength=300,
            justify="left",
        )
        grid_append(compare, self._util_cmp_info, sticky="w", pady=(4, 0))
        self._util_cmp_column = ttk.Entry(compare, width=26)
        self._util_cmp_column.insert(0, "Ligand")
        Tooltip(
            self._util_cmp_column,
            "Compare mode: the ligand-name column present in BOTH "
            "tables (normalised before comparing, so 'LIG1.pdbqt' "
            "equals 'lig1').",
        )
        form_row(compare, "compare column", self._util_cmp_column)
        self._util_cmp_names = ttk.Entry(compare, width=26)
        self._util_cmp_names.insert(0, "Ligand")
        Tooltip(
            self._util_cmp_names,
            "Annotate mode: comma-separated name columns in table A "
            "that receive a '<column>_SMILES' companion column.",
        )
        form_row(compare, "annotate columns", self._util_cmp_names)
        self._util_cmp_ref_name = ttk.Entry(compare, width=26)
        self._util_cmp_ref_name.insert(0, "Ligand")
        form_row(compare, "reference name col", self._util_cmp_ref_name)
        self._util_cmp_ref_smiles = ttk.Entry(compare, width=26)
        self._util_cmp_ref_smiles.insert(0, "SMILES")
        form_row(compare, "reference SMILES col", self._util_cmp_ref_smiles)
        cmp_run_row = ttk.Frame(compare, style="Card.TFrame")
        grid_append(compare, cmp_run_row, sticky="w", pady=(6, 0))
        cmp_run_btn = self._action_button(
            cmp_run_row,
            "Run",
            self._util_compare_run,
            primary=True,
            tooltip="Compare: the three-way reconciliation table; "
            "annotate: table A with the SMILES columns appended "
            "(empty string when a name is unknown).",
        )
        cmp_run_btn.pack(side="left")
        self._util_cmp_summary = ttk.Label(
            cmp_run_row, text="—", style="CardMuted.TLabel", wraplength=300, justify="left"
        )
        self._util_cmp_summary.pack(side="left", padx=(8, 0))
        cmp_tree_frame = ttk.Frame(compare, style="Card.TFrame")
        grid_append(compare, cmp_tree_frame, sticky="nsew", pady=(6, 0), weight=True)
        self._util_cmp_tree = ttk.Treeview(cmp_tree_frame, show="headings", height=7)
        cmp_bar = ttk.Scrollbar(
            cmp_tree_frame, orient="vertical", command=self._util_cmp_tree.yview
        )
        self._util_cmp_tree.configure(yscrollcommand=cmp_bar.set)
        self._util_cmp_tree.pack(side="left", fill="both", expand=True)
        cmp_bar.pack(side="right", fill="y")
        # 100x-120: the reconciliation figure (plot_table_comparison) --
        # the three-way overlap as a picture beside the tree.
        cmp_plot_row = ttk.Frame(compare, style="Card.TFrame")
        grid_append(compare, cmp_plot_row, sticky="w", pady=(6, 0))
        cmp_plot_btn = self._action_button(
            cmp_plot_row,
            "Plot reconciliation",
            self._util_cmp_plot,
            tooltip="The last three-way reconciliation as an overlap "
            "figure (plot_table_comparison): common / only-A / "
            "only-B counts -- the set story the table tells, "
            "told visually.",
        )
        cmp_plot_btn.pack(side="left")
        self._util_cmp_plot_note = ttk.Label(
            cmp_plot_row, text="", style="CardMuted.TLabel", wraplength=300, justify="left"
        )
        self._util_cmp_plot_note.pack(side="left", padx=(8, 0))
        save_cmp_figure_btn = self._action_button(
            cmp_plot_row,
            "Save figure…",
            self._save_util_cmp_figure,
            tooltip="Save the figure this card is currently showing -- the "
            "three-way overlap figure of the last reconciliation -- as "
            "PNG, SVG or PDF (unlike Ctrl+S, which saves the last "
            "figure drawn anywhere).",
        )
        save_cmp_figure_btn.pack(side="left", padx=(10, 0))
        self._util_cmp_host = self._figure_host(compare, height=260)
        self._util_cmp_last: Any = None

        # -- card 3: approved drugs ------------------------------------- #
        approved = make_card(
            page.grid,
            "Approved drugs → report",
            row=1,
            column=1,
            subtitle="approved.py: collect the drug names whose "
            "regulatory-approval column matches a status (a "
            "folder of TSV/CSV exports or several picked "
            "files), then write the list as CSV or as the "
            "rar's .docx -- now a real bordered Word table.",
        )
        appr_pick = ttk.Frame(approved, style="Card.TFrame")
        grid_append(approved, appr_pick, sticky="w")
        appr_btn = self._action_button(appr_pick, "Pick files…", self._util_appr_pick_files)
        appr_btn.pack(side="left")
        self._util_appr_files: list[Path] = []
        self._util_appr_info = ttk.Label(
            approved,
            text="no approval exports picked yet",
            style="CardMuted.TLabel",
            wraplength=300,
            justify="left",
        )
        grid_append(approved, self._util_appr_info, sticky="w", pady=(4, 0))
        self._util_appr_drug = ttk.Entry(approved, width=26)
        self._util_appr_drug.insert(0, "drug")
        Tooltip(
            self._util_appr_drug,
            "Drug-name column (matched case-insensitively; the DGIdb export header is 'drug').",
        )
        form_row(approved, "drug column", self._util_appr_drug)
        self._util_appr_col = ttk.Entry(approved, width=26)
        self._util_appr_col.insert(0, "regulatory approval")
        form_row(approved, "approval column", self._util_appr_col)
        self._util_appr_status = ttk.Entry(approved, width=26)
        self._util_appr_status.insert(0, "approved")
        form_row(approved, "status", self._util_appr_status)
        appr_run_row = ttk.Frame(approved, style="Card.TFrame")
        grid_append(approved, appr_run_row, sticky="w", pady=(6, 0))
        appr_run_btn = self._action_button(
            appr_run_row,
            "Filter",
            self._util_approved_run,
            primary=True,
            tooltip="One pass over every picked file; the matched names "
            "land in the list below, deduplicated and sorted.",
        )
        appr_run_btn.pack(side="left")
        self._util_appr_summary = ttk.Label(
            appr_run_row, text="—", style="CardMuted.TLabel", wraplength=300, justify="left"
        )
        self._util_appr_summary.pack(side="left", padx=(8, 0))
        appr_save_row = ttk.Frame(approved, style="Card.TFrame")
        grid_append(approved, appr_save_row, sticky="w", pady=(4, 0))
        appr_csv_btn = self._action_button(
            appr_save_row, "Save names CSV…", self._util_approved_save_csv
        )
        appr_csv_btn.pack(side="left")
        appr_docx_btn = self._action_button(
            appr_save_row,
            "Save report DOCX…",
            self._util_approved_save_docx,
            tooltip="The rar's .docx output, upgraded: a bordered Word "
            "table with a bold header row (needs python-docx, "
            "pharmaml[reports]).",
        )
        appr_docx_btn.pack(side="left", padx=(10, 0))
        appr_tree_frame = ttk.Frame(approved, style="Card.TFrame")
        grid_append(approved, appr_tree_frame, sticky="nsew", pady=(6, 0), weight=True)
        self._util_appr_tree = ttk.Treeview(
            appr_tree_frame, columns=("drug",), show="headings", height=7
        )
        self._util_appr_tree.heading("drug", text="drug")
        self._util_appr_tree.column("drug", width=220, stretch=True)
        appr_bar = ttk.Scrollbar(
            appr_tree_frame, orient="vertical", command=self._util_appr_tree.yview
        )
        self._util_appr_tree.configure(yscrollcommand=appr_bar.set)
        self._util_appr_tree.pack(side="left", fill="both", expand=True)
        appr_bar.pack(side="right", fill="y")

        # -- card 4: campaign file tools -------------------------------- #
        tools = make_card(
            page.grid,
            "Campaign file tools",
            row=2,
            column=0,
            subtitle="extaacter / dlg_extracter / ligand_pdbqt_extracter / "
            "Nameextracter / adder / deleter / delete: collect "
            "matching files out of a campaign tree, list a "
            "folder's names, distribute binaries into every "
            "sub-folder, delete strays, or clean a tree down to "
            "an allowlist -- destructive paths run dry-run "
            "first, always.",
        )
        self._util_tool_mode = ttk.Combobox(
            tools, state="readonly", width=28, values=_UTIL_TOOL_MODES
        )
        self._util_tool_mode.set(_UTIL_TOOL_MODES[0])
        self._util_tool_mode.bind("<<ComboboxSelected>>", lambda _e: self._util_tool_mode_changed())
        form_row(tools, "mode", self._util_tool_mode)
        tool_pick = ttk.Frame(tools, style="Card.TFrame")
        grid_append(tools, tool_pick, sticky="w")
        for label, command in (
            ("Folder…", self._util_tool_pick_folder),
            ("Files…", self._util_tool_pick_files),
            ("Collect into…", self._util_tool_pick_out),
        ):
            button = self._action_button(tool_pick, label, command)
            button.pack(side="left")
        self._util_tool_folder: Path | None = None
        self._util_tool_files: list[Path] = []
        self._util_tool_out: Path | None = None
        self._util_tool_info = ttk.Label(
            tools,
            text="pick a campaign folder (and files for distribute, an output folder for collect)",
            style="CardMuted.TLabel",
            wraplength=300,
            justify="left",
        )
        grid_append(tools, self._util_tool_info, sticky="w", pady=(4, 0))
        self._util_tool_filename = ttk.Entry(tools, width=26)
        self._util_tool_filename.insert(0, "r.dlg")
        Tooltip(
            self._util_tool_filename,
            "Collect: exact filename to gather (r.dlg / r.gpf / "
            "l.pdbqt ...); delete: the stray filename to remove "
            "anywhere under the folder.",
        )
        form_row(tools, "filename", self._util_tool_filename)
        self._util_tool_pattern = ttk.Entry(tools, width=26)
        self._util_tool_pattern.insert(0, r"\d+\.pdbqt")
        Tooltip(
            self._util_tool_pattern,
            "Collect: a regex the filename must match (combine with "
            "the exact name as a union); cleanup: the keep-pattern "
            "filenames must match to survive.",
        )
        form_row(tools, "pattern", self._util_tool_pattern)
        self._util_tool_ext = ttk.Entry(tools, width=26)
        self._util_tool_ext.insert(0, ".csv")
        form_row(tools, "extension (list)", self._util_tool_ext)
        self._util_tool_keep = ttk.Entry(tools, width=26)
        self._util_tool_keep.insert(0, "r.pdbqt,r.dlg,r.gpf,r.dpf")
        Tooltip(
            self._util_tool_keep,
            "Cleanup: comma-separated filenames that survive; "
            "everything else in the tree is a deletion candidate.",
        )
        form_row(tools, "keep names (cleanup)", self._util_tool_keep)
        self._util_tool_dry_var = tk.BooleanVar(value=True)
        dry_check = ttk.Checkbutton(
            tools, text="dry run (report only, nothing deleted)", variable=self._util_tool_dry_var
        )
        Tooltip(
            dry_check,
            "On (the default): collect/delete/cleanup only report "
            "what they would do. Untick and confirm to apply for "
            "real -- the confirmation names the exact counts.",
        )
        form_row(tools, "safety", dry_check)
        tool_run_row = ttk.Frame(tools, style="Card.TFrame")
        grid_append(tools, tool_run_row, sticky="w", pady=(6, 0))
        tool_run_btn = self._action_button(
            tool_run_row,
            "Run",
            self._util_tools_run,
            primary=True,
            tooltip="Distribute copies the picked files into every "
            "immediate sub-folder of the campaign folder (the "
            "adder.py bin/receptor push); the rest read the "
            "tree and report.",
        )
        tool_run_btn.pack(side="left")
        self._util_tool_summary = ttk.Label(
            tool_run_row, text="—", style="CardMuted.TLabel", wraplength=300, justify="left"
        )
        self._util_tool_summary.pack(side="left", padx=(8, 0))
        tool_tree_frame = ttk.Frame(tools, style="Card.TFrame")
        grid_append(tools, tool_tree_frame, sticky="nsew", pady=(6, 0), weight=True)
        self._util_tool_tree = ttk.Treeview(tool_tree_frame, show="headings", height=7)
        tool_bar = ttk.Scrollbar(
            tool_tree_frame, orient="vertical", command=self._util_tool_tree.yview
        )
        self._util_tool_tree.configure(yscrollcommand=tool_bar.set)
        self._util_tool_tree.pack(side="left", fill="both", expand=True)
        tool_bar.pack(side="right", fill="y")

        # -- card 5: reindex by number ---------------------------------- #
        reindex = make_card(
            page.grid,
            "Reindex by number",
            row=2,
            column=1,
            subtitle="Prettier_extracted_dlgs: align sparse per-ligand "
            "rows onto the full number range so missing runs "
            "appear as gaps instead of silently vanishing; rows "
            "outside the range are dropped with a warning.",
        )
        self._util_reindex_pick_btn = self._action_button(
            reindex, "Pick CSV…", self._util_reindex_pick
        )
        self._util_reindex_pick_btn.grid(row=0, column=0, sticky="w")
        self._util_reindex_path: Path | None = None
        self._util_reindex_info = ttk.Label(
            reindex,
            text="no table picked yet",
            style="CardMuted.TLabel",
            wraplength=300,
            justify="left",
        )
        grid_append(reindex, self._util_reindex_info, sticky="w", pady=(4, 0))
        self._util_reindex_column = ttk.Entry(reindex, width=26)
        self._util_reindex_column.insert(0, "ligand")
        Tooltip(
            self._util_reindex_column,
            "Column carrying the numbered names (e.g. "
            "'5_result.dlg'); its first number becomes the index.",
        )
        form_row(reindex, "column", self._util_reindex_column)
        reindex_range = ttk.Frame(reindex, style="Card.TFrame")
        grid_append(reindex, reindex_range, sticky="w")
        reindex_range.columnconfigure(1, weight=1)
        self._util_reindex_start = ttk.Entry(reindex_range, width=8)
        self._util_reindex_start.insert(0, "0")
        form_row(reindex_range, "start", self._util_reindex_start)
        self._util_reindex_stop = ttk.Entry(reindex_range, width=8)
        self._util_reindex_stop.insert(0, "300")
        form_row(reindex_range, "stop", self._util_reindex_stop)
        self._util_reindex_pattern = ttk.Entry(reindex, width=26)
        self._util_reindex_pattern.insert(0, r"(\d+)")
        Tooltip(
            self._util_reindex_pattern,
            "Regex whose first capture group extracts the ligand number out of the column value.",
        )
        form_row(reindex, "number pattern", self._util_reindex_pattern)
        reindex_run_row = ttk.Frame(reindex, style="Card.TFrame")
        grid_append(reindex, reindex_run_row, sticky="w", pady=(6, 0))
        reindex_run_btn = self._action_button(
            reindex_run_row,
            "Reindex",
            self._util_reindex_run,
            primary=True,
            tooltip="Left-joins the rows onto range(start, stop+1); the "
            "dense table previews below and Save CSV… writes it.",
        )
        reindex_run_btn.pack(side="left")
        self._util_reindex_summary = ttk.Label(
            reindex_run_row, text="—", style="CardMuted.TLabel", wraplength=300, justify="left"
        )
        self._util_reindex_summary.pack(side="left", padx=(8, 0))
        reindex_save_btn = self._action_button(
            reindex_run_row, "Save CSV…", self._util_reindex_save
        )
        reindex_save_btn.pack(side="left", padx=(10, 0))
        reindex_tree_frame = ttk.Frame(reindex, style="Card.TFrame")
        grid_append(reindex, reindex_tree_frame, sticky="nsew", pady=(6, 0), weight=True)
        self._util_reindex_tree = ttk.Treeview(reindex_tree_frame, show="headings", height=7)
        reindex_bar = ttk.Scrollbar(
            reindex_tree_frame, orient="vertical", command=self._util_reindex_tree.yview
        )
        self._util_reindex_tree.configure(yscrollcommand=reindex_bar.set)
        self._util_reindex_tree.pack(side="left", fill="both", expand=True)
        reindex_bar.pack(side="right", fill="y")

        # dynamic trees fill lazily on first render
        self._util_frames: dict[str, Any] = {}

    # -- utilities: shared helpers ------------------------------------- #
    def _fill_dynamic_tree(
        self, tree: Any, frame: Any, max_rows: int = 200, widths: dict[str, int] | None = None
    ) -> int:
        """Rebuild a Treeview from an arbitrary DataFrame.

        Returns the number of rows actually shown (capped at
        ``max_rows`` so a 100k-row merge never freezes the UI -- the
        summary labels carry the true count).
        """
        tree.delete(*tree.get_children())
        columns = [str(column) for column in frame.columns]
        tree["columns"] = columns
        for column in columns:
            tree.heading(column, text=column)
            width = (widths or {}).get(column, 110)
            tree.column(column, width=width, minwidth=56, stretch=True)
        shown = 0
        for _, row in frame.head(max_rows).iterrows():
            tree.insert("", "end", values=[_cell_text(v, limit=32) for v in row.tolist()])
            shown += 1
        if len(frame) > max_rows:
            tree.insert(
                "",
                "end",
                values=[
                    (f"… {len(frame) - max_rows:,} more rows (total {len(frame):,})"),
                    *[""] * (len(columns) - 1),
                ],
            )
        return shown

    def _save_frame_dialog(self, frame: Any, title: str, name: str, subject: str = "table") -> None:
        """Ask a path and write ``frame`` (``export_table``, five formats).

        The library's visual export story owns the dialog (100x-121):
        ``.csv``, ``.tsv``, GitHub-ready ``.md``, records ``.json`` and a
        standalone styled ``.html`` -- ``export_table`` picks the writer
        from the picked extension, so every table card can hand its
        results to a report, a notebook or a browser.
        """
        if frame is None:
            messagebox.showinfo("Nothing to save", "Run the tool first.")
            return
        path = filedialog.asksaveasfilename(
            title=title,
            defaultextension=".csv",
            initialfile=name,
            filetypes=[
                ("CSV table", "*.csv"),
                ("TSV table", "*.tsv"),
                ("Markdown table", "*.md"),
                ("JSON records", "*.json"),
                ("HTML table", "*.html"),
            ],
        )
        if not path:
            return
        if not self._require_pharmaml():
            return
        try:
            from pharmaml.viz import export_table

            written = export_table(frame, path)
            messagebox.showinfo("Saved", f"{subject} written to\n{written}")
        except Exception as exc:  # noqa: BLE001
            self._show_error("Could not save", exc)

    # -- utilities: merge & split -------------------------------------- #
    def _util_merge_mode_changed(self) -> None:
        mode = self._util_merge_mode.get()
        picked = "no tables, folder or file picked yet"
        if mode.startswith("merge picked") and self._util_merge_files:
            picked = (
                f"{len(self._util_merge_files)} table(s): "
                + ", ".join(p.name for p in self._util_merge_files[:4])
                + (" …" if len(self._util_merge_files) > 4 else "")
            )
        elif mode.startswith("merge whole") and self._util_merge_folder:
            picked = f"folder: {self._util_merge_folder}"
        elif mode.startswith("split") and self._util_merge_split_file:
            picked = f"big CSV: {self._util_merge_split_file}"
        self._util_merge_info.configure(text=picked)

    def _util_merge_pick_files(self) -> None:
        paths = filedialog.askopenfilenames(
            title="Pick the tables to merge",
            filetypes=[("Tables", "*.csv *.tsv *.xlsx"), ("All files", "*.*")],
        )
        if not paths:
            return
        self._util_merge_files = [Path(p) for p in paths]
        self._util_merge_mode_changed()

    def _util_merge_pick_folder(self) -> None:
        path = filedialog.askdirectory(title="Pick the folder to merge")
        if path:
            self._util_merge_folder = Path(path)
            self._util_merge_mode_changed()

    def _util_merge_pick_split_file(self) -> None:
        path = filedialog.askopenfilename(
            title="Pick the big CSV to split",
            filetypes=[("CSV file", "*.csv"), ("All files", "*.*")],
        )
        if path:
            self._util_merge_split_file = Path(path)
            self._util_merge_mode_changed()

    def _util_merge_run(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "table merge"):
            return
        mode = self._util_merge_mode.get()
        first_columns = [
            token.strip() for token in self._util_merge_firstcols.get().split(",") if token.strip()
        ] or None

        if mode.startswith("merge picked"):
            sources: list[Any] = list(getattr(self, "_util_merge_files", []))
            if not sources:
                messagebox.showwarning("No tables", "Pick the tables to merge first.")
                return
            label = f"merging {len(sources)} table(s)"
            out_dir = None
            chunk_rows = 0
        elif mode.startswith("merge whole"):
            folder = getattr(self, "_util_merge_folder", None)
            if folder is None:
                messagebox.showwarning("No folder", "Pick the folder to merge first.")
                return
            extension = self._util_merge_ext.get().strip() or ".csv"
            sources = [folder]
            label = f"merging {folder.name} ({extension})"
            out_dir = None
            chunk_rows = 0
        else:  # split
            big = getattr(self, "_util_merge_split_file", None)
            if big is None:
                messagebox.showwarning("No file", "Pick the big CSV to split first.")
                return
            try:
                chunk_rows = parse_int(self._util_merge_chunk.get(), "rows per part", minimum=1)
            except ValueError as exc:
                messagebox.showerror("Input", str(exc))
                return
            out_dir = filedialog.askdirectory(title="Pick the folder for the part files")
            if not out_dir:
                return
            sources = [big]
            label = f"splitting {big.name} every {chunk_rows:,} rows"

        def work() -> Any:
            from pharmaml.chem import merge_table_folder, merge_tables
            from pharmaml.chem.converters import split_table_into_chunks

            if mode.startswith("merge picked"):
                return {
                    "kind": "merge",
                    "frame": merge_tables(sources, first_columns=first_columns),
                }
            if mode.startswith("merge whole"):
                return {
                    "kind": "merge",
                    "frame": merge_table_folder(
                        sources[0], extension=extension, first_columns=first_columns
                    ),
                }
            parts = split_table_into_chunks(sources[0], Path(out_dir), chunk_rows=chunk_rows)
            return {"kind": "split", "parts": parts}

        def render(result: Any) -> None:
            if result["kind"] == "merge":
                frame = result["frame"]
                self._util_frames["merge"] = frame
                self._fill_dynamic_tree(self._util_merge_tree, frame)
                self._util_merge_save_btn.state(["!disabled"])
                self._util_merge_summary.configure(
                    text=(f"merged: {len(frame):,} rows × {len(frame.columns)} columns"),
                    style="Field.TLabel",
                )
            else:
                parts = result["parts"]
                self._util_frames.pop("merge", None)
                self._util_merge_save_btn.state(["disabled"])
                self._fill_dynamic_tree(
                    self._util_merge_tree,
                    _frame_from_records(
                        ("part", "rows", "bytes"),
                        [(p.name, "?", p.stat().st_size if p.exists() else 0) for p in parts],
                    ),
                )
                self._util_merge_summary.configure(
                    text=(
                        f"split into {len(parts)} part file(s) in "
                        f"{Path(out_dir).name} · "
                        f"≤{chunk_rows:,} rows each"
                    ),
                    style="Field.TLabel",
                )

        self._start_job(label, work, render)

    def _util_merge_save(self) -> None:
        self._save_frame_dialog(
            self._util_frames.get("merge"), "Save the merged table", "merged_output.csv"
        )

    # -- utilities: compare & annotate ---------------------------------- #
    def _util_cmp_pick_a(self) -> None:
        path = filedialog.askopenfilename(
            title="Pick table A",
            filetypes=[("Tables", "*.csv *.tsv *.xlsx"), ("All files", "*.*")],
        )
        if path:
            self._util_cmp_a = Path(path)
            self._util_cmp_refresh_info()

    def _util_cmp_pick_b(self) -> None:
        path = filedialog.askopenfilename(
            title="Pick table B (or the SMILES reference)",
            filetypes=[("Tables", "*.csv *.tsv *.xlsx"), ("All files", "*.*")],
        )
        if path:
            self._util_cmp_b = Path(path)
            self._util_cmp_refresh_info()

    def _util_cmp_refresh_info(self) -> None:
        a = self._util_cmp_a.name if self._util_cmp_a else "—"
        b = self._util_cmp_b.name if self._util_cmp_b else "—"
        self._util_cmp_info.configure(text=f"A: {a}\nB: {b}")

    def _util_compare_run(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "table compare"):
            return
        if self._util_cmp_a is None or self._util_cmp_b is None:
            messagebox.showwarning("Two tables needed", "Pick table A and table B first.")
            return
        mode = self._util_cmp_mode.get()
        a_path, b_path = self._util_cmp_a, self._util_cmp_b

        if mode.startswith("compare"):
            column = self._util_cmp_column.get().strip()
            if not column:
                messagebox.showwarning("Column", "Name the compare column.")
                return

            def work() -> Any:
                from pharmaml.chem import compare_tables

                return compare_tables(a_path, b_path, column)

            def render(comparison: Any) -> None:
                import pandas as pd

                # 100x-120: keep the comparison object itself for the
                # reconciliation figure button below the tree.
                self._util_cmp_last = comparison
                records = (
                    [("common", name) for name in comparison.common]
                    + [("only in A", name) for name in comparison.only_in_a]
                    + [("only in B", name) for name in comparison.only_in_b]
                )
                frame = pd.DataFrame(records, columns=["section", "name"])
                self._util_frames["compare"] = frame
                self._fill_dynamic_tree(
                    self._util_cmp_tree, frame, widths={"section": 90, "name": 180}
                )
                self._util_cmp_summary.configure(
                    text=(
                        f"common {len(comparison.common)} · "
                        f"only A {len(comparison.only_in_a)} · "
                        f"only B {len(comparison.only_in_b)}"
                    ),
                    style="Field.TLabel",
                )

            self._start_job(f"comparing '{column}'", work, render)
            return

        # annotate mode
        name_columns = [
            token.strip() for token in self._util_cmp_names.get().split(",") if token.strip()
        ]
        if not name_columns:
            messagebox.showwarning("Columns", "Name the columns to annotate (comma-separated).")
            return
        ref_name = self._util_cmp_ref_name.get().strip() or "Ligand"
        ref_smiles = self._util_cmp_ref_smiles.get().strip() or "SMILES"

        def work() -> Any:
            from pharmaml.chem import annotate_with_smiles
            from pharmaml.utils.io import read_table

            frame = read_table(a_path)
            return annotate_with_smiles(
                frame,
                b_path,
                name_columns,
                reference_name_column=ref_name,
                reference_smiles_column=ref_smiles,
            )

        def render(frame: Any) -> None:
            self._util_frames["compare"] = frame
            self._util_cmp_last = None  # annotate mode has no comparison
            self._fill_dynamic_tree(self._util_cmp_tree, frame)
            joined = sum(
                1
                for column in name_columns
                if column + "_SMILES" in frame.columns
                and frame[column + "_SMILES"].astype(str).str.len().any()
            )
            self._util_cmp_summary.configure(
                text=(
                    f"{len(frame):,} rows · {len(name_columns)} name "
                    f"column(s) annotated ({joined} found SMILES)"
                ),
                style="Field.TLabel",
            )

        self._start_job("annotating with SMILES", work, render)

    def _util_cmp_plot(self) -> None:
        """The last three-way reconciliation as a figure (100x-120).

        ``plot_table_comparison`` finally has its GUI surface: the
        common / only-A / only-B counts of the last ``compare_tables``
        run drawn as the toolkit's own overlap figure.
        """
        comparison = getattr(self, "_util_cmp_last", None)
        if comparison is None:
            messagebox.showinfo(
                "No comparison yet",
                "Run the compare mode first — the overlap figure needs "
                "the last three-way reconciliation.",
            )
            return
        if not self._require_pharmaml() or not self._require(
            "matplotlib", "the reconciliation figure"
        ):
            return
        a_name = self._util_cmp_a.name if self._util_cmp_a is not None else "A"
        b_name = self._util_cmp_b.name if self._util_cmp_b is not None else "B"

        def work() -> Any:
            from pharmaml.viz import plot_table_comparison

            return plot_table_comparison(
                comparison, labels=(a_name, b_name), title="Ligand-set reconciliation"
            )

        def render(figure: Any) -> None:
            self._render_figure(self._util_cmp_host, figure)
            self._util_cmp_plot_note.configure(
                text="reconciliation figure replaces the tree's width — Run refreshes the table"
            )

        self._start_job("reconciliation figure", work, render)

    # -- utilities: approved drugs -------------------------------------- #
    def _util_appr_pick_files(self) -> None:
        paths = filedialog.askopenfilenames(
            title="Pick the approval exports",
            filetypes=[("Approval exports", "*.tsv *.csv *.tab"), ("All files", "*.*")],
        )
        if not paths:
            return
        self._util_appr_files = [Path(p) for p in paths]
        shown = ", ".join(p.name for p in self._util_appr_files[:3])
        if len(self._util_appr_files) > 3:
            shown += f" … (+{len(self._util_appr_files) - 3})"
        self._util_appr_info.configure(text=shown)

    def _util_approved_run(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "approval filtering"):
            return
        if not self._util_appr_files:
            messagebox.showwarning("No files", "Pick the approval export files first.")
            return
        files = list(self._util_appr_files)
        drug_column = self._util_appr_drug.get().strip() or "drug"
        approval_column = self._util_appr_col.get().strip() or "regulatory approval"
        status = self._util_appr_status.get().strip() or "approved"

        def work() -> Any:
            from pharmaml.pharma import filter_approved_drugs

            return filter_approved_drugs(
                [str(p) for p in files],
                drug_column=drug_column,
                approval_column=approval_column,
                approval_status=status,
            )

        def render(names: Any) -> None:
            import pandas as pd

            frame = pd.DataFrame({"drug": list(names)})
            self._util_frames["approved"] = frame
            tree = self._util_appr_tree
            tree.delete(*tree.get_children())
            for name in list(names)[:500]:
                tree.insert("", "end", values=(_cell_text(name, limit=40),))
            if len(names) > 500:
                tree.insert(
                    "", "end", values=((f"… {len(names) - 500:,} more (total {len(names):,})"),)
                )
            self._util_appr_summary.configure(
                text=(f"{len(names)} approved drug name(s) (status '{status}')"),
                style="Field.TLabel",
            )

        self._start_job(f"filtering {len(files)} file(s)", work, render)

    def _util_approved_save_csv(self) -> None:
        self._save_frame_dialog(
            self._util_frames.get("approved"), "Save the approved-drug names", "approved_drugs.csv"
        )

    def _util_approved_save_docx(self) -> None:
        frame = self._util_frames.get("approved")
        if frame is None:
            messagebox.showinfo("Nothing to save", "Filter the approval files first.")
            return
        if not self._require_pharmaml():
            return
        import importlib.util

        try:
            has_docx = importlib.util.find_spec("docx") is not None
        except (ImportError, ValueError):  # pragma: no cover
            has_docx = False
        if not has_docx:
            messagebox.showwarning(
                "DOCX needs python-docx",
                "The Word export needs python-docx -- install it with:\n\n"
                "    pip install 'pharmaml[reports]'\n\n"
                "(the CSV export works without it).",
            )
            return
        path = filedialog.asksaveasfilename(
            title="Save the approved-drug report",
            defaultextension=".docx",
            initialfile="approved_drugs.docx",
            filetypes=[("Word document", "*.docx")],
        )
        if not path:
            return

        def work() -> Any:
            from pharmaml.viz import export_docx

            return export_docx(frame, path)

        def render(written: Any) -> None:
            messagebox.showinfo("Saved", f"Word report written to\n{written}")

        self._start_job("writing the DOCX report", work, render)

    # -- utilities: campaign file tools --------------------------------- #
    def _util_tool_mode_changed(self) -> None:
        mode = self._util_tool_mode.get()
        parts = []
        if self._util_tool_folder is not None:
            parts.append(f"folder: {self._util_tool_folder.name}")
        if self._util_tool_files and mode.startswith("distribute"):
            parts.append(
                f"{len(self._util_tool_files)} file(s): "
                + ", ".join(p.name for p in self._util_tool_files[:3])
            )
        if self._util_tool_out is not None and mode.startswith("collect"):
            parts.append(f"collect into: {self._util_tool_out.name}")
        self._util_tool_info.configure(
            text="\n".join(parts)
            or "pick a campaign folder (and files for distribute, an output folder for collect)"
        )

    def _util_tool_pick_folder(self) -> None:
        path = filedialog.askdirectory(title="Pick the campaign folder")
        if path:
            self._util_tool_folder = Path(path)
            self._util_tool_mode_changed()

    def _util_tool_pick_files(self) -> None:
        paths = filedialog.askopenfilenames(
            title="Pick the files to distribute",
            filetypes=[("All files", "*.*")],
        )
        if paths:
            self._util_tool_files = [Path(p) for p in paths]
            self._util_tool_mode_changed()

    def _util_tool_pick_out(self) -> None:
        path = filedialog.askdirectory(title="Pick the collect-output folder")
        if path:
            self._util_tool_out = Path(path)
            self._util_tool_mode_changed()

    def _util_tools_run(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "campaign tools"):
            return
        mode = self._util_tool_mode.get()
        folder = self._util_tool_folder
        if folder is None and not mode.startswith("distribute"):
            messagebox.showwarning("No folder", "Pick the campaign folder first.")
            return
        if folder is None and mode.startswith("distribute"):
            messagebox.showwarning(
                "No target folder", "Pick the campaign folder whose sub-folders receive the files."
            )
            return
        dry_run = bool(self._util_tool_dry_var.get())
        filename = self._util_tool_filename.get().strip() or None
        pattern = self._util_tool_pattern.get().strip() or None
        extension = self._util_tool_ext.get().strip() or ".csv"

        if mode.startswith("collect"):
            if not filename and not pattern:
                messagebox.showwarning(
                    "Nothing to match", "Give a filename and/or a pattern to collect."
                )
                return
            out_dir = self._util_tool_out or (folder / "collected")

            def work() -> Any:
                from pharmaml.docking import collect_files

                return collect_files(
                    folder, filename=filename, pattern=pattern, out_dir=out_dir, dry_run=dry_run
                )

            def render(frame: Any) -> None:
                self._util_frames["tools"] = frame
                self._fill_dynamic_tree(
                    self._util_tool_tree, frame, widths={"source": 200, "destination": 200}
                )
                copied = int(frame["copied"].sum()) if "copied" in frame else 0
                verb = "would copy" if dry_run else "copied"
                self._util_tool_summary.configure(
                    text=(
                        f"{len(frame)} match(es) · {verb} {copied} "
                        f"into {out_dir.name}" + ("" if dry_run else " (dry run off)")
                    ),
                    style="Field.TLabel",
                )

            self._start_job("collecting files", work, render)
            return

        if mode.startswith("list"):

            def work() -> Any:
                from pharmaml.docking import list_file_names

                return list_file_names(folder, extension=extension)

            def render(names: Any) -> None:
                import pandas as pd

                frame = pd.DataFrame({"name": list(names)})
                self._util_frames["tools"] = frame
                self._fill_dynamic_tree(self._util_tool_tree, frame, widths={"name": 220})
                self._util_tool_summary.configure(
                    text=f"{len(names)} {extension} name(s), sorted", style="Field.TLabel"
                )

            self._start_job(f"listing {extension} files", work, render)
            return

        if mode.startswith("distribute"):
            if not self._util_tool_files:
                messagebox.showwarning(
                    "No files", "Pick the files to distribute first (binaries, receptor, ...)."
                )
                return
            files = [str(p) for p in self._util_tool_files]
            if not dry_run and not messagebox.askyesno(
                "Distribute for real",
                f"Copy {len(files)} file(s) into EVERY immediate "
                f"sub-folder of\n{folder}?\n(existing copies are kept)",
            ):
                return

            def work() -> Any:
                from pharmaml.docking import distribute_files

                return distribute_files(files, folder, overwrite=False)

            def render(copied: Any) -> None:
                import pandas as pd

                frame = pd.DataFrame({"destination": [str(p) for p in copied]})
                self._util_frames["tools"] = frame
                self._fill_dynamic_tree(self._util_tool_tree, frame, widths={"destination": 260})
                self._util_tool_summary.configure(
                    text=f"placed {len(copied)} copy/copies across {folder.name}",
                    style="Field.TLabel",
                )

            self._start_job(f"distributing {len(files)} file(s)", work, render)
            return

        if mode.startswith("delete"):
            if not filename:
                messagebox.showwarning("Filename", "Name the stray file to delete.")
                return

            def work() -> Any:
                from pharmaml.docking import delete_named_files

                return delete_named_files(folder, filename, dry_run=dry_run)

            def render(count: Any) -> None:
                verb = "would delete" if dry_run else "deleted"
                self._util_frames.pop("tools", None)
                tree = self._util_tool_tree
                tree.delete(*tree.get_children())
                tree["columns"] = ("result",)
                tree.heading("result", text="result")
                tree.column("result", width=240, stretch=True)
                tree.insert("", "end", values=(f"{verb} {count} '{filename}' file(s)",))
                self._util_tool_summary.configure(
                    text=f"{verb} {count} file(s) under {folder.name}", style="Field.TLabel"
                )

            self._start_job(f"deleting '{filename}'", work, render)
            return

        if mode.startswith("cleanup"):
            keep = {
                token.strip() for token in self._util_tool_keep.get().split(",") if token.strip()
            }
            if not dry_run and not messagebox.askyesno(
                "Cleanup for real",
                f"Delete every file under\n{folder}\nthat is NOT one "
                f"of the keep names / pattern?\n(empty folders can "
                f"remain; this cannot be undone)",
            ):
                return

            def work() -> Any:
                from pharmaml.docking import cleanup_tree

                return cleanup_tree(folder, keep=keep, keep_pattern=pattern, dry_run=dry_run)

            def render(frame: Any) -> None:
                self._util_frames["tools"] = frame
                self._fill_dynamic_tree(self._util_tool_tree, frame)
                verb = "would delete" if dry_run else "deleted"
                self._util_tool_summary.configure(
                    text=f"{len(frame)} file(s) {verb}", style="Field.TLabel"
                )

            self._start_job("cleaning the tree", work, render)

    # -- utilities: reindex by number ----------------------------------- #
    def _util_reindex_pick(self) -> None:
        path = filedialog.askopenfilename(
            title="Pick the sparse results table",
            filetypes=[("Tables", "*.csv *.tsv *.xlsx"), ("All files", "*.*")],
        )
        if path:
            self._util_reindex_path = Path(path)
            self._util_reindex_info.configure(text=path)

    def _util_reindex_run(self) -> None:
        if not self._require_pharmaml() or not self._require("pandas", "reindex"):
            return
        if self._util_reindex_path is None:
            messagebox.showwarning("No table", "Pick the CSV first.")
            return
        column = self._util_reindex_column.get().strip()
        if not column:
            messagebox.showwarning("Column", "Name the number column.")
            return
        try:
            start = parse_int(self._util_reindex_start.get(), "start", minimum=0)
            stop = parse_int(self._util_reindex_stop.get(), "stop", minimum=0)
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return
        if stop < start:
            messagebox.showerror("Input", "stop must be >= start")
            return
        pattern = self._util_reindex_pattern.get().strip() or r"(\d+)"
        path = self._util_reindex_path

        def work() -> Any:
            from pharmaml.docking import reindex_by_number
            from pharmaml.utils.io import read_table

            frame = read_table(path)
            return reindex_by_number(frame, column, start=start, stop=stop, pattern=pattern)

        def render(frame: Any) -> None:
            self._util_frames["reindex"] = frame
            self._fill_dynamic_tree(self._util_reindex_tree, frame)
            missing = int(frame.iloc[:, 0].isna().sum()) if len(frame.columns) else 0
            self._util_reindex_summary.configure(
                text=(f"dense {start}…{stop} · {len(frame)} rows · {missing} gap row(s)"),
                style="Field.TLabel",
            )

        self._start_job(f"reindexing {path.name}", work, render)

    def _util_reindex_save(self) -> None:
        self._save_frame_dialog(
            self._util_frames.get("reindex"), "Save the dense table", "reindexed.csv"
        )


def _frame_from_records(columns: tuple[str, ...], records: list[tuple[Any, ...]]) -> Any:
    """Build a small DataFrame from records (lazy pandas import)."""
    import pandas as pd

    return pd.DataFrame(records, columns=list(columns))


def _format_operator_stats(metadata: dict[str, Any]) -> str:
    """Render ``metadata['operator_stats']`` as a compact text table."""
    stats = metadata.get("operator_stats") or {}
    lines: list[str] = []
    for level in ("level1", "geometry", "mutation"):
        operators = stats.get(level)
        if not operators:
            continue
        lines.append(f"[{level}]")
        for name, info in operators.items():
            draws = info.get("draws", 0)
            successes = info.get("successes", 0)
            probability = info.get("final_probability", 0.0)
            lines.append(
                f"  {name:<18} draws {draws:>4}   successes {successes:>4}   p {probability:.3f}"
            )
    if not lines:
        return "operator statistics appear here on adaptive runs"
    lines.insert(0, "operator statistics (adaptive run)")
    return "\n".join(lines)


def _format_rl_history(result: Any) -> str:
    """Render an RL run's ``history`` first→last as a compact learning table.

    The 100x-66 introspection made the drift measurable; this is its GUI
    twin -- the numbers the figure plots, in text form.
    """
    history = list(getattr(result, "history", []) or [])
    if not history:
        return "RL history appears here after a run"
    first, last = history[0], history[-1]

    def _fmt(key: str) -> str:
        a, b = first.get(key), last.get(key)
        if a is None or b is None:
            return f"  {key:<16} (missing)"
        return f"  {key:<16} {a:>9.3f} → {b:>9.3f}"

    lines = ["RL run — history (first → last iteration)"]
    lines.append(_fmt("best_score"))
    lines.append(_fmt("mean_score"))
    lines.append(_fmt("valid_fraction"))
    # the prior-drift diagnostics (the anchor penalty's own quantities)
    drift_a, drift_b = first.get("drift"), last.get("drift")
    if drift_a is not None and drift_b is not None:
        lines.append(
            f"  {'drift':<16} {drift_a:>9.3f} → {drift_b:>9.3f}   "
            "(the squared agent-vs-prior gap the anchor penalises; "
            "iteration 0 is exactly 0.0)"
        )
    lines.append(_fmt("entropy"))
    lines.append(_fmt("agent_logprob"))
    lines.append(_fmt("prior_logprob"))
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# command line entry points
# --------------------------------------------------------------------------- #
def print_banner(app: PlaygroundApp) -> None:
    """Explain the launch state on stdout (the VSCode terminal)."""
    print("=" * 66)
    print(f"  PharmaML Playground {__version__} — window is open")
    print("=" * 66)
    if app.pharmaml is not None:
        print(f"  pharmaml {app.pharmaml.__version__} loaded")
    else:
        print("  pharmaml NOT loaded:", app.pharmaml_error)
        print("  fix:", _PHARMAML_HINT.replace("\n", " "))
    missing = [label for module, label, _purpose, _pip in _DEPENDENCIES if not app.deps.get(module)]
    if missing:
        print(f"  optional dependencies missing: {', '.join(missing)}")
        print("  (the tabs that need them explain their pip line when you use them)")
    else:
        print("  all optional dependencies installed — every tab fully armed")
    print("  close the window or press Ctrl+Q to exit.")
    print("=" * 66)


def self_test() -> int:
    """Build the whole UI, pump the event loop, visit every tab, exit.

    Runs headlessly under ``xvfb-run``; used by CI-style checks::

        xvfb-run -a python playground.py --self-test

    The build is fully deterministic: ``persist_session=False`` keeps
    the run from reading -- and, worse, re-writing -- the developer's
    real ``~/.pharmaml/playground-session.json``.  Since 100x-106 the
    self-test also exercises the manual-hyperparameter card end to end
    (dataset load → model pick → panel build → typed parse → JSON
    persistence) and the progress plumbing (report → poll → determinate
    bar + ETA label), asserting loudly instead of trusting the build.
    """
    app = PlaygroundApp(persist_session=False)
    for _ in range(4):
        app.update_idletasks()
        app.update()
    for index in range(app._book.index("end")):
        app._book.select(index)
        app.update()
    app.update()

    # -- manual hyperparameters (100x-106) ---------------------------- #
    app._ml_load_example()  # qsar_regression.csv
    assert app._model_combo.get() == "auto", "a fresh load resets the model"
    app._model_combo.set("ridge")
    app._ml_refresh_hyperparam_panel()
    entries = getattr(app, "_ml_param_entries", {})
    assert list(entries) == ["alpha"], f"ridge's grid knobs: {list(entries)}"
    assert entries["alpha"].get().strip() == "", "blank field = estimator default"
    entries["alpha"].delete(0, "end")
    entries["alpha"].insert(0, "0.5")
    app._ml_sync_params_var()
    assert json.loads(app._ml_params_var.get()) == {"ridge": {"alpha": "0.5"}}, (
        "per-model JSON persistence"
    )
    parsed = app._ml_manual_params("ridge", "regression")
    assert parsed == {"alpha": 0.5}, f"typed parse: {parsed!r}"
    entries["alpha"].delete(0, "end")
    entries["alpha"].insert(0, "not-a-number")
    try:
        app._ml_manual_params("ridge", "regression")
        raise AssertionError("a bad float must raise with the field named")
    except ValueError as exc:
        assert "alpha" in str(exc)
    entries["alpha"].delete(0, "end")
    entries["alpha"].insert(0, "0.5")  # leave a pinned value
    app._ml_params_reset()
    assert app._ml_params_var.get() == "{}", "reset clears the JSON"
    assert app._ml_manual_params("ridge", "regression") is None

    # -- progress + ETA plumbing (100x-106) --------------------------- #
    assert _fmt_duration(0) == "0 s" and _fmt_duration(42.4) == "42 s"
    assert _fmt_duration(192) == "3 min 12 s" and _fmt_duration(3720) == "1 h 02 min"
    assert _fmt_duration(-5) == "0 s", "negative ETAs clamp to zero"
    assert parse_typed_value("true", False) is True
    assert parse_typed_value("0", True) is False
    assert parse_typed_value("7", None) == 7 and parse_typed_value("none", None) is None
    assert parse_typed_value("0.25", 1.0) == 0.25 and parse_typed_value("l1", "l2") == "l1"
    assert parse_typed_value("(128, 64)", (100,)) == (128, 64)
    assert _accepts_progress_argument(lambda report: None) is True
    assert _accepts_progress_argument(lambda: None) is False
    app._busy = True
    app._job_label_base = "probe"
    app._job_started = time.monotonic() - 4.0  # 4 s "elapsed"
    app._report_progress(3, 10, "best 0.71")
    app._poll_progress()
    assert str(app._progress.cget("mode")) == "determinate"
    assert int(app._progress["value"]) == 3 and int(app._progress.cget("maximum")) == 10
    label = app._job_label.cget("text")
    assert label.startswith("probe — 3/10 · ~") and label.endswith("left · best 0.71"), (
        f"progress label: {label!r}"
    )
    app._report_progress(2, None, "")  # total-less degradation
    app._poll_progress()
    assert app._job_label.cget("text") == "probe — 2"
    app._busy = False
    app._report_progress(9, 10, "straggler")  # dropped when idle
    app._poll_progress()
    assert app._job_label.cget("text") == "probe — 2"

    app.destroy()
    print(
        "self-test: UI built, every tab visited, manual hyperparameters "
        "+ progress/ETA verified, no errors"
    )
    return 0


def main(argv: list[str] | None = None) -> int:
    """Parse the command line and start the playground (or its helpers)."""
    parser = argparse.ArgumentParser(
        prog="playground.py",
        description="PharmaML Playground — the pharmaml toolkit behind one window.",
    )
    parser.add_argument(
        "--self-test",
        action="store_true",
        help="build the UI, pump the event loop and exit (headless check)",
    )
    parser.add_argument(
        "--probe",
        action="store_true",
        help="print a dependency report and exit",
    )
    parser.add_argument("--version", action="store_true", help="print versions and exit")
    args = parser.parse_args(argv)

    if args.version:
        print(f"playground {__version__}")
        try:
            module = load_pharmaml()
            print(f"pharmaml {module.__version__}")
        except Exception as exc:  # noqa: BLE001
            print(f"pharmaml unavailable ({exc})")
        print(f"toolkit v{__version__}")
        return 0

    if args.probe:
        deps = probe_dependencies()
        print(f"playground {__version__} · python {sys.version.split()[0]}")
        print(f"toolkit root: {TOOLKIT_ROOT}")
        for module, label, purpose, pip in _DEPENDENCIES:
            state = "ok" if deps.get(module) else f"MISSING (pip install {pip})"
            print(f"  {label:<14} {state:<34} {purpose}")
        print(f"  {'tkinter':<14} {'ok' if tk is not None else 'MISSING'}")
        try:
            module = load_pharmaml()
            print(f"  pharmaml      ok ({module.__version__})")
        except Exception as exc:  # noqa: BLE001
            print(f"  pharmaml      FAILED — {exc}")
            return 1
        return 0

    if tk is None:
        print(
            "tkinter is not available in this Python build.\n"
            "Install the python3-tk system package (Debian/Ubuntu) or use an\n"
            "official python.org build, then run playground.py again.",
            file=sys.stderr,
        )
        return 2

    if args.self_test:
        return self_test()

    app = PlaygroundApp()
    print_banner(app)
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
